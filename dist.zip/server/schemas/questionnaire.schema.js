'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var QuestionnaireSchema = new _mongoose.Schema({
  appointment: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Appointment',
    index: true
  },
  questions: {
    type: Array,
    default: []
  },
  created_at: Date,
  rmp_rating: {
    type: Number,
    default: 0
  }
});

QuestionnaireSchema.set('autoIndex', true).set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = QuestionnaireSchema;
//# sourceMappingURL=questionnaire.schema.js.map
