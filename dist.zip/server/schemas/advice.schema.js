'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var AdviceSchema = new _mongoose.Schema({
  conceptId: String,
  primaryTerm: {
    type: String,
    unique: true,
    index: true,
    required: true
  },
  speciality: String,
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  isPrimary: {
    type: Boolean
  },
  isIgnored: {
    type: Boolean,
    default: false
  }
});

AdviceSchema.set('autoIndex', true).set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = AdviceSchema;
//# sourceMappingURL=advice.schema.js.map
