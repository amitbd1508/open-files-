'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var DrugSchema = new _mongoose.Schema({
  brand_id: Number,
  generic_id: {
    type: Number,
    default: 0
  },
  company_id: {
    type: Number,
    default: 0
  },
  trade_name: {
    type: String,
    index: true
  },
  formulation: String,
  strength: String,
  price: String,
  packSize: String,
  source: {
    type: String,
    enum: ['dims', 'projotno'],
    default: 'projotno'
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  isIgnore: {
    type: Boolean,
    default: false
  },
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

DrugSchema.set('minimize', true).set('autoIndex', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = DrugSchema;
//# sourceMappingURL=drug.schema.js.map
