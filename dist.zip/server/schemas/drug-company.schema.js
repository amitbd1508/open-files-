'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var DrugCompanySchema = new _mongoose.Schema({
  company_name: String,
  company_id: Number
});

DrugCompanySchema.set('minimize', true).set('autoIndex', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = DrugCompanySchema;
//# sourceMappingURL=drug-company.schema.js.map
