'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var PrescriptionNoteSchema = new _mongoose.Schema({
  prescriptionId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Prescription',
    index: true,
    required: '{PATH} is required!'
  },
  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true,
    required: '{PATH} is required!'
  },
  text: {
    type: String
  },
  isDone: {
    type: Boolean,
    default: false
  }
});

PrescriptionNoteSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = PrescriptionNoteSchema;
//# sourceMappingURL=prescription-note.schema.js.map
