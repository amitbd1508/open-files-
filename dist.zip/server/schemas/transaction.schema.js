'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var TransactionSchema = new _mongoose.Schema({
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true
  },
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Appointment',
    index: true
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    index: true
  },
  prescription_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Prescription',
    index: true
  },
  v2_id: {
    type: String
  },
  total: Number,
  rmp_share: Number
});

TransactionSchema.set('autoIndex', true).set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = TransactionSchema;
//# sourceMappingURL=transaction.schema.js.map
