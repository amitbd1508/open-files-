'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

/**
 * Schemas
 */
var AreaSchema = new _mongoose.Schema({
  // area longitude will be saved from google map function its to do
  longitude: Number,
  // area latitude will be saved from google map function its to do
  latitude: Number,
  // this entry now only come from when user create.
  village: {
    type: String,
    lowercase: true,
    trim: true
  },
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

AreaSchema.set('autoIndex', true).set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = AreaSchema;
//# sourceMappingURL=area.schema.js.map
