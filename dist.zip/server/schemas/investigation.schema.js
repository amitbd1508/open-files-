'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var InvestigationSchema = new _mongoose.Schema({
  conceptId: String,
  primaryTerm: {
    type: String,
    unique: true,
    index: true
  },
  speciality: String,
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isApproved: {
    type: Boolean
  },
  isPrimary: {
    type: Boolean
  },
  isIgnored: {
    type: Boolean,
    default: false
  }
});

InvestigationSchema.set('autoIndex', true).set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = InvestigationSchema;
//# sourceMappingURL=investigation.schema.js.map
