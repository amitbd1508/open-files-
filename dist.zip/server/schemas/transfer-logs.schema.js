'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var TransferLogsSchema = new _mongoose.Schema({
  fromAppointmentId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Appointment',
    require: true
  },
  toAppointmentId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Appointment',
    require: true
  },
  toDoctorId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    require: true
  },
  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    require: true
  },
  responseType: {
    type: String,
    enum: ['timeOut', 'accepted', 'rejected']
  },
  respondedFor: {
    type: String
  },
  createdFor: {
    type: String
  },
  isActive: {
    type: Boolean,
    default: true,
    index: true
  },
  respondedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  respondedAt: {
    type: Date
  }
});

TransferLogsSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = TransferLogsSchema;
//# sourceMappingURL=transfer-logs.schema.js.map
