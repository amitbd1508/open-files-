'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var DrugsAvailbility = new _mongoose.Schema({
  rmpId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: '{PATH} is required!'
  },
  prescriptionId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Prescription',
    required: '{PATH} is required!'
  },
  drugId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Drugs',
    required: '{PATH} is required!'
  },
  patientId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    required: '{PATH} is required!'
  },
  doctorId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: '{PATH} is required!'
  },
  isAvailable: {
    type: Boolean,
    default: false,
    required: '{PATH} is required!'
  }
});

DrugsAvailbility.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = DrugsAvailbility;
//# sourceMappingURL=drugs-availability.schema.js.map
