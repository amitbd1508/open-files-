'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var PaymentSchema = new _mongoose.Schema({
  trxid: String,
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  amount: Number,
  counter: String,
  currency: String,
  receiver: String,
  reference: String,
  sender: String,
  service: String,
  trxTimestamp: String,
  trxStatus: String,
  reversed: String
});

PaymentSchema.set('autoIndex', true).set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = PaymentSchema;
//# sourceMappingURL=payment.schema.js.map
