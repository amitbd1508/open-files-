'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var FeedbackSchema = new _mongoose.Schema({
  appointmentId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Appointment'
  },
  type: {
    type: String,
    enum: ['logOut', 'appointment'],
    default: 'appointment'
  },
  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  isMarked: {
    type: Boolean,
    default: true
  },
  feedback: {
    type: String
  },
  note: {
    type: String
  },
  incident: {
    type: String
  },
  rate: {
    type: Number
  },
  rateText: {
    type: String
  }
});

FeedbackSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = FeedbackSchema;
//# sourceMappingURL=feedback.schema.js.map
