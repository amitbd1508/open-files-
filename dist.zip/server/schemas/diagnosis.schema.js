'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var DiagnosesSchema = new _mongoose.Schema({
  SNOMEDConceptId: String,
  primaryTerm: {
    type: String,
    index: true,
    required: '{PATH} is required!'
  },
  system: {
    type: Array,
    default: []
  },
  note: String,
  advice: {
    type: Array,
    default: []
  },
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: '{PATH} is required!'
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  isPrimary: {
    type: Boolean,
    default: true
  },
  isIgnore: {
    type: Boolean,
    default: false
  }
});

DiagnosesSchema.set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = DiagnosesSchema;
//# sourceMappingURL=diagnosis.schema.js.map
