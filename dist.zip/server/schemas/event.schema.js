'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var EventSchema = new _mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  subTitle: {
    type: String
  },
  description: {
    type: String
  },
  icon: {
    type: String
  },
  type: {
    type: String,
    enum: ['notification', 'announcement'],
    default: 'notification',
    required: true
  },
  isSeen: {
    type: Boolean,
    default: false
  },
  forUserGroup: {
    type: Array,
    default: ['doctor']
  },
  createdFor: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

EventSchema.set('minimize', true).set('autoIndex', true).set('timestamps', true);

exports.default = EventSchema;
//# sourceMappingURL=event.schema.js.map
