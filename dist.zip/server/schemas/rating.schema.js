'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var RatingSchema = new _mongoose.Schema({
  user_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  rmpId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  prescriptionId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Prescription'
  },
  //FIXME "Legacy code"
  rating1: {
    type: Number,
    default: 0
  },
  rating2: {
    type: Number,
    default: 0
  },
  rating3: {
    type: Number,
    default: 0
  },
  rating4: {
    type: Number,
    default: 0
  },
  rating5: {
    type: Number,
    default: 0
  }

});

RatingSchema.set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = RatingSchema;
//# sourceMappingURL=rating.schema.js.map
