'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var AppointmentSchema = new _mongoose.Schema({
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Patient'
  },
  is_booked: {
    type: Boolean,
    default: false,
    index: true
  },
  is_marked: {
    type: Boolean,
    default: false
  },
  is_prescribed: {
    type: Boolean,
    default: false
  },
  timestamp: {
    book_by_rmp: Date
  },
  start: {
    type: Date,
    index: true
  },
  end: Date,
  transfer: {
    transferBy: {
      type: _mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    transferAt: Date
  },
  patients_images: {
    type: Array,
    default: [],
    set: function set(value) {
      return value || [];
    }
  },
  patient_weight: Number,
  patient_temp: {
    type: Number,
    set: function set(temp) {
      return temp < 70 && temp ? temp * 1.8 + 32 : temp;
    }
  },
  patient_pulse: Number,
  symptoms: {
    type: Array,
    default: []
  },
  time_took: {
    type: Number
  },
  patient_systole: Number,
  patient_diastole: Number,

  patient_diabetic: String,
  patient_glucose: Number,

  source: String,

  cancel: {
    accountable: {
      type: _mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    at: Date,
    reason: String
  },
  schedule_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Schedule'
  }
});

AppointmentSchema.set('autoIndex', true).set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = AppointmentSchema;
//# sourceMappingURL=appointment.schema.js.map
