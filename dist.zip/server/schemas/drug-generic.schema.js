'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var DrugGenericSchema = new _mongoose.Schema({
  generic_id: {
    type: Number,
    index: true
  },
  generic_name: {
    type: String,
    index: true
  },
  precaution: String,
  indication: String,
  contra_indication: String,
  dose: String,
  side_effect: String,
  pregnancy_category_id: Number,
  mode_of_action: String,
  isNewlyAdded: {
    type: Boolean,
    default: true
  },
  interaction: String
});

DrugGenericSchema.set('minimize', true).set('autoIndex', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = DrugGenericSchema;
//# sourceMappingURL=drug-generic.schema.js.map
