'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var ScoreSchema = new _mongoose.Schema({
  parentType: String,
  parentId: String,
  objectType: String,
  objectReference: String,
  rating: Number,
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

ScoreSchema.set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = ScoreSchema;
//# sourceMappingURL=score.schema.js.map
