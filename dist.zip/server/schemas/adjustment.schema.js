'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var AdjustmentSchema = new _mongoose.Schema({
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true,
    required: true
  },
  total: Number,
  owner_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  amount: {
    type: Number,
    required: true
  },
  reason: String
});

AdjustmentSchema.set('autoIndex', true).set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = AdjustmentSchema;
//# sourceMappingURL=adjustment.schema.js.map
