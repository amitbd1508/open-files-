'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var SituationSchema = new _mongoose.Schema({
  SNOMEDConceptId: String,
  primaryTerm: String,
  system: String,
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  isApproved: {
    type: Boolean
  },
  isPrimary: {
    type: Boolean
  },
  isIgnored: {
    type: Boolean,
    default: false
  }
});

SituationSchema.set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = SituationSchema;
//# sourceMappingURL=situation.schema.js.map
