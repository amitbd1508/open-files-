'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var RedFlagSchema = new _mongoose.Schema({
  prescriptionId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Prescription',
    require: true
  },
  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    require: true
  },
  doctorId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    require: true
  },
  flag: {
    type: String
  }
});

RedFlagSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = RedFlagSchema;
//# sourceMappingURL=red-flag.schema.js.map
