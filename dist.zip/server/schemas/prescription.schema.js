'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var PrescriptionSchema = new _mongoose.Schema({
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Appointment',
    unique: true,
    index: true
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    index: true
  },
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true
  },
  chief_complaint: {
    type: Array,
    default: []
  },
  symptoms: {
    type: Array,
    default: []
  },
  rmpfinding: {
    type: Array,
    default: []
  },
  is_followup: {
    type: Boolean,
    default: false
  },
  followup_date: {
    type: Date
  },
  is_referred: {
    type: Boolean,
    default: false
  },
  is_free: {
    type: Boolean,
    default: false
  },
  isRMPFamily: {
    type: Boolean,
    default: false
  },
  isJeeonEmployee: {
    type: Boolean,
    default: false
  },
  isReactionPatient: {
    type: Boolean,
    default: false
  },
  diagnosis: {
    type: Array,
    default: []
  },
  encodedSymptoms: {
    type: Array,
    default: []
  },
  diagnoses: {
    provisional: {
      type: Array,
      default: []
    },
    differential: {
      type: Array,
      default: []
    },
    final: {
      type: Array,
      default: []
    }
  },
  investigations: {
    type: Array,
    default: []
  },
  note: String,
  referredNote: String,
  advices: {
    type: Array,
    default: []
  },
  personalinfo: {
    type: Array,
    default: []
  },
  familyinfo: {
    type: Array,
    default: []
  },
  druginfo: {
    type: Array,
    default: []
  },
  chronicinfo: {
    type: Array,
    default: []
  },
  allergy: {
    type: Array,
    default: []
  },
  instruction: {
    type: Array,
    default: []
  },
  fee: {
    type: Number,
    default: 0
  },
  payment_selected: String,
  publishAt: {
    type: Date,
    index: true
  },
  pdflink: String,
  v2_prescription: _mongoose.Schema.Types.Mixed,
  v2_advice: String,
  v2_complain: String,
  v2_followupstatus: {
    type: Boolean
  },
  v2_id: String,
  rmp_seen: {
    type: Boolean,
    default: false,
    index: true
  },
  is_pdfready: {
    type: Boolean,
    default: false,
    index: true
  },
  increment_index: {
    type: Number
  },
  time_took: {
    type: Number,
    default: 0
  },
  opened: {
    type: Date,
    default: Date.now
  },
  isPayed: {
    type: Boolean,
    default: false,
    index: true
  },
  timestamp: {
    rmp_seen_time: {
      type: Date
    }
  },
  encoded_symptoms: {
    type: Array,
    default: []
  }
});

PrescriptionSchema.set('autoIndex', true).set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = PrescriptionSchema;
//# sourceMappingURL=prescription.schema.js.map
