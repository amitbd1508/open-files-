'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var PatientSchema = new _mongoose.Schema({
  fullname: {
    type: String,
    default: ''
  },
  serialnumber: {
    type: String,
    index: true,
    unique: true,
    required: '{PATH} is required!'
  },
  gender: {
    type: String,
    default: 'male'
  },
  profilepiclink: {
    type: String,
    default: ''
  },
  phone: {
    type: String
  },
  active: {
    type: Boolean,
    default: false
  },
  isFake: {
    type: Boolean,
    default: false
  },
  isDistributed: {
    type: Boolean,
    default: false
  },
  village: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Area'
  },
  dob: {
    type: Date
  },
  reference: String,
  registered_at: {
    type: Date
  },
  registeredBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  distributedTo: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

PatientSchema.set('autoIndex', true).set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

// Validate serialNumber
PatientSchema.path('serialnumber').validate(function (value) {
  var _this = this;

  return this.constructor.findOne({ serialnumber: value }).exec().then(function (patient) {
    return patient ? _this.id === patient.id : true;
  }).catch(function (err) {
    throw err;
  });
}, 'The specified serial number is already Exist');

exports.default = PatientSchema;
//# sourceMappingURL=patient.schema.js.map
