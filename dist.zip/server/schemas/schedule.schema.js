'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var _environment = require('../config/environment');

var _environment2 = _interopRequireDefault(_environment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var HOURS = _environment2.default.scheduleHours;
var DAYS = _environment2.default.scheduleDays;
var DURATIONS = _environment2.default.scheduleDurations;

/**
 * Generate Schedule Schema Type
 *
 * @returns {{}}
 */
function generateScheduleType() {
  var scheduleType = {};

  HOURS.forEach(function (hour) {
    scheduleType[hour] = {};
    DAYS.forEach(function (day) {
      scheduleType[hour][day] = [{
        type: _mongoose.Schema.Types.ObjectId,
        ref: 'User'
      }];
    });
  });

  return scheduleType;
}

/**
 * Generate Schedule Schema Default
 *
 * @returns {{}}
 */
function generateScheduleDefault() {
  var scheduleDefault = {};

  HOURS.forEach(function (hour) {
    scheduleDefault[hour] = {};
    DAYS.forEach(function (day) {
      scheduleDefault[hour][day] = [];
    });
  });

  return scheduleDefault;
}

var ScheduleSchema = new _mongoose.Schema({
  created_by: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  duration: {
    type: Number,
    enum: DURATIONS,
    default: DURATIONS[0]
  },
  schedule: {
    type: generateScheduleType(),
    default: generateScheduleDefault()
  }
});

ScheduleSchema.set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = ScheduleSchema;
//# sourceMappingURL=schedule.schema.js.map
