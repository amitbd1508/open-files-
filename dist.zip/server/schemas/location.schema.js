'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var LocationSchema = new _mongoose.Schema({
  location: {
    type: {
      type: String,
      default: 'point'
    },
    coordinates: [Number]
  },
  speed: Number,
  accuracy: Number,
  altitude: Number,
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
});

LocationSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = LocationSchema;
//# sourceMappingURL=location.schema.js.map
