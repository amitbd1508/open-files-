'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _mongoose = require('mongoose');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../config/environment');

var CashoutRequestSchema = new _mongoose.Schema({
  requestedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'E_Learning_User',
    required: 'User is required!',
    index: true
  },
  requestedAt: {
    type: Date,
    default: Date.now
  },
  isResponded: {
    type: Boolean,
    default: false
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  phone: {
    type: String,
    required: 'Phone is required'
  },
  type: {
    type: String,
    enum: (0, _keys2.default)(environment.CASHOUT_TYPE)
  },
  note: {
    type: String
  },
  amount: {
    type: Number,
    required: 'Price amount is required!'
  }
});

CashoutRequestSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = CashoutRequestSchema;
//# sourceMappingURL=cashout-request.schema.js.map
