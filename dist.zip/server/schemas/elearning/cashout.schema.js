'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var CashoutSchema = new _mongoose.Schema({
  requestId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'CashoutRequest',
    required: 'Request id is required!',
    index: true
  },
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'E_Learning_User',
    required: 'user is required!',
    index: true
  },
  updatedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: 'User is required!'
  },
  isActive: {
    type: Boolean,
    default: true
  },
  note: {
    type: String
  }
});

CashoutSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = CashoutSchema;
//# sourceMappingURL=cashout.schema.js.map
