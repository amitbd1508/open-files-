'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var TransactionSchema = new _mongoose.Schema({
  prescriptionCollectId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'PrescriptionCollect',
    index: true
  },
  patientReferralId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'PatientReferral',
    index: true
  },
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'E_Learning_User',
    required: 'user is required!',
    index: true
  },
  updatedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'E_Learning_User',
    required: 'user is required!'
  },
  priceId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Price',
    required: 'Price is required!'
  },
  isActive: {
    type: Boolean,
    default: true,
    index: true
  }
});

TransactionSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = TransactionSchema;
//# sourceMappingURL=transaction.schema.js.map
