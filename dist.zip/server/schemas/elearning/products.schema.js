'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var ProductsSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,

  description: String,
  description_bn: String,

  imageURL: String,
  bannerURL: String,

  embedUrl: {
    type: String,
    default: ""
  },
  publishedAt: {
    type: Date,
    default: Date.now
  },
  isScrollingDisabledForEmbedUrl: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true,
    index: true
  },

  companyIds: [{
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Company',
    default: []
  }],

  order: {
    type: Number,
    default: 0
  }
});

ProductsSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = ProductsSchema;
//# sourceMappingURL=products.schema.js.map
