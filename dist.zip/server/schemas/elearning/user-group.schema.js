'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var UserGroupSchema = new _mongoose.Schema({
  name: {
    type: String,
    required: 'Group name is required!'
  },

  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: 'User is required!'
  },
  service: {
    type: String
  },
  isActive: {
    type: Boolean,
    default: true
  }
});

UserGroupSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = UserGroupSchema;
//# sourceMappingURL=user-group.schema.js.map
