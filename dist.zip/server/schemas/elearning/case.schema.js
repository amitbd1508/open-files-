'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var CaseSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,

  description: String,
  description_bn: String,

  embedUrl: String,

  imageUrl: String,
  bannerUrl: String,

  publishDate: {
    type: Date,
    default: Date.now()
  },
  unpublishDate: {
    type: Date,
    default: Date.now()
  },

  active: {
    type: Boolean,
    default: true
  },
  isInBanner: {
    type: Boolean,
    default: false
  },
  order: {
    type: Number
  },
  rugies: [{
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Rugi',
    index: true
  }]
});

CaseSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = CaseSchema;
//# sourceMappingURL=case.schema.js.map
