'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var PrescriptionCollectSchema = new _mongoose.Schema({
  imageURL: String,
  isApproved: {
    type: Boolean,
    default: false
  },
  priceId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Price',
    required: 'Price is required!'
  },
  submittedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'E_Learning_User',
    required: 'User is required!',
    index: true
  },
  respondedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  respondedAt: {
    type: Date
  },
  submittedAt: {
    type: Date,
    default: Date.now
  }
});

PrescriptionCollectSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = PrescriptionCollectSchema;
//# sourceMappingURL=prescription-collect.schema.js.map
