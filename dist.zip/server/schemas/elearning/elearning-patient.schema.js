'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var ElearningPatientSchema = new _mongoose.Schema({
  name: {
    type: String,
    required: true,
    min: 3,
    max: 100
  },
  gender: {
    type: String,
    required: true
  },
  imageURL: {
    type: String,
    default: ''
  },
  phone: {
    type: String
  },
  weight: {
    type: String
  },
  type: {
    type: String,
    enum: ['cleft', 'cataract', 'MR', 'fistula']
  },
  dob: {
    type: Date
  },
  address: {
    type: String
  }
});

ElearningPatientSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = ElearningPatientSchema;
//# sourceMappingURL=elearning-patient.schema.js.map
