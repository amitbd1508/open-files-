'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var CloudNotificationSchema = new _mongoose.Schema({
  to: String,
  condition: String,
  ttl: String,
  priority: String,
  restricted_package_name: String,
  notification: {
    title: String,
    body: String,
    click_action: String,
    sound: String
  },
  data: {
    title: String,
    body: String,
    deep_link: String
  },
  response: {
    type: _mongoose.Schema.Types.Mixed
  }
});

CloudNotificationSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = CloudNotificationSchema;
//# sourceMappingURL=cloud-notification.schema.js.map
