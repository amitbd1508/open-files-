'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var PatientReferralSchema = new _mongoose.Schema({
  isApproved: {
    type: Boolean,
    default: false,
    index: true
  },
  priceId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Price',
    required: 'Price is required!',
    index: true
  },
  patientId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'ElearningPatient',
    required: 'ElearningPatient is required!',
    index: true
  },
  submittedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'E_Learning_User',
    required: 'User is required!',
    index: true
  },
  respondedBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true
  },
  respondedAt: {
    type: Date
  },
  submittedAt: {
    type: Date,
    default: Date.now
  }
});

PatientReferralSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = PatientReferralSchema;
//# sourceMappingURL=patient-referral.schema.js.map
