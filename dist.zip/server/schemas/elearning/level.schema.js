'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var LevelSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,

  description: String,
  description_bn: String,

  imageUrl: String,
  bannerUrl: String,

  embedUrl: {
    type: String,
    default: ""
  },
  embedUrlContent: {
    type: String,
    default: ""
  },
  embedUrlFeedback: {
    type: String,
    default: ""
  },
  publishDate: {
    type: Date,
    default: Date.now()
  },
  isScrollingDisabledForEmbedUrl: {
    type: Boolean,
    default: false
  },
  isInBanner: {
    type: Boolean,
    default: false
  },
  isScrollingDisabledForEmbedUrlContent: {
    type: Boolean,
    default: false
  },
  isScrollingDisabledForEmbedUrlFeedback: {
    type: Boolean,
    default: false
  },
  points: {
    type: Number,
    default: 0
  },
  passingScore: {
    type: Number,
    default: 0
  },
  active: {
    type: Boolean,
    default: true,
    index: true
  },
  order: {
    type: Number
  }
});

LevelSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = LevelSchema;
//# sourceMappingURL=level.schema.js.map
