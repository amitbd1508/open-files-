'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var PriceSchema = new _mongoose.Schema({
  amount: {
    type: Number,
    required: 'price amount is required!'
  },

  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: 'User is required!'
  },

  category: {
    type: String,
    required: 'Service category is required!'
  },

  isDefault: {
    type: Boolean,
    default: false,
    required: '{PATH} is required!'
  }
});

PriceSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = PriceSchema;
//# sourceMappingURL=price.schema.js.map
