'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var ChapterSchema = new _mongoose.Schema({
  title: {
    type: String,
    required: 'title is required!'
  },
  title_bn: {
    type: String,
    required: 'Bengali title is required!'
  },

  description: String,
  description_bn: {
    type: String,
    required: 'Bengali Description is required!'
  },

  publishedAt: {
    type: Date,
    required: 'Publish Date is required!'
  },

  imageURL: {
    type: String,
    required: 'Image is required!'
  },
  bannerURL: {
    type: String
  },

  isActive: {
    type: Boolean,
    default: true
  },

  companies: [{
    companyId: {
      type: _mongoose.Schema.Types.ObjectId,
      ref: 'Company',
      index: true
    },
    order: {
      type: Number,
      default: 0
    }
  }]

});

ChapterSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = ChapterSchema;
//# sourceMappingURL=chapter.schema.js.map
