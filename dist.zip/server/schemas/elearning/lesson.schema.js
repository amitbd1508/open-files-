'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var LessonSchema = new _mongoose.Schema({
  title: {
    type: String,
    required: 'title is required!'
  },
  title_bn: {
    type: String,
    required: 'Bengali title is required!'
  },

  description: String,
  description_bn: {
    type: String,
    required: 'Bengali Description is required!'
  },

  order: {
    type: Number,
    required: 'Order is required!'
  },

  publishedAt: {
    type: Date,
    required: 'Publish Date is required!'
  },

  imageURL: {
    type: String,
    required: 'Image is required!'
  },
  bannerURL: {
    type: String
  },

  embedURL: {
    type: String
  },
  isScrollingDisabledForEmbedURL: {
    type: Boolean,
    default: false
  },

  isActive: {
    type: Boolean,
    default: true
  },

  chapterId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Chapter',
    index: true
  }
});

LessonSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = LessonSchema;
//# sourceMappingURL=lesson.schema.js.map
