'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var SecurityQuestionSchema = new _mongoose.Schema({
  question: String,
  question_bn: String,

  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },

  isActive: {
    type: Boolean,
    default: true
  }
});

SecurityQuestionSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = SecurityQuestionSchema;
//# sourceMappingURL=security-question.schema.js.map
