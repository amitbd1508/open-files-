'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

/**
 * Schemas
 */

var UserAddressSchema = new _mongoose.Schema({
  districtCode: {
    type: Number
  },
  subDistrictCode: {
    type: Number
  },
  unionCode: {
    type: Number
  }
});

var UserDetailsSchema = new _mongoose.Schema({
  occupation: {
    type: String
  },
  reference: {
    type: String
  }
});

var UserSchema = new _mongoose.Schema({
  name: {
    type: String,
    required: true,
    min: 3,
    max: 100,
    index: true
  },
  phone: {
    type: String,
    required: true,
    unique: true,
    index: true,
    min: 11,
    max: 14
  },
  photo: {
    type: String
  },
  age: {
    type: Number,
    index: true,
    min: 10,
    max: 100
  },
  yearOfJoining: {
    type: Number,
    index: true
  },
  designation: {
    type: String,
    index: true
  },
  uuid: {
    type: String
  },
  pin: {
    type: String
  },

  groupIds: [{
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'UserGroup',
    default: []
  }],

  address: {
    type: UserAddressSchema,
    required: true
  },
  details: UserDetailsSchema,

  isVisible: {
    type: Boolean,
    default: true
  },
  active: {
    type: Boolean,
    default: true,
    index: true
  },
  appVersion: {
    type: String,
    index: true
  },
  appToken: {
    type: String
  },
  fbkAccountId: {
    type: String
  },
  fbUserToken: {
    type: String
  }
});

UserSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = UserSchema;
//# sourceMappingURL=user.schema.js.map
