'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var LocationSchema = new _mongoose.Schema({
  speed: Number,
  accuracy: Number,
  altitude: Number,
  altitudeAccuracy: Number,
  heading: Number,

  userPhone: {
    type: String,
    required: true,
    index: true
  },

  location: {
    type: {
      type: String,
      default: 'point'
    },
    coordinates: [Number]
  }
});

LocationSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = LocationSchema;
//# sourceMappingURL=location.schema.js.map
