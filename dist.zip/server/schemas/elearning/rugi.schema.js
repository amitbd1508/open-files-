'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var RugiSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,
  description: String,
  description_bn: String,
  imageUrl: String,
  bannerUrl: String,
  difficultyLevel: {
    type: Number,
    default: 1
  },
  embedUrl: {
    type: String,
    default: ""
  },
  embedUrlContent: {
    type: String,
    default: ""
  },
  embedUrlFeedback: {
    type: String,
    default: ""
  },
  publishDate: {
    type: Date,
    default: Date.now()
  },
  isScrollingDisabledForEmbedUrl: {
    type: Boolean,
    default: false
  },
  isInBanner: {
    type: Boolean,
    default: false
  },
  isScrollingDisabledForEmbedUrlContent: {
    type: Boolean,
    default: false
  },
  isScrollingDisabledForEmbedUrlFeedback: {
    type: Boolean,
    default: false
  },
  points: {
    type: Number,
    default: 0
  },
  passingScore: {
    type: Number,
    default: 0
  },
  active: {
    type: Boolean,
    default: true
  },
  order: {
    type: Number
  }
});

RugiSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = RugiSchema;
//# sourceMappingURL=rugi.schema.js.map
