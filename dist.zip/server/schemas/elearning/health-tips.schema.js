'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var HealthTipsSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,
  description: String,
  description_bn: String,
  body: String,
  body_bn: String,

  imageUrl: String,
  bannerUrl: String,

  startDate: {
    type: Date,
    default: Date.now
  },
  endDate: {
    type: Date,
    default: Date.now
  }
});

HealthTipsSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = HealthTipsSchema;
//# sourceMappingURL=health-tips.schema.js.map
