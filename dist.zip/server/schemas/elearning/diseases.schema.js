'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var DiseaseSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,
  description: String,
  description_bn: String,
  imageUrl: String,
  bannerUrl: String,
  publishDate: {
    type: Date,
    default: Date.now()
  },
  active: {
    type: Boolean,
    default: true
  },
  isInBanner: {
    type: Boolean,
    default: false
  },
  isHighlighted: {
    type: Boolean,
    default: false
  },
  order: {
    type: Number
  },
  levels: [{
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Level'
  }]
});

DiseaseSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = DiseaseSchema;
//# sourceMappingURL=diseases.schema.js.map
