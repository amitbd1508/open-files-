'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var SystemSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,

  description: String,
  description_bn: String,

  imageUrl: String,
  bannerUrl: String,

  publishDate: {
    type: Date,
    default: Date.now()
  },
  active: {
    type: Boolean,
    default: true
  },
  isInBanner: {
    type: Boolean,
    default: false
  },
  order: {
    type: Number
  },
  diseases: [{
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Disease',
    index: true
  }],
  cases: [{
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Case',
    index: true
  }]
});

SystemSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = SystemSchema;
//# sourceMappingURL=system.schema.js.map
