'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var QuizSchema = new _mongoose.Schema({
  name: String,
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  embedUrl: {
    type: String,
    required: true
  },
  isScrollingDisabled: {
    type: Boolean,
    default: false
  },
  points: {
    type: Number,
    default: 0
  },
  passingScore: {
    type: Number,
    default: 0
  }
});

QuizSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = QuizSchema;
//# sourceMappingURL=quiz.schema.js.map
