'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var HomeSliderSchema = new _mongoose.Schema({
  title: String,
  title_bn: String,
  description: String,
  description_bn: String,
  bannerUrl: String,
  deepLink: String,
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },

  order: {
    type: Number,
    default: 0
  },
  levelId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Level'
  },
  diseaseId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Disease'
  },
  caseId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Case'
  },
  rugiId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Rugi'
  },
  healthTipId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'HealthTips'
  }
});

HomeSliderSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = HomeSliderSchema;
//# sourceMappingURL=home-slider.schema.js.map
