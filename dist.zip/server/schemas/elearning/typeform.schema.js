'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TypeformFormSchema = exports.TypeformResultSchema = exports.TypeformEventSchema = exports.TypeformResponseSchema = undefined;

var _mongoose = require('mongoose');

/**
 * Constants
 */

var QUESTION_TYPES = ['date', 'dropdown', 'email', 'file_upload', 'group', 'hidden', 'legal', 'long_text', 'multiple_choice', 'number', 'opinion_scale', 'payment', 'picture_choice', 'rating', 'short_text', 'statement', 'website', 'yes_no'];

var ANSWER_TYPES = ['text', 'choice', 'choices', 'email', 'url', 'file_url', 'boolean', 'number', 'date', 'payment'];

var QUESTION_ANSWER_MAP = {
  'date': ['date'],
  'dropdown': ['text'],
  'email': ['email'],
  'file_upload': ['file_url'],
  'group': [],
  'legal': ['boolean'],
  'long_text': ['text'],
  'multiple_choice': ['choice', 'choices'],
  'number': ['number'],
  'opinion_scale': ['number'],
  'payment': ['payment'],
  'picture_choice': ['choice', 'choices'],
  'rating': ['number'],
  'short_text': ['text'],
  'statement': [],
  'website': ['url'],
  'yes_no': ['boolean']
};

/**
 * Schemas
 */

var TypeformAnswerFieldSchema = new _mongoose.Schema({
  id: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: QUESTION_TYPES,
    required: true
  },
  ref: {
    type: String,
    required: false
  }
}).set('minimize', false);

/**
 * REMINDER: Do not use arrow functions in validators because "this" will not be bound.
 */
var TypeformAnswerSchema = new _mongoose.Schema({
  field: {
    type: TypeformAnswerFieldSchema,
    required: true
  },

  type: {
    type: String,
    enum: ANSWER_TYPES,
    required: true,
    validate: {
      validator: function validator(val) {
        return QUESTION_ANSWER_MAP[this.field.type].includes(val);
      }
    }
  },

  text: {
    type: String,
    required: function required() {
      return this.type === 'text';
    }
  },
  email: {
    type: String,
    required: function required() {
      return this.type === 'email';
    }
  },
  date: {
    type: String,
    required: function required() {
      return this.type === 'date';
    }
  },
  boolean: {
    type: Boolean,
    required: function required() {
      return this.type === 'boolean';
    }
  },
  number: {
    type: Number,
    required: function required() {
      return this.type === 'number';
    }
  },
  choice: {
    type: {
      label: {
        type: String,
        required: false // Does not exist if "other" option was chosen
      },
      other: {
        type: String,
        required: false // Does not exist if "other" option was not chosen
      }
    },
    required: function required() {
      return this.type === 'choice';
    }
  },
  choices: {
    type: {
      labels: {
        type: String,
        required: false // May or may not exist based on choices
      },
      other: {
        type: String,
        required: false // May or may not exist based on choices
      }
    },
    required: function required() {
      return this.type === 'choices';
    }
  },
  url: {
    type: String,
    required: function required() {
      return this.type === 'url';
    }
  },
  file_url: {
    type: String,
    required: function required() {
      return this.type === 'file_url';
    }
  },
  payment: {
    type: {
      amount: {
        type: String,
        required: true
      },
      last4: {
        type: String,
        required: true
      },
      name: {
        type: String,
        required: true
      },
      success: {
        type: Boolean,
        required: true
      }
    },
    required: function required() {
      return this.type === 'payment';
    }
  }
}).set('minimize', false);

var TypeformHiddenSchema = new _mongoose.Schema({
  user_phone: {
    type: String,
    required: false, // May not have been provided by earlier code
    index: true
  },
  user_name: {
    type: String,
    required: false, // May not have been provided by earlier code
    index: true
  },
  user_is_hidden: {
    type: Boolean,
    required: false, // May not have been provided by earlier code
    index: true
  },
  app_token: {
    type: String,
    required: false, // May not have been provided by earlier code
    index: true
  },
  app_version: {
    type: String,
    required: false, // May not have been provided by earlier code
    index: true
  }
}).set('minimize', false);

var TypeformCalculatedSchema = new _mongoose.Schema({
  score: {
    type: Number,
    required: true,
    default: 0,
    index: true
  }
}).set('minimize', false);

var TypeformMetadataSchema = new _mongoose.Schema({
  user_agent: {
    type: String,
    required: true
  },
  platform: {
    type: String,
    required: true
  },
  referer: {
    type: String,
    required: true
  },
  network_id: {
    type: String,
    required: true
  },
  browser: {
    type: String,
    required: true
  }
}).set('minimize', false);

var TypeformItemSchema = new _mongoose.Schema({
  landing_id: {
    type: String,
    required: true, // The value of "landing_id" is identical to that of "token"
    index: true
  },
  token: {
    type: String,
    required: true, // The value of "landing_id" is identical to that of "token"
    index: true
  },

  landed_at: {
    type: Date,
    required: true
  },
  submitted_at: {
    type: Date,
    required: true
  },

  metadata: {
    type: TypeformMetadataSchema,
    required: true
  },

  answers: {
    type: [TypeformAnswerSchema],
    // "answers" is null if the typeform was opened but never submitted (i.e. completed=false)
    required: function required(val) {
      return Array.isArray(val);
    },
    default: []
  },
  hidden: {
    type: TypeformHiddenSchema,
    required: true,
    default: {}
  },
  calculated: {
    type: TypeformCalculatedSchema,
    required: true,
    default: {}
  }
}).set('minimize', false);

var TypeformDefinitionFieldSchema = new _mongoose.Schema({
  id: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: QUESTION_TYPES,
    required: true
  },
  ref: {
    type: String,
    required: false
  },
  allow_multiple_selections: {
    type: Boolean,
    required: false
  },
  allow_other_choice: {
    type: Boolean,
    required: false
  }
}).set('minimize', false);

var TypeformDefinitionSchema = new _mongoose.Schema({
  id: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  fields: {
    type: [TypeformDefinitionFieldSchema],
    required: true
  }
}).set('minimize', false);

var TypeformFormResponseSchema = new _mongoose.Schema({
  form_id: {
    type: String,
    required: true,
    index: true
  },
  token: {
    type: String,
    required: true,
    index: true
  },

  landed_at: {
    type: Date,
    required: true
  },
  submitted_at: {
    type: Date,
    required: true
  },

  definition: {
    type: TypeformDefinitionSchema,
    required: true
  },

  answers: {
    type: [TypeformAnswerSchema],
    // "answers" is null if the typeform was opened but never submitted (i.e. completed=false)
    required: function required(val) {
      return Array.isArray(val);
    },
    default: []
  },
  hidden: {
    type: TypeformHiddenSchema,
    required: true,
    default: {}
  },
  calculated: {
    type: TypeformCalculatedSchema,
    required: true,
    default: {}
  }
}).set('minimize', false);

/**
 * TypeForm Response API (retrieve form response) response type
 */
var TypeformResponseSchema = new _mongoose.Schema({
  total_items: {
    type: Number,
    required: true,
    min: 0
  },
  page_count: {
    type: Number,
    required: true,
    min: 0
  },
  items: [TypeformItemSchema]
}).set('minimize', false);

/**
 * TypeForm WebHook API (Form Response) response type
 */
var TypeformEventSchema = new _mongoose.Schema({
  event_id: {
    type: String,
    required: true
  },
  event_type: {
    type: String,
    enum: ['form_response'],
    required: true
  },

  form_response: TypeformFormResponseSchema
}).set('minimize', false);

/**
 * Our own database's TypeForm Result type
 */
var TypeformResultSchema = new _mongoose.Schema({
  form_id: {
    type: String,
    required: true,
    index: true
  },
  token: {
    type: String,
    required: true,
    index: true
  },

  landed_at: {
    type: Date,
    required: true
  },
  submitted_at: {
    type: Date,
    required: true
  },

  answers: {
    type: [TypeformAnswerSchema],
    // "answers" is null if the typeform was opened but never submitted (i.e. completed=false)
    required: function required(val) {
      return Array.isArray(val);
    },
    default: []
  },
  hidden: {
    type: TypeformHiddenSchema,
    required: true,
    default: {}
  },
  calculated: {
    type: TypeformCalculatedSchema,
    required: true,
    default: {}
  }
}).set('autoIndex', true).set('minimize', false).set('timestamps', true);

/**
 * TypeForm Create API (retrieve form) response type
 */
var TypeformFormSchema = new _mongoose.Schema({
  id: {
    type: String,
    required: false // Does not exist when creating, but exists when retrieving
  },
  title: {
    type: String,
    required: true
  },
  language: {
    type: String,
    required: false // Does not exist when creating, but exists when retrieving
  },
  theme: {
    type: String,
    required: true
  },

  settings: {
    type: _mongoose.Schema.Types.Mixed, // See https://developer.typeform.com/create/reference/create-form/
    required: true
  },
  workspace: {
    type: _mongoose.Schema.Types.Mixed, // See https://developer.typeform.com/create/reference/create-form/
    required: true
  },

  hidden: {
    type: [String],
    required: true
  },
  variables: {
    type: _mongoose.Schema.Types.Mixed, // See https://developer.typeform.com/create/reference/create-form/
    required: true
  },

  welcome_screens: {
    type: [_mongoose.Schema.Types.Mixed], // See https://developer.typeform.com/create/reference/create-form/
    required: true
  },
  thankyou_screens: {
    type: [_mongoose.Schema.Types.Mixed], // See https://developer.typeform.com/create/reference/create-form/
    required: true
  },
  fields: {
    type: [_mongoose.Schema.Types.Mixed], // See https://developer.typeform.com/create/reference/create-form/
    required: true
  },
  logic: {
    type: [_mongoose.Schema.Types.Mixed], // See https://developer.typeform.com/create/reference/create-form/
    required: true
  }
}).set('autoIndex', true).set('minimize', false).set('timestamps', true);

/**
 * Exports
 */

exports.TypeformResponseSchema = TypeformResponseSchema;
exports.TypeformEventSchema = TypeformEventSchema;
exports.TypeformResultSchema = TypeformResultSchema;
exports.TypeformFormSchema = TypeformFormSchema;
//# sourceMappingURL=typeform.schema.js.map
