'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var UsersSecurityQuestionSchema = new _mongoose.Schema({
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'E_Learning_User',
    required: 'User is required!'
  },

  questionId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'SecurityQuestion',
    required: 'Question is required!'
  },

  isActive: {
    type: Boolean,
    default: true
  },
  answer: {
    type: String,
    required: 'Answer is required!'
  }
});

UsersSecurityQuestionSchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = UsersSecurityQuestionSchema;
//# sourceMappingURL=users-security-question.schema.js.map
