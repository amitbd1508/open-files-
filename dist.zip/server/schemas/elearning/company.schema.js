'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var CompanySchema = new _mongoose.Schema({
  name: String,

  isActive: {
    type: Boolean,
    default: true
  },

  imageURL: String
});

CompanySchema.set('autoIndex', true).set('minimize', false).set('timestamps', true);

exports.default = CompanySchema;
//# sourceMappingURL=company.schema.js.map
