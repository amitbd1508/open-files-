'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var environment = require('../config/environment');

var UserSchema = new _mongoose.Schema({
  name: String,
  username: {
    type: String,
    required: true
  },
  email: {
    type: String,
    lowercase: true,
    required: true
  },
  phone: String,
  phone_tab: String,
  role: {
    type: String,
    default: 'user'
  },
  milestone: {
    type: Number,
    default: 0
  },
  password: {
    type: String,
    required: true
  },
  provider: String,
  salt: String,
  fullname: String,
  account_balance: Number,
  usertype: {
    type: String,
    enum: environment.userType
  },
  center: String,
  mpo_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  te_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  specialized: String,
  identity: String,
  village_id: [{
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'Area'
  }],
  rmp_share_1: Number,
  rmp_share_2: Number,
  credit_range: {
    type: Number,
    default: 0
  },
  pricing1: Number,
  pricing2: Number,
  profile_url: String,
  signature_url: String,
  is_active: {
    type: Boolean,
    default: true
  },
  territories: {
    type: String
  },
  dashboard: {
    type: {
      savedWidgets: [{
        id: String,
        tag: String,
        config: Object
      }],
      publishedWidgets: [{
        id: String,
        tag: String,
        config: Object
      }]
    },
    default: {
      savedWidgets: [],
      publishedWidgets: []
    }
  }
});

UserSchema.set('minimize', true).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = UserSchema;
//# sourceMappingURL=user.schema.js.map
