'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var UserSignInOutLogSchema = new _mongoose.Schema({
  createdBy: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  time: {
    type: Date,
    required: true
  },
  eventType: {
    type: String,
    enum: ['login', 'logout'],
    required: true
  },
  inputSource: {
    type: String,
    enum: ['auto', 'manual'],
    default: 'auto'
  },
  userAgent: {
    isAuthoritative: {
      type: Boolean,
      default: false
    },
    isMobile: {
      type: Boolean,
      default: false
    },
    isTablet: {
      type: Boolean,
      default: false
    },
    isiPad: {
      type: Boolean,
      default: false
    },
    isiPhone: {
      type: Boolean,
      default: false
    },
    isAndroid: {
      type: Boolean,
      default: false
    },
    isBlackberry: {
      type: Boolean,
      default: false
    },
    isOpera: {
      type: Boolean,
      default: false
    },
    isIE: {
      type: Boolean,
      default: false
    },
    isEdge: {
      type: Boolean,
      default: false
    },
    isIECompatibilityMode: {
      type: Boolean,
      default: false
    },
    isSafari: {
      type: Boolean,
      default: false
    },
    isFirefox: {
      type: Boolean,
      default: false
    },
    isWebkit: {
      type: Boolean,
      default: false
    },
    isChrome: {
      type: Boolean,
      default: false
    },
    isKonqueror: {
      type: Boolean,
      default: false
    },
    isOmniWeb: {
      type: Boolean,
      default: false
    },
    isSeaMonkey: {
      type: Boolean,
      default: false
    },
    isFlock: {
      type: Boolean,
      default: false
    },
    isAmaya: {
      type: Boolean,
      default: false
    },
    isPhantomJS: {
      type: Boolean,
      default: false
    },
    isEpiphany: {
      type: Boolean,
      default: false
    },
    isDesktop: {
      type: Boolean,
      default: false
    },
    isWindows: {
      type: Boolean,
      default: false
    },
    isLinux: {
      type: Boolean,
      default: false
    },
    isLinux64: {
      type: Boolean,
      default: false
    },
    isMac: {
      type: Boolean,
      default: false
    },
    isChromeOS: {
      type: Boolean,
      default: false
    },
    isBada: {
      type: Boolean,
      default: false
    },
    isSamsung: {
      type: Boolean,
      default: false
    },
    isRaspberry: {
      type: Boolean,
      default: false
    },
    isBot: {
      type: Boolean,
      default: false
    },
    isCurl: {
      type: Boolean,
      default: false
    },
    isAndroidTablet: {
      type: Boolean,
      default: false
    },
    isWinJs: {
      type: Boolean,
      default: false
    },
    isKindleFire: {
      type: Boolean,
      default: false
    },
    isSilk: {
      type: Boolean,
      default: false
    },
    isCaptive: {
      type: Boolean,
      default: false
    },
    isSmartTV: {
      type: Boolean,
      default: false
    },
    isUC: {
      type: Boolean,
      default: false
    },
    isFacebook: {
      type: Boolean,
      default: false
    },
    silkAccelerated: {
      type: Boolean,
      default: false
    },
    browser: {
      type: String
    },
    version: {
      type: String
    },
    os: {
      type: String
    },
    platform: {
      type: String
    },
    geoIp: {
      type: _mongoose.Schema.Types.Mixed
    },
    source: {
      type: String
    }
  }
});

UserSignInOutLogSchema.set('autoIndex', true).set('minimize', true).set('timestamps', true);

exports.default = UserSignInOutLogSchema;
//# sourceMappingURL=user-sing-in-out-log.schema.js.map
