'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var SymptomsSchema = new _mongoose.Schema({
  SNOMEDConceptId: {
    type: Number,
    default: 0
  },
  primaryTerm: {
    type: String,
    required: '{PATH} is required'
  },
  system: {
    type: Array,
    default: []
  },
  advice: {
    type: Array,
    default: []
  },
  userId: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: '{PATH} is required'
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  isPrimary: {
    type: Boolean,
    default: true
  },
  isIgnored: {
    type: Boolean,
    default: false
  }
});

SymptomsSchema.set('minimize', false).set('timestamps', {
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

exports.default = SymptomsSchema;
//# sourceMappingURL=symptom.schema.js.map
