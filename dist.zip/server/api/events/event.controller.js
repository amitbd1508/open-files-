'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.updateUsersEvents = exports.countUserEvents = exports.usersEvents = exports.addEvent = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var addEvent = exports.addEvent = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var formBody, event;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            formBody = req.body;


            if (!formBody.title) res.status(400).end('title not found');

            _context.next = 5;
            return (0, _bluebird.resolve)(_event.Event.saveEvent(formBody));

          case 5:
            event = _context.sent;


            res.json({
              timestamp: Date.now(),
              event: event
            });
            _context.next = 12;
            break;

          case 9:
            _context.prev = 9;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 12:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 9]]);
  }));

  return function addEvent(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var usersEvents = exports.usersEvents = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var userId, limit, skip, events;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            userId = req.user._id;
            limit = req.body.limit;
            skip = req.body.skip;
            _context2.next = 6;
            return (0, _bluebird.resolve)(_event.Event.myEvents(userId, limit, skip));

          case 6:
            events = _context2.sent;


            res.json({
              timestamp: Date.now(),
              events: events
            });
            _context2.next = 13;
            break;

          case 10:
            _context2.prev = 10;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 13:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 10]]);
  }));

  return function usersEvents(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var countUserEvents = exports.countUserEvents = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var userId, count;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            userId = req.user._id;
            _context3.next = 4;
            return (0, _bluebird.resolve)(_event.Event.countUserEvents(userId));

          case 4:
            count = _context3.sent;


            res.json({
              timestamp: Date.now(),
              count: count
            });
            _context3.next = 11;
            break;

          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 8]]);
  }));

  return function countUserEvents(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var updateUsersEvents = exports.updateUsersEvents = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var userId, events;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            userId = req.user._id;
            _context4.next = 4;
            return (0, _bluebird.resolve)(_event.Event.updateUsersEvents(userId));

          case 4:
            events = _context4.sent;


            res.json({
              timestamp: Date.now(),
              events: events
            });
            _context4.next = 11;
            break;

          case 8:
            _context4.prev = 8;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 11:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 8]]);
  }));

  return function updateUsersEvents(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var _event = require('./event.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=event.controller.js.map
