'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EventAppointment = exports.Event = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var getTodaysFirstAppointmentByDoctorId = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(doctorId) {
    var dateStartOfDay, dateEndOfDay, query;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            dateStartOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').startOf('day').toDate();
            dateEndOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').endOf('day').toDate();
            query = {};


            query.doctors_id = doctorId;
            query.start = {
              $gte: dateStartOfDay,
              $lte: dateEndOfDay
            };

            _context.next = 7;
            return (0, _bluebird.resolve)(EventAppointment.findOne(query).sort('start').lean().exec());

          case 7:
            return _context.abrupt('return', _context.sent);

          case 8:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function getTodaysFirstAppointmentByDoctorId(_x) {
    return _ref.apply(this, arguments);
  };
}();

var saveEvent = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(formData) {
    var event;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            event = new Event();


            event.title = formData.title;
            event.createdFor = formData.createdFor;
            event.createdBy = formData.createdBy;
            event.type = formData.type;
            event.subTitle = formData.subTitle;
            event.description = formData.description;
            event.icon = formData.icon;
            event.forUserGroup = formData.forUserGroup;

            _event4.default.emit('event:create');

            _context2.next = 12;
            return (0, _bluebird.resolve)(event.save());

          case 12:
            return _context2.abrupt('return', _context2.sent);

          case 13:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function saveEvent(_x2) {
    return _ref2.apply(this, arguments);
  };
}();

var myEvents = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(userId) {
    var limit = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 10;
    var skip = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(Event.find({
              createdFor: userId
            }).populate({
              path: 'createdBy',
              select: 'fullname'
            }).limit(limit).skip(skip).sort('-createdAt').exec());

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function myEvents(_x3, _x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}();

var countUserEvents = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(userId) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Event.count({
              createdFor: userId,
              isSeen: false
            }).exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function countUserEvents(_x8) {
    return _ref4.apply(this, arguments);
  };
}();

var updateUsersEvents = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(userId) {
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:

            _event4.default.emit('event:update');

            _context5.next = 3;
            return (0, _bluebird.resolve)(Event.update({
              createdFor: userId
            }, {
              isSeen: true
            }, {
              multi: true
            }).exec());

          case 3:
            return _context5.abrupt('return', _context5.sent);

          case 4:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function updateUsersEvents(_x9) {
    return _ref5.apply(this, arguments);
  };
}();

var lateArrivalNotificationForDoctor = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(user) {
    var _this = this;

    var todaysAvailableDoctors;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.findAvailableDoctors());

          case 2:
            todaysAvailableDoctors = _context7.sent;


            todaysAvailableDoctors.forEach(function () {
              var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(doctor) {
                var firstAppointment, duration, timeDifference, event;
                return _regenerator2.default.wrap(function _callee6$(_context6) {
                  while (1) {
                    switch (_context6.prev = _context6.next) {
                      case 0:
                        if (!(doctor._id.toString() === user._id.toString())) {
                          _context6.next = 10;
                          break;
                        }

                        _context6.next = 3;
                        return (0, _bluebird.resolve)(EventAppointment.getTodaysFirstAppointmentByDoctorId(doctor._id));

                      case 3:
                        firstAppointment = _context6.sent;
                        duration = _momentTimezone2.default.duration((0, _momentTimezone2.default)(firstAppointment.start).diff((0, _momentTimezone2.default)()));
                        timeDifference = duration.humanize();

                        if (!(0, _momentTimezone2.default)().isSameOrAfter(firstAppointment.start)) {
                          _context6.next = 10;
                          break;
                        }

                        event = {
                          title: 'Late Entrance',
                          createdFor: user,
                          type: 'notification',
                          icon: user.profile_url,
                          description: timeDifference
                        };
                        _context6.next = 10;
                        return (0, _bluebird.resolve)(Event.saveEvent(event));

                      case 10:
                      case 'end':
                        return _context6.stop();
                    }
                  }
                }, _callee6, _this);
              }));

              return function (_x11) {
                return _ref7.apply(this, arguments);
              };
            }());

          case 4:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function lateArrivalNotificationForDoctor(_x10) {
    return _ref6.apply(this, arguments);
  };
}();

// /**
//  * Model
//  */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _event = require('../../schemas/event.schema');

var _event2 = _interopRequireDefault(_event);

var _event3 = require('./event.events');

var _event4 = _interopRequireDefault(_event3);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _appointmentTransfer = require('../appointment-transfer/appointment-transfer.model');

var _appointment = require('../../schemas/appointment.schema');

var _appointment2 = _interopRequireDefault(_appointment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */

_event2.default.static('saveEvent', saveEvent).static('myEvents', myEvents).static('countUserEvents', countUserEvents).static('updateUsersEvents', updateUsersEvents).static('lateArrivalNotificationForDoctor', lateArrivalNotificationForDoctor);

_appointment2.default.static('getTodaysFirstAppointmentByDoctorId', getTodaysFirstAppointmentByDoctorId);

var Event = exports.Event = _mongoose2.default.model('Event', _event2.default, 'events');
var EventAppointment = exports.EventAppointment = _mongoose2.default.model('EventAppointment', _appointment2.default, 'appointments');
//# sourceMappingURL=event.model.js.map
