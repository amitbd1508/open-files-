'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _event = require('./event.events');

var _event2 = _interopRequireDefault(_event);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
}

/**
 * Socket Messages
 */

/**
 * Publish Widget Message
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('event:create', {
      timestamp: Date.now()
    });
  };

  _event2.default.on('event:create', listener);

  socket.on('disconnect', function () {
    _event2.default.removeListener('event:create', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('event:update', {
      timestamp: Date.now()
    });
  };

  _event2.default.on('event:update', listener);

  socket.on('disconnect', function () {
    _event2.default.removeListener('event:update', listener);
  });
}
//# sourceMappingURL=event.socket.js.map
