'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var NotificationEvents = new _events.EventEmitter();

/**
 * Options
 */
NotificationEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = NotificationEvents;
//# sourceMappingURL=event.events.js.map
