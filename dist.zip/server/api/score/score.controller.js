'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getScore = exports.giveScore = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var giveScore = exports.giveScore = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var score;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (req.user) {
              req.body.userId = req.user._id;
            }

            _context.next = 3;
            return (0, _bluebird.resolve)(_score.Score.giveScore(req.body));

          case 3:
            score = _context.sent;

            res.json({
              timestamp: Date.now(),
              score: score
            });

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function giveScore(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var getScore = exports.getScore = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var userId, objectReference, score, rating;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            userId = void 0;
            objectReference = void 0;

            if (req.user) {
              userId = req.user._id;
              objectReference = req.query.objectReference;
            }

            _context2.next = 5;
            return (0, _bluebird.resolve)(_score.Score.getScore(userId, objectReference));

          case 5:
            score = _context2.sent;
            rating = void 0;

            if (score !== undefined && score !== null) {
              if ('rating' in score) {
                rating = score.rating;
              } else {
                rating = 0;
              }
              res.json({
                timestamp: Date.now(),
                rating: rating
              });
            } else {
              res.json({
                timestamp: Date.now(),
                rating: 0
              });
            }

          case 8:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getScore(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var _score = require('./score.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=score.controller.js.map
