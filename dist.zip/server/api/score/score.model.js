'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Score = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var giveScore = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData) {
    var score, newScore, savedRating, updatedRating;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Score.findOne({
              objectReference: formData.objectReference
            }).exec());

          case 2:
            score = _context.sent;

            if (!(score === null)) {
              _context.next = 20;
              break;
            }

            newScore = new Score();

            newScore.userId = formData.userId;
            newScore.rating = formData.rating;
            newScore.objectReference = formData.objectReference;
            newScore.parentType = 'Appointment';
            // parentId: String,
            newScore.objectType = 'Image';

            if (!(formData.userId && formData.objectReference)) {
              _context.next = 17;
              break;
            }

            _context.next = 13;
            return (0, _bluebird.resolve)(newScore.save());

          case 13:
            savedRating = _context.sent;
            return _context.abrupt('return', savedRating);

          case 17:
            return _context.abrupt('return', score);

          case 18:
            _context.next = 28;
            break;

          case 20:
            score.userId = formData.userId;
            score.rating = formData.rating;
            score.objectReference = formData.objectReference;

            if (!(formData.userId && formData.objectReference)) {
              _context.next = 28;
              break;
            }

            _context.next = 26;
            return (0, _bluebird.resolve)(score.save());

          case 26:
            updatedRating = _context.sent;
            return _context.abrupt('return', updatedRating);

          case 28:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function giveScore(_x) {
    return _ref.apply(this, arguments);
  };
}();

var getScore = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(userId, objectReference) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(Score.findOne({ objectReference: objectReference }).lean());

          case 2:
            return _context2.abrupt('return', _context2.sent);

          case 3:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getScore(_x2, _x3) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _score = require('../../schemas/score.schema');

var _score2 = _interopRequireDefault(_score);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */

_score2.default.static('giveScore', giveScore).static('getScore', getScore);

var Score = exports.Score = _mongoose2.default.model('Score', _score2.default, 'scores');
//# sourceMappingURL=score.model.js.map
