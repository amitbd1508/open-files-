'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var MobileEvents = new _events.EventEmitter();

/**
 * Options
 */
MobileEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = MobileEvents;
//# sourceMappingURL=mobile.events.js.map
