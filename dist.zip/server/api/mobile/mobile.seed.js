"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.seedData = undefined;

var _momentTimezone = require("moment-timezone");

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var rmp = {
  "_id": "5805e6d5995bb80011fba444",
  "fullname": 'rmp',
  "username": 'rmp@jeeon.com',
  "email": 'rmp@jeeon.co',
  "userType": 'rmp',
  "password": 'password',
  "role": 2
};

var rmp2 = {
  "_id": "5805e6d5995bb80011fba555",
  "fullname": 'rmp2',
  "username": 'rmp2@jeeon.com',
  "email": 'rmp2@jeeon.co',
  "userType": 'rmp',
  "password": 'password2',
  "role": 2
};

var doctor = {
  "_id": "5805e6d5995bb80011fba974",
  "fullname": 'doctor',
  "username": 'fromDoctor@jeeon.com',
  "email": 'fromDoctor@jeeon.co',
  "userType": 'doctor',
  "password": 'password',
  "role": 2
};

var patientActive = {
  "_id": "58399528cc32be0011fe8951",
  "serialnumber": 'ADp:04770',
  "active": true,
  "fullname": 'patient',
  "phone": '01918580662',
  "dob": '2001-08-28T07:05:34.235Z'
};

var patientActive2 = {
  "_id": "58399598cc32be0211fe8925",
  "serialnumber": 'ADp:03870',
  "active": true,
  "fullname": 'patient2',
  "phone": '01718580662',
  "dob": '2000-08-28T07:05:34.235Z'
};

var patientInActive = {
  "_id": "58399528cc32be0011ae8953",
  "serialnumber": 'ADp:04773',
  "active": false
};

var appointment = {
  "_id": "57fa4f389946d20011448aef",
  "doctors_id": "5805e6d5995bb80011fba974",
  "rmp_id": "5805e6d5995bb80011fba444",
  "patients_id": "58399528cc32be0011fe8951",
  "start": (0, _momentTimezone2.default)().add(2, 'hours'),
  "end": (0, _momentTimezone2.default)().add(2, 'hours').add(20, 'minus'),
  "symptoms": [],
  "patients_images": ["https://projotno-server.s3.ap-south-1.amazonaws.com/appointmentdata/profile-1476612931321.jpeg"],
  "is_prescribed": false,
  "is_booked": true,
  "time_took": 10101,
  "patient_weight": 101.11,
  "patient_temp": 111,
  "patient_systole": 1111.1,
  "patient_pulse": 1111
};

var appointment2 = {
  "_id": "57fa4f389946d20022448aew",
  "doctors_id": "5805e6d5995bb80011fba974",
  "rmp_id": "5805e6d5995bb80011fba444",
  "patients_id": "58399528cc32be0011fe8951",
  "start": (0, _momentTimezone2.default)().add(3, 'hours'),
  "end": (0, _momentTimezone2.default)().add(3, 'hours').add(40, 'minus'),
  "symptoms": [],
  "patients_images": ["https://projotno-server.s3.ap-south-1.amazonaws.com/appointmentdata/profile-1476612931321.jpeg"],
  "is_prescribed": false,
  "is_booked": true,
  "time_took": 22,
  "patient_weight": 22.22,
  "patient_temp": 22,
  "patient_systole": 2222.1,
  "patient_pulse": 22222
};

var prescription = {
  "_id": "5a0d117af3b8031b4cb0a1d9",
  "updated_at": "2017-11-16T10:33:45.515+0000",
  "created_at": "2017-11-16T04:18:02.929+0000",
  "appointment_id": "57fa4f389946d20011448aef",
  "rmp_id": "5805e6d5995bb80011fba444",
  "doctors_id": "5805e6d5995bb80011fba974",
  "patients_id": "58399528cc32be0011fe8951",
  "pdflink": null,
  "encoded_symptoms": [],
  "timestamp": {
    "rmp_seen_time": "2017-11-16T10:26:26.252+0000"
  },
  "isPayed": true,
  "opened": "2017-11-16T04:18:02.927+0000",
  "time_took": 522,
  "is_pdfready": true,
  "rmp_seen": false,
  "fee": 50,
  "instruction": [{
    "additional_instructions": [],
    "instructions": [],
    "duration_type": null,
    "duration": null,
    "doses": {
      "0": ""
    },
    "selected": [{
      "packSize": "4's pack",
      "price": "200",
      "indication": "Pneumonia, Pharyngitis, Typhoid fever, Susceptible infections , Sinusitis, Otitis media, Tonsillitis, Soft tissue infections, Respiratory tract infections, Acute Exacerbations of Chronic bronchitis, Gonococcal urethritis, Acute bronchitis",
      "formulation": "Tablet",
      "strength": "400mg",
      "companyName": "Medimet Pharmaceuticals Ltd.",
      "genericName": "Cefixime",
      "trade_name": "Tablet 3rd Cef (400mg)",
      "_id": "588955c8817c2c039723bd1e"
    }]
  }],
  "allergy": [],
  "chronicinfo": [],
  "druginfo": [],
  "familyinfo": [],
  "personalinfo": [],
  "advices": [],
  "investigations": [],
  "diagnoses": {
    "final": [],
    "differential": [],
    "provisional": []
  },
  "encodedSymptoms": [],
  "diagnosis": [],
  "is_free": false,
  "is_referred": true,
  "is_followup": true,
  "rmpfinding": [{
    "SNOMEDConceptId": 405729008,
    "primaryTerm": "stoolandurine",
    "_id": 9
  }],
  "symptoms": ["stoolandurine"],
  "chief_complaint": [],
  "followup_date": null,
  "publishAt": "2017-11-16T10:33:45.514+0000"
};

var prescriptionPublishAndUnpaid = {
  "_id": "5a0d117af3b8031b4cb0a1d9",
  "updated_at": "2017-11-16T10:33:45.515+0000",
  "created_at": "2017-11-16T04:18:02.929+0000",
  "appointment_id": "57fa4f389946d20011448aef",
  "rmp_id": "5805e6d5995bb80011fba444",
  "doctors_id": "5805e6d5995bb80011fba974",
  "patients_id": "58399528cc32be0011fe8951",
  "pdflink": null,
  "encoded_symptoms": [],
  "timestamp": {
    "rmp_seen_time": "2017-11-16T10:26:26.252+0000"
  },
  "isPayed": false,
  "opened": "2017-11-16T04:18:02.927+0000",
  "time_took": 522,
  "is_pdfready": true,
  "rmp_seen": false,
  "fee": 50,
  "instruction": [{
    "additional_instructions": [],
    "instructions": [],
    "duration_type": null,
    "duration": null,
    "doses": {
      "0": ""
    },
    "selected": [{
      "packSize": "4's pack",
      "price": "200",
      "indication": "Pneumonia, Pharyngitis, Typhoid fever, Susceptible infections , Sinusitis, Otitis media, Tonsillitis, Soft tissue infections, Respiratory tract infections, Acute Exacerbations of Chronic bronchitis, Gonococcal urethritis, Acute bronchitis",
      "formulation": "Tablet",
      "strength": "400mg",
      "companyName": "Medimet Pharmaceuticals Ltd.",
      "genericName": "Cefixime",
      "trade_name": "Tablet 3rd Cef (400mg)",
      "_id": "588955c8817c2c039723bd1e"
    }]
  }],
  "allergy": [],
  "chronicinfo": [],
  "druginfo": [],
  "familyinfo": [],
  "personalinfo": [],
  "advices": [],
  "investigations": [],
  "diagnoses": {
    "final": [],
    "differential": [],
    "provisional": []
  },
  "encodedSymptoms": [],
  "diagnosis": [],
  "is_free": false,
  "is_referred": true,
  "is_followup": true,
  "rmpfinding": [{
    "SNOMEDConceptId": 405729008,
    "primaryTerm": "stoolandurine",
    "_id": 9
  }],
  "symptoms": ["stoolandurine"],
  "chief_complaint": [],
  "followup_date": null,
  "publishAt": "2017-11-16T10:33:45.514+0000"
};

var bKash = {
  "_id": "580751498e7a3c0011da2387",
  "created_at": "2016-10-19T10:56:09.274+0000",
  "updated_at": "2016-10-19T10:56:09.274+0000",
  "trxid": "5758151048",
  "rmp_id": "5805e6d5995bb80011fba444",
  "amount": 1000,
  "counter": "1",
  "currency": "BDT",
  "receiver": "01792608430",
  "reference": "1234",
  "sender": "01721154138",
  "service": "Payment",
  "trxTimestamp": "2016-10-19T16:55:23.759+06:00",
  "increment_index": 1476829719252.0,
  "__v": 0
};

var seedData = exports.seedData = {
  rmp: rmp,
  rmp2: rmp2,
  doctor: doctor,
  patientActive: patientActive,
  patientActive2: patientActive2,
  patientInActive: patientInActive,
  appointment: appointment,
  appointment2: appointment2,
  prescription: prescription,
  prescriptionPublishAndUnpaid: prescriptionPublishAndUnpaid,
  bKash: bKash
};
//# sourceMappingURL=mobile.seed.js.map
