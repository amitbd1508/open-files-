'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RMPLocation = exports.DoctorFlag = exports.RMPRating = exports.RMPTransactions = exports.RMPAppointment = exports.RMPPatient = exports.RMPPayment = exports.RMPDrugAvailability = exports.RMPPrescription = exports.RMPUser = exports.prescriptionsByPatientsSerialKey = exports.saveTransaction = exports.settlement = exports.flag = exports.rate = exports.savePayment = exports.saveDrugAvailability = exports.getSavedDrugs = exports.getLastPrescriptionDrugs = exports.findMedicinesAvailability = exports.findPrescriptions = exports.findTodaysPrescriptions = exports.findAppointmentByToday = exports.findTodaysAppointments = exports.findAppointmentsByPatientIdByRange = exports.findAppointments = exports.findAppointmentByPatientId = exports.updateAppointment = exports.book = exports.findOnePreventingOverwrite = exports.findOnePreventingDuplicate = exports.bookAppointment = exports.patientsRegisteredByRMPByToday = exports.patientsRegisteredByRMPByDateRange = exports.updatePatient = exports.getSerialKeys = exports.registerPatient = exports.findPatientBySerialKey = exports.saveLocation = exports.fetch = exports.login = undefined;

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _values = require('babel-runtime/core-js/object/values');

var _values2 = _interopRequireDefault(_values);

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Statics
 */

var login = exports.login = function () {
  var _ref = (0, _bluebird.method)(function (userId) {
    return _jsonwebtoken2.default.sign({
      id: userId,
      sessionExpiresIn: (0, _momentTimezone2.default)().add(8, 'hours')
    }, _environment2.default.secrets.session);
  });

  return function login(_x) {
    return _ref.apply(this, arguments);
  };
}();

var fetch = exports.fetch = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(userId) {
    var startDate, endDate, unseenPrescriptions, RMP, balance, bKash, isRechargeNeeded, isRechargeWarn;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();
            _context.next = 4;
            return (0, _bluebird.resolve)(RMPPrescription.count({
              publishAt: {
                $gte: startDate,
                $lte: endDate
              },
              rmp_id: userId,
              rmp_seen: false,
              is_pdfready: true
            }).exec());

          case 4:
            unseenPrescriptions = _context.sent;
            _context.next = 7;
            return (0, _bluebird.resolve)(_rmp.User.findById(userId).populate({
              path: 'village_id',
              select: 'village'
            }).exec());

          case 7:
            RMP = _context.sent;
            _context.next = 10;
            return (0, _bluebird.resolve)(RMP.calculatedBalance());

          case 10:
            balance = _context.sent;
            _context.next = 13;
            return (0, _bluebird.resolve)(RMPPayment.findOne({
              rmp_id: userId
            }).sort('-created_at').limit(1).lean().exec());

          case 13:
            bKash = _context.sent;
            isRechargeNeeded = false;
            isRechargeWarn = false;


            if (balance < 30) {
              isRechargeNeeded = true;
              isRechargeWarn = true;
            }

            return _context.abrupt('return', {
              timestamp: Date.now(),
              RMP: RMP,
              unseenPrescriptions: unseenPrescriptions,
              balance: balance,
              bKash: bKash,
              isRechargeNeeded: isRechargeNeeded,
              isRechargeWarn: isRechargeWarn
            });

          case 18:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function fetch(_x2) {
    return _ref2.apply(this, arguments);
  };
}();

var saveLocation = exports.saveLocation = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(userId, position) {
    var location;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            location = new RMPLocation();


            location.timestamp = position.timestamp;
            location.heading = position.coords.heading || '';
            location.altitudeAccuracy = position.coords.altitudeAccuracy || '';
            location.accuracy = position.coords.accuracy || '';
            location.altitude = position.coords.altitude || '';

            location.location.coordinates = [position.coords.longitude, position.coords.latitude];
            location.userId = userId;

            _context2.next = 10;
            return (0, _bluebird.resolve)(location.save());

          case 10:
            return _context2.abrupt('return', _context2.sent);

          case 11:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function saveLocation(_x3, _x4) {
    return _ref3.apply(this, arguments);
  };
}();

var findPatientBySerialKey = exports.findPatientBySerialKey = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(serialKey) {
    var patient, msg;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(RMPPatient.findOne({
              serialnumber: serialKey
            }).populate('village').lean().exec());

          case 2:
            patient = _context3.sent;

            if (patient) {
              _context3.next = 5;
              break;
            }

            throw new Error(_mobile4.default.patientNotFound.message);

          case 5:
            if (patient.active) {
              _context3.next = 9;
              break;
            }

            msg = _mobile4.default.patientNotRegisteredYet;

            msg._id = patient._id;
            return _context3.abrupt('return', msg);

          case 9:

            patient.isActive = patient.active;
            return _context3.abrupt('return', patient);

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findPatientBySerialKey(_x5) {
    return _ref4.apply(this, arguments);
  };
}();

var registerPatient = exports.registerPatient = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(userId, id, formBody) {
    var patient, birthMoment;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              _id: id
            }).exec());

          case 2:
            patient = _context4.sent;

            if (patient) {
              _context4.next = 5;
              break;
            }

            throw new Error('Patient not found');

          case 5:
            if (!patient.active) {
              _context4.next = 7;
              break;
            }

            throw new Error('Patient already exist');

          case 7:
            birthMoment = (0, _momentTimezone2.default)().subtract(formBody.year, 'years').subtract(formBody.month, 'months').subtract(formBody.day, 'days');

            formBody.dob = birthMoment.toDate();

            formBody.active = true;

            formBody.registeredBy = userId;
            formBody.registered_at = new Date();

            _mobile2.default.emit('mobile:patient:register');

            _context4.next = 15;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(patient._id, formBody).exec());

          case 15:
            return _context4.abrupt('return', _context4.sent);

          case 16:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function registerPatient(_x6, _x7, _x8) {
    return _ref5.apply(this, arguments);
  };
}();

// find last inactive/unused qr key or if there is no unused qr key this function
// will create and return 9 newly generated qr key


var getSerialKeys = exports.getSerialKeys = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(userId) {
    var limit, increamentalValue, initialNumber, serialKeys, LastSerialKey, key, serialNumber, patient, serialKey, qrKeybase64;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            limit = 9;
            increamentalValue = 0;
            initialNumber = 10000;
            serialKeys = [];
            _context5.next = 6;
            return (0, _bluebird.resolve)(RMPPatient.findOne().sort('-_id').exec());

          case 6:
            LastSerialKey = _context5.sent;


            if (LastSerialKey) {
              key = parseInt(LastSerialKey.serialnumber.slice(4));

              initialNumber = isNaN(key) ? 10000 : key;
            }

          case 8:
            if (!(increamentalValue < limit)) {
              _context5.next = 28;
              break;
            }

            initialNumber++;
            serialNumber = 'ADp:' + initialNumber;
            _context5.next = 13;
            return (0, _bluebird.resolve)(RMPPatient.findOne({
              serialnumber: serialNumber
            }).exec());

          case 13:
            patient = _context5.sent;

            if (patient) {
              _context5.next = 26;
              break;
            }

            serialKey = new RMPPatient();


            serialKey.serialnumber = serialNumber;
            serialKey.distributedTo = userId;
            serialKey.isDistributed = true;

            // FIXME manipulating model function to get the correct result is not a good practice
            // we can do this in mobile app/client side
            _context5.next = 21;
            return (0, _bluebird.resolve)(stringToBase64OfQR(serialNumber));

          case 21:
            qrKeybase64 = _context5.sent;
            _context5.next = 24;
            return (0, _bluebird.resolve)(serialKey.save());

          case 24:

            serialKeys.push({
              qrKeybase64: qrKeybase64,
              serialKey: serialKey
            });

            increamentalValue++;

          case 26:
            _context5.next = 8;
            break;

          case 28:
            return _context5.abrupt('return', serialKeys);

          case 29:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function getSerialKeys(_x9) {
    return _ref6.apply(this, arguments);
  };
}();

var stringToBase64OfQR = function () {
  var _ref7 = (0, _bluebird.method)(function (string) {
    if (string) {
      var qr = new _qrcoder2.default({
        data: string,
        size: 100
      });

      return qr.getDataURL();
    }
  });

  return function stringToBase64OfQR(_x10) {
    return _ref7.apply(this, arguments);
  };
}();

var updatePatient = exports.updatePatient = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(id, formBody) {
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:

            _mobile2.default.emit('mobile:patient:update');

            _context6.next = 3;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(id, formBody).exec());

          case 3:
            return _context6.abrupt('return', _context6.sent);

          case 4:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function updatePatient(_x11, _x12) {
    return _ref8.apply(this, arguments);
  };
}();

var patientsRegisteredByRMPByDateRange = exports.patientsRegisteredByRMPByDateRange = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(rmpId, startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:

            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : '';
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : '';

            query = {};


            query.registeredBy = rmpId;

            if (startDate && endDate) {
              query.registered_at = {
                $gte: startDate,
                $lte: endDate
              };
            }
            _context7.next = 7;
            return (0, _bluebird.resolve)(findPatientByQuery(query));

          case 7:
            return _context7.abrupt('return', _context7.sent);

          case 8:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function patientsRegisteredByRMPByDateRange(_x13, _x14, _x15) {
    return _ref9.apply(this, arguments);
  };
}();

var patientsRegisteredByRMPByToday = exports.patientsRegisteredByRMPByToday = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(rmpId) {
    var startDate, endDate, query;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();
            query = {};


            query.registeredBy = rmpId;

            query.registered_at = {
              $gte: startDate,
              $lte: endDate
            };
            _context8.next = 7;
            return (0, _bluebird.resolve)(findPatientByQuery(query));

          case 7:
            return _context8.abrupt('return', _context8.sent);

          case 8:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function patientsRegisteredByRMPByToday(_x16) {
    return _ref10.apply(this, arguments);
  };
}();

var findPatientByQuery = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(query) {
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.next = 2;
            return (0, _bluebird.resolve)(RMPPatient.find(query).exec());

          case 2:
            return _context9.abrupt('return', _context9.sent);

          case 3:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this);
  }));

  return function findPatientByQuery(_x17) {
    return _ref11.apply(this, arguments);
  };
}();

var bookAppointment = exports.bookAppointment = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(appointmentId, appointmentForm) {
    var patientId;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            patientId = appointmentForm.patients_id;
            _context10.next = 3;
            return (0, _bluebird.resolve)(this.findOnePreventingDuplicate(appointmentId, patientId));

          case 3:
            appointmentId = _context10.sent;
            _context10.next = 6;
            return (0, _bluebird.resolve)(this.findOnePreventingOverwrite(appointmentId, patientId));

          case 6:
            appointmentId = _context10.sent;
            _context10.next = 9;
            return (0, _bluebird.resolve)(this.book(appointmentId, appointmentForm));

          case 9:
            return _context10.abrupt('return', _context10.sent);

          case 10:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this);
  }));

  return function bookAppointment(_x18, _x19) {
    return _ref12.apply(this, arguments);
  };
}();

// Checks to see if the patient already has an existing appointment on the day of
// the appointmentId currently provided. If one already exists, return the existing
// appointment's id instead of the provided appointmentId.


var findOnePreventingDuplicate = exports.findOnePreventingDuplicate = function () {
  var _ref13 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee11(appointmentId, patientId) {
    var _this = this;

    return _regenerator2.default.wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            _context11.next = 2;
            return (0, _bluebird.resolve)(this.findById(appointmentId).exec().then(function (appointment) {
              if (!appointment) throw new Error('Appointment not found.');
              if (!patientId) throw new Error('Patient not found.');

              var startOfDay = (0, _momentTimezone2.default)(appointment.start).tz('Asia/Dhaka').startOf('day').toDate();
              var endOfDay = (0, _momentTimezone2.default)(appointment.start).tz('Asia/Dhaka').endOf('day').toDate();

              return _this.findOne({
                $or: [{ is_booked: true }, { is_marked: true }],
                patients_id: patientId,
                start: { $gte: startOfDay },
                end: { $lte: endOfDay }
              }).sort('start').exec();
            }).then(function (appointment) {
              if (!appointment) return appointmentId;

              return appointment._id;
            }));

          case 2:
            return _context11.abrupt('return', _context11.sent);

          case 3:
          case 'end':
            return _context11.stop();
        }
      }
    }, _callee11, this);
  }));

  return function findOnePreventingDuplicate(_x20, _x21) {
    return _ref13.apply(this, arguments);
  };
}();

// Checks to see if the appointmentId provided is already marked or booked (perhaps
// due to a race condition). If not, return that appointment's id. Otherwise, check
// to see of the marked/booked appointment happens to be for that same patient, and
// return if so. Otherwise, find the next available appointment with that doctor.


var findOnePreventingOverwrite = exports.findOnePreventingOverwrite = function () {
  var _ref14 = (0, _bluebird.method)(function (appointmentId, patientId) {
    var _this2 = this;

    return this.findById(appointmentId).exec().then(function (appointment) {
      if (!appointment) throw new Error('Appointment not found.');
      if (!patientId) throw new Error('Patient not found.');

      if (!appointment.is_booked && !appointment.is_marked) return appointment;
      if (appointment.patients_id.toString() === patientId.toString()) return appointment;

      var doctorId = appointment.doctors_id;
      var startOfHour = (0, _momentTimezone2.default)(appointment.start).tz('Asia/Dhaka').startOf('hour').toDate();
      var endOfDay = (0, _momentTimezone2.default)(appointment.start).tz('Asia/Dhaka').endOf('day').toDate();

      return _this2.findOne({
        $and: [{
          $or: [{ is_booked: { $exists: false } }, { is_booked: false }]
        }, {
          $or: [{ is_marked: { $exists: false } }, { is_marked: false }]
        }],
        doctors_id: doctorId,
        start: { $gte: startOfHour },
        end: { $lte: endOfDay }
      }).sort('start').exec();
    }).then(function (appointment) {
      if (!appointment) throw new Error('Appointment not found.');

      return appointment._id;
    });
  });

  return function findOnePreventingOverwrite(_x22, _x23) {
    return _ref14.apply(this, arguments);
  };
}();

var book = exports.book = function () {
  var _ref15 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee12(appointmentId, appointmentForm) {
    var appointment;
    return _regenerator2.default.wrap(function _callee12$(_context12) {
      while (1) {
        switch (_context12.prev = _context12.next) {
          case 0:
            _context12.next = 2;
            return (0, _bluebird.resolve)(this.findById(appointmentId));

          case 2:
            appointment = _context12.sent;


            appointmentForm.rmp_id ? appointment.rmp_id = appointmentForm.rmp_id : '';
            appointmentForm.patients_id ? appointment.patients_id = appointmentForm.patients_id : '';
            appointment.is_booked = true;

            appointmentForm.patient_weight ? appointment.patient_weight = appointmentForm.patient_weight : '';
            appointmentForm.patient_temp ? appointment.patient_temp = appointmentForm.patient_temp : '';
            appointmentForm.patient_pulse ? appointment.patient_pulse = appointmentForm.patient_pulse : '';
            appointmentForm.symptoms ? appointment.symptoms = appointmentForm.symptoms : '';
            appointmentForm.time_took ? appointment.time_took = appointmentForm.time_took : '';
            appointmentForm.patient_systole ? appointment.patient_systole = appointmentForm.patient_systole : '';
            appointmentForm.patient_diastole ? appointment.patient_diastole = appointmentForm.patient_diastole : '';
            appointmentForm.patient_diabetic ? appointment.patient_diabetic = appointmentForm.patient_diabetic : '';
            appointmentForm.patient_glucose ? appointment.patient_glucose = appointmentForm.patient_glucose : '';

            !appointment.timestamp ? appointment.timestamp = {} : '';
            !appointment.timestamp.book_by_rmp ? appointment.timestamp.book_by_rmp = Date.now() : '';

            _mobile2.default.emit('appointment:book');

            _context12.next = 20;
            return (0, _bluebird.resolve)(appointment.save());

          case 20:
            return _context12.abrupt('return', _context12.sent);

          case 21:
          case 'end':
            return _context12.stop();
        }
      }
    }, _callee12, this);
  }));

  return function book(_x24, _x25) {
    return _ref15.apply(this, arguments);
  };
}();

// FIXME this hack to prevent overwrite and duplicate


var updateAppointment = exports.updateAppointment = function () {
  var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee13(appointmentId, appointmentForm) {
    var patientId;
    return _regenerator2.default.wrap(function _callee13$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            patientId = appointmentForm.patients_id;
            _context13.next = 3;
            return (0, _bluebird.resolve)(RMPAppointment.findOnePreventingDuplicate(appointmentId, patientId));

          case 3:
            appointmentId = _context13.sent;
            _context13.next = 6;
            return (0, _bluebird.resolve)(RMPAppointment.findOnePreventingOverwrite(appointmentId, patientId));

          case 6:
            appointmentId = _context13.sent;
            _context13.next = 9;
            return (0, _bluebird.resolve)(RMPAppointment.book(appointmentId, appointmentForm));

          case 9:
            return _context13.abrupt('return', _context13.sent);

          case 10:
          case 'end':
            return _context13.stop();
        }
      }
    }, _callee13, this);
  }));

  return function updateAppointment(_x26, _x27) {
    return _ref16.apply(this, arguments);
  };
}();

var findAppointmentByPatientId = exports.findAppointmentByPatientId = function () {
  var _ref17 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee14(patientId, startOfDay, endOfDay) {
    var appointment;
    return _regenerator2.default.wrap(function _callee14$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            _context14.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              $or: [{ is_booked: true }, { is_marked: true }],
              is_prescribed: false,
              patients_id: patientId,
              start: { $gte: startOfDay },
              end: { $lte: endOfDay }
            }).sort('start').populate({
              path: 'doctors_id',
              select: '-signature_url'
            }).populate('patients_id').exec());

          case 2:
            appointment = _context14.sent;

            if (appointment) {
              _context14.next = 5;
              break;
            }

            throw new Error('Appointment not found.');

          case 5:
            return _context14.abrupt('return', appointment);

          case 6:
          case 'end':
            return _context14.stop();
        }
      }
    }, _callee14, this);
  }));

  return function findAppointmentByPatientId(_x28, _x29, _x30) {
    return _ref17.apply(this, arguments);
  };
}();

var findAppointments = exports.findAppointments = function () {
  var _ref18 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee15(rmpId, startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee15$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : '';
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : '';

            query = {};


            query.rmp_id = rmpId;
            query.is_booked = true;

            if (startDate && endDate) {
              query.start = {
                $gte: startDate,
                $lte: endDate
              };
            }

            _context15.next = 8;
            return (0, _bluebird.resolve)(findAppointmentsByQuery(query));

          case 8:
            return _context15.abrupt('return', _context15.sent);

          case 9:
          case 'end':
            return _context15.stop();
        }
      }
    }, _callee15, this);
  }));

  return function findAppointments(_x31, _x32, _x33) {
    return _ref18.apply(this, arguments);
  };
}();

var findAppointmentsByPatientIdByRange = exports.findAppointmentsByPatientIdByRange = function () {
  var _ref19 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee16(patientId, startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee16$(_context16) {
      while (1) {
        switch (_context16.prev = _context16.next) {
          case 0:
            query = {
              is_booked: true,
              is_prescribed: true,
              patients_id: patientId
            };


            query.start = {
              $gte: startDate,
              $lte: endDate
            };

            _context16.next = 4;
            return (0, _bluebird.resolve)(findAppointmentsByQuery(query));

          case 4:
            return _context16.abrupt('return', _context16.sent);

          case 5:
          case 'end':
            return _context16.stop();
        }
      }
    }, _callee16, this);
  }));

  return function findAppointmentsByPatientIdByRange(_x34, _x35, _x36) {
    return _ref19.apply(this, arguments);
  };
}();

var findTodaysAppointments = exports.findTodaysAppointments = function () {
  var _ref20 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee17(rmpId) {
    var query, startDate, endDate;
    return _regenerator2.default.wrap(function _callee17$(_context17) {
      while (1) {
        switch (_context17.prev = _context17.next) {
          case 0:
            query = {};
            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();


            query.rmp_id = rmpId;
            query.is_booked = true;

            query.start = {
              $gte: startDate,
              $lte: endDate
            };

            _context17.next = 8;
            return (0, _bluebird.resolve)(findAppointmentsByQuery(query));

          case 8:
            return _context17.abrupt('return', _context17.sent);

          case 9:
          case 'end':
            return _context17.stop();
        }
      }
    }, _callee17, this);
  }));

  return function findTodaysAppointments(_x37) {
    return _ref20.apply(this, arguments);
  };
}();

var findAppointmentsByQuery = function () {
  var _ref21 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee18(query) {
    return _regenerator2.default.wrap(function _callee18$(_context18) {
      while (1) {
        switch (_context18.prev = _context18.next) {
          case 0:
            _context18.next = 2;
            return (0, _bluebird.resolve)(RMPAppointment.find(query).sort('start').populate({
              path: 'doctors_id',
              select: '-signature_url -password -dashboard'
            }).populate('patients_id').exec());

          case 2:
            return _context18.abrupt('return', _context18.sent);

          case 3:
          case 'end':
            return _context18.stop();
        }
      }
    }, _callee18, this);
  }));

  return function findAppointmentsByQuery(_x38) {
    return _ref21.apply(this, arguments);
  };
}();

// FIXME not following our REST API standard, delete this function when you can fix this
// This function takes a patientId, and
// 1. If an non-prescribed appointment for that patient exists today, return the appointment
// 2. Otherwise, return null.


var findAppointmentByToday = exports.findAppointmentByToday = function () {
  var _ref22 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee19(patientId) {
    var startDate, endDate, query;
    return _regenerator2.default.wrap(function _callee19$(_context19) {
      while (1) {
        switch (_context19.prev = _context19.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();
            query = {
              $or: [{ is_booked: true }, { is_marked: true }],
              is_prescribed: false,
              patients_id: patientId
            };


            query.start = {
              $gte: startDate,
              $lte: endDate
            };

            _context19.next = 6;
            return (0, _bluebird.resolve)(this.findOne(query).sort('start').populate({
              path: 'doctors_id',
              select: '-signature_url -password'
            }).populate('patients_id').exec());

          case 6:
            return _context19.abrupt('return', _context19.sent);

          case 7:
          case 'end':
            return _context19.stop();
        }
      }
    }, _callee19, this);
  }));

  return function findAppointmentByToday(_x39) {
    return _ref22.apply(this, arguments);
  };
}();

var findTodaysPrescriptions = exports.findTodaysPrescriptions = function () {
  var _ref23 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee20(rmpId) {
    var query, startDate, endDate;
    return _regenerator2.default.wrap(function _callee20$(_context20) {
      while (1) {
        switch (_context20.prev = _context20.next) {
          case 0:
            query = {};
            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();

            query.rmp_id = rmpId;
            query.is_pdfready = true;
            query.publishAt = {
              $gte: startDate,
              $lte: endDate
            };

            _context20.next = 8;
            return (0, _bluebird.resolve)(findPrescriptions(query));

          case 8:
            return _context20.abrupt('return', _context20.sent);

          case 9:
          case 'end':
            return _context20.stop();
        }
      }
    }, _callee20, this);
  }));

  return function findTodaysPrescriptions(_x40) {
    return _ref23.apply(this, arguments);
  };
}();

var findPrescriptions = exports.findPrescriptions = function () {
  var _ref24 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee21(query) {
    return _regenerator2.default.wrap(function _callee21$(_context21) {
      while (1) {
        switch (_context21.prev = _context21.next) {
          case 0:
            _context21.next = 2;
            return (0, _bluebird.resolve)(RMPPrescription.find(query).populate({
              path: 'patients_id',
              select: 'fullname serialnumber gender profilepiclink'
            }).populate({
              path: 'doctors_id',
              select: '-signature_url -password -dashboard'
            }).populate({
              path: 'appointment_id',
              select: 'start end'
            }).limit(10).skip(0).sort('-publishAt').exec());

          case 2:
            return _context21.abrupt('return', _context21.sent);

          case 3:
          case 'end':
            return _context21.stop();
        }
      }
    }, _callee21, this);
  }));

  return function findPrescriptions(_x41) {
    return _ref24.apply(this, arguments);
  };
}();

//FIXME


var findMedicinesAvailability = exports.findMedicinesAvailability = function () {
  var _ref25 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee22(rmpId) {
    var drugs, savedDrugs, filterdDrugs;
    return _regenerator2.default.wrap(function _callee22$(_context22) {
      while (1) {
        switch (_context22.prev = _context22.next) {
          case 0:
            _context22.next = 2;
            return (0, _bluebird.resolve)(getLastPrescriptionDrugs(rmpId));

          case 2:
            drugs = _context22.sent;
            _context22.next = 5;
            return (0, _bluebird.resolve)(getSavedDrugs(rmpId));

          case 5:
            savedDrugs = _context22.sent;
            filterdDrugs = [];

            drugs.map(function (drug) {
              var isValid = true;
              savedDrugs.map(function (savedDrug) {
                if (drug.medicines.drug._id == savedDrug.drugId || drug._id == savedDrug.prescriptionId) {
                  isValid = false;
                }
              });
              if (isValid) filterdDrugs.push(drug);
            });
            return _context22.abrupt('return', filterdDrugs);

          case 9:
          case 'end':
            return _context22.stop();
        }
      }
    }, _callee22, this);
  }));

  return function findMedicinesAvailability(_x42) {
    return _ref25.apply(this, arguments);
  };
}();

var getLastPrescriptionDrugs = exports.getLastPrescriptionDrugs = function () {
  var _ref26 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee23(rmpId) {
    return _regenerator2.default.wrap(function _callee23$(_context23) {
      while (1) {
        switch (_context23.prev = _context23.next) {
          case 0:
            _context23.next = 2;
            return (0, _bluebird.resolve)(RMPPrescription.aggregate([{
              "$sort": {
                "publishAt": -1
              }
            }, {
              "$match": {
                "rmp_id": objectId(rmpId),
                "is_pdfready": true,
                "isPayed": true,
                "patients_id": {
                  "$exists": true
                }
              }
            }, {
              "$limit": 50
            }, {
              "$lookup": {
                "from": "patients",
                "localField": "patients_id",
                "foreignField": "_id",
                "as": "patients_id"
              }
            }, {
              "$unwind": {
                "path": "$patients_id"
              }
            }, {
              "$lookup": {
                "from": "users",
                "localField": "doctors_id",
                "foreignField": "_id",
                "as": "doctors_id"
              }
            }, {
              "$unwind": {
                "path": "$doctors_id"
              }
            }, {
              "$project": {
                "doctors_id": {
                  "_id": "$doctors_id._id",
                  "fullname": "$doctors_id.fullname",
                  "identity": "$doctors_id.identity"
                },
                "patients_id": {
                  "_id": "$patients_id._id",
                  "fullname": "$patients_id.fullname",
                  "profilepiclink": "$patients_id.profilepiclink"
                },
                "publishAt": "$publishAt",
                "medicines": {
                  "$map": {
                    "input": "$instruction",
                    "in": {
                      "$let": {
                        "vars": {
                          "drug": {
                            "$arrayElemAt": ["$$this.selected", 0.0]
                          }
                        },
                        "in": {
                          "drug": {
                            "_id": '$$drug._id',
                            "brand_name": {
                              "$ifNull": ["$$drug.tradeName", "$$drug.trade_name"]
                            },
                            "generic_name": {
                              "$ifNull": ["$$drug.genericName", "$$drug.generic_name"]
                            },
                            "company_name": {
                              "$ifNull": ["$$drug.companyName", "$$drug.company_name"]
                            },
                            "strength": "$$drug.strength"
                          }
                        }
                      }
                    }
                  }
                }
              }
            }, {
              "$unwind": {
                "path": "$medicines"
              }
            }, {
              "$limit": 10
            }]));

          case 2:
            return _context23.abrupt('return', _context23.sent);

          case 3:
          case 'end':
            return _context23.stop();
        }
      }
    }, _callee23, this);
  }));

  return function getLastPrescriptionDrugs(_x43) {
    return _ref26.apply(this, arguments);
  };
}();

var getSavedDrugs = exports.getSavedDrugs = function () {
  var _ref27 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee24(rmpId) {
    return _regenerator2.default.wrap(function _callee24$(_context24) {
      while (1) {
        switch (_context24.prev = _context24.next) {
          case 0:
            _context24.next = 2;
            return (0, _bluebird.resolve)(RMPDrugAvailability.find({ "rmpId": rmpId }).lean().exec());

          case 2:
            return _context24.abrupt('return', _context24.sent);

          case 3:
          case 'end':
            return _context24.stop();
        }
      }
    }, _callee24, this);
  }));

  return function getSavedDrugs(_x44) {
    return _ref27.apply(this, arguments);
  };
}();

var saveDrugAvailability = exports.saveDrugAvailability = function () {
  var _ref28 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee25(rmpId, formData) {
    var doctorId, prescriptionId, patientId, drugId, isAvailable, drugAvailability;
    return _regenerator2.default.wrap(function _callee25$(_context25) {
      while (1) {
        switch (_context25.prev = _context25.next) {
          case 0:
            doctorId = formData.doctorId;
            prescriptionId = formData.prescriptionId;
            patientId = formData.patientId;
            drugId = formData.drugId;
            isAvailable = formData.isAvailable;

            if (doctorId) {
              _context25.next = 7;
              break;
            }

            throw new Error('doctor id not found');

          case 7:
            if (prescriptionId) {
              _context25.next = 9;
              break;
            }

            throw new Error('prescription id not found');

          case 9:
            if (patientId) {
              _context25.next = 11;
              break;
            }

            throw new Error('patient id not found');

          case 11:
            if (drugId) {
              _context25.next = 13;
              break;
            }

            throw new Error('drug id not found');

          case 13:
            drugAvailability = new RMPDrugAvailability();


            drugAvailability.rmpId = rmpId;
            drugAvailability.prescriptionId = prescriptionId;
            drugAvailability.drugId = drugId;
            drugAvailability.doctorId = doctorId;
            drugAvailability.patientId = patientId;
            drugAvailability.isAvailable = isAvailable;

            _mobile2.default.emit('mobile:medicine:availability:create');

            _context25.next = 23;
            return (0, _bluebird.resolve)(drugAvailability.save());

          case 23:
            return _context25.abrupt('return', _context25.sent);

          case 24:
          case 'end':
            return _context25.stop();
        }
      }
    }, _callee25, this);
  }));

  return function saveDrugAvailability(_x45, _x46) {
    return _ref28.apply(this, arguments);
  };
}();

var savePayment = exports.savePayment = function () {
  var _ref29 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee26(trxId, userId, bKashURL) {
    var payment, bKash, message;
    return _regenerator2.default.wrap(function _callee26$(_context26) {
      while (1) {
        switch (_context26.prev = _context26.next) {
          case 0:
            _context26.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              trxid: trxId
            }).exec());

          case 2:
            payment = _context26.sent;

            if (!payment) {
              _context26.next = 5;
              break;
            }

            throw new Error(_mobile4.default.trxIdAlreadyUsed.message);

          case 5:
            _context26.next = 7;
            return (0, _bluebird.resolve)(trxIdCheck(trxId, bKashURL));

          case 7:
            bKash = _context26.sent;

            if (!(parseInt(bKash.trxStatus) !== parseInt(_mobile4.default.bKashResponses[0].code))) {
              _context26.next = 10;
              break;
            }

            throw new Error(_mobile4.default.bKashResponses.find(function (element) {
              return parseInt(bKash.trxStatus) === parseInt(element.code);
            }).message);

          case 10:

            payment = new RMPPayment(bKash);
            payment.trxid = trxId;
            payment.rmp_id = userId;

            _context26.next = 15;
            return (0, _bluebird.resolve)(payment.save());

          case 15:
            message = '\u0986\u09AA\u09A8\u09BE\u09B0 ' + bKash.amount + ' \u099F\u09BE\u0995\u09BE\u09B0 \u09AC\u09BF\u0995\u09BE\u09B6 \u09B8\u09AB\u09B2 \u09B9\u09DF\u09C7\u099B\u09C7 \u0964';
            return _context26.abrupt('return', {
              success: true,
              message: message
            });

          case 17:
          case 'end':
            return _context26.stop();
        }
      }
    }, _callee26, this);
  }));

  return function savePayment(_x47, _x48, _x49) {
    return _ref29.apply(this, arguments);
  };
}();

var rate = exports.rate = function () {
  var _ref30 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee27(rmpId, prescriptionId, rate) {
    var prescription, rating;
    return _regenerator2.default.wrap(function _callee27$(_context27) {
      while (1) {
        switch (_context27.prev = _context27.next) {
          case 0:
            _context27.next = 2;
            return (0, _bluebird.resolve)(RMPPrescription.findById(prescriptionId).exec());

          case 2:
            prescription = _context27.sent;

            if (prescription) {
              _context27.next = 5;
              break;
            }

            throw new Error('Prescription not found');

          case 5:
            _context27.next = 7;
            return (0, _bluebird.resolve)(this.findOne({
              prescriptionId: prescriptionId
            }).exec());

          case 7:
            rating = _context27.sent;

            if (!rating) {
              _context27.next = 18;
              break;
            }

            rating.user_id = prescription.doctors_id;
            rating.rmpId = rmpId;
            rating.prescriptionId = prescriptionId;
            // FIXME messed up code to maintain v3 rating system. Please fix this ASAP
            rating[(0, _keys2.default)(rate)[0]] = (0, _values2.default)(rate)[0];

            _context27.next = 15;
            return (0, _bluebird.resolve)(rating.save());

          case 15:
            return _context27.abrupt('return', _context27.sent);

          case 18:
            rating = new RMPRating();
            rating.user_id = prescription.doctors_id;
            rating.rmpId = rmpId;
            rating.prescriptionId = prescriptionId;
            // FIXME messed up code to maintain v3 rating system. Please fix this ASAP
            rating[(0, _keys2.default)(rate)[0]] = (0, _values2.default)(rate)[0];

            _context27.next = 25;
            return (0, _bluebird.resolve)(rating.save());

          case 25:
            return _context27.abrupt('return', _context27.sent);

          case 26:
          case 'end':
            return _context27.stop();
        }
      }
    }, _callee27, this);
  }));

  return function rate(_x50, _x51, _x52) {
    return _ref30.apply(this, arguments);
  };
}();

var flag = exports.flag = function () {
  var _ref31 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee28(rmpId, prescriptionId, flagBody) {
    var prescription, flag;
    return _regenerator2.default.wrap(function _callee28$(_context28) {
      while (1) {
        switch (_context28.prev = _context28.next) {
          case 0:
            _context28.next = 2;
            return (0, _bluebird.resolve)(RMPPrescription.findById(prescriptionId).exec());

          case 2:
            prescription = _context28.sent;

            if (prescription) {
              _context28.next = 5;
              break;
            }

            throw new Error('Prescription not found');

          case 5:
            _context28.next = 7;
            return (0, _bluebird.resolve)(DoctorFlag.findOne({
              prescriptionId: prescriptionId
            }).exec());

          case 7:
            flag = _context28.sent;

            if (!flag) {
              _context28.next = 18;
              break;
            }

            flag.doctorId = prescription.doctors_id;
            flag.createdBy = rmpId;
            flag.prescriptionId = prescriptionId;
            flag.flag = flagBody.flag;

            _context28.next = 15;
            return (0, _bluebird.resolve)(flag.save());

          case 15:
            return _context28.abrupt('return', _context28.sent);

          case 18:
            flag = new this();
            flag.doctorId = prescription.doctors_id;
            flag.createdBy = rmpId;
            flag.prescriptionId = prescriptionId;
            flag.flag = flagBody.flag;

            _context28.next = 25;
            return (0, _bluebird.resolve)(flag.save());

          case 25:
            return _context28.abrupt('return', _context28.sent);

          case 26:
          case 'end':
            return _context28.stop();
        }
      }
    }, _callee28, this);
  }));

  return function flag(_x53, _x54, _x55) {
    return _ref31.apply(this, arguments);
  };
}();

var settlement = exports.settlement = function () {
  var _ref32 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee29(prescriptionId, userId) {
    var prescription, RMP, RMPBalance, RMPShare, result, transaction;
    return _regenerator2.default.wrap(function _callee29$(_context29) {
      while (1) {
        switch (_context29.prev = _context29.next) {
          case 0:
            _context29.next = 2;
            return (0, _bluebird.resolve)(this.findById(prescriptionId).populate({
              path: 'rmp_id patients_id doctors_id appointment_id',
              select: '-password -dashboard'
            }).exec());

          case 2:
            prescription = _context29.sent;

            if (prescription) {
              _context29.next = 5;
              break;
            }

            throw new Error('Prescription Not Found');

          case 5:
            _context29.next = 7;
            return (0, _bluebird.resolve)(_rmp.User.findById(userId).exec());

          case 7:
            RMP = _context29.sent;
            _context29.next = 10;
            return (0, _bluebird.resolve)(RMP.calculatedBalance());

          case 10:
            RMPBalance = _context29.sent;
            _context29.next = 13;
            return (0, _bluebird.resolve)(_rmp.User.calculateRMPShare(prescription._id));

          case 13:
            RMPShare = _context29.sent;
            result = void 0;

            if (!prescription.isPayed) {
              _context29.next = 19;
              break;
            }

            result = _mobile4.default.alreadyPayed;
            result.prescription = prescription;
            return _context29.abrupt('return', result);

          case 19:
            if (!(prescription.fee - RMPShare > RMPBalance)) {
              _context29.next = 21;
              break;
            }

            throw new Error(_mobile4.default.insufficientBalance.message);

          case 21:
            _context29.next = 23;
            return (0, _bluebird.resolve)(RMPTransactions.saveTransaction(prescription, RMPShare));

          case 23:
            transaction = _context29.sent;


            prescription.isPayed = true;
            prescription.timestamp.rmp_seen_time = new Date();
            prescription.rmp_seen = true;
            _context29.next = 29;
            return (0, _bluebird.resolve)(prescription.save());

          case 29:
            prescription = _context29.sent;


            result = _mobile4.default.transactionUpdated;
            result.prescription = prescription;
            result.transaction = transaction;

            _mobile2.default.emit('prescription:settlement');

            return _context29.abrupt('return', result);

          case 35:
          case 'end':
            return _context29.stop();
        }
      }
    }, _callee29, this);
  }));

  return function settlement(_x56, _x57) {
    return _ref32.apply(this, arguments);
  };
}();

var saveTransaction = exports.saveTransaction = function () {
  var _ref33 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee30(prescription, RMPShare) {
    var transaction;
    return _regenerator2.default.wrap(function _callee30$(_context30) {
      while (1) {
        switch (_context30.prev = _context30.next) {
          case 0:
            _context30.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              prescription_id: prescription._id
            }).exec());

          case 2:
            transaction = _context30.sent;


            if (transaction) {
              transaction.rmp_id = prescription.rmp_id._id;
              transaction.appointment_id = prescription.appointment_id;
              transaction.doctors_id = prescription.doctors_id;
              transaction.patients_id = prescription.patients_id;
              transaction.total = prescription.fee;
              transaction.payment_selected = prescription.payment_selected;
              transaction.rmp_share = RMPShare;
            } else {
              transaction = new this({
                rmp_id: prescription.rmp_id._id,
                appointment_id: prescription.appointment_id,
                doctors_id: prescription.doctors_id,
                prescription_id: prescription._id,
                patients_id: prescription.patients_id,
                total: prescription.fee,
                payment_selected: prescription.payment_selected,
                rmp_share: RMPShare
              });
            }

            _context30.next = 6;
            return (0, _bluebird.resolve)(transaction.save());

          case 6:
            return _context30.abrupt('return', _context30.sent);

          case 7:
          case 'end':
            return _context30.stop();
        }
      }
    }, _callee30, this);
  }));

  return function saveTransaction(_x58, _x59) {
    return _ref33.apply(this, arguments);
  };
}();

var prescriptionsByPatientsSerialKey = exports.prescriptionsByPatientsSerialKey = function () {
  var _ref34 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee31(serialNumber) {
    var limit = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 30;
    var skip = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
    var patient;
    return _regenerator2.default.wrap(function _callee31$(_context31) {
      while (1) {
        switch (_context31.prev = _context31.next) {
          case 0:
            _context31.next = 2;
            return (0, _bluebird.resolve)(RMPPatient.findOne({
              serialnumber: serialNumber
            }).exec());

          case 2:
            patient = _context31.sent;

            if (patient) {
              _context31.next = 5;
              break;
            }

            throw new Error('Patient Not Found');

          case 5:
            _context31.next = 7;
            return (0, _bluebird.resolve)(this.find({
              patients_id: patient._id
            }).populate({
              path: 'patients_id doctors_id',
              select: '-signature_url -password -dashboard'
            }).skip(parseInt(skip)).limit(parseInt(limit)).exec());

          case 7:
            return _context31.abrupt('return', _context31.sent);

          case 8:
          case 'end':
            return _context31.stop();
        }
      }
    }, _callee31, this);
  }));

  return function prescriptionsByPatientsSerialKey(_x60, _x61, _x62) {
    return _ref34.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _drugsAvailability = require('../../schemas/drugs-availability.schema');

var _drugsAvailability2 = _interopRequireDefault(_drugsAvailability);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

var _transaction = require('../../schemas/transaction.schema');

var _transaction2 = _interopRequireDefault(_transaction);

var _appointment = require('../../schemas/appointment.schema');

var _appointment2 = _interopRequireDefault(_appointment);

var _location = require('../../schemas/location.schema');

var _location2 = _interopRequireDefault(_location);

var _payment = require('../../schemas/payment.schema');

var _payment2 = _interopRequireDefault(_payment);

var _patient = require('../../schemas/patient.schema');

var _patient2 = _interopRequireDefault(_patient);

var _rating = require('../../schemas/rating.schema');

var _rating2 = _interopRequireDefault(_rating);

var _redFlag = require('../../schemas/red-flag.schema');

var _redFlag2 = _interopRequireDefault(_redFlag);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

var _environment = require('../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

var _mobile = require('./mobile.events');

var _mobile2 = _interopRequireDefault(_mobile);

var _mobile3 = require('./mobile.responses');

var _mobile4 = _interopRequireDefault(_mobile3);

var _rmp = require('../rmp/rmp.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _jsonwebtoken = require('jsonwebtoken');

var _jsonwebtoken2 = _interopRequireDefault(_jsonwebtoken);

var _qrcoder = require('qrcoder');

var _qrcoder2 = _interopRequireDefault(_qrcoder);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;
var request = require('request-promise');

_user2.default.static('login', login).static('fetch', fetch);

_payment2.default.static('savePayment', savePayment);

_patient2.default.static('patientsRegisteredByRMPByDateRange', patientsRegisteredByRMPByDateRange).static('patientsRegisteredByRMPByToday', patientsRegisteredByRMPByToday).static('registerPatient', registerPatient).static('getSerialKeys', getSerialKeys).static('updatePatient', updatePatient).static('showPatient', findPatientBySerialKey);

_appointment2.default.static('findAppointmentsByPatientIdByRange', findAppointmentsByPatientIdByRange).static('findOnePreventingDuplicate', findOnePreventingDuplicate).static('findOnePreventingOverwrite', findOnePreventingOverwrite).static('findAppointmentByPatientId', findAppointmentByPatientId).static('findTodaysAppointments', findTodaysAppointments).static('findAppointmentByToday', findAppointmentByToday).static('updateAppointment', updateAppointment).static('findAppointments', findAppointments).static('bookAppointment', bookAppointment).static('book', book);

_prescription2.default.static('prescriptionsByPatientsSerialKey', prescriptionsByPatientsSerialKey).static('findMedicinesAvailability', findMedicinesAvailability).static('findTodaysPrescriptions', findTodaysPrescriptions).static('findPrescriptions', findPrescriptions).static('settlement', settlement);

_drugsAvailability2.default.static('saveDrugAvailability', saveDrugAvailability);

_transaction2.default.static('saveTransaction', saveTransaction);

_rating2.default.static('rate', rate);

_redFlag2.default.static('flag', flag);

_location2.default.static('saveLocation', saveLocation);

function trxIdCheck(trxId, bKashURL) {
  var options = {
    method: 'GET',
    uri: '' + bKashURL + trxId,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    json: true
  };
  return new _promise2.default(function (resolve, reject) {
    request(options).then(function (data) {
      resolve(data.transaction);
    }).catch(function (err) {
      reject(err);
    });
  });
}

var RMPUser = exports.RMPUser = _mongoose2.default.model('RMPUser', _user2.default, 'users');
var RMPPrescription = exports.RMPPrescription = _mongoose2.default.model('RMPPrescription', _prescription2.default, 'prescriptions');
var RMPDrugAvailability = exports.RMPDrugAvailability = _mongoose2.default.model('RMPDrugAvailability', _drugsAvailability2.default, 'drugs-availability');
var RMPPayment = exports.RMPPayment = _mongoose2.default.model('RMPPayment', _payment2.default, 'payments');
var RMPPatient = exports.RMPPatient = _mongoose2.default.model('RMPPatient', _patient2.default, 'patients');
var RMPAppointment = exports.RMPAppointment = _mongoose2.default.model('RMPAppointment', _appointment2.default, 'appointments');
var RMPTransactions = exports.RMPTransactions = _mongoose2.default.model('RMPTransactions', _transaction2.default, 'transactions');
var RMPRating = exports.RMPRating = _mongoose2.default.model('RMPRating', _rating2.default, 'ratings');
var DoctorFlag = exports.DoctorFlag = _mongoose2.default.model('DoctorFlag', _redFlag2.default, 'redFlags');
var RMPLocation = exports.RMPLocation = _mongoose2.default.model('LocationSchema', _location2.default, 'locations');
//# sourceMappingURL=mobile.model.js.map
