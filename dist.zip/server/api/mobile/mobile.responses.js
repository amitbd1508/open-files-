'use strict';

exports = module.exports = {
  bKash: {
    URLOld: 'https://www.bkashcluster.com:9081/dreamwave/merchant/trxcheck/sendmsg?user=MPOWER&pass=wP0m3r786&msisdn=01792608430&trxid=',
    URLNew: 'https://www.bkashcluster.com:9081/dreamwave/merchant/trxcheck/sendmsg?user=JEEONBANGLADESHLTD&pass=189@J3eonbDLtd&msisdn=01708527699&trxid=',
    receiverOld: '01792608430',
    receiverNew: '01708527699'
  },
  scanTheRightQR: {
    timestamp: Date.now(),
    success: false,
    message: 'সঠিক কার্ড স্ক্যান করুন।'
  },
  accountDisabled: {
    timestamp: Date.now(),
    success: false,
    message: 'আপনার অ্যাকাউন্ট বন্ধ করা হয়েছে ।'
  },
  unauthorizedAccess: {
    timestamp: Date.now(),
    success: false,
    message: 'No Token Found, Unauthorized Access'
  },
  paramsNotFound: {
    timestamp: Date.now(),
    success: false,
    message: 'Params Not Found'
  },
  patientNotFound: {
    timestamp: Date.now(),
    success: false,
    patient_status: false,
    message: 'দয়া করে রুগীর কার্ড দিন'
  },
  patientNotRegisteredYet: {
    timestamp: Date.now(),
    success: false,
    patient_status: false,
    message: 'এই রুগী এখনও রেজিস্ট্রেশন করে নাই'
  },
  invalidId: {
    timestamp: Date.now(),
    success: false,
    message: 'Invalid Params'
  },
  trxIdAlreadyUsed: {
    timestamp: Date.now(),
    success: false,
    message: 'এই TrxID আগেই ব্যবহার হয়ে গেছে ।'
  },
  alreadyPayed: {
    timestamp: Date.now(),
    success: true,
    message: 'Already paid for this appointment'
  },
  patientIdNotFound: {
    timestamp: Date.now(),
    success: false,
    message: 'patient id not found'
  },
  insufficientBalance: {
    timestamp: Date.now(),
    success: false,
    message: 'আপানর অ্যাকাউন্ট এ যথেষ্ট টাকা নাই, দয়া করে এখন রিচার্জ করুন'
  },
  transactionUpdated: {
    timestamp: Date.now(),
    success: true,
    message: 'আপনার অ্যাকাউন্ট হালনাগাদ করা হয়েছে'
  },
  bKashResponses: [{
    code: '0000',
    message: 'টrxID is valid and transaction is successful',
    interpretation: 'Transaction Successful'
  }, {
    code: '0010',
    message: 'এই TrxID তে টাকা এখনও আশে নাই। কিছুখন পর চেষ্টা করেন।',
    interpretation: 'Transaction Pending'
  }, {
    code: '0011',
    message: 'এই TrxID তে টাকা এখনও আশে নাই। কিছুখন পর চেষ্টা করেন।',
    interpretation: 'Transaction Pending'
  }, {
    code: '0100',
    message: 'এই TrxID তে কোন টাকা ভরানো হইনি। সঠিক TrxID দিয়ে চেষ্টা করেন।',
    interpretation: 'Transaction Reversed'
  }, {
    code: '0111',
    message: 'এই TrxID তে কোন টাকা ভরানো হইনি। সঠিক TrxID দিয়ে চেষ্টা করেন।',
    interpretation: 'Transaction Failed'
  }, {
    code: '1001',
    message: 'বিকাশে সমস্যা হচ্ছে । টেরিটোরি এক্সেকুটিভ কে জানান।',
    interpretation: 'Format Error'
  }, {
    code: '1002',
    message: 'এই TrxID টা ভুল। সঠিক TrxID দিয়ে চেষ্টা করেন।',
    interpretation: 'Invalid Reference'
  }, {
    code: '1003',
    message: 'বিকাশে সমস্যা হচ্ছে । টেরিটোরি এক্সেকুটিভ কে জানান।',
    interpretation: 'Authorization Error'
  }, {
    code: '1004',
    message: 'আপনার trxID অন্য কোন বিকাশ নাম্বার এ পাঠান হয়েছে',
    interpretation: 'Authorization Error'
  }, {
    code: '2000',
    message: 'বিকাশে সমস্যা হচ্ছে । টেরিটোরি এক্সেকুটিভ কে জানান।',
    interpretation: 'Authorization Error'
  }, {
    code: '2001',
    message: 'বিকাশে সমস্যা হচ্ছে । টেরিটোরি এক্সেকুটিভ কে জানান।',
    interpretation: 'Date time limit Error'
  }, {
    code: '3000',
    message: 'বিকাশে সমস্যা হচ্ছে । টেরিটোরি এক্সেকুটিভ কে জানান।',
    interpretation: 'Missing Fields Error'
  }, {
    code: '4001',
    message: 'এই TrxID দিয়ে আগেও চেষ্টা করেছেন। অন্য TrxID দিয়ে চেষ্টা করেন।',
    interpretation: 'Duplicate Request'
  }, {
    code: '9999',
    message: 'বিকাশে সমস্যা হচ্ছে । টেরিটোরি এক্সেকুটিভ কে জানান।',
    interpretation: 'System Error'
  }]
};
//# sourceMappingURL=mobile.responses.js.map
