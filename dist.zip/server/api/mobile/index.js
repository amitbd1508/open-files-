'use strict';

/**
 * Imports
 */

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./mobile.controller');

var router = express.Router();

/**
 * Routes
 */

// login
router.post('/auth/:userId', controller.login);

// RMP summary for home page
router.get('/users/summary', auth.isTokenAuthenticated, controller.summary);

// Save RMP location
router.post('/users/locations', auth.isTokenAuthenticated, controller.saveLocation);

// List patients registered by RMP in date range (or all)
router.get('/patients/registered', auth.isTokenAuthenticated, controller.patientsRegisteredByRMPByDateRange);

// list patients registered by RMP today
router.get('/patients/registered/today', auth.isTokenAuthenticated, controller.patientsRegisteredByRMPByToday);

// retrieve patient
router.get('/patients/:serialKey', auth.isTokenAuthenticated, controller.showPatient);

// retrieve serialKeys
router.post('/patients/serialKeys/printing', auth.isTokenAuthenticated, controller.getSerialKeys);

// register patient
router.post('/patients/:id', auth.isTokenAuthenticated, controller.registerPatient);

// update patient
router.put('/patients/:id', auth.isTokenAuthenticated, controller.updatePatient);

// list patient's prescriptions in date range (or all)
router.get('/patients/:serialKey/prescriptions', auth.isTokenAuthenticated, controller.prescriptionsByPatientsSerialKey);

// list patient's appointments in date range (or all)
router.get('/patients/:id/appointments', auth.isTokenAuthenticated, controller.findAppointmentsByPatientIdByRange);

// FIXME patient's appointment in today, this route should not be covering this,
// please delete after fix the dependency from mobile
router.get('/patients/:id/appointment', auth.isTokenAuthenticated, controller.findAppointmentByPatientIdByToday);

// list patient's appointments today
router.get('/patients/:id/appointments/today', auth.isTokenAuthenticated, controller.findTodaysAppointmentsByPatientId);

// book appointment
router.post('/appointments/:id', auth.isTokenAuthenticated, controller.bookAppointment);

// update appointment
router.put('/appointments/:id', auth.isTokenAuthenticated, controller.updateAppointment);

// list appointments of RMP in date range (or all)
router.get('/appointments', auth.isTokenAuthenticated, controller.findAppointments);

// list appointments of RMP today
router.get('/appointments/today', auth.isTokenAuthenticated, controller.findTodaysAppointments);

// list seen/unseen prescriptions of the RMP
router.get('/prescriptions', auth.isTokenAuthenticated, controller.findPrescriptions);

// list seen/unseen prescriptions of the RMP by today
router.get('/prescriptions/today', auth.isTokenAuthenticated, controller.findTodaysPrescriptions);

// list of medicines for the RMP to ask to check for its availability
router.get('/prescriptions/medicines/availability', auth.isTokenAuthenticated, controller.findMedicinesAvailability);

// save medicine availability status
router.post('/prescriptions/medicines/availability', auth.isTokenAuthenticated, controller.saveDrugAvailability);

// settle prescription payment (if necessary) and download it
router.post('/prescriptions/:id/settlement', auth.isTokenAuthenticated, controller.settlementForPrescription);

// create a prescription rating
router.post('/prescriptions/:id/rating', auth.isTokenAuthenticated, controller.rateDoctorForPrescription);

// create a prescription red-flag
router.post('/prescriptions/:id/red-flag', auth.isTokenAuthenticated, controller.flagDoctorForPrescription);

// list doctors available in date range (or today)
router.get('/doctors/available', auth.isTokenAuthenticated, controller.findAvailableDoctors);

// list doctors available today
router.get('/doctors/available/today', auth.isTokenAuthenticated, controller.findAvailableDoctorsToday);

// list doctors schedule weekly
router.get('/doctors/schedule', auth.isTokenAuthenticated, controller.doctorSchedule);

// list doctor's appointments in date range
router.get('/doctors/:id/appointments', auth.isTokenAuthenticated, controller.findAppointmentsByDoctorId);

// list doctor's appointments today
router.get('/doctors/:id/appointments/today', auth.isTokenAuthenticated, controller.findTodaysAppointmentsByDoctorId);

// bKash payment by RMP
router.post('/payments/:trxId', auth.isTokenAuthenticated, controller.savePayment);

// upload patient image
router.post('/images/patients/:id', controller.uploading, controller.patientImageUpload);

// upload appointment image
router.post('/images/appointments/:id', controller.uploading, controller.appointmentsImageUpload);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
