'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _mobile = require('./mobile.events');

var _mobile2 = _interopRequireDefault(_mobile);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  appointmentBook(socket);
  appointmentUpdate(socket);

  patientRegister(socket);
  patientUpdate(socket);

  settlement(socket);
  saveDrugAvailability(socket);
}

/**
 * Socket Messages
 */

/**
 * Refresh Appointments Message
 *
 * @param socket
 */
function appointmentBook(socket) {
  var listener = function listener() {
    socket.emit('appointment:book', {
      timestamp: Date.now()
    });
  };

  _mobile2.default.on('appointment:book', listener);

  socket.on('disconnect', function () {
    _mobile2.default.removeListener('appointment:book', listener);
  });
}

function patientRegister(socket) {
  var listener = function listener() {
    socket.emit('mobile:patient:register', {
      timestamp: Date.now()
    });
  };

  _mobile2.default.on('mobile:patient:register', listener);

  socket.on('disconnect', function () {
    _mobile2.default.removeListener('mobile:patient:register', listener);
  });
}

function patientUpdate(socket) {
  var listener = function listener() {
    socket.emit('mobile:patient:update', {
      timestamp: Date.now()
    });
  };

  _mobile2.default.on('mobile:patient:update', listener);

  socket.on('disconnect', function () {
    _mobile2.default.removeListener('mobile:patient:update', listener);
  });
}

function appointmentUpdate(socket) {
  var listener = function listener() {
    socket.emit('appointment:update', {
      timestamp: Date.now()
    });
  };

  _mobile2.default.on('appointment:update', listener);

  socket.on('disconnect', function () {
    _mobile2.default.removeListener('appointment:update', listener);
  });
}

function settlement(socket) {
  var listener = function listener() {
    socket.emit('prescription:settlement', {
      timestamp: Date.now()
    });
  };

  _mobile2.default.on('prescription:settlement', listener);

  socket.on('disconnect', function () {
    _mobile2.default.removeListener('prescription:settlement', listener);
  });
}

function saveDrugAvailability(socket) {
  var listener = function listener() {
    socket.emit('mobile:medicine:availability:create', {
      timestamp: Date.now()
    });
  };

  _mobile2.default.on('mobile:medicine:availability:create', listener);

  socket.on('disconnect', function () {
    _mobile2.default.removeListener('mobile:medicine:availability:create', listener);
  });
}
//# sourceMappingURL=mobile.socket.js.map
