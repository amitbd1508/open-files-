'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.uploading = exports.appointmentsImageUpload = exports.patientImageUpload = exports.flagDoctorForPrescription = exports.rateDoctorForPrescription = exports.settlementForPrescription = exports.savePayment = exports.saveDrugAvailability = exports.findMedicinesAvailability = exports.findTodaysPrescriptions = exports.findPrescriptions = exports.prescriptionsByPatientsSerialKey = exports.findAppointmentByPatientIdByToday = exports.findAppointmentsByPatientIdByRange = exports.findTodaysAppointmentsByPatientId = exports.findTodaysAppointmentsByDoctorId = exports.findAppointmentsByDoctorId = exports.doctorSchedule = exports.findAvailableDoctorsToday = exports.findAvailableDoctors = exports.findTodaysAppointments = exports.findAppointments = exports.updateAppointment = exports.bookAppointment = exports.patientsRegisteredByRMPByToday = exports.patientsRegisteredByRMPByDateRange = exports.updatePatient = exports.showPatient = exports.getSerialKeys = exports.registerPatient = exports.saveLocation = exports.summary = exports.login = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */
var login = exports.login = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var userId, user, token;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            userId = req.params.userId;

            if (userId.match(/^[a-f\d]{24}$/i)) {
              _context.next = 4;
              break;
            }

            throw new Error(_mobile3.default.scanTheRightQR.message);

          case 4:
            _context.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPUser.findById(userId).exec());

          case 6:
            user = _context.sent;

            if (user) {
              _context.next = 9;
              break;
            }

            throw new Error(_mobile3.default.scanTheRightQR.message);

          case 9:
            if (user.is_active) {
              _context.next = 11;
              break;
            }

            throw new Error(_mobile3.default.accountDisabled.message);

          case 11:
            _context.next = 13;
            return (0, _bluebird.resolve)(_mobile.RMPUser.login(userId));

          case 13:
            token = _context.sent;


            res.json({
              timestamp: Date.now(),
              projotnoToken: token
            });
            _context.next = 20;
            break;

          case 17:
            _context.prev = 17;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 20:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 17]]);
  }));

  return function login(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var summary = exports.summary = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var userId, rmp;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            userId = req.userId;
            _context2.next = 4;
            return (0, _bluebird.resolve)(_mobile.RMPUser.fetch(userId));

          case 4:
            rmp = _context2.sent;


            res.json(rmp);
            _context2.next = 11;
            break;

          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 11:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 8]]);
  }));

  return function summary(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var saveLocation = exports.saveLocation = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var formData, userId, location;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            formData = JSON.parse(req.query.position);

            if (formData.coords) {
              _context3.next = 4;
              break;
            }

            throw new Error('Location error');

          case 4:
            userId = req.userId;
            _context3.next = 7;
            return (0, _bluebird.resolve)(_mobile.RMPLocation.saveLocation(userId, formData));

          case 7:
            location = _context3.sent;


            res.json({
              timestamp: Date.now(),
              location: location
            });

            _context3.next = 14;
            break;

          case 11:
            _context3.prev = 11;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 11]]);
  }));

  return function saveLocation(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var registerPatient = exports.registerPatient = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var id, userId, formData, patient;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            id = req.params.id;

            if (!id) res.status(400).end(_mobile3.default.paramsNotFound);

            _context4.prev = 2;
            userId = req.userId;
            formData = req.query;
            _context4.next = 7;
            return (0, _bluebird.resolve)(_mobile.RMPPatient.registerPatient(userId, id, formData));

          case 7:
            patient = _context4.sent;


            res.json({
              timestamp: Date.now(),
              patient: patient
            });
            _context4.next = 14;
            break;

          case 11:
            _context4.prev = 11;
            _context4.t0 = _context4['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 14:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[2, 11]]);
  }));

  return function registerPatient(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var getSerialKeys = exports.getSerialKeys = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var userId, serialKeys;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            userId = req.userId;
            _context5.next = 4;
            return (0, _bluebird.resolve)(_mobile.RMPPatient.getSerialKeys(userId));

          case 4:
            serialKeys = _context5.sent;


            res.json({
              timestamp: Date.now(),
              serialKeys: serialKeys
            });
            _context5.next = 11;
            break;

          case 8:
            _context5.prev = 8;
            _context5.t0 = _context5['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 11:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 8]]);
  }));

  return function getSerialKeys(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var showPatient = exports.showPatient = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var serialKey, patient;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            serialKey = req.params.serialKey;

            if (!serialKey) res.status(400).end(_mobile3.default.paramsNotFound);

            _context6.prev = 2;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_mobile.RMPPatient.showPatient(serialKey));

          case 5:
            patient = _context6.sent;


            res.json({
              timestamp: new Date(),
              patient: patient
            });
            _context6.next = 12;
            break;

          case 9:
            _context6.prev = 9;
            _context6.t0 = _context6['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0.toString()
            });

          case 12:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[2, 9]]);
  }));

  return function showPatient(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var updatePatient = exports.updatePatient = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var id, formBody, patient;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            id = req.params.id;
            formBody = req.query;

            if (!id) res.status(400).end(_mobile3.default.paramsNotFound);

            _context7.prev = 3;
            _context7.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPPatient.updatePatient(id, formBody));

          case 6:
            patient = _context7.sent;


            res.json({
              timestamp: new Date(),
              patient: patient
            });
            _context7.next = 13;
            break;

          case 10:
            _context7.prev = 10;
            _context7.t0 = _context7['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context7.t0.toString()
            });

          case 13:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[3, 10]]);
  }));

  return function updatePatient(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var patientsRegisteredByRMPByDateRange = exports.patientsRegisteredByRMPByDateRange = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(req, res) {
    var rmpId, startDate, endDate, patients;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            rmpId = req.userId;
            startDate = req.query.startDate;
            endDate = req.query.endDate;
            _context8.prev = 3;
            _context8.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPPatient.patientsRegisteredByRMPByDateRange(rmpId, startDate, endDate));

          case 6:
            patients = _context8.sent;


            res.json({
              timestamp: Date.now(),
              patients: patients
            });
            _context8.next = 13;
            break;

          case 10:
            _context8.prev = 10;
            _context8.t0 = _context8['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context8.t0.toString()
            });

          case 13:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this, [[3, 10]]);
  }));

  return function patientsRegisteredByRMPByDateRange(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

var patientsRegisteredByRMPByToday = exports.patientsRegisteredByRMPByToday = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(req, res) {
    var rmpId, patients;
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            rmpId = req.userId;
            _context9.prev = 1;
            _context9.next = 4;
            return (0, _bluebird.resolve)(_mobile.RMPPatient.patientsRegisteredByRMPByToday(rmpId));

          case 4:
            patients = _context9.sent;


            res.json({
              timestamp: Date.now(),
              patients: patients
            });
            _context9.next = 11;
            break;

          case 8:
            _context9.prev = 8;
            _context9.t0 = _context9['catch'](1);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context9.t0.toString()
            });

          case 11:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this, [[1, 8]]);
  }));

  return function patientsRegisteredByRMPByToday(_x17, _x18) {
    return _ref9.apply(this, arguments);
  };
}();

var bookAppointment = exports.bookAppointment = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(req, res) {
    var appointmentForm, appointmentId, appointment;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            appointmentForm = req.query;
            appointmentId = req.params.id;

            if (!appointmentId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context10.prev = 3;
            _context10.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.bookAppointment(appointmentId, appointmentForm));

          case 6:
            appointment = _context10.sent;


            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context10.next = 13;
            break;

          case 10:
            _context10.prev = 10;
            _context10.t0 = _context10['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context10.t0.toString()
            });

          case 13:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this, [[3, 10]]);
  }));

  return function bookAppointment(_x19, _x20) {
    return _ref10.apply(this, arguments);
  };
}();

var updateAppointment = exports.updateAppointment = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee11(req, res) {
    var appointmentForm, appointmentId, appointment;
    return _regenerator2.default.wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            appointmentForm = req.query;
            appointmentId = req.params.id;

            if (!appointmentId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context11.prev = 3;
            _context11.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.updateAppointment(appointmentId, appointmentForm));

          case 6:
            appointment = _context11.sent;


            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context11.next = 13;
            break;

          case 10:
            _context11.prev = 10;
            _context11.t0 = _context11['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context11.t0.toString()
            });

          case 13:
          case 'end':
            return _context11.stop();
        }
      }
    }, _callee11, this, [[3, 10]]);
  }));

  return function updateAppointment(_x21, _x22) {
    return _ref11.apply(this, arguments);
  };
}();

var findAppointments = exports.findAppointments = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee12(req, res) {
    var rmpId, startDate, endDate, appointments;
    return _regenerator2.default.wrap(function _callee12$(_context12) {
      while (1) {
        switch (_context12.prev = _context12.next) {
          case 0:
            rmpId = req.userId;
            startDate = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate).toDate() : '';
            endDate = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate).toDate() : '';
            _context12.prev = 3;
            _context12.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.findAppointments(rmpId, startDate, endDate));

          case 6:
            appointments = _context12.sent;


            res.json({
              timestamp: Date.now(),
              appointments: appointments
            });
            _context12.next = 13;
            break;

          case 10:
            _context12.prev = 10;
            _context12.t0 = _context12['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context12.t0.toString()
            });

          case 13:
          case 'end':
            return _context12.stop();
        }
      }
    }, _callee12, this, [[3, 10]]);
  }));

  return function findAppointments(_x23, _x24) {
    return _ref12.apply(this, arguments);
  };
}();

var findTodaysAppointments = exports.findTodaysAppointments = function () {
  var _ref13 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee13(req, res) {
    var rmpId, appointments;
    return _regenerator2.default.wrap(function _callee13$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            _context13.prev = 0;
            rmpId = req.userId;
            _context13.next = 4;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.findTodaysAppointments(rmpId));

          case 4:
            appointments = _context13.sent;


            res.json({
              timestamp: Date.now(),
              appointments: appointments
            });
            _context13.next = 11;
            break;

          case 8:
            _context13.prev = 8;
            _context13.t0 = _context13['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context13.t0.toString()
            });

          case 11:
          case 'end':
            return _context13.stop();
        }
      }
    }, _callee13, this, [[0, 8]]);
  }));

  return function findTodaysAppointments(_x25, _x26) {
    return _ref13.apply(this, arguments);
  };
}();

var findAvailableDoctors = exports.findAvailableDoctors = function () {
  var _ref14 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee14(req, res) {
    var dateStartOfDay, dateEndOfDay, startDate, endDate, dateNow, doctors;
    return _regenerator2.default.wrap(function _callee14$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            dateStartOfDay = (0, _momentTimezone2.default)().startOf('day').toDate();
            dateEndOfDay = (0, _momentTimezone2.default)().endOf('day').toDate();
            startDate = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate).startOf('day').toDate() : dateStartOfDay;
            endDate = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate).endOf('day').toDate() : dateEndOfDay;
            dateNow = req.query.startDate && req.query.endDate ? (0, _momentTimezone2.default)(req.query.startDate).toDate() : (0, _momentTimezone2.default)().toDate();
            _context14.prev = 5;
            _context14.next = 8;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.findAvailableDoctors(dateNow, startDate, endDate));

          case 8:
            doctors = _context14.sent;


            res.json({
              timestamp: Date.now(),
              doctors: doctors
            });
            _context14.next = 15;
            break;

          case 12:
            _context14.prev = 12;
            _context14.t0 = _context14['catch'](5);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context14.t0.toString()
            });

          case 15:
          case 'end':
            return _context14.stop();
        }
      }
    }, _callee14, this, [[5, 12]]);
  }));

  return function findAvailableDoctors(_x27, _x28) {
    return _ref14.apply(this, arguments);
  };
}();

var findAvailableDoctorsToday = exports.findAvailableDoctorsToday = function () {
  var _ref15 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee15(req, res) {
    var dateNow, startDate, endDate, doctors;
    return _regenerator2.default.wrap(function _callee15$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            dateNow = (0, _momentTimezone2.default)().toDate();
            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();
            _context15.prev = 3;
            _context15.next = 6;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.findAvailableDoctors(dateNow, startDate, endDate));

          case 6:
            doctors = _context15.sent;


            res.json({
              timestamp: Date.now(),
              doctors: doctors
            });
            _context15.next = 13;
            break;

          case 10:
            _context15.prev = 10;
            _context15.t0 = _context15['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context15.t0.toString()
            });

          case 13:
          case 'end':
            return _context15.stop();
        }
      }
    }, _callee15, this, [[3, 10]]);
  }));

  return function findAvailableDoctorsToday(_x29, _x30) {
    return _ref15.apply(this, arguments);
  };
}();

var doctorSchedule = exports.doctorSchedule = function () {
  var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee16(req, res) {
    var _doctorSchedule;

    return _regenerator2.default.wrap(function _callee16$(_context16) {
      while (1) {
        switch (_context16.prev = _context16.next) {
          case 0:
            _context16.prev = 0;
            _context16.next = 3;
            return (0, _bluebird.resolve)(_doctorSchedule2.Schedule.findOneLatestWithDetails());

          case 3:
            _doctorSchedule = _context16.sent;


            res.json({
              timestamp: Date.now(),
              doctorSchedule: _doctorSchedule
            });
            _context16.next = 10;
            break;

          case 7:
            _context16.prev = 7;
            _context16.t0 = _context16['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context16.t0.toString()
            });

          case 10:
          case 'end':
            return _context16.stop();
        }
      }
    }, _callee16, this, [[0, 7]]);
  }));

  return function doctorSchedule(_x31, _x32) {
    return _ref16.apply(this, arguments);
  };
}();

var findAppointmentsByDoctorId = exports.findAppointmentsByDoctorId = function () {
  var _ref17 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee17(req, res) {
    var query, dateStartOfHour, dateEndOfDay, startDate, endDate, doctorId, appointments;
    return _regenerator2.default.wrap(function _callee17$(_context17) {
      while (1) {
        switch (_context17.prev = _context17.next) {
          case 0:
            query = {};
            dateStartOfHour = (0, _momentTimezone2.default)().startOf('hour').toDate();
            dateEndOfDay = (0, _momentTimezone2.default)().endOf('day').toDate();
            startDate = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate).toDate() : dateStartOfHour;
            endDate = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate).toDate() : dateEndOfDay;
            doctorId = req.params.id;

            if (!doctorId) res.status(400).end(_mobile3.default.paramsNotFound);

            query.doctors_id = doctorId;

            if (startDate && endDate) {
              query.start = {
                $gte: startDate,
                $lte: endDate
              };
            }

            _context17.prev = 9;
            _context17.next = 12;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.getAppointmentsByDoctorId(query));

          case 12:
            appointments = _context17.sent;


            res.json({
              timestamp: Date.now(),
              appointments: appointments
            });
            _context17.next = 19;
            break;

          case 16:
            _context17.prev = 16;
            _context17.t0 = _context17['catch'](9);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context17.t0.toString()
            });

          case 19:
          case 'end':
            return _context17.stop();
        }
      }
    }, _callee17, this, [[9, 16]]);
  }));

  return function findAppointmentsByDoctorId(_x33, _x34) {
    return _ref17.apply(this, arguments);
  };
}();

var findTodaysAppointmentsByDoctorId = exports.findTodaysAppointmentsByDoctorId = function () {
  var _ref18 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee18(req, res) {
    var query, dateStartOfHour, dateEndOfDay, doctorId, appointments;
    return _regenerator2.default.wrap(function _callee18$(_context18) {
      while (1) {
        switch (_context18.prev = _context18.next) {
          case 0:
            query = {};
            dateStartOfHour = (0, _momentTimezone2.default)().startOf('hour').toDate();
            dateEndOfDay = (0, _momentTimezone2.default)().endOf('day').toDate();
            doctorId = req.params.id;

            if (!doctorId) res.status(400).end(_mobile3.default.paramsNotFound);

            query.start = {
              $gte: dateStartOfHour,
              $lte: dateEndOfDay
            };

            _context18.prev = 6;
            _context18.next = 9;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.getAppointmentsByDoctorId(query));

          case 9:
            appointments = _context18.sent;


            res.json({
              timestamp: Date.now(),
              appointments: appointments
            });
            _context18.next = 16;
            break;

          case 13:
            _context18.prev = 13;
            _context18.t0 = _context18['catch'](6);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context18.t0.toString()
            });

          case 16:
          case 'end':
            return _context18.stop();
        }
      }
    }, _callee18, this, [[6, 13]]);
  }));

  return function findTodaysAppointmentsByDoctorId(_x35, _x36) {
    return _ref18.apply(this, arguments);
  };
}();

var findTodaysAppointmentsByPatientId = exports.findTodaysAppointmentsByPatientId = function () {
  var _ref19 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee19(req, res) {
    var startOfDay, endOfDay, patientId, appointment;
    return _regenerator2.default.wrap(function _callee19$(_context19) {
      while (1) {
        switch (_context19.prev = _context19.next) {
          case 0:
            startOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').startOf('day').toDate();
            endOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').endOf('day').toDate();
            patientId = req.params.id;

            if (!patientId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context19.prev = 4;
            _context19.next = 7;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.findAppointmentByPatientId(patientId, startOfDay, endOfDay));

          case 7:
            appointment = _context19.sent;


            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context19.next = 14;
            break;

          case 11:
            _context19.prev = 11;
            _context19.t0 = _context19['catch'](4);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context19.t0.toString()
            });

          case 14:
          case 'end':
            return _context19.stop();
        }
      }
    }, _callee19, this, [[4, 11]]);
  }));

  return function findTodaysAppointmentsByPatientId(_x37, _x38) {
    return _ref19.apply(this, arguments);
  };
}();

var findAppointmentsByPatientIdByRange = exports.findAppointmentsByPatientIdByRange = function () {
  var _ref20 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee20(req, res) {
    var patientId, startDate, endDate, appointments;
    return _regenerator2.default.wrap(function _callee20$(_context20) {
      while (1) {
        switch (_context20.prev = _context20.next) {
          case 0:
            patientId = req.params.id;

            if (!patientId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context20.prev = 2;
            startDate = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate).toDate() : '';
            endDate = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate).toDate() : '';
            _context20.next = 7;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.findAppointmentsByPatientIdByRange(patientId, startDate, endDate));

          case 7:
            appointments = _context20.sent;


            res.json({
              timestamp: Date.now(),
              appointments: appointments
            });
            _context20.next = 14;
            break;

          case 11:
            _context20.prev = 11;
            _context20.t0 = _context20['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context20.t0.toString()
            });

          case 14:
          case 'end':
            return _context20.stop();
        }
      }
    }, _callee20, this, [[2, 11]]);
  }));

  return function findAppointmentsByPatientIdByRange(_x39, _x40) {
    return _ref20.apply(this, arguments);
  };
}();

var findAppointmentByPatientIdByToday = exports.findAppointmentByPatientIdByToday = function () {
  var _ref21 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee21(req, res) {
    var patientId, appointment;
    return _regenerator2.default.wrap(function _callee21$(_context21) {
      while (1) {
        switch (_context21.prev = _context21.next) {
          case 0:
            patientId = req.params.id;

            if (!patientId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context21.prev = 2;
            _context21.next = 5;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.findAppointmentByToday(patientId));

          case 5:
            appointment = _context21.sent;


            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context21.next = 12;
            break;

          case 9:
            _context21.prev = 9;
            _context21.t0 = _context21['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context21.t0.toString()
            });

          case 12:
          case 'end':
            return _context21.stop();
        }
      }
    }, _callee21, this, [[2, 9]]);
  }));

  return function findAppointmentByPatientIdByToday(_x41, _x42) {
    return _ref21.apply(this, arguments);
  };
}();

var prescriptionsByPatientsSerialKey = exports.prescriptionsByPatientsSerialKey = function () {
  var _ref22 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee22(req, res) {
    var serialKey, limit, skip, prescriptions;
    return _regenerator2.default.wrap(function _callee22$(_context22) {
      while (1) {
        switch (_context22.prev = _context22.next) {
          case 0:
            serialKey = req.params.serialKey;

            if (!serialKey) res.status(400).end(_mobile3.default.paramsNotFound);

            _context22.prev = 2;
            limit = req.query.limit;
            skip = req.query.skip;
            _context22.next = 7;
            return (0, _bluebird.resolve)(_mobile.RMPPrescription.prescriptionsByPatientsSerialKey(serialKey, limit, skip));

          case 7:
            prescriptions = _context22.sent;


            res.json({
              timestamp: Date.now(),
              prescriptions: prescriptions
            });
            _context22.next = 14;
            break;

          case 11:
            _context22.prev = 11;
            _context22.t0 = _context22['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context22.t0.toString()
            });

          case 14:
          case 'end':
            return _context22.stop();
        }
      }
    }, _callee22, this, [[2, 11]]);
  }));

  return function prescriptionsByPatientsSerialKey(_x43, _x44) {
    return _ref22.apply(this, arguments);
  };
}();

var findPrescriptions = exports.findPrescriptions = function () {
  var _ref23 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee23(req, res) {
    var userId, seen, query, prescriptions;
    return _regenerator2.default.wrap(function _callee23$(_context23) {
      while (1) {
        switch (_context23.prev = _context23.next) {
          case 0:
            _context23.prev = 0;
            userId = req.userId;
            seen = req.query.seen || false;
            query = {};

            query.rmp_seen = seen;
            query.rmp_id = userId;
            query.is_pdfready = true;

            _context23.next = 9;
            return (0, _bluebird.resolve)(_mobile.RMPPrescription.findPrescriptions(query));

          case 9:
            prescriptions = _context23.sent;


            res.json({
              timestamp: Date.now(),
              prescriptions: prescriptions
            });
            _context23.next = 16;
            break;

          case 13:
            _context23.prev = 13;
            _context23.t0 = _context23['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context23.t0.toString()
            });

          case 16:
          case 'end':
            return _context23.stop();
        }
      }
    }, _callee23, this, [[0, 13]]);
  }));

  return function findPrescriptions(_x45, _x46) {
    return _ref23.apply(this, arguments);
  };
}();

var findTodaysPrescriptions = exports.findTodaysPrescriptions = function () {
  var _ref24 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee24(req, res) {
    var rmpId, prescriptions;
    return _regenerator2.default.wrap(function _callee24$(_context24) {
      while (1) {
        switch (_context24.prev = _context24.next) {
          case 0:
            _context24.prev = 0;
            rmpId = req.userId;
            _context24.next = 4;
            return (0, _bluebird.resolve)(_mobile.RMPPrescription.findTodaysPrescriptions(rmpId));

          case 4:
            prescriptions = _context24.sent;


            res.json({
              timestamp: Date.now(),
              prescriptions: prescriptions
            });
            _context24.next = 11;
            break;

          case 8:
            _context24.prev = 8;
            _context24.t0 = _context24['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context24.t0.toString()
            });

          case 11:
          case 'end':
            return _context24.stop();
        }
      }
    }, _callee24, this, [[0, 8]]);
  }));

  return function findTodaysPrescriptions(_x47, _x48) {
    return _ref24.apply(this, arguments);
  };
}();

var findMedicinesAvailability = exports.findMedicinesAvailability = function () {
  var _ref25 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee25(req, res) {
    var rmpId, prescriptions;
    return _regenerator2.default.wrap(function _callee25$(_context25) {
      while (1) {
        switch (_context25.prev = _context25.next) {
          case 0:
            _context25.prev = 0;
            rmpId = req.userId;
            _context25.next = 4;
            return (0, _bluebird.resolve)(_mobile.RMPPrescription.findMedicinesAvailability(rmpId));

          case 4:
            prescriptions = _context25.sent;


            res.json({
              timestamp: Date.now(),
              prescriptions: prescriptions
            });
            _context25.next = 11;
            break;

          case 8:
            _context25.prev = 8;
            _context25.t0 = _context25['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context25.t0.toString()
            });

          case 11:
          case 'end':
            return _context25.stop();
        }
      }
    }, _callee25, this, [[0, 8]]);
  }));

  return function findMedicinesAvailability(_x49, _x50) {
    return _ref25.apply(this, arguments);
  };
}();

var saveDrugAvailability = exports.saveDrugAvailability = function () {
  var _ref26 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee26(req, res) {
    var rmpId, formData, drugAvailability;
    return _regenerator2.default.wrap(function _callee26$(_context26) {
      while (1) {
        switch (_context26.prev = _context26.next) {
          case 0:
            _context26.prev = 0;
            rmpId = req.userId;
            formData = req.query;
            _context26.next = 5;
            return (0, _bluebird.resolve)(_mobile.RMPDrugAvailability.saveDrugAvailability(rmpId, formData));

          case 5:
            drugAvailability = _context26.sent;


            res.json({
              timestamp: Date.now(),
              drugAvailability: drugAvailability
            });
            _context26.next = 12;
            break;

          case 9:
            _context26.prev = 9;
            _context26.t0 = _context26['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context26.t0.toString()
            });

          case 12:
          case 'end':
            return _context26.stop();
        }
      }
    }, _callee26, this, [[0, 9]]);
  }));

  return function saveDrugAvailability(_x51, _x52) {
    return _ref26.apply(this, arguments);
  };
}();

var savePayment = exports.savePayment = function () {
  var _ref27 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee27(req, res) {
    var userId, trxId, bKashReceiver, bKashURL, payment;
    return _regenerator2.default.wrap(function _callee27$(_context27) {
      while (1) {
        switch (_context27.prev = _context27.next) {
          case 0:
            userId = req.userId;
            trxId = req.params.trxId;
            bKashReceiver = _mobile3.default.bKash.receiverNew;
            bKashURL = _mobile3.default.bKash.URLNew;


            if (!trxId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context27.prev = 5;
            _context27.next = 8;
            return (0, _bluebird.resolve)(_mobile.RMPPayment.savePayment(trxId, userId, bKashURL, bKashReceiver));

          case 8:
            payment = _context27.sent;


            res.status(201).json({
              timestamp: Date.now(),
              payment: payment
            });
            _context27.next = 15;
            break;

          case 12:
            _context27.prev = 12;
            _context27.t0 = _context27['catch'](5);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context27.t0.toString()
            });

          case 15:
          case 'end':
            return _context27.stop();
        }
      }
    }, _callee27, this, [[5, 12]]);
  }));

  return function savePayment(_x53, _x54) {
    return _ref27.apply(this, arguments);
  };
}();

var settlementForPrescription = exports.settlementForPrescription = function () {
  var _ref28 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee28(req, res) {
    var userId, prescriptionId, settlement;
    return _regenerator2.default.wrap(function _callee28$(_context28) {
      while (1) {
        switch (_context28.prev = _context28.next) {
          case 0:
            userId = req.userId;
            prescriptionId = req.params.id;

            if (!prescriptionId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context28.prev = 3;
            _context28.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPPrescription.settlement(prescriptionId, userId));

          case 6:
            settlement = _context28.sent;


            res.json({
              timestamp: Date.now(),
              settlement: settlement
            });
            _context28.next = 13;
            break;

          case 10:
            _context28.prev = 10;
            _context28.t0 = _context28['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context28.t0.toString()
            });

          case 13:
          case 'end':
            return _context28.stop();
        }
      }
    }, _callee28, this, [[3, 10]]);
  }));

  return function settlementForPrescription(_x55, _x56) {
    return _ref28.apply(this, arguments);
  };
}();

var rateDoctorForPrescription = exports.rateDoctorForPrescription = function () {
  var _ref29 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee29(req, res) {
    var rmpId, prescriptionId, rate, rating;
    return _regenerator2.default.wrap(function _callee29$(_context29) {
      while (1) {
        switch (_context29.prev = _context29.next) {
          case 0:
            rmpId = req.userId;
            prescriptionId = req.params.id;
            rate = req.query;
            _context29.prev = 3;
            _context29.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPRating.rate(rmpId, prescriptionId, rate));

          case 6:
            rating = _context29.sent;


            res.json({
              timestamp: Date.now(),
              rating: rating
            });
            _context29.next = 13;
            break;

          case 10:
            _context29.prev = 10;
            _context29.t0 = _context29['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context29.t0.toString()
            });

          case 13:
          case 'end':
            return _context29.stop();
        }
      }
    }, _callee29, this, [[3, 10]]);
  }));

  return function rateDoctorForPrescription(_x57, _x58) {
    return _ref29.apply(this, arguments);
  };
}();

var flagDoctorForPrescription = exports.flagDoctorForPrescription = function () {
  var _ref30 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee30(req, res) {
    var rmpId, prescriptionId, flagBody, flag;
    return _regenerator2.default.wrap(function _callee30$(_context30) {
      while (1) {
        switch (_context30.prev = _context30.next) {
          case 0:
            rmpId = req.userId;
            prescriptionId = req.params.id;
            flagBody = req.query;
            _context30.prev = 3;
            _context30.next = 6;
            return (0, _bluebird.resolve)(_mobile.DoctorFlag.flag(rmpId, prescriptionId, flagBody));

          case 6:
            flag = _context30.sent;


            res.json({
              timestamp: Date.now(),
              flag: flag
            });
            _context30.next = 13;
            break;

          case 10:
            _context30.prev = 10;
            _context30.t0 = _context30['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context30.t0.toString()
            });

          case 13:
          case 'end':
            return _context30.stop();
        }
      }
    }, _callee30, this, [[3, 10]]);
  }));

  return function flagDoctorForPrescription(_x59, _x60) {
    return _ref30.apply(this, arguments);
  };
}();

var patientImageUpload = exports.patientImageUpload = function () {
  var _ref31 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee31(req, res) {
    var location, patientId, formBody, patient;
    return _regenerator2.default.wrap(function _callee31$(_context31) {
      while (1) {
        switch (_context31.prev = _context31.next) {
          case 0:
            _context31.prev = 0;
            location = req.file.location;
            patientId = req.params.id;


            if (!patientId) res.status(400).end(_mobile3.default.paramsNotFound);

            formBody = {
              profilepiclink: location
            };
            _context31.next = 7;
            return (0, _bluebird.resolve)(_mobile.RMPPatient.updatePatient(patientId, formBody));

          case 7:
            patient = _context31.sent;


            _mobile5.default.emit('mobile:patient:update');

            res.json({
              timestamp: Date.now(),
              patient: patient
            });
            _context31.next = 15;
            break;

          case 12:
            _context31.prev = 12;
            _context31.t0 = _context31['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context31.t0.toString()
            });

          case 15:
          case 'end':
            return _context31.stop();
        }
      }
    }, _callee31, this, [[0, 12]]);
  }));

  return function patientImageUpload(_x61, _x62) {
    return _ref31.apply(this, arguments);
  };
}();

var appointmentsImageUpload = exports.appointmentsImageUpload = function () {
  var _ref32 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee32(req, res) {
    var location, appointmentId, appointment;
    return _regenerator2.default.wrap(function _callee32$(_context32) {
      while (1) {
        switch (_context32.prev = _context32.next) {
          case 0:
            _context32.prev = 0;
            location = req.file.location;
            appointmentId = req.params.id;


            if (!appointmentId) res.status(400).end(_mobile3.default.paramsNotFound);

            _context32.next = 6;
            return (0, _bluebird.resolve)(_mobile.RMPAppointment.findByIdAndUpdate(appointmentId, {
              $push: {
                patients_images: location
              }
            }).exec());

          case 6:
            appointment = _context32.sent;


            _mobile5.default.emit('appointment:update');

            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context32.next = 14;
            break;

          case 11:
            _context32.prev = 11;
            _context32.t0 = _context32['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context32.t0.toString()
            });

          case 14:
          case 'end':
            return _context32.stop();
        }
      }
    }, _callee32, this, [[0, 11]]);
  }));

  return function appointmentsImageUpload(_x63, _x64) {
    return _ref32.apply(this, arguments);
  };
}();

var _mobile = require('./mobile.model');

var _appointmentTransfer = require('../appointment-transfer/appointment-transfer.model');

var _doctorSchedule2 = require('../doctor-schedule/doctor-schedule.model');

var _mobile2 = require('./mobile.responses');

var _mobile3 = _interopRequireDefault(_mobile2);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _mobile4 = require('./mobile.events');

var _mobile5 = _interopRequireDefault(_mobile4);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var multer = require('multer');
var multerS3 = require('multer-s3');
var environment = require('../../config/environment');

_awsSdk2.default.config.update(environment.aws);

var s3 = new _awsSdk2.default.S3();var uploading = exports.uploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: environment.aws.s3_bucket,
    location: function location(req, file, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function key(req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('profile');
//# sourceMappingURL=mobile.controller.js.map
