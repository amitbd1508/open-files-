'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Feedback = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var createOrUpdate = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(appointmentId, userId, formData) {
    var feedback;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Feedback.findOne({
              appointmentId: appointmentId
            }).exec());

          case 2:
            feedback = _context.sent;

            if (!(feedback === null)) {
              _context.next = 19;
              break;
            }

            feedback = new Feedback();

            feedback.createdBy = userId;
            feedback.appointmentId = appointmentId;
            feedback.incident = formData.incident;
            feedback.rate = formData.rate;
            feedback.rateText = formData.rateText;
            feedback.note = formData.note;
            feedback.type = 'appointment';
            feedback.isMarked = false;

            _feedback5.default.emit('feedback:create');

            _context.next = 16;
            return (0, _bluebird.resolve)(feedback.save());

          case 16:
            return _context.abrupt('return', _context.sent);

          case 19:

            feedback.incident = formData.incident;
            feedback.note = formData.note;
            feedback.rate = formData.rate;
            feedback.rateText = formData.rateText;
            feedback.isMarked = false;

            _feedback5.default.emit('feedback:update');

            _context.next = 27;
            return (0, _bluebird.resolve)(feedback.save());

          case 27:
            return _context.abrupt('return', _context.sent);

          case 28:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function createOrUpdate(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

var findAppointmentsFeedbacks = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(startDate, endDate, doctorsIds) {
    var limit = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 50;
    var skip = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
    var dateStartOfWeek, dateEndOfWeek, type, query;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            dateStartOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            dateEndOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();
            type = "appointment";


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : dateStartOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : dateEndOfWeek;

            _context2.next = 7;
            return (0, _bluebird.resolve)(filters(startDate, endDate, doctorsIds, type));

          case 7:
            query = _context2.sent;
            _context2.next = 10;
            return (0, _bluebird.resolve)(Feedback.find(query).populate({
              path: 'createdBy',
              select: 'fullname profile_url specialized'
            }).limit(parseInt(limit)).skip(parseInt(skip)).sort('-createdAt').exec());

          case 10:
            return _context2.abrupt('return', _context2.sent);

          case 11:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findAppointmentsFeedbacks(_x4, _x5, _x6, _x7, _x8) {
    return _ref2.apply(this, arguments);
  };
}();

var findLogoutsFeedbacks = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(startDate, endDate, doctorIds) {
    var limit = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 50;
    var skip = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
    var dateStartOfWeek, dateEndOfWeek, type, query;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            dateStartOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            dateEndOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();
            type = "logOut";


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : dateStartOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : dateEndOfWeek;

            _context3.next = 7;
            return (0, _bluebird.resolve)(filters(startDate, endDate, doctorIds, type));

          case 7:
            query = _context3.sent;
            _context3.next = 10;
            return (0, _bluebird.resolve)(Feedback.find(query).populate({
              path: 'createdBy',
              select: 'fullname profile_url specialized'
            }).limit(parseInt(limit)).skip(parseInt(skip)).sort('-createdAt').exec());

          case 10:
            return _context3.abrupt('return', _context3.sent);

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findLogoutsFeedbacks(_x11, _x12, _x13, _x14, _x15) {
    return _ref3.apply(this, arguments);
  };
}();

var findCount = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(startDate, endDate, type) {
    var dateStartOfWeek, dateEndOfWeek, query;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            dateStartOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            dateEndOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : dateStartOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : dateEndOfWeek;

            query = {
              createdAt: {
                $gte: startDate,
                $lte: endDate
              },
              type: type
            };
            _context4.next = 7;
            return (0, _bluebird.resolve)(Feedback.count(query).exec());

          case 7:
            return _context4.abrupt('return', _context4.sent);

          case 8:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findCount(_x18, _x19, _x20) {
    return _ref4.apply(this, arguments);
  };
}();

var markFeedback = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(userId) {
    var startDate, endDate, feedback, _feedback;

    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();
            _context5.next = 4;
            return (0, _bluebird.resolve)(Feedback.findOne({
              createdAt: {
                $gte: startDate,
                $lte: endDate
              },
              createdBy: userId,
              type: 'logOut',
              isMarked: true
            }).exec());

          case 4:
            feedback = _context5.sent;

            if (!feedback) {
              _context5.next = 9;
              break;
            }

            return _context5.abrupt('return', feedback);

          case 9:
            _feedback = new Feedback();


            _feedback.createdBy = userId;
            _feedback.type = 'logOut';
            _feedback.isMarked = true;

            _context5.next = 15;
            return (0, _bluebird.resolve)(_feedback.save());

          case 15:
            return _context5.abrupt('return', _context5.sent);

          case 16:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function markFeedback(_x21) {
    return _ref5.apply(this, arguments);
  };
}();

var updateByFeedbackId = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(feedbackId, formData) {
    var feedback;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(Feedback.findOne({
              _id: objectId(feedbackId)
            }).exec());

          case 2:
            feedback = _context6.sent;

            if (!(feedback === null)) {
              _context6.next = 16;
              break;
            }

            feedback = new Feedback();

            feedback.incident = formData.incident;
            feedback.feedback = formData.feedback;
            feedback.rate = formData.rate;
            feedback.rateText = formData.rateText;
            feedback.isMarked = false;

            _feedback5.default.emit('feedback:create');
            _context6.next = 13;
            return (0, _bluebird.resolve)(feedback.save());

          case 13:
            return _context6.abrupt('return', _context6.sent);

          case 16:

            feedback.incident = formData.incident;
            feedback.feedback = formData.feedback;
            feedback.rate = formData.rate;
            feedback.rateText = formData.rateText;
            feedback.isMarked = false;

            _feedback5.default.emit('feedback:update');

            _context6.next = 24;
            return (0, _bluebird.resolve)(feedback.save());

          case 24:
            return _context6.abrupt('return', _context6.sent);

          case 25:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function updateByFeedbackId(_x22, _x23) {
    return _ref6.apply(this, arguments);
  };
}();

var findByAppointmentId = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(appointmentId) {
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              appointmentId: appointmentId
            }).exec());

          case 2:
            return _context7.abrupt('return', _context7.sent);

          case 3:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function findByAppointmentId(_x24) {
    return _ref7.apply(this, arguments);
  };
}();

var findLastIncompleteFeedback = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(userId) {
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            _context8.next = 2;
            return (0, _bluebird.resolve)(Feedback.findOne({
              createdBy: userId,
              isMarked: true,
              type: 'logOut'
            }).sort('-createdAt').exec());

          case 2:
            return _context8.abrupt('return', _context8.sent);

          case 3:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function findLastIncompleteFeedback(_x25) {
    return _ref8.apply(this, arguments);
  };
}();

var filters = function () {
  var _ref9 = (0, _bluebird.method)(function (startDate, endDate, doctorIds, type) {
    var query = {
      createdAt: {
        $gte: startDate,
        $lte: endDate
      },
      type: type
    };
    if (doctorIds) {
      doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
      doctorIds = doctorIds.map(function (id) {
        return objectId(id);
      });
      doctorIds ? query.createdBy = { $in: doctorIds } : '';
    }
    return query;
  });

  return function filters(_x26, _x27, _x28, _x29) {
    return _ref9.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _feedback2 = require('../../schemas/feedback.schema');

var _feedback3 = _interopRequireDefault(_feedback2);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _feedback4 = require('./feedback.events');

var _feedback5 = _interopRequireDefault(_feedback4);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Statics
 */

_feedback3.default.static('createOrUpdate', createOrUpdate).static('findAppointmentsFeedbacks', findAppointmentsFeedbacks).static('findLogoutsFeedbacks', findLogoutsFeedbacks).static('findByAppointmentId', findByAppointmentId).static('markFeedback', markFeedback).static('updateByFeedbackId', updateByFeedbackId).static('findLastIncompleteFeedback', findLastIncompleteFeedback).static('findCount', findCount);

var Feedback = exports.Feedback = _mongoose2.default.model('Feedback', _feedback3.default, 'feedback');
//# sourceMappingURL=feedback.model.js.map
