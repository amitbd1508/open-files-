'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _feedback = require('./feedback.events');

var _feedback2 = _interopRequireDefault(_feedback);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
}

/**
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('feedback:create', {
      timestamp: Date.now()
    });
  };

  _feedback2.default.on('feedback:create', listener);

  socket.on('disconnect', function () {
    _feedback2.default.removeListener('feedback:create', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('feedback:update', {
      timestamp: Date.now()
    });
  };

  _feedback2.default.on('feedback:update', listener);

  socket.on('disconnect', function () {
    _feedback2.default.removeListener('feedback:update', listener);
  });
}
//# sourceMappingURL=feedback.socket.js.map
