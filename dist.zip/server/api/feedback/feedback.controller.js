'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findLastIncompleteFeedback = exports.markFeedback = exports.update = exports.findByAppointmentId = exports.findLogoutsFeedbacksAndCount = exports.findAppointmentsFeedbacksAndCount = exports.createOrUpdate = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var createOrUpdate = exports.createOrUpdate = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var appointmentId, userId, feedback;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            appointmentId = req.params.id;
            userId = req.user._id;


            if (!appointmentId) res.status(400).send();

            if (!req.body.rate) res.status(400).send();

            _context.next = 7;
            return (0, _bluebird.resolve)(_feedback.Feedback.createOrUpdate(appointmentId, userId, req.body));

          case 7:
            feedback = _context.sent;


            res.json({
              timestamp: Date.now(),
              feedback: feedback
            });
            _context.next = 14;
            break;

          case 11:
            _context.prev = 11;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 14:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 11]]);
  }));

  return function createOrUpdate(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var findAppointmentsFeedbacksAndCount = exports.findAppointmentsFeedbacksAndCount = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var startDate, endDate, limit, skip, doctorIds, type, appointmentsFeedbacks, count;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            startDate = req.query.startDate;
            endDate = req.query.endDate;
            limit = req.query.limit;
            skip = req.query.skip;
            doctorIds = req.query.doctorIds;
            type = "appointment";
            _context2.next = 9;
            return (0, _bluebird.resolve)(_feedback.Feedback.findAppointmentsFeedbacks(startDate, endDate, doctorIds, limit, skip));

          case 9:
            appointmentsFeedbacks = _context2.sent;
            _context2.next = 12;
            return (0, _bluebird.resolve)(_feedback.Feedback.findCount(startDate, endDate, type));

          case 12:
            count = _context2.sent;


            res.json({
              timestamp: Date.now(),
              appointmentsFeedbacks: appointmentsFeedbacks,
              count: count
            });
            _context2.next = 19;
            break;

          case 16:
            _context2.prev = 16;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 19:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 16]]);
  }));

  return function findAppointmentsFeedbacksAndCount(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findLogoutsFeedbacksAndCount = exports.findLogoutsFeedbacksAndCount = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var startDate, endDate, limit, skip, doctorIds, type, logoutsFeedbacks, count;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            startDate = req.query.startDate;
            endDate = req.query.endDate;
            limit = req.query.limit;
            skip = req.query.skip;
            doctorIds = req.query.doctorIds;
            type = "logOut";
            _context3.next = 9;
            return (0, _bluebird.resolve)(_feedback.Feedback.findLogoutsFeedbacks(startDate, endDate, doctorIds, limit, skip));

          case 9:
            logoutsFeedbacks = _context3.sent;
            _context3.next = 12;
            return (0, _bluebird.resolve)(_feedback.Feedback.findCount(startDate, endDate, type));

          case 12:
            count = _context3.sent;


            res.json({
              timestamp: Date.now(),
              logoutsFeedbacks: logoutsFeedbacks,
              count: count
            });
            _context3.next = 19;
            break;

          case 16:
            _context3.prev = 16;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 19:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 16]]);
  }));

  return function findLogoutsFeedbacksAndCount(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findByAppointmentId = exports.findByAppointmentId = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var appointmentId, feedback;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            appointmentId = req.params.id;
            _context4.next = 4;
            return (0, _bluebird.resolve)(_feedback.Feedback.findByAppointmentId(appointmentId));

          case 4:
            feedback = _context4.sent;


            res.json({
              timestamp: Date.now(),
              feedback: feedback
            });
            _context4.next = 11;
            break;

          case 8:
            _context4.prev = 8;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 11:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 8]]);
  }));

  return function findByAppointmentId(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var update = exports.update = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var feedbackId, formData, feedback;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            feedbackId = req.params.id;
            formData = req.body;
            _context5.next = 5;
            return (0, _bluebird.resolve)(_feedback.Feedback.updateByFeedbackId(feedbackId, formData));

          case 5:
            feedback = _context5.sent;


            res.json({
              timestamp: Date.now(),
              feedback: feedback
            });
            _context5.next = 12;
            break;

          case 9:
            _context5.prev = 9;
            _context5.t0 = _context5['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 12:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 9]]);
  }));

  return function update(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var markFeedback = exports.markFeedback = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var userId, feedback;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.prev = 0;
            userId = req.params.id;
            _context6.next = 4;
            return (0, _bluebird.resolve)(_feedback.Feedback.markFeedback(userId));

          case 4:
            feedback = _context6.sent;


            res.json({
              timestamp: Date.now(),
              feedback: feedback
            });
            _context6.next = 11;
            break;

          case 8:
            _context6.prev = 8;
            _context6.t0 = _context6['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0.toString()
            });

          case 11:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[0, 8]]);
  }));

  return function markFeedback(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var findLastIncompleteFeedback = exports.findLastIncompleteFeedback = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var userId, feedback;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.prev = 0;
            userId = req.user._id;
            _context7.next = 4;
            return (0, _bluebird.resolve)(_feedback.Feedback.findLastIncompleteFeedback(userId));

          case 4:
            feedback = _context7.sent;


            res.json({
              timestamp: Date.now(),
              feedback: feedback
            });
            _context7.next = 11;
            break;

          case 8:
            _context7.prev = 8;
            _context7.t0 = _context7['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context7.t0.toString()
            });

          case 11:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[0, 8]]);
  }));

  return function findLastIncompleteFeedback(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var _feedback = require('./feedback.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=feedback.controller.js.map
