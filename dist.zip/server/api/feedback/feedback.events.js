'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var FeedbackEvents = new _events.EventEmitter();

/**
 * Options
 */
FeedbackEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = FeedbackEvents;
//# sourceMappingURL=feedback.events.js.map
