'use strict';

/**
 * Imports
 */

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./feedback.controller');


var router = express.Router();

/**
 * Routes
 */

router.get('/appointments', auth.isAuthenticated(), controller.findAppointmentsFeedbacksAndCount);

router.get('/logouts', auth.isAuthenticated(), controller.findLogoutsFeedbacksAndCount);

router.put('/:id', auth.isAuthenticated(), controller.update);

router.post('/appointments/:id', auth.isAuthenticated(), controller.createOrUpdate);

router.get('/appointments/:id', auth.isAuthenticated(), controller.findByAppointmentId);

router.post('/users/:id/logout/mark', auth.isAuthenticated(), controller.markFeedback);

router.get('/logout/incomplete', auth.isAuthenticated(), controller.findLastIncompleteFeedback);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
