'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./prescription-archive.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', controller.list);
router.get('/count', controller.count);

//router.get('/anonymized', controller.listAnonymized);
//router.get('/anonymized/count', controller.countAnonymized);

router.get('/form', controller.listForm);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
