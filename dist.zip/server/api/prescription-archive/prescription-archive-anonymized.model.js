'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PrescriptionAnonymizedArchive = exports.AppointmentAnonymizedArchive = exports.AreaAnonymizedArchive = exports.PatientAnonymizedArchive = exports.DoctorAnonymizedArchive = exports.RmpAnonymizedArchive = undefined;

var _values = require('babel-runtime/core-js/object/values');

var _values2 = _interopRequireDefault(_values);

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Schemas
 */
var RmpAnonymizedArchiveSchema = new _mongoose.Schema({
  profile_url: String,
  fullname: String,
  center: String
});

var DoctorAnonymizedArchiveSchema = new _mongoose.Schema({
  profile_url: String,
  fullname: String,
  identity: String,
  specialized: String
});

var PatientAnonymizedArchiveSchema = new _mongoose.Schema({
  gender: String,
  dob: Date,
  village: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AreaAnonymizedArchive'
  }
});

var AreaAnonymizedArchiveSchema = new _mongoose.Schema({
  village: String
});

var AppointmentAnonymizedArchiveSchema = new _mongoose.Schema({
  patient_weight: Number,
  patient_temp: Number,
  patient_pulse: Number,
  patient_systole: Number,
  patient_diastole: Number,
  patient_glucose: Number,

  symptoms: [String]
});

var PrescriptionAnonymizedArchiveSchema = new _mongoose.Schema({
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AppointmentAnonymizedArchive'
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'PatientAnonymizedArchive'
  },
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'RmpAnonymizedArchive'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorAnonymizedArchive'
  },

  is_pdfready: Boolean,

  symptoms: [String],

  personalinfo: [String],
  familyinfo: [String],
  druginfo: [String],
  chronicinfo: [String],

  is_followup: Boolean,
  is_referred: Boolean,

  chief_complaint: [{
    complainText: String,
    complainValue: Number,
    complainDur: String,
    complainDetail: String
  }],

  diagnosis: [String],
  investigations: [String],
  advices: [String],

  instruction: [{
    // FIXME: Should just be a single object instead of always an array of one value.
    selected: [{
      generic_name: String,
      trade_name: String,
      formulation: String
    }],
    // FIXME: Should just be an array of strings or numbers.
    doses: Object,
    duration: String,
    duration_type: String,
    // FIXME: Should just be an array of strings.
    instructions: [{
      text: String
    }],
    // FIXME: Should just be an array of strings.
    additional_instructions: [{
      text: String
    }]
  }]
});

/**
 * Options
 */
RmpAnonymizedArchiveSchema.set('toJSON', {
  transform: transformRmpToJSON
});

DoctorAnonymizedArchiveSchema.set('toJSON', {
  transform: transformDoctorToJSON
});

PatientAnonymizedArchiveSchema.set('toJSON', {
  transform: transformPatientToJSON
});

AreaAnonymizedArchiveSchema.set('toJSON', {
  transform: transformAreaToJSON
});

AppointmentAnonymizedArchiveSchema.set('toJSON', {
  transform: transformAppointmentToJSON
});

PrescriptionAnonymizedArchiveSchema.set('toJSON', {
  transform: transformPrescriptionToJSON
});

/**
 * Statics
 */
PrescriptionAnonymizedArchiveSchema.static('findLatestComplete', findLatestComplete).static('countComplete', countComplete);

/**
 * Models
 */
var RmpAnonymizedArchive = exports.RmpAnonymizedArchive = _mongoose2.default.model('RmpAnonymizedArchive', RmpAnonymizedArchiveSchema, 'users');
var DoctorAnonymizedArchive = exports.DoctorAnonymizedArchive = _mongoose2.default.model('DoctorAnonymizedArchive', DoctorAnonymizedArchiveSchema, 'users');
var PatientAnonymizedArchive = exports.PatientAnonymizedArchive = _mongoose2.default.model('PatientAnonymizedArchive', PatientAnonymizedArchiveSchema, 'patients');
var AreaAnonymizedArchive = exports.AreaAnonymizedArchive = _mongoose2.default.model('AreaAnonymizedArchive', AreaAnonymizedArchiveSchema, 'areas');
var AppointmentAnonymizedArchive = exports.AppointmentAnonymizedArchive = _mongoose2.default.model('AppointmentAnonymizedArchive', AppointmentAnonymizedArchiveSchema, 'appointments');
var PrescriptionAnonymizedArchive = exports.PrescriptionAnonymizedArchive = _mongoose2.default.model('PrescriptionAnonymizedArchive', PrescriptionAnonymizedArchiveSchema, 'prescriptions');

/**
 * Functions for Transforms
 */

/**
 * Transform RMP to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformRmpToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,

    name: ret.fullname,
    center: ret.center
  };
}

/**
 * Transform Doctor to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformDoctorToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,

    name: ret.fullname,
    identity: ret.identity,
    speciality: ret.specialized
  };
}

/**
 * Transform Patient to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformPatientToJSON(doc, ret) {
  return {
    id: ret._id,

    sex: ret.gender,
    age: {
      then: (0, _momentTimezone2.default)(doc.updated_at).diff((0, _momentTimezone2.default)(ret.dob), 'years'),
      now: (0, _momentTimezone2.default)().diff((0, _momentTimezone2.default)(ret.dob), 'years')
    },
    village: ret.village
  };
}

/**
 * Transform Area to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformAreaToJSON(doc, ret) {
  return {
    id: ret._id,

    name: ret.village
  };
}

/**
 * Transform Appointment to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformAppointmentToJSON(doc, ret) {
  return {
    id: ret._id,

    weight: ret.patient_weight,
    temperature: ret.patient_temp,
    pulse: ret.patient_pulse,

    blood_pressure: {
      systole: ret.patient_systole,
      diastole: ret.patient_diastole
    },
    glucose: ret.patient_glucose,

    symptoms: ret.symptoms
  };
}

/**
 * Transform Prescription to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformPrescriptionToJSON(doc, ret) {
  return {
    id: ret._id,
    published_at: ret.updated_at,

    rmp: ret.rmp_id,
    doctor: ret.doctors_id,
    patient: ret.patients_id,
    appointment: ret.appointment_id,

    is_followup: ret.is_followup,
    is_referred: ret.is_referred,

    symptoms: ret.symptoms,

    history: {
      personal: ret.personalinfo,
      family: ret.familyinfo,
      drug: ret.druginfo,
      chronic: ret.chronicinfo
    },

    chief_complaint: ret.chief_complaint.map(function (complaint) {
      return {
        description: complaint.complainText,
        duration: {
          value: complaint.complainValue,
          type: complaint.complainDur
        },
        additional_description: complaint.complainDetail
      };
    }),

    diagnosis: ret.diagnosis,
    investigations: ret.investigations,
    advice: ret.advices,

    prescription: ret.instruction.map(function (instruct) {
      return {
        medicine: {
          generic_name: instruct.selected[0].generic_name,
          trade_name: instruct.selected[0].trade_name,
          formulation: instruct.selected[0].formulation
        },
        dose: instruct.doses ? (0, _values2.default)(instruct.doses).join('-') : '',
        duration: {
          value: instruct.duration,
          type: instruct.duration_type
        },
        instructions: instruct.instructions.map(function (innerInstruct) {
          return innerInstruct.text;
        }),
        additional_instructions: instruct.additional_instructions.map(function (innerInstruct) {
          return innerInstruct.text;
        })
      };
    })
  };
}

/**
 * Functions for Statics
 */

/**
 * Find completed prescriptions. Combines appointment and patient information,
 * with pagination. Skips some personally identifiable info on doctors and
 * RMPs, and all personally identifiable info on patients.
 *
 * @param start
 * @param limit
 */
function findLatestComplete(start, limit) {
  var query = this.find({
    is_pdfready: true
  }).populate('appointment_id rmp_id doctors_id').populate({
    path: 'patients_id',
    populate: {
      path: 'village'
    }
  }).sort('-updated_at -_id');

  if (start) query.skip(start);
  if (limit) query.limit(limit);

  return query.exec();
}

/**
 * Count completed prescriptions, with pagination.
 *
 * @param start
 * @param limit
 */
function countComplete(start, limit) {
  var query = this.count({
    is_pdfready: true
  });

  if (start) query.skip(start);
  if (limit) query.limit(limit);

  return query.exec();
}

/**
 * Exports
 */
exports.default = PrescriptionAnonymizedArchive;
//# sourceMappingURL=prescription-archive-anonymized.model.js.map
