'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _values = require('babel-runtime/core-js/object/values');

var _values2 = _interopRequireDefault(_values);

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Schemas
 */
var RmpArchiveSchema = new _mongoose.Schema({
  profile_url: String,
  fullname: String,
  center: String,
  phone: String,
  email: String
});

var DoctorArchiveSchema = new _mongoose.Schema({
  profile_url: String,
  fullname: String,
  identity: String,
  specialized: String,
  email: String
});

var PatientArchiveSchema = new _mongoose.Schema({
  serialnumber: String,
  profilepiclink: String,
  fullname: String,
  gender: String,
  dob: Date,
  village: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AreaArchive'
  },
  phone: String
});

var AreaArchiveSchema = new _mongoose.Schema({
  village: String
});

var AppointmentArchiveSchema = new _mongoose.Schema({
  patient_weight: Number,
  patient_temp: Number,
  patient_pulse: Number,
  patient_systole: Number,
  patient_diastole: Number,
  patient_glucose: Number,

  symptoms: [String],
  patients_images: [String]
});

var PrescriptionArchiveSchema = new _mongoose.Schema({
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AppointmentArchive'
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'PatientArchive'
  },
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'RmpArchive'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorArchive'
  },

  is_pdfready: Boolean,

  symptoms: [String],

  personalinfo: [String],
  familyinfo: [String],
  druginfo: [String],
  chronicinfo: [String],

  is_followup: Boolean,
  is_referred: Boolean,

  chief_complaint: [{
    complainText: String,
    complainValue: Number,
    complainDur: String,
    complainDetail: String
  }],

  diagnosis: [String],
  investigations: [String],
  advices: [String],
  note: String,

  instruction: [{
    // FIXME: Should just be a single object instead of always an array of one value.
    selected: [{
      generic_name: String,
      trade_name: String,
      formulation: String
    }],
    // FIXME: Should just be an array of strings or numbers.
    doses: Object,
    duration: String,
    duration_type: String,
    // FIXME: Should just be an array of strings.
    instructions: [{
      text: String
    }],
    // FIXME: Should just be an array of strings.
    additional_instructions: [{
      text: String
    }]
  }]
});

/**
 * Options
 */
RmpArchiveSchema.set('toJSON', {
  transform: transformRmpToJSON
});

DoctorArchiveSchema.set('toJSON', {
  transform: transformDoctorToJSON
});

PatientArchiveSchema.set('toJSON', {
  transform: transformPatientToJSON
});

AreaArchiveSchema.set('toJSON', {
  transform: transformAreaToJSON
});

AppointmentArchiveSchema.set('toJSON', {
  transform: transformAppointmentToJSON
});

PrescriptionArchiveSchema.set('toJSON', {
  transform: transformPrescriptionToJSON
});

/**
 * Statics
 */
PrescriptionArchiveSchema.static('findLatestComplete', findLatestComplete).static('countComplete', countComplete);

/**
 * Models
 */
/* eslint-disable no-unused-vars */
var RmpArchive = _mongoose2.default.model('RmpArchive', RmpArchiveSchema, 'users');
var DoctorArchive = _mongoose2.default.model('DoctorArchive', DoctorArchiveSchema, 'users');
var PatientArchive = _mongoose2.default.model('PatientArchive', PatientArchiveSchema, 'patients');
var AreaArchive = _mongoose2.default.model('AreaArchive', AreaArchiveSchema, 'areas');
var AppointmentArchive = _mongoose2.default.model('AppointmentArchive', AppointmentArchiveSchema, 'appointments');
var PrescriptionArchive = _mongoose2.default.model('PrescriptionArchive', PrescriptionArchiveSchema, 'prescriptions');
/* eslint-enable no-unused-vars */

/**
 * Functions for Transforms
 */

/**
 * Transform RMP to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformRmpToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,

    name: ret.fullname,
    center: ret.center,

    phone: ret.phone,
    email: ret.email
  };
}

/**
 * Transform Doctor to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformDoctorToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,

    name: ret.fullname,
    identity: ret.identity,
    speciality: ret.specialized,

    email: ret.email
  };
}

/**
 * Transform Patient to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformPatientToJSON(doc, ret) {
  return {
    id: ret._id,
    serial_number: ret.serialnumber,
    profile_pic: ret.profilepiclink,

    name: ret.fullname,
    sex: ret.gender,
    age: {
      then: (0, _momentTimezone2.default)(doc.updated_at).diff((0, _momentTimezone2.default)(ret.dob), 'years'),
      now: (0, _momentTimezone2.default)().diff((0, _momentTimezone2.default)(ret.dob), 'years')
    },
    village: ret.village,

    phone: ret.phone
  };
}

/**
 * Transform Area to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformAreaToJSON(doc, ret) {
  return {
    id: ret._id,

    name: ret.village
  };
}

/**
 * Transform Appointment to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformAppointmentToJSON(doc, ret) {
  return {
    id: ret._id,

    weight: ret.patient_weight,
    temperature: ret.patient_temp,
    pulse: ret.patient_pulse,

    blood_pressure: {
      systole: ret.patient_systole,
      diastole: ret.patient_diastole
    },
    glucose: ret.patient_glucose,

    symptoms: ret.symptoms,
    images: ret.patients_images
  };
}

/**
 * Transform Prescription to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformPrescriptionToJSON(doc, ret) {
  return {
    id: ret._id,
    published_at: ret.updated_at,

    rmp: ret.rmp_id,
    doctor: ret.doctors_id,
    patient: ret.patients_id,
    appointment: ret.appointment_id,

    is_followup: ret.is_followup,
    is_referred: ret.is_referred,

    symptoms: ret.symptoms,

    history: {
      personal: ret.personalinfo,
      family: ret.familyinfo,
      drug: ret.druginfo,
      chronic: ret.chronicinfo
    },

    chief_complaint: ret.chief_complaint.map(function (complaint) {
      return {
        description: complaint.complainText,
        duration: {
          value: complaint.complainValue,
          type: complaint.complainDur
        },
        additional_description: complaint.complainDetail
      };
    }),

    diagnosis: ret.diagnosis,
    investigations: ret.investigations,
    advice: ret.advices,

    prescription: ret.instruction.map(function (instruct) {
      return {
        medicine: {
          generic_name: instruct.selected[0].generic_name,
          trade_name: instruct.selected[0].trade_name,
          formulation: instruct.selected[0].formulation
        },
        dose: instruct.doses ? (0, _values2.default)(instruct.doses).join('-') : '',
        duration: {
          value: instruct.duration,
          type: instruct.duration_type
        },
        instructions: instruct.instructions.map(function (innerInstruct) {
          return innerInstruct.text;
        }),
        additional_instructions: instruct.additional_instructions.map(function (innerInstruct) {
          return innerInstruct.text;
        })
      };
    })
  };
}

/**
 * Functions for Statics
 */

/**
 * Find completed prescriptions. Combines appointment and patient information,
 * with pagination.
 *
 * @param start
 * @param limit
 */
function findLatestComplete(start, limit) {
  var query = this.find({
    is_pdfready: true
  }).populate('appointment_id rmp_id doctors_id').populate({
    path: 'patients_id',
    populate: {
      path: 'village'
    }
  }).sort('-updated_at -_id');

  if (start) query.skip(start);
  if (limit) query.limit(limit);

  return query.exec();
}

/**
 * Count completed prescriptions, with pagination.
 *
 * @param start
 * @param limit
 */
function countComplete(start, limit) {
  var query = this.count({
    is_pdfready: true
  });

  if (start) query.skip(start);
  if (limit) query.limit(limit);

  return query.exec();
}

/**
 * Exports
 */
exports.default = PrescriptionArchive;
//# sourceMappingURL=prescription-archive.model.js.map
