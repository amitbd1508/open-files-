'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _bluebird = require('bluebird');

exports.list = list;
exports.count = count;
exports.listAnonymized = listAnonymized;
exports.countAnonymized = countAnonymized;
exports.listForm = listForm;

var _prescriptionArchive = require('./prescription-archive.model');

var _prescriptionArchive2 = _interopRequireDefault(_prescriptionArchive);

var _prescriptionArchiveAnonymized = require('./prescription-archive-anonymized.model');

var _prescriptionArchiveAnonymized2 = _interopRequireDefault(_prescriptionArchiveAnonymized);

var _prescriptionArchiveForm = require('./prescription-archive-form.model');

var _prescriptionArchiveForm2 = _interopRequireDefault(_prescriptionArchiveForm);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Actions
 */

/**
 * Prescriptions List
 *
 * @param req
 * @param res
 */
function list(req, res) {
  var start = parseInt(req.query.start) || 0;
  var limit = parseInt(req.query.limit) || 0;

  (0, _bluebird.all)([_prescriptionArchive2.default.countComplete(), _prescriptionArchive2.default.findLatestComplete(start, limit)]).spread(function (total, prescriptions) {
    res.json({
      timestamp: Date.now(),
      total: total,
      start: start,
      limit: limit,
      prescriptions: prescriptions
    });
  });
}

/**
 * Prescriptions Count
 *
 * @param req
 * @param res
 */
function count(req, res) {
  _prescriptionArchive2.default.countComplete().then(function (total) {
    res.json({
      timestamp: Date.now(),
      total: total
    });
  });
}

/**
 * Anonymized Prescriptions List
 *
 * @param req
 * @param res
 */
function listAnonymized(req, res) {
  var start = parseInt(req.query.start) || 0;
  var limit = parseInt(req.query.limit) || 0;

  (0, _bluebird.all)([_prescriptionArchiveAnonymized2.default.countComplete(), _prescriptionArchiveAnonymized2.default.findLatestComplete(start, limit)]).spread(function (total, prescriptions) {
    res.json({
      timestamp: Date.now(),
      total: total,
      start: start,
      limit: limit,
      prescriptions: prescriptions
    });
  });
}

/**
 * Anonymized Prescriptions Count
 *
 * @param req
 * @param res
 */
function countAnonymized(req, res) {
  _prescriptionArchiveAnonymized2.default.countComplete().then(function (total) {
    res.json({
      timestamp: Date.now(),
      total: total
    });
  });
}

/**
 * Prescriptions List for Prescription Form
 *
 * @param req
 * @param res
 */
function listForm(req, res) {
  var start = parseInt(req.query.start) || 0;
  var limit = parseInt(req.query.limit) || 0;

  _prescriptionArchiveForm2.default.findLatestComplete(start, limit).then(function (prescriptions) {
    res.json({
      timestamp: Date.now(),
      start: start,
      limit: limit,
      prescriptions: prescriptions
    });
  });
}
//# sourceMappingURL=prescription-archive.controller.js.map
