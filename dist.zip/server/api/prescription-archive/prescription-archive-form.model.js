'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Schemas
 */
var RmpFormArchiveSchema = new _mongoose.Schema({
  profile_url: String,
  fullname: String,
  center: String,
  phone: String,
  email: String
});

var DoctorFormArchiveSchema = new _mongoose.Schema({
  profile_url: String,
  fullname: String,
  identity: String,
  specialized: String,
  email: String
});

var PatientFormArchiveSchema = new _mongoose.Schema({
  serialnumber: String,
  profilepiclink: String,
  fullname: String,
  gender: String,
  dob: Date,
  village: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AreaFormArchive'
  },
  phone: String
});

var AreaFormArchiveSchema = new _mongoose.Schema({
  village: String
});

var AppointmentFormArchiveSchema = new _mongoose.Schema({
  patient_weight: Number,
  patient_temp: Number,
  patient_pulse: Number,
  patient_systole: Number,
  patient_diastole: Number,
  patient_glucose: Number,

  symptoms: [String],
  patients_images: [String]
});

var PrescriptionFormArchiveSchema = new _mongoose.Schema({
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AppointmentFormArchive'
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'PatientFormArchive'
  },
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'RmpFormArchive'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorFormArchive'
  },

  is_pdfready: Boolean,

  symptoms: [String],

  personalinfo: [String],
  familyinfo: [String],
  druginfo: [String],
  chronicinfo: [String],

  is_followup: Boolean,
  is_referred: Boolean,

  chief_complaint: [{
    complainText: String,
    complainValue: Number,
    complainDur: String,
    complainDetail: String
  }],

  diagnosis: [String],
  investigations: [String],
  advices: [String],
  note: String,

  instruction: [{
    // FIXME: Should just be a single object instead of always an array of one value.
    selected: [{
      generic_name: String,
      trade_name: String,
      formulation: String
    }],
    // FIXME: Should just be an array of strings or numbers.
    doses: Object,
    duration: String,
    duration_type: String,
    // FIXME: Should just be an array of strings.
    instructions: [{
      text: String
    }],
    // FIXME: Should just be an array of strings.
    additional_instructions: [{
      text: String
    }]
  }]
});

/**
 * Statics
 */
PrescriptionFormArchiveSchema.static('findLatestComplete', findLatestComplete);

/**
 * Models
 */
/* eslint-disable no-unused-vars */
var RmpFormArchive = _mongoose2.default.model('RmpFormArchive', RmpFormArchiveSchema, 'users');
var DoctorFormArchive = _mongoose2.default.model('DoctorFormArchive', DoctorFormArchiveSchema, 'users');
var PatientFormArchive = _mongoose2.default.model('PatientFormArchive', PatientFormArchiveSchema, 'patients');
var AreaFormArchive = _mongoose2.default.model('AreaFormArchive', AreaFormArchiveSchema, 'areas');
var AppointmentFormArchive = _mongoose2.default.model('AppointmentFormArchive', AppointmentFormArchiveSchema, 'appointments');
var PrescriptionFormArchive = _mongoose2.default.model('PrescriptionFormArchive', PrescriptionFormArchiveSchema, 'prescriptions');
/* eslint-enable no-unused-vars */

/**
 * Functions for Statics
 */

/**
 * Find completed prescriptions. Combines appointment and patient information,
 * with pagination.
 *
 * @param start
 * @param limit
 */
function findLatestComplete(start, limit) {
  var query = this.find({
    is_pdfready: true
  }).populate('appointment_id rmp_id doctors_id').populate({
    path: 'patients_id',
    populate: {
      path: 'village'
    }
  }).sort('-updated_at -_id');

  if (start) query.skip(start);
  if (limit) query.limit(limit);

  return query.exec();
}

/**
 * Exports
 */
exports.default = PrescriptionFormArchive;
//# sourceMappingURL=prescription-archive-form.model.js.map
