'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _rmpFinding = require('./rmp-finding.events');

var _rmpFinding2 = _interopRequireDefault(_rmpFinding);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
}

/**
 * Socket Messages
 */

/**
 * Publish Widget Message
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener(symptom) {
    socket.emit('prescription:complaint:add', {
      timestamp: Date.now(),
      symptom: symptom
    });
  };

  _rmpFinding2.default.on('prescription:complaint:add', listener);

  socket.on('disconnect', function () {
    _rmpFinding2.default.removeListener('prescription:complaint:add', listener);
  });
}
//# sourceMappingURL=rmp-finding.socket.js.map
