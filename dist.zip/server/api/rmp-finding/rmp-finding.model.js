'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RMPFinding = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData) {
    var rmpfinding, newSymptom, savedSymptom;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(RMPFinding.findOne({
              primaryTerm: formData.primaryTerm
            }).exec());

          case 2:
            rmpfinding = _context.sent;

            if (!(rmpfinding === null)) {
              _context.next = 19;
              break;
            }

            newSymptom = new RMPFinding();

            newSymptom.primaryTerm = formData.primaryTerm;
            newSymptom.SNOMEDConceptId = formData.SNOMEDConceptId;
            newSymptom.userId = formData.userId;
            newSymptom.isApproved = false;
            newSymptom.isPrimary = true;

            if (!(formData.userId && formData.primaryTerm)) {
              _context.next = 18;
              break;
            }

            _context.next = 13;
            return (0, _bluebird.resolve)(newSymptom.save());

          case 13:
            savedSymptom = _context.sent;

            _rmpFinding2.default.emit('prescription:complaint:add', savedSymptom);
            return _context.abrupt('return', savedSymptom);

          case 18:
            return _context.abrupt('return', rmpfinding);

          case 19:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var findSymptom = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(query, limit) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            limit = parseInt(limit, 10);
            _context2.next = 3;
            return (0, _bluebird.resolve)(RMPFinding.find(query).limit(limit).lean().sort({
              snomed_id: -1
            }));

          case 3:
            return _context2.abrupt('return', _context2.sent);

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findSymptom(_x2, _x3) {
    return _ref2.apply(this, arguments);
  };
}();

var getRMPFinding = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(thePrescription) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(Prescription.aggregate([{
              $match: {
                _id: objectId(thePrescription)
              }
            }, {
              $project: {
                _id: 0,
                rmpfinding: 1
              }
            }]));

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getRMPFinding(_x4) {
    return _ref3.apply(this, arguments);
  };
}();

var getSymptoms = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(thePrescription) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Prescription.aggregate([{
              $match: {
                _id: objectId(thePrescription)
              }
            }, {
              $lookup: {
                from: 'appointments',
                localField: 'appointment_id',
                foreignField: '_id',
                as: 'theAppointment'
              }
            }, {
              $unwind: {
                path: '$theAppointment'
              }
            }, {
              $project: {
                _id: 0,
                symptoms: '$theAppointment.symptoms'
              }
            }]));

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function getSymptoms(_x5) {
    return _ref4.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _symptom = require('../../schemas/symptom.schema');

var _symptom2 = _interopRequireDefault(_symptom);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

var _rmpFinding = require('./rmp-finding.events');

var _rmpFinding2 = _interopRequireDefault(_rmpFinding);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

// Models
var Prescription = _mongoose2.default.model('RmpFindingPrescription', _prescription2.default, 'prescriptions');

_symptom2.default.static('create', create).static('getSymptoms', getSymptoms).static('getRMPFinding', getRMPFinding).static('findSymptom', findSymptom);

var RMPFinding = exports.RMPFinding = _mongoose2.default.model('Symptom', _symptom2.default, 'symptoms');
//# sourceMappingURL=rmp-finding.model.js.map
