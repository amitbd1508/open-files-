'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findSymptom = exports.getRMPFinding = exports.getSymptoms = exports.create = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

// Actions
var create = exports.create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var reports;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (req.user) {
              req.body.userId = req.user._id;
            }
            _context.next = 3;
            return (0, _bluebird.resolve)(_rmpFinding.RMPFinding.create(req.body));

          case 3:
            reports = _context.sent;

            res.json({
              timestamp: Date.now(),
              reports: reports
            });

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var getSymptoms = exports.getSymptoms = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var thePrescription, symptoms;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            thePrescription = req.query.prescriptionId;
            _context2.next = 3;
            return (0, _bluebird.resolve)(_rmpFinding.RMPFinding.getSymptoms(thePrescription));

          case 3:
            symptoms = _context2.sent;

            res.json({
              timestamp: Date.now(),
              reports: symptoms
            });

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getSymptoms(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

// Actions


var getRMPFinding = exports.getRMPFinding = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var thePrescription, rmpFindings;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            thePrescription = req.query.prescriptionId;
            _context3.next = 3;
            return (0, _bluebird.resolve)(_rmpFinding.RMPFinding.getRMPFinding(thePrescription));

          case 3:
            rmpFindings = _context3.sent;

            res.json({
              timestamp: Date.now(),
              reports: rmpFindings
            });

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getRMPFinding(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findSymptom = exports.findSymptom = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var limit, searchQuery, query, reports;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            limit = req.params.limit || 10;
            searchQuery = req.params.searchQuery || 'A';
            query = { primaryTerm: { $regex: searchQuery, $options: 'i' } };
            _context4.next = 5;
            return (0, _bluebird.resolve)(_rmpFinding.RMPFinding.findSymptom(query, limit));

          case 5:
            reports = _context4.sent;

            res.json({
              timestamp: Date.now(),
              reports: reports
            });

          case 7:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findSymptom(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var _rmpFinding = require('./rmp-finding.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=rmp-finding.controller.js.map
