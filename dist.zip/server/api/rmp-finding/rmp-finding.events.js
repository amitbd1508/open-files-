'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var RMPFindingEvents = new _events.EventEmitter();

/**
 * Options
 */
RMPFindingEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = RMPFindingEvents;
//# sourceMappingURL=rmp-finding.events.js.map
