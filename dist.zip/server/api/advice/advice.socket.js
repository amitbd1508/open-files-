'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _advice = require('./advice.events');

var _advice2 = _interopRequireDefault(_advice);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
}

/**
 * Socket Messages
 */

/**
 * Publish Widget Message
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('advice:create', {
      timestamp: Date.now()
    });
  };

  _advice2.default.on('advice:create', listener);

  socket.on('disconnect', function () {
    _advice2.default.removeListener('advice:create', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('advice:update', {
      timestamp: Date.now()
    });
  };

  _advice2.default.on('advice:update', listener);

  socket.on('disconnect', function () {
    _advice2.default.removeListener('advice:update', listener);
  });
}
//# sourceMappingURL=advice.socket.js.map
