'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.AdvicePrescription = exports.Advice = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData) {
    var advices;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Advice.findOne({
              primaryTerm: formData.primaryTerm
            }).exec());

          case 2:
            advices = _context.sent;

            if (!(advices === null)) {
              _context.next = 16;
              break;
            }

            advices = new Advice();
            advices.primaryTerm = formData.primaryTerm;
            advices.conceptId = formData.conceptId;
            advices.userId = formData.userId;
            advices.isApproved = false;
            advices.isPrimary = true;

            _advice2.default.emit('advice:create');

            _context.next = 13;
            return (0, _bluebird.resolve)(advices.save());

          case 13:
            return _context.abrupt('return', _context.sent);

          case 16:
            return _context.abrupt('return', advices);

          case 17:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var findAdvice = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(skip, limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            skip = parseInt(skip, 10) || 0;
            limit = parseInt(limit, 10) || 10;

            query = {
              primaryTerm: { $regex: searchQuery, $options: 'i' },
              isIgnored: false
            };
            _context2.next = 5;
            return (0, _bluebird.resolve)(Advice.find(query).limit(limit).skip(skip).sort({
              primaryTerm: -1
            }).select('primaryTerm conceptId').lean().exec());

          case 5:
            return _context2.abrupt('return', _context2.sent);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findAdvice(_x2, _x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findPendingApproval = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(skip, limit) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            skip = parseInt(skip, 10) || 0;
            limit = parseInt(limit, 10) || 20;

            _context3.next = 4;
            return (0, _bluebird.resolve)(this.find({
              isIgnored: false
            }).populate({
              path: 'userId',
              select: 'fullname'
            }).limit(parseInt(limit)).skip(parseInt(skip)).sort('isApproved primaryTerm').exec());

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findPendingApproval(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var countPendingApproval = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4() {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.count({
              isApproved: false
            }).exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function countPendingApproval() {
    return _ref4.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(adviceId, formData) {
    var advices;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(Advice.findById(adviceId).exec());

          case 2:
            advices = _context5.sent;


            advices.conceptId = formData.conceptId;
            advices.primaryTerm = formData.primaryTerm;
            advices.system = formData.system;
            advices.isApproved = true;
            advices.isPrimary = formData.isPrimary;
            advices.isIgnored = formData.isIgnored;
            advices.advice = formData.advice;

            _advice2.default.emit('advice:update');

            _context5.next = 13;
            return (0, _bluebird.resolve)(advices.save());

          case 13:
            return _context5.abrupt('return', _context5.sent);

          case 14:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findByIdAndUpdateWithApprove(_x7, _x8) {
    return _ref5.apply(this, arguments);
  };
}();

var suggestionsByAppointmentId = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(appointmentId) {
    var appointment, prescriptions;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(_prescription3.Appointment.findById(appointmentId).select('patients_id start').lean().exec());

          case 2:
            appointment = _context6.sent;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_prescription3.Prescription.find({
              is_pdfready: true,
              publishAt: {
                $lt: appointment.start
              },
              patients_id: appointment.patients_id
            }).lean().exec());

          case 5:
            prescriptions = _context6.sent;
            return _context6.abrupt('return', prescriptions.map(function (prescription) {
              return prescription.advices;
            }).reduce(function (accum, advice) {
              return accum.concat(advice);
            }, []).map(function (advice) {
              return typeof advice === 'string' ? { primaryTerm: advice } : advice;
            }) // FIXME: remove after data normalization
            .reduce(function (accum, advice) {
              return accum.concat(accum.find(function (testAdvice) {
                return testAdvice.primaryTerm === advice.primaryTerm;
              }) ? [] : [advice]);
            }, []));

          case 7:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function suggestionsByAppointmentId(_x9) {
    return _ref6.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _advice = require('./advice.events');

var _advice2 = _interopRequireDefault(_advice);

var _advice3 = require('../../schemas/advice.schema');

var _advice4 = _interopRequireDefault(_advice3);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

var _prescription3 = require('../prescription/prescription.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */

_advice4.default.static('create', create).static('findAdvice', findAdvice).static('findPendingApproval', findPendingApproval).static('countPendingApproval', countPendingApproval).static('findByIdAndUpdateWithApprove', findByIdAndUpdateWithApprove).static('suggestionsByAppointmentId', suggestionsByAppointmentId);var Advice = exports.Advice = _mongoose2.default.model('Advice', _advice4.default, 'advices');
var AdvicePrescription = exports.AdvicePrescription = _mongoose2.default.model('AdvicePrescription', _prescription2.default, 'prescriptions');
//# sourceMappingURL=advice.model.js.map
