'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.suggestions = exports.findByIdAndUpdateWithApprove = exports.list = exports.search = exports.create = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var create = exports.create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var reports;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;

            req.body.userId = req.user._id;
            _context.next = 4;
            return (0, _bluebird.resolve)(_advice.Advice.create(req.body));

          case 4:
            reports = _context.sent;

            res.json({
              timestamp: Date.now(),
              reports: reports
            });
            _context.next = 11;
            break;

          case 8:
            _context.prev = 8;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0
            });

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 8]]);
  }));

  return function create(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var search = exports.search = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var limit, skip, searchQuery, reports;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            limit = parseInt(req.query.limit, 10) || 20;
            skip = parseInt(req.query.skip, 10) || 0;
            searchQuery = req.query.q;


            if (!searchQuery) {
              searchQuery = 'A';
            }

            _context2.next = 7;
            return (0, _bluebird.resolve)(_advice.Advice.findAdvice(skip, limit, searchQuery));

          case 7:
            reports = _context2.sent;


            res.json({
              timestamp: Date.now(),
              reports: reports
            });
            _context2.next = 14;
            break;

          case 11:
            _context2.prev = 11;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0
            });

          case 14:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 11]]);
  }));

  return function search(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var list = exports.list = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var limit, skip, count, countPending, advices;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            limit = parseInt(req.query.limit, 10) || 20;
            skip = parseInt(req.query.skip, 10) || 0;
            _context3.next = 5;
            return (0, _bluebird.resolve)(_advice.Advice.count());

          case 5:
            count = _context3.sent;
            _context3.next = 8;
            return (0, _bluebird.resolve)(_advice.Advice.countPendingApproval());

          case 8:
            countPending = _context3.sent;
            _context3.next = 11;
            return (0, _bluebird.resolve)(_advice.Advice.findPendingApproval(skip, limit));

          case 11:
            advices = _context3.sent;


            res.json({
              timestamp: Date.now(),
              advices: advices,
              count: count,
              countPending: countPending
            });
            _context3.next = 18;
            break;

          case 15:
            _context3.prev = 15;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0
            });

          case 18:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 15]]);
  }));

  return function list(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = exports.findByIdAndUpdateWithApprove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var adviceId, formBody, reports;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            adviceId = req.params.id;
            formBody = req.body;
            _context4.next = 5;
            return (0, _bluebird.resolve)(_advice.Advice.findByIdAndUpdateWithApprove(adviceId, formBody));

          case 5:
            reports = _context4.sent;

            res.json({
              timestamp: Date.now(),
              reports: reports
            });
            _context4.next = 12;
            break;

          case 9:
            _context4.prev = 9;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0
            });

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 9]]);
  }));

  return function findByIdAndUpdateWithApprove(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var suggestions = exports.suggestions = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var appointmentId, _suggestions;

    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            appointmentId = req.params.id;


            if (!appointmentId) res.status(400).send();

            _context5.prev = 2;
            _context5.next = 5;
            return (0, _bluebird.resolve)(_advice.Advice.suggestionsByAppointmentId(appointmentId));

          case 5:
            _suggestions = _context5.sent;


            res.json({
              timestamp: Date.now(),
              suggestions: _suggestions
            });
            _context5.next = 12;
            break;

          case 9:
            _context5.prev = 9;
            _context5.t0 = _context5['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0
            });

          case 12:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[2, 9]]);
  }));

  return function suggestions(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var _advice = require('./advice.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=advice.controller.js.map
