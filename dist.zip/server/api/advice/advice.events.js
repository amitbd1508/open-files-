'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var AdviceEvents = new _events.EventEmitter();

/**
 * Options
 */
AdviceEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = AdviceEvents;
//# sourceMappingURL=advice.events.js.map
