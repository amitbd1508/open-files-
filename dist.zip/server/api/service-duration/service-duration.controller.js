'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.byDoctor = exports.perCenter = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 *
 * @param req
 * @param res
 * @returns {Promise.<void>}
 */
var perCenter = exports.perCenter = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, centers;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context.prev = 5;
            _context.next = 8;
            return (0, _bluebird.resolve)(_serviceDuration.ServicePrescription.perCenter(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            centers = _context.sent;


            res.json({
              timestamp: Date.now(),
              centers: centers
            });
            _context.next = 15;
            break;

          case 12:
            _context.prev = 12;
            _context.t0 = _context['catch'](5);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0
            });

          case 15:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[5, 12]]);
  }));

  return function perCenter(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise.<void>}
 */


var byDoctor = exports.byDoctor = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, centers;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context2.prev = 5;
            _context2.next = 8;
            return (0, _bluebird.resolve)(_serviceDuration.ServicePrescription.byDoctor(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            centers = _context2.sent;


            res.json({
              timestamp: Date.now(),
              centers: centers
            });
            _context2.next = 15;
            break;

          case 12:
            _context2.prev = 12;
            _context2.t0 = _context2['catch'](5);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0
            });

          case 15:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[5, 12]]);
  }));

  return function byDoctor(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var _serviceDuration = require('./service-duration.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=service-duration.controller.js.map
