'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ServicePrescription = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var perCenter = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(startDate, endDate, type, rmpIds, doctorIds) {
    var query, centers;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context.sent;
            _context.next = 5;
            return (0, _bluebird.resolve)(ServicePrescription.aggregate([{
              $match: query
            }, {
              $lookup: {
                'from': "users",
                "localField": "rmp_id",
                "foreignField": "_id",
                "as": "rmp_id"
              }
            }, {
              $unwind: {
                path: "$rmp_id",
                includeArrayIndex: "arrayIndex",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $lookup: {
                "from": "patients",
                "localField": "patients_id",
                "foreignField": "_id",
                "as": "patients_id"
              }
            }, {
              $unwind: {
                path: "$patients_id",
                includeArrayIndex: "arrayIndex",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $lookup: {
                "from": "appointments",
                "localField": "appointment_id",
                "foreignField": "_id",
                "as": "appointment_id"
              }
            }, {
              $unwind: {
                path: "$appointment_id",
                includeArrayIndex: "arrayIndex",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $project: {
                center: '$rmp_id.center',

                registrationTimeTook: '$patients_id.time_took',
                registeredAt: '$patients_id.registered_at',

                appointmentTimeTook: '$appointment_id.time_took',
                appointmentBookedAt: '$appointment_id.timestamp.book_by_rmp',

                prescriptionOpened: '$opened',
                prescriptionTimeTook: '$time_took',
                PublishedAt: '$publishAt',

                downloadedAt: '$timestamp.rmp_seen_time'
              }
            }]));

          case 5:
            centers = _context.sent;


            centers.map(function (appointment) {
              appointment.registrationStart = (0, _momentTimezone2.default)(appointment.registeredAt).subtract(appointment.registrationTimeTook, 'seconds');
              appointment.appointmentStart = (0, _momentTimezone2.default)(appointment.appointmentBookedAt).subtract(appointment.appointmentTimeTook, 'seconds');

              if ((0, _momentTimezone2.default)(appointment.registeredAt).isSame(appointment.appointmentStart, 'day')) {
                appointment.registrationToAppointmentStart = _momentTimezone2.default.duration((0, _momentTimezone2.default)(appointment.appointmentStart).diff((0, _momentTimezone2.default)(appointment.registeredAt))).asSeconds();
              }

              appointment.bookedToOpened = _momentTimezone2.default.duration((0, _momentTimezone2.default)(appointment.prescriptionOpened).diff((0, _momentTimezone2.default)(appointment.appointmentBookedAt))).asSeconds();

              appointment.publishedToDownloaded = _momentTimezone2.default.duration((0, _momentTimezone2.default)(appointment.downloadedAt).diff((0, _momentTimezone2.default)(appointment.PublishedAt))).asSeconds();

              return appointment;
            });

            return _context.abrupt('return', _lodash2.default.groupBy(centers, 'center'));

          case 8:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function perCenter(_x, _x2, _x3, _x4, _x5) {
    return _ref.apply(this, arguments);
  };
}();

var byDoctor = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(startDate, endDate, type, rmpIds, doctorIds) {
    var query, centers;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context2.sent;
            _context2.next = 5;
            return (0, _bluebird.resolve)(ServicePrescription.aggregate([{
              $match: query
            }, {
              $lookup: {
                'from': "users",
                "localField": "rmp_id",
                "foreignField": "_id",
                "as": "rmp_id"
              }
            }, {
              $unwind: {
                path: "$rmp_id",
                includeArrayIndex: "arrayIndex",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $lookup: {
                "from": "appointments",
                "localField": "appointment_id",
                "foreignField": "_id",
                "as": "appointment_id"
              }
            }, {
              $unwind: {
                path: "$appointment_id",
                includeArrayIndex: "arrayIndex",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $lookup: {
                "from": "users",
                "localField": "doctors_id",
                "foreignField": "_id",
                "as": "doctors_id"
              }
            }, {
              $unwind: {
                path: "$doctors_id",
                includeArrayIndex: "arrayIndex"
              }
            }, {
              $project: {
                center: '$rmp_id.center',
                doctor: '$doctors_id.fullname',

                appointmentTimeTook: '$appointment_id.time_took',
                appointmentBookedAt: '$appointment_id.timestamp.book_by_rmp',

                prescriptionOpened: { $ifNull: ["$opened", "$created_at"] },
                prescriptionTimeTook: '$time_took',
                PublishedAt: { $ifNull: ["$publishAt", "$updated_at"] },

                downloadedAt: '$timestamp.rmp_seen_time'
              }
            }]));

          case 5:
            centers = _context2.sent;


            centers.map(function (appointment) {

              appointment.bookedToOpened = _momentTimezone2.default.duration((0, _momentTimezone2.default)(appointment.prescriptionOpened).diff((0, _momentTimezone2.default)(appointment.appointmentBookedAt))).asSeconds();

              appointment.publishedToDownloaded = _momentTimezone2.default.duration((0, _momentTimezone2.default)(appointment.downloadedAt).diff((0, _momentTimezone2.default)(appointment.PublishedAt))).asSeconds();

              return appointment;
            });

            return _context2.abrupt('return', _lodash2.default.groupBy(centers, 'doctor'));

          case 8:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function byDoctor(_x6, _x7, _x8, _x9, _x10) {
    return _ref2.apply(this, arguments);
  };
}();

var filters = function () {
  var _ref3 = (0, _bluebird.method)(function (startDate, endDate, type, rmpIds, doctorIds) {
    var query = {
      created_at: { $gt: startDate, $lt: endDate }
    };

    if (doctorIds) {
      doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
      doctorIds = doctorIds.map(function (id) {
        return objectId(id);
      });
      doctorIds ? query.doctors_id = { $in: doctorIds } : '';
    }

    if (rmpIds) {
      rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
      rmpIds = rmpIds.map(function (id) {
        return objectId(id);
      });
      rmpIds ? query.rmp_id = { $in: rmpIds } : '';
    }

    !type ? query.is_pdfready = true : '';
    type === 'Published' ? query.is_pdfready = true : '';
    type === 'New' ? query.is_followup = false : '';
    type === 'Follow-Up' ? query.is_followup = true : '';
    type === 'Referred' ? query.is_referred = true : '';
    type === 'Free' ? query.is_free = true : '';
    type === 'Un Published' ? query.is_pdfready = false : true;

    return query;
  });

  return function filters(_x11, _x12, _x13, _x14, _x15) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Statics
 */

_prescription2.default.static('perCenter', perCenter).static('byDoctor', byDoctor);

var ServicePrescription = exports.ServicePrescription = _mongoose2.default.model('ServicePrescription', _prescription2.default, 'prescriptions');

/**
 * Exports
 */
exports.default = ServicePrescription;
//# sourceMappingURL=service-duration.model.js.map
