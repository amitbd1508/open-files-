'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./user-picker.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/rmps', controller.rmps);
router.get('/tes', controller.tes);
router.get('/hpos', controller.hpos);
router.get('/doctors', controller.doctors);
router.get('/admins', controller.admins);
router.get('/', controller.all);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
