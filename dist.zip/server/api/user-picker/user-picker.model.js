'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Schemas
 */
var UserPickerSchema = new _mongoose.Schema({
  fullname: String,
  usertype: {
    type: String,
    enum: ['doctor', 'rmp', 'fieldstaff', 'mpo', 'admin', 'cca', 'te']
  },
  center: String
});

/**
 * Options
 */

/**
 * Statics
 */
UserPickerSchema.static('findAllRMPs', findAllRMPs).static('findAllHPOs', findAllHPOs).static('findAllTEs', findAllTEs).static('findAllDoctors', findAllDoctors).static('findAllAdmins', findAllAdmins).static('findAll', findAll);

/**
 * Models
 */
var User = _mongoose2.default.model('UserPicker', UserPickerSchema, 'users');

/**
 * Functions for User Picker
 */

function findAllRMPs() {
  return findAllByType('rmp');
}

function findAllHPOs() {
  return findAllByType('mpo');
}

function findAllTEs() {
  return findAllByType('te');
}

function findAllDoctors() {
  return findAllByType('doctor');
}

function findAllAdmins() {
  return findAllByType('admin');
}

function findAllByType(type) {
  return User.find({
    'usertype': type
  }).select('_id fullname is_active').sort('-is_active fullname _id').exec();
}

function findAll() {
  return User.find().select('_id fullname is_active usertype').sort('-is_active usertype fullname _id').exec();
}

/**
 * Exports
 */
exports.default = User;
//# sourceMappingURL=user-picker.model.js.map
