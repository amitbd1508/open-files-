'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.rmps = rmps;
exports.hpos = hpos;
exports.tes = tes;
exports.doctors = doctors;
exports.admins = admins;
exports.all = all;

var _userPicker = require('./user-picker.model');

var _userPicker2 = _interopRequireDefault(_userPicker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Actions
 */

/**
 * List of all RMPs
 *
 * @param req
 * @param res
 */
function rmps(req, res) {
  _userPicker2.default.findAllRMPs().then(function (users) {
    res.json({
      timestamp: Date.now(),
      rmps: users
    });
  });
}

/**
 * List of all HPOs
 *
 * @param req
 * @param res
 */
function hpos(req, res) {
  _userPicker2.default.findAllHPOs().then(function (users) {
    res.json({
      timestamp: Date.now(),
      hpos: users
    });
  });
}

/**
 * List of all TEs
 *
 * @param req
 * @param res
 */
function tes(req, res) {
  _userPicker2.default.findAllTEs().then(function (users) {
    res.json({
      timestamp: Date.now(),
      tes: users
    });
  });
}

/**
 * List of all Doctors
 *
 * @param req
 * @param res
 */
function doctors(req, res) {
  _userPicker2.default.findAllDoctors().then(function (users) {
    res.json({
      timestamp: Date.now(),
      doctors: users
    });
  });
}

/**
 * List of all Admins
 *
 * @param req
 * @param res
 */
function admins(req, res) {
  _userPicker2.default.findAllAdmins().then(function (users) {
    res.json({
      timestamp: Date.now(),
      admins: users
    });
  });
}

/**
 * List of all Users
 *
 * @param req
 * @param res
 */
function all(req, res) {
  _userPicker2.default.findAll().then(function (users) {
    res.json({
      timestamp: Date.now(),
      users: users
    });
  });
}
//# sourceMappingURL=user-picker.controller.js.map
