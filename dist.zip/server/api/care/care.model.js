'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.list = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var list = exports.list = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(starDate, endDate, skip, limit, rmpId, doctorId) {
    var filterBy;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            skip = parseInt(skip) || 0;
            limit = parseInt(limit) || 10;

            filterBy = {};

            if (rmpId) {
              filterBy.rmpId = objectId(rmpId);
            }
            if (doctorId) {
              filterBy.doctorId = objectId(doctorId);
            }

            _context.next = 7;
            return (0, _bluebird.resolve)(Questionnaire.aggregate([{
              $match: {
                created_at: {
                  $gte: starDate,
                  $lt: endDate
                }
              }
            }, {
              $unwind: {
                path: "$questions"
              }
            }, {
              $project: {
                appointment: 1,
                questions: 1,
                created_at: 1
              }
            }, {
              $lookup: {
                "from": "appointments",
                "localField": "appointment",
                "foreignField": "_id",
                "as": "appointment"
              }
            }, {
              $unwind: {
                path: "$appointment"
              }
            }, {
              $match: {
                "questions.answer": true
              }
            }, {
              $lookup: {
                "from": "users",
                "localField": "appointment.rmp_id",
                "foreignField": "_id",
                "as": "rmp"
              }
            }, {
              $unwind: {
                path: "$rmp"
              }
            }, {
              $lookup: {
                "from": "users",
                "localField": "appointment.doctors_id",
                "foreignField": "_id",
                "as": "doctor"
              }
            }, {
              $unwind: {
                path: "$doctor"
              }
            }, {
              $project: {
                appointment: 1,
                questions: 1,
                created_at: 1,
                doctorId: '$doctor._id',
                doctorName: '$doctor.fullname',
                rmpName: '$rmp.fullname',
                rmpPhone: '$rmp.phone',
                rmpId: '$rmp._id'
              }
            }, {
              $match: filterBy
            }, {
              $skip: skip
            }, {
              $limit: limit
            }, {
              $sort: {
                created_at: -1
              }
            }]));

          case 7:
            return _context.abrupt('return', _context.sent);

          case 8:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function list(_x, _x2, _x3, _x4, _x5, _x6) {
    return _ref.apply(this, arguments);
  };
}();

exports.getRMPRedflags = getRMPRedflags;
exports.getRedflags = getRedflags;
exports.findAllRmps = findAllRmps;

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _questionnaire = require('../../schemas/questionnaire.schema');

var _questionnaire2 = _interopRequireDefault(_questionnaire);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Options
 */
/**
 * Models
 */
var User = _mongoose2.default.model('CareUser', _user2.default, 'users');
var Questionnaire = _mongoose2.default.model('CareQuestionnaire', _questionnaire2.default, 'questionnaires');

/**
 * Statics
 */
// Questionnaire
//   .static('countRMPRedFlags', countRMPRedFlags);


/**
 * Functions for Finance
 */

function getRMPRedflags(fromMoment, toMoment, rmpId) {
  var fMoment = fromMoment.clone();
  var tMoment = toMoment.clone();
  return countRMPRedFlags(fMoment, tMoment, rmpId);
}

function getRedflags(fromMoment, toMoment) {
  var fMoment = fromMoment.clone();
  var tMoment = toMoment.clone();
  return calculateAllRedFlags(fMoment, tMoment);
}

function countRMPRedFlags(fromMoment, toMoment, rmpId) {
  return Questionnaire.aggregate([{
    $match: {
      created_at: { $gte: fromMoment.toDate(), $lt: toMoment.toDate() }
    }
  }, {
    $unwind: {
      path: "$questions"
    }
  }, {
    $project: {
      appointment: 1,
      questions: 1,
      created_at: 1
    }
  }, {
    $lookup: {
      "from": "appointments",
      "localField": "appointment",
      "foreignField": "_id",
      "as": "theAppointment"
    }
  }, {
    $unwind: {
      path: "$theAppointment"
    }
  }, {
    $match: {
      "theAppointment.rmp_id": objectId(rmpId)
    }
  }, {
    $group: {
      _id: { $cond: { if: { $eq: ["$questions.answer", true] }, then: 1, else: 0 } },
      totalProblems: { $sum: 1 }
    }
  }, {
    $redact: {
      $cond: {
        if: { $eq: ["$_id", 1] },
        then: "$$DESCEND",
        else: "$$PRUNE"
      }
    }
  }, {
    $project: {
      numberOfRedFlags: "$totalProblems",
      _id: 0
    }
  }]);
}

function calculateAllRedFlags(fromMoment, toMoment) {
  return Questionnaire.aggregate([{
    $match: {
      created_at: { $gte: fromMoment.toDate(), $lt: toMoment.toDate() }
    }
  }, {
    $unwind: {
      path: "$questions"
    }
  }, {
    $project: {
      appointment: 1,
      questions: 1,
      created_at: 1
    }
  }, {
    $lookup: {
      "from": "appointments",
      "localField": "appointment",
      "foreignField": "_id",
      "as": "theAppointment"
    }
  }, {
    $unwind: {
      path: "$theAppointment"
    }
  }, {
    $group: {
      _id: { $cond: { if: { $eq: ["$questions.answer", true] }, then: 1, else: 0 } },
      totalProblems: { $sum: 1 }
    }
  }, {
    $redact: {
      $cond: {
        if: { $eq: ["$_id", 1] },
        then: "$$DESCEND",
        else: "$$PRUNE"
      }
    }
  }, {
    $project: {
      numberOfRedFlags: "$totalProblems",
      _id: 0
    }
  }]);
}

function findAllRmps() {
  return User.find({
    'usertype': 'rmp'
  }).select('_id fullname').exec();
}
//# sourceMappingURL=care.model.js.map
