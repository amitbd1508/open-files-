'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.list = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var list = exports.list = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, limit, skip, doctorId, rmpId, redFlags;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate() || (0, _momentTimezone2.default)().startOf('month').toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate() || (0, _momentTimezone2.default)().endOf('month').toDate();
            limit = parseInt(req.query.limit) || 10;
            skip = parseInt(req.query.skip) || 0;
            doctorId = req.query.doctorId;
            rmpId = req.query.rmpId;
            redFlags = void 0;
            _context.prev = 7;
            _context.next = 10;
            return (0, _bluebird.resolve)(Care.list(startDate, endDate, skip, limit, rmpId, doctorId));

          case 10:
            redFlags = _context.sent;
            _context.next = 17;
            break;

          case 13:
            _context.prev = 13;
            _context.t0 = _context['catch'](7);

            console.error(_context.t0);
            return _context.abrupt('return', []);

          case 17:

            res.json({
              timestamp: Date.now(),
              redFlags: redFlags
            });

          case 18:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[7, 13]]);
  }));

  return function list(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * List of all RMPs
 *
 * @param req
 * @param res
 */


exports.getRMPRedflags = getRMPRedflags;
exports.getRedflags = getRedflags;
exports.allRmps = allRmps;

var _care = require('./care.model');

var Care = _interopRequireWildcard(_care);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Actions
 */

/**
 * Reports for all RMPs
 *
 * @param req
 * @param res
 */

function getRMPRedflags(req, res) {
  var fromMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate, "YYYY-MM-DD") : (0, _momentTimezone2.default)().startOf('month');
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate, "YYYY-MM-DD") : (0, _momentTimezone2.default)().endOf('month');
  var rmpId = req.params.rmpId;

  Care.getRMPRedflags(fromMoment, toMoment, rmpId).then(function (reports) {
    var numberOfRedFlags = 0;
    if (reports[0]) numberOfRedFlags = reports[0].numberOfRedFlags;
    res.json({
      timestamp: Date.now(),
      fromDate: fromMoment,
      toDate: toMoment,
      numberOfRedFlags: numberOfRedFlags
    });
  });
}

function getRedflags(req, res) {
  var fromMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate, "YYYY-MM-DD") : (0, _momentTimezone2.default)().startOf('month');
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate, "YYYY-MM-DD") : (0, _momentTimezone2.default)().endOf('month');
  Care.getRedflags(fromMoment, toMoment).then(function (reports) {
    var numberOfRedFlags = 0;
    if (reports[0]) numberOfRedFlags = reports[0].numberOfRedFlags;
    res.json({
      timestamp: Date.now(),
      fromDate: fromMoment,
      toDate: toMoment,
      numberOfRedFlags: numberOfRedFlags
    });
  });
}

function allRmps(req, res) {
  Care.findAllRmps().then(function (rmps) {
    res.json({
      timestamp: Date.now(),
      rmps: rmps
    });
  });
}
//# sourceMappingURL=care.controller.js.map
