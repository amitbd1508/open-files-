'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./care.controller');
var router = express.Router();

/**
 * Routes
 */

router.get('/redFlags/list', controller.list);
router.get('/redflags/:rmpId', controller.getRMPRedflags);
router.get('/redflags', controller.getRedflags);
router.get('/rmps', controller.allRmps);
/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
