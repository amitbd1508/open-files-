'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var DoctorScheduleEvents = new _events.EventEmitter();

/**
 * Options
 */
DoctorScheduleEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = DoctorScheduleEvents;
//# sourceMappingURL=doctor-schedule.events.js.map
