'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _doctorSchedule = require('./doctor-schedule.events');

var _doctorSchedule2 = _interopRequireDefault(_doctorSchedule);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  refresh(socket);
}

/**
 * Socket Messages
 */

/**
 * Doctor Schedule Update Message
 *
 * @param socket
 */
function refresh(socket) {
  var listener = function listener(schedule) {
    socket.emit('schedule:update', {
      timestamp: Date.now(),
      schedule: schedule
    });
  };

  _doctorSchedule2.default.on('schedule:update', listener);

  socket.on('disconnect', function () {
    _doctorSchedule2.default.removeListener('schedule:update', listener);
  });
}
//# sourceMappingURL=doctor-schedule.socket.js.map
