'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.view = exports.save = exports.load = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

/**
 * Load Latest Doctor Schedule
 *
 * @param req
 * @param res
 */
var load = exports.load = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var userId, doctorSchedule;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            userId = req.user._id;
            _context.next = 3;
            return (0, _bluebird.resolve)(_doctorSchedule.Schedule.findOneLatest(userId));

          case 3:
            doctorSchedule = _context.sent;


            res.json({
              timestamp: Date.now(),
              schedule: doctorSchedule
            });

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function load(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Save Doctor Schedule
 *
 * @param req
 * @param res
 */


var save = exports.save = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var userId, duration, schedule, doctorSchedule, removeCount, createCount;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            userId = req.user._id;
            duration = req.body.duration;
            schedule = req.body.schedule;
            _context2.next = 6;
            return (0, _bluebird.resolve)(_doctorSchedule.Schedule.createLatest(userId, duration, schedule));

          case 6:
            doctorSchedule = _context2.sent;
            _context2.next = 9;
            return (0, _bluebird.resolve)(_doctorSchedule.Appointment.removeUnusedAll());

          case 9:
            removeCount = _context2.sent;
            _context2.next = 12;
            return (0, _bluebird.resolve)(_doctorSchedule.Appointment.createFreshTillNextMonth(doctorSchedule));

          case 12:
            createCount = _context2.sent;


            res.json({
              timestamp: Date.now(),
              schedule: doctorSchedule,
              appointmentCount: {
                removed: removeCount,
                created: createCount
              }
            });
            _context2.next = 19;
            break;

          case 16:
            _context2.prev = 16;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 19:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 16]]);
  }));

  return function save(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * View Latest Doctor Schedule
 *
 * @param req
 * @param res
 */


var view = exports.view = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var doctorSchedule;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return (0, _bluebird.resolve)(_doctorSchedule.Schedule.findOneLatestWithDetails());

          case 3:
            doctorSchedule = _context3.sent;


            res.json({
              timestamp: Date.now(),
              schedule: doctorSchedule
            });
            _context3.next = 10;
            break;

          case 7:
            _context3.prev = 7;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 10:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 7]]);
  }));

  return function view(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var _doctorSchedule = require('./doctor-schedule.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=doctor-schedule.controller.js.map
