'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Schedule = exports.Appointment = exports.User = undefined;

var _bluebird = require('bluebird');

var _getIterator2 = require('babel-runtime/core-js/get-iterator');

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Functions
 */

/**
 * Create latest Doctor Schedule
 *
 * @param userId
 * @param schedule
 * @param duration
 * @returns {Promise.<*>}
 */
var createLatest = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(userId, duration, schedule) {
    var doctorSchedule;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.create({
              created_by: userId,
              duration: duration,
              schedule: schedule
            }));

          case 2:
            doctorSchedule = _context.sent;
            _context.next = 5;
            return (0, _bluebird.resolve)(this.populate(doctorSchedule, {
              path: 'created_by',
              select: 'fullname'
            }));

          case 5:
            doctorSchedule = _context.sent;


            _doctorSchedule2.default.emit('schedule:update', doctorSchedule);

            return _context.abrupt('return', doctorSchedule);

          case 8:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function createLatest(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Find latest Doctor Schedule, or create one if necessary.
 *
 * @param userId
 * @returns {Promise}
 */


var findOneLatest = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(userId) {
    var doctorSchedule;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              schedule: { $exists: true }
            }).populate({
              path: 'created_by',
              select: 'fullname'
            }).sort('-created_at').exec());

          case 2:
            doctorSchedule = _context2.sent;

            if (doctorSchedule) {
              _context2.next = 10;
              break;
            }

            _context2.next = 6;
            return (0, _bluebird.resolve)(this.create({
              created_by: userId
            }));

          case 6:
            doctorSchedule = _context2.sent;
            _context2.next = 9;
            return (0, _bluebird.resolve)(this.populate(doctorSchedule, {
              path: 'created_by',
              select: 'fullname'
            }));

          case 9:
            doctorSchedule = _context2.sent;

          case 10:
            return _context2.abrupt('return', doctorSchedule);

          case 11:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findOneLatest(_x4) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Find latest Doctor Schedule, and include details on the doctors.
 *
 * @returns {Promise}
 */


var findOneLatestWithDetails = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3() {
    var doctorSchedule, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, hour, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, day;

    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(this.findOneLatest());

          case 2:
            doctorSchedule = _context3.sent;
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            _context3.prev = 6;
            _iterator = (0, _getIterator3.default)(HOURS);

          case 8:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              _context3.next = 40;
              break;
            }

            hour = _step.value;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            _context3.prev = 13;
            _iterator2 = (0, _getIterator3.default)(DAYS);

          case 15:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              _context3.next = 23;
              break;
            }

            day = _step2.value;
            _context3.next = 19;
            return (0, _bluebird.resolve)(User.find({
              _id: { $in: doctorSchedule.schedule[hour][day] }
            }).select('fullname identity specialized profile_url').sort('specialized fullname _id').exec());

          case 19:
            doctorSchedule.schedule[hour][day] = _context3.sent;

          case 20:
            _iteratorNormalCompletion2 = true;
            _context3.next = 15;
            break;

          case 23:
            _context3.next = 29;
            break;

          case 25:
            _context3.prev = 25;
            _context3.t0 = _context3['catch'](13);
            _didIteratorError2 = true;
            _iteratorError2 = _context3.t0;

          case 29:
            _context3.prev = 29;
            _context3.prev = 30;

            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }

          case 32:
            _context3.prev = 32;

            if (!_didIteratorError2) {
              _context3.next = 35;
              break;
            }

            throw _iteratorError2;

          case 35:
            return _context3.finish(32);

          case 36:
            return _context3.finish(29);

          case 37:
            _iteratorNormalCompletion = true;
            _context3.next = 8;
            break;

          case 40:
            _context3.next = 46;
            break;

          case 42:
            _context3.prev = 42;
            _context3.t1 = _context3['catch'](6);
            _didIteratorError = true;
            _iteratorError = _context3.t1;

          case 46:
            _context3.prev = 46;
            _context3.prev = 47;

            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }

          case 49:
            _context3.prev = 49;

            if (!_didIteratorError) {
              _context3.next = 52;
              break;
            }

            throw _iteratorError;

          case 52:
            return _context3.finish(49);

          case 53:
            return _context3.finish(46);

          case 54:
            return _context3.abrupt('return', doctorSchedule);

          case 55:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[6, 42, 46, 54], [13, 25, 29, 37], [30,, 32, 36], [47,, 49, 53]]);
  }));

  return function findOneLatestWithDetails() {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Remove unused appointments in the given date range
 *
 * @param startDate
 * @param endDate
 * @returns {Promise.<number>}
 */


var removeUnusedByDates = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(startDate, endDate) {
    var criteria, count;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            criteria = {
              // Only remove appointments that were never booked nor prescribed
              is_booked: false,
              is_prescribed: false,

              // Don't remove any appointments that were transferred or cancelled
              transfer: { $exists: false },
              cancel: { $exists: false },

              $or: [
              // For safety, don't remove any appointments that have a patient assigned
              { patients_id: { $exists: false } }, { patients_id: null },

              // For safety, don't remove any appointments from v2 just yet
              { v2_id: { $exists: false } }, { v2_id: null }]
            };

            // Only remove appointments within the given dates

            if (startDate) criteria.start = { $gte: startDate };
            if (endDate) criteria.end = { $lte: endDate };

            _context4.next = 5;
            return (0, _bluebird.resolve)(this.count(criteria));

          case 5:
            count = _context4.sent;
            _context4.next = 8;
            return (0, _bluebird.resolve)(this.remove(criteria).exec());

          case 8:
            return _context4.abrupt('return', count);

          case 9:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function removeUnusedByDates(_x5, _x6) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Remove unused appointments till last week.
 *
 * @returns {Promise.<number>}
 */


var removeUnusedTillLastWeek = function () {
  var _ref5 = (0, _bluebird.method)(function () {
    var endDate = (0, _momentTimezone2.default)().tz(TIMEZONE).endOf('day').subtract(1, 'day').subtract(1, 'week').toDate();

    return this.removeUnusedByDates(null, endDate);
  });

  return function removeUnusedTillLastWeek() {
    return _ref5.apply(this, arguments);
  };
}();

/**
 * Remove all unused appointments.
 *
 * @returns {Promise.<number>}
 */


var removeUnusedAll = function () {
  var _ref6 = (0, _bluebird.method)(function () {
    return this.removeUnusedByDates();
  });

  return function removeUnusedAll() {
    return _ref6.apply(this, arguments);
  };
}();

/**
 * Create fresh appointment, but only if an existing appointment doesn't overlap with it
 * (for the same doctor).
 *
 * @param scheduleId
 * @param doctorId
 * @param slotStart
 * @param slotEnd
 * @returns {Promise.<*>}
 */


var createFresh = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(scheduleId, doctorId, slotStart, slotEnd) {
    var appointments;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(this.find({
              doctors_id: doctorId,
              start: { $gte: slotStart },
              end: { $lte: slotEnd }
            }));

          case 2:
            appointments = _context5.sent;

            if (!(appointments.length > 0)) {
              _context5.next = 5;
              break;
            }

            return _context5.abrupt('return', appointments[0]);

          case 5:
            return _context5.abrupt('return', this.create({
              schedule_id: scheduleId,
              doctors_id: doctorId,
              start: slotStart,
              end: slotEnd
            }));

          case 6:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function createFresh(_x7, _x8, _x9, _x10) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Create fresh appointments for the given schedule and duration,
 * within the given date range.
 *
 * @param doctorSchedule
 * @param startDate
 * @param endDate
 * @returns {Promise.<number>}
 */


var createFreshByDates = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(doctorSchedule, startDate, endDate) {
    var _this = this;

    var count, allMoments, aMoment;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            count = 0;
            allMoments = [];
            aMoment = (0, _momentTimezone2.default)(startDate).startOf('day');

            while (aMoment.isBetween(startDate, endDate, 'day', '[]')) {
              allMoments.push(aMoment.clone());
              aMoment.add(doctorSchedule.duration, 'minutes');
            }

            _context8.next = 6;
            return (0, _bluebird.resolve)((0, _bluebird.all)(allMoments.map(function () {
              var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(currentMoment) {
                var hour, day, doctorIds;
                return _regenerator2.default.wrap(function _callee7$(_context7) {
                  while (1) {
                    switch (_context7.prev = _context7.next) {
                      case 0:
                        hour = currentMoment.tz('Asia/Dhaka').format('hh a').toLowerCase();
                        day = currentMoment.tz('Asia/Dhaka').format('ddd').toLowerCase();

                        if (!(doctorSchedule.schedule[hour] == undefined)) {
                          _context7.next = 4;
                          break;
                        }

                        return _context7.abrupt('return');

                      case 4:
                        if (!(doctorSchedule.schedule[hour][day] == undefined)) {
                          _context7.next = 6;
                          break;
                        }

                        return _context7.abrupt('return');

                      case 6:
                        doctorIds = doctorSchedule.schedule[hour][day];
                        _context7.next = 9;
                        return (0, _bluebird.resolve)((0, _bluebird.all)(doctorIds.map(function () {
                          var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(doctorId) {
                            var slotStart, slotEnd;
                            return _regenerator2.default.wrap(function _callee6$(_context6) {
                              while (1) {
                                switch (_context6.prev = _context6.next) {
                                  case 0:
                                    slotStart = currentMoment.toDate();
                                    slotEnd = currentMoment.clone().add(doctorSchedule.duration, 'minutes').subtract(1, 'ms');
                                    _context6.next = 4;
                                    return (0, _bluebird.resolve)(_this.createFresh(doctorSchedule._id, doctorId, slotStart, slotEnd));

                                  case 4:

                                    count++;

                                  case 5:
                                  case 'end':
                                    return _context6.stop();
                                }
                              }
                            }, _callee6, _this);
                          }));

                          return function (_x15) {
                            return _ref10.apply(this, arguments);
                          };
                        }())));

                      case 9:
                      case 'end':
                        return _context7.stop();
                    }
                  }
                }, _callee7, _this);
              }));

              return function (_x14) {
                return _ref9.apply(this, arguments);
              };
            }())));

          case 6:
            return _context8.abrupt('return', count);

          case 7:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function createFreshByDates(_x11, _x12, _x13) {
    return _ref8.apply(this, arguments);
  };
}();

/**
 * Create fresh appointments from the given schedule and duration,
 * from last week till next month.
 *
 * @param doctorSchedule
 * @returns {Promise.<number>}
 */


var createFreshTillNextMonth = function () {
  var _ref11 = (0, _bluebird.method)(function (doctorSchedule) {
    var startDate = (0, _momentTimezone2.default)().tz(TIMEZONE).startOf('day').subtract(1, 'week').toDate();
    var endDate = (0, _momentTimezone2.default)().tz(TIMEZONE).endOf('day').add(1, 'month').toDate();

    return this.createFreshByDates(doctorSchedule, startDate, endDate);
  });

  return function createFreshTillNextMonth(_x16) {
    return _ref11.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _environment = require('../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

var _doctorSchedule = require('./doctor-schedule.events');

var _doctorSchedule2 = _interopRequireDefault(_doctorSchedule);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

var _schedule = require('../../schemas/schedule.schema');

var _schedule2 = _interopRequireDefault(_schedule);

var _appointment = require('../../schemas/appointment.schema');

var _appointment2 = _interopRequireDefault(_appointment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */
var TIMEZONE = _environment2.default.scheduleTimeZone;
var HOURS = _environment2.default.scheduleHours;
var DAYS = _environment2.default.scheduleDays;

/**
 * Statics
 */
_schedule2.default.static('createLatest', createLatest).static('findOneLatest', findOneLatest).static('findOneLatestWithDetails', findOneLatestWithDetails);

_appointment2.default.static('removeUnusedByDates', removeUnusedByDates).static('removeUnusedTillLastWeek', removeUnusedTillLastWeek).static('removeUnusedAll', removeUnusedAll).static('createFresh', createFresh).static('createFreshByDates', createFreshByDates).static('createFreshTillNextMonth', createFreshTillNextMonth);

/**
 * Models
 */
var User = exports.User = _mongoose2.default.model('ScheduleUser', _user2.default, 'users');
var Appointment = exports.Appointment = _mongoose2.default.model('ScheduleAppointment', _appointment2.default, 'appointments');
var Schedule = exports.Schedule = _mongoose2.default.model('Schedule', _schedule2.default, 'schedules');
//# sourceMappingURL=doctor-schedule.model.js.map
