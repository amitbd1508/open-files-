'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Transaction = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

//  Farazi: we need to clean all old legacy code written by rezaur, i just tried to fix this function
var updatePrescription = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData) {
    var transaction;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Transaction.findOne({
              prescription_id: formData.prescriptionId
            }).exec());

          case 2:
            transaction = _context.sent;

            if (!(transaction !== null)) {
              _context.next = 12;
              break;
            }

            transaction.total = formData.total;
            if (transaction.total === 0) {
              formData.is_free = true;
            }

            _context.next = 8;
            return (0, _bluebird.resolve)(_rmp.User.calculateRMPShare(formData.prescriptionId));

          case 8:
            transaction.rmp_share = _context.sent;
            _context.next = 11;
            return (0, _bluebird.resolve)(transaction.save());

          case 11:
            return _context.abrupt('return', _context.sent);

          case 12:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function updatePrescription(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _transaction = require('../../schemas/transaction.schema');

var _transaction2 = _interopRequireDefault(_transaction);

var _rmp = require('../rmp/rmp.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */

_transaction2.default.static('updatePrescription', updatePrescription);var Transaction = exports.Transaction = _mongoose2.default.model('Transaction', _transaction2.default, 'transactions');
//# sourceMappingURL=transaction.model.js.map
