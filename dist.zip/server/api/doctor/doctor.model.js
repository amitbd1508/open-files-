'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Prescription = exports.Appointment = exports.Patient = exports.Doctor = exports.Rmp = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

/**
 * Find a doctor.
 *
 * @param doctorId
 * @returns {Promise}
 */
var findByDoctorId = function () {
  var _ref = (0, _bluebird.method)(function (doctorId) {
    return this.findById(doctorId).exec();
  });

  return function findByDoctorId(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Find all appointments for today (in Dhaka time).
 *
 * @returns {Promise}
 */


var findToday = function () {
  var _ref2 = (0, _bluebird.method)(function () {
    var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('day').toDate();
    var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('day').toDate();

    return this.findByDates(startDate, endDate);
  });

  return function findToday() {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Find a doctor's appointments for today (in Dhaka time).
 *
 * @param doctorId
 * @returns {Promise}
 */


var findTodayByDoctorId = function () {
  var _ref3 = (0, _bluebird.method)(function (doctorId) {
    var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('day').toDate();
    var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('day').toDate();

    return this.findByDoctorIdAndDates(doctorId, startDate, endDate);
  });

  return function findTodayByDoctorId(_x2) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Find all appointments for a date range.
 *
 * @param startDate
 * @param endDate
 * @returns {Promise}
 */


var findByDates = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(startDate, endDate) {
    var appointments;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: {
                is_booked: true,
                start: {
                  $gte: startDate,
                  $lte: endDate
                }
              }
            }, {
              $lookup: {
                from: 'prescriptions',
                localField: '_id',
                foreignField: 'appointment_id',
                as: 'prescriptions'
              }
            }, {
              $unwind: {
                path: '$prescriptions',
                preserveNullAndEmptyArrays: true
              }
            }, {
              $project: {
                rmp_id: '$rmp_id',
                doctors_id: '$doctors_id',
                patients_id: '$patients_id',
                prescription_id: '$prescriptions._id',

                is_booked: '$is_booked',
                is_prescribed: '$is_prescribed',
                pdfReady: '$prescriptions.pdfReady',

                start: '$start',
                end: '$end',
                timestamp: '$timestamp'
              }
            }]).sort('start doctor_id').exec());

          case 2:
            appointments = _context.sent;


            appointments = appointments.map(function (appointment) {
              return new Appointment(appointment);
            });

            return _context.abrupt('return', this.populate(appointments, {
              path: 'rmp_id doctors_id patients_id prescription_id'
            }));

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findByDates(_x3, _x4) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Find a doctor's appointments for a date range.
 * If a prescription exists, it is included.
 *
 * @param doctorId
 * @param startDate
 * @param endDate
 * @returns {Promise}
 */


var findByDoctorIdAndDates = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(doctorId, startDate, endDate) {
    var appointments;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: {
                is_booked: true,
                start: {
                  $gte: startDate,
                  $lte: endDate
                },
                doctors_id: doctorId
              }
            }, {
              $lookup: {
                from: 'prescriptions',
                localField: '_id',
                foreignField: 'appointment_id',
                as: 'prescriptions'
              }
            }, {
              $unwind: {
                path: '$prescriptions',
                preserveNullAndEmptyArrays: true
              }
            }, {
              $project: {
                rmp_id: '$rmp_id',
                doctors_id: '$doctors_id',
                patients_id: '$patients_id',
                prescription_id: '$prescriptions._id',

                is_booked: '$is_booked',
                is_prescribed: '$is_prescribed',
                pdfReady: '$prescriptions.pdfReady',

                source: '$source',

                start: '$start',
                end: '$end',
                timestamp: '$timestamp'
              }
            }]).sort({ start: -1 }).exec());

          case 2:
            appointments = _context2.sent;


            appointments = appointments.map(function (appointment) {
              return new Appointment(appointment);
            });

            return _context2.abrupt('return', this.populate(appointments, {
              path: 'rmp_id patients_id prescription_id'
            }));

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findByDoctorIdAndDates(_x5, _x6, _x7) {
    return _ref5.apply(this, arguments);
  };
}();

/**
 * Count total number of pending appointments for a doctor.
 *
 * @param doctorId
 * @returns {Promise.<*>}
 */


var countPendingByDoctorId = function () {
  var _ref6 = (0, _bluebird.method)(function (doctorId) {
    return this.countByDoctorIdAndIsPrescribed(doctorId, false);
  });

  return function countPendingByDoctorId(_x8) {
    return _ref6.apply(this, arguments);
  };
}();

/**
 * Count total number of prescribed appointments for a doctor.
 *
 * @param doctorId
 * @returns {Promise.<*>}
 */


var countPrescribedByDoctorId = function () {
  var _ref7 = (0, _bluebird.method)(function (doctorId) {
    return this.countByDoctorIdAndIsPrescribed(doctorId, true);
  });

  return function countPrescribedByDoctorId(_x9) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Count number of pending appointments today for a doctor.
 *
 * @param doctorId
 * @returns {Promise.<*>}
 */


var countPendingTodayByDoctorId = function () {
  var _ref8 = (0, _bluebird.method)(function (doctorId) {
    var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('day').toDate();
    var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('day').toDate();

    return this.countPendingByDoctorIdAndDates(doctorId, startDate, endDate);
  });

  return function countPendingTodayByDoctorId(_x10) {
    return _ref8.apply(this, arguments);
  };
}();

/**
 * Count number of prescribed appointments today for a doctor.
 *
 * @param doctorId
 * @returns {Promise.<*>}
 */


var countPrescribedTodayByDoctorId = function () {
  var _ref9 = (0, _bluebird.method)(function (doctorId) {
    var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('day').toDate();
    var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('day').toDate();

    return this.countPrescribedByDoctorIdAndDates(doctorId, startDate, endDate);
  });

  return function countPrescribedTodayByDoctorId(_x11) {
    return _ref9.apply(this, arguments);
  };
}();

/**
 * Count number of pending appointments for a doctor in a date range
 *
 * @param doctorId
 * @param startDate
 * @param endDate
 * @returns {Promise.<*>}
 */


var countPendingByDoctorIdAndDates = function () {
  var _ref10 = (0, _bluebird.method)(function (doctorId, startDate, endDate) {
    return this.countByDoctorIdAndIsPrescribedAndDates(doctorId, false, startDate, endDate);
  });

  return function countPendingByDoctorIdAndDates(_x12, _x13, _x14) {
    return _ref10.apply(this, arguments);
  };
}();

/**
 * Count number of prescribed appointments for a doctor in a date range
 *
 * @param doctorId
 * @param startDate
 * @param endDate
 * @returns {Promise.<*>}
 */


var countPrescribedByDoctorIdAndDates = function () {
  var _ref11 = (0, _bluebird.method)(function (doctorId, startDate, endDate) {
    return this.countByDoctorIdAndIsPrescribedAndDates(doctorId, true, startDate, endDate);
  });

  return function countPrescribedByDoctorIdAndDates(_x15, _x16, _x17) {
    return _ref11.apply(this, arguments);
  };
}();

/**
 * Count total number of pending/prescribed appointments for a doctor.
 *
 * @param doctorId
 * @param isPrescribed
 * @returns {Promise.<*>}
 */


var countByDoctorIdAndIsPrescribed = function () {
  var _ref12 = (0, _bluebird.method)(function (doctorId, isPrescribed) {
    return this.count({
      doctors_id: doctorId,
      is_booked: true,
      is_prescribed: isPrescribed
    });
  });

  return function countByDoctorIdAndIsPrescribed(_x18, _x19) {
    return _ref12.apply(this, arguments);
  };
}();

/**
 * Count number of pending/prescribed appointments for a doctor in a date range.
 *
 * @param doctorId
 * @param isPrescribed
 * @param startDate
 * @param endDate
 * @returns {Promise.<*>}
 */


var countByDoctorIdAndIsPrescribedAndDates = function () {
  var _ref13 = (0, _bluebird.method)(function (doctorId, isPrescribed, startDate, endDate) {
    return this.count({
      doctors_id: doctorId,
      is_booked: true,
      is_prescribed: isPrescribed,
      start: {
        $gte: startDate,
        $lte: endDate
      }
    });
  });

  return function countByDoctorIdAndIsPrescribedAndDates(_x20, _x21, _x22, _x23) {
    return _ref13.apply(this, arguments);
  };
}();

/**
 *
 * @param searchQuery
 * @returns {Promise.<*|Object|Aggregate|Promise>}
 */


var findSpecializations = function () {
  var _ref14 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            query = {
              specialized: { '$regex': searchQuery, '$options': 'i' }
            };
            _context3.next = 3;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $group: {
                _id: "$specialized"
              }
            }, {
              $project: {
                _id: 0,
                specialized: "$_id"
              }
            }]).exec());

          case 3:
            return _context3.abrupt('return', _context3.sent);

          case 4:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findSpecializations(_x24) {
    return _ref14.apply(this, arguments);
  };
}();

var findPrescriptionIdsByDoctorIdAndDates = function () {
  var _ref15 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(doctorId, startDate, endDate) {
    var result;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: {
                doctors_id: doctorId,
                is_booked: true,
                is_prescribed: true,
                start: {
                  $gte: startDate,
                  $lte: endDate
                }
              }
            }, {
              $project: {
                _id: true
              }
            }]).exec());

          case 2:
            result = _context4.sent;
            return _context4.abrupt('return', result.map(function (r) {
              return r._id;
            }));

          case 4:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findPrescriptionIdsByDoctorIdAndDates(_x25, _x26, _x27) {
    return _ref15.apply(this, arguments);
  };
}();

var findMinMaxTimeTookByIds = function () {
  var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(ids) {
    var result;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            if (!(ids && ids.length > 0)) {
              _context5.next = 7;
              break;
            }

            _context5.next = 3;
            return (0, _bluebird.resolve)(Prescription.aggregate([{
              $match: {
                appointment_id: { $in: ids }
              }
            }, {
              $group: {
                _id: null,
                min: { $min: '$time_took' },
                max: { $max: '$time_took' }
              }
            }]).exec());

          case 3:
            result = _context5.sent;
            return _context5.abrupt('return', { min: result[0].min, max: result[0].max });

          case 7:
            return _context5.abrupt('return', { min: 0, max: 0 });

          case 8:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findMinMaxTimeTookByIds(_x28) {
    return _ref16.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _environment = require('../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */
var TIMEZONE = _environment2.default.scheduleTimeZone;

/**
 * Schemas
 */
var DoctorRmpSchema = new _mongoose.Schema({
  fullname: String,
  center: String,
  phone: String,
  email: String,
  profile_pic: String
});

var DoctorDoctorSchema = new _mongoose.Schema({
  fullname: String,
  identity: String,
  specialized: String,
  phone: String,
  email: String,
  profile_pic: String
});

var DoctorPatientSchema = new _mongoose.Schema({
  serialnumber: String,
  fullname: String,
  gender: String,
  dob: Date,
  registered_at: Date,
  profilepiclink: String
});

var DoctorAppointmentSchema = new _mongoose.Schema({
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorRmp'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorDoctor'
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorPatient'
  },
  is_booked: {
    type: Boolean
  },
  is_prescribed: {
    type: Boolean,
    default: false
  },
  start: {
    type: Date
  },
  end: Date,
  timestamp: {
    book_by_rmp: Date
  },
  source: String,

  // FIXME: This is not saved. It is generated by the aggregate function below
  prescription_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorPrescription'
  }
});

var DoctorPrescriptionSchema = new _mongoose.Schema({
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorAppointment'
  },
  opened: Date,
  publishAt: Date,
  created_at: Date,
  updated_at: Date
});

/**
 * Options
 */
DoctorRmpSchema.set('toJSON', {
  transform: transformRmpToJSON
});

DoctorDoctorSchema.set('toJSON', {
  transform: transformDoctorToJSON
});

DoctorPatientSchema.set('toJSON', {
  transform: transformPatientToJSON
});

DoctorAppointmentSchema.set('toJSON', {
  transform: transformAppointmentToJSON
});

DoctorPrescriptionSchema.set('toJSON', {
  transform: transformPrescriptionToJSON
});

/**
 * Statics
 */
DoctorDoctorSchema.static('findByDoctorId', findByDoctorId).static('findSpecializations', findSpecializations);

DoctorAppointmentSchema.static('findToday', findToday).static('findByDates', findByDates).static('findTodayByDoctorId', findTodayByDoctorId).static('findByDoctorIdAndDates', findByDoctorIdAndDates).static('countPendingByDoctorId', countPendingByDoctorId).static('countPrescribedByDoctorId', countPrescribedByDoctorId).static('countPendingTodayByDoctorId', countPendingTodayByDoctorId).static('countPrescribedTodayByDoctorId', countPrescribedTodayByDoctorId).static('countPendingByDoctorIdAndDates', countPendingByDoctorIdAndDates).static('countPrescribedByDoctorIdAndDates', countPrescribedByDoctorIdAndDates).static('countByDoctorIdAndIsPrescribed', countByDoctorIdAndIsPrescribed).static('countByDoctorIdAndIsPrescribedAndDates', countByDoctorIdAndIsPrescribedAndDates).static('findPrescriptionIdsByDoctorIdAndDates', findPrescriptionIdsByDoctorIdAndDates).static('findMinMaxTimeTookByIds', findMinMaxTimeTookByIds);

/**
 * Transform functions
 */

/**
 * Transform RMP to JSON
 *
 * @param doc
 * @param ret
 */
function transformRmpToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,

    name: ret.fullname,
    center: ret.center,
    phone: ret.phone
  };
}

/**
 * Transform Doctor to JSON
 *
 * @param doc
 * @param ret
 */
function transformDoctorToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,

    name: ret.fullname,
    identity: ret.identity,
    speciality: ret.specialized,
    phone: ret.phone,
    email: ret.email
  };
}

/**
 * Transform Patient to JSON
 *
 * @param doc
 * @param ret
 */
function transformPatientToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profilepiclink,
    serial: ret.serialnumber,

    name: ret.fullname,
    sex: ret.gender,
    age: (0, _momentTimezone2.default)().diff((0, _momentTimezone2.default)(ret.dob), 'years')
  };
}

/**
 * Transform Appointment to JSON
 *
 * @param doc
 * @param ret
 */
function transformAppointmentToJSON(doc, ret) {
  return {
    id: ret._id,

    rmp: ret.rmp_id,
    doctor: ret.doctors_id,
    patient: ret.patients_id,
    prescription: ret.prescription_id,

    is_booked: ret.is_booked,
    is_prescribed: ret.is_prescribed,

    source: ret.source,

    start_at: ret.start,
    end_at: ret.end,
    booked_at: ret.timestamp.book_by_rmp
  };
}

/**
 * Transform Prescription to JSON
 *
 * @param doc
 * @param ret
 * @param options
 */
function transformPrescriptionToJSON(doc, ret) {
  return {
    id: ret._id,

    opened_at: ret.opened,
    fee: ret.fee,
    is_referred: ret.is_referred,
    is_followup: ret.is_followup,
    is_free: ret.is_free,
    pdfReady: ret.is_pdfready,
    followup_date: ret.followup_date,
    isPayed: ret.isPayed,
    published_at: ret.publishAt
  };
}var Rmp = exports.Rmp = _mongoose2.default.model('DoctorRmp', DoctorRmpSchema, 'users');
var Doctor = exports.Doctor = _mongoose2.default.model('DoctorDoctor', DoctorDoctorSchema, 'users');
var Patient = exports.Patient = _mongoose2.default.model('DoctorPatient', DoctorPatientSchema, 'patients');
var Appointment = exports.Appointment = _mongoose2.default.model('DoctorAppointment', DoctorAppointmentSchema, 'appointments');
var Prescription = exports.Prescription = _mongoose2.default.model('DoctorPrescription', DoctorPrescriptionSchema, 'prescriptions');
//# sourceMappingURL=doctor.model.js.map
