'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findSpecializations = exports.appointments = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var _slicedToArray2 = require('babel-runtime/helpers/slicedToArray');

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

/**
 * Appointments
 *
 * @param req
 * @param res
 */
var appointments = exports.appointments = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var doctorId, startDate, endDate, _ref2, _ref3, doctor, appointmentsPendingSpecified, appointmentsPendingTotal, appointmentsPrescribedSpecified, appointmentsPrescribedTotal, appointments;

    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            doctorId = req.query.doctorId;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            _context.next = 5;
            return (0, _bluebird.resolve)((0, _bluebird.all)([_doctor.Doctor.findByDoctorId(doctorId), _doctor.Appointment.countPendingByDoctorIdAndDates(doctorId, startDate, endDate), _doctor.Appointment.countPendingByDoctorId(doctorId), _doctor.Appointment.countPrescribedByDoctorIdAndDates(doctorId, startDate, endDate), _doctor.Appointment.countPrescribedByDoctorId(doctorId), _doctor.Appointment.findByDoctorIdAndDates(doctorId, startDate, endDate)]));

          case 5:
            _ref2 = _context.sent;
            _ref3 = (0, _slicedToArray3.default)(_ref2, 6);
            doctor = _ref3[0];
            appointmentsPendingSpecified = _ref3[1];
            appointmentsPendingTotal = _ref3[2];
            appointmentsPrescribedSpecified = _ref3[3];
            appointmentsPrescribedTotal = _ref3[4];
            appointments = _ref3[5];


            res.json({
              timestamp: Date.now(),
              doctor: doctor,
              appointmentCount: {
                pending: {
                  specified: appointmentsPendingSpecified,
                  total: appointmentsPendingTotal
                },
                prescribed: {
                  specified: appointmentsPrescribedSpecified,
                  total: appointmentsPrescribedTotal
                }
              },
              startDate: startDate,
              endDate: endDate,
              appointments: appointments
            });

          case 14:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function appointments(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var findSpecializations = exports.findSpecializations = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var searchQuery, specializations;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            searchQuery = req.query.searchQuery;
            _context2.prev = 1;
            _context2.next = 4;
            return (0, _bluebird.resolve)(_doctor.Doctor.findSpecializations(searchQuery));

          case 4:
            specializations = _context2.sent;


            res.json({
              timestamp: Date.now(),
              specializations: specializations
            });
            _context2.next = 11;
            break;

          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2['catch'](1);

            res.status(400).end();

          case 11:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[1, 8]]);
  }));

  return function findSpecializations(_x3, _x4) {
    return _ref4.apply(this, arguments);
  };
}();

exports.injectParams = injectParams;

var _doctor = require('./doctor.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Actions
 */

/**
 * Inject authenticated user's id as a request parameter.
 *
 * @param req
 * @param res
 * @param next
 */
function injectParams(req, res, next) {
  req.query.doctorId = req.user._id;

  next();
}
//# sourceMappingURL=doctor.controller.js.map
