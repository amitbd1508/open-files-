'use strict';
/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.FeePrescription = exports.FeeAppointment = exports.getAppointmentType = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var getAppointmentType = exports.getAppointmentType = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(appointmentId) {
    var isAfterFollowUpDate, appointment, latestPrescription, followUpDate;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            // true mean its a new appointment
            isAfterFollowUpDate = true;
            _context.next = 3;
            return (0, _bluebird.resolve)(FeeAppointment.findById(appointmentId).exec());

          case 3:
            appointment = _context.sent;
            _context.next = 6;
            return (0, _bluebird.resolve)(FeePrescription.findOne({
              is_pdfready: true,
              patients_id: appointment.patients_id,
              created_at: {
                $lt: appointment.timestamp.book_by_rmp
              }
            }).sort('-publishAt').exec());

          case 6:
            latestPrescription = _context.sent;

            if (!(!latestPrescription || !latestPrescription.followup_date)) {
              _context.next = 9;
              break;
            }

            return _context.abrupt('return', isAfterFollowUpDate);

          case 9:

            // FIXME try not to use hard coded number, try to use ENUM
            followUpDate = (0, _momentTimezone2.default)(latestPrescription.followup_date).add(8, 'day');

            isAfterFollowUpDate = (0, _momentTimezone2.default)().isSameOrAfter(followUpDate);

            return _context.abrupt('return', isAfterFollowUpDate);

          case 12:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function getAppointmentType(_x) {
    return _ref.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _appointment = require('../../schemas/appointment.schema');

var _appointment2 = _interopRequireDefault(_appointment);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_prescription2.default.static('getAppointmentType', getAppointmentType);

var FeeAppointment = exports.FeeAppointment = _mongoose2.default.model('FeeAppointment', _appointment2.default, 'appointments');
var FeePrescription = exports.FeePrescription = _mongoose2.default.model('FeePrescription', _prescription2.default, 'prescriptions');
//# sourceMappingURL=fee.model.js.map
