'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getAppointmentType = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */
// All this codes are fucked up by one of the coders i just try to fix this as much as possible.

var getAppointmentType = exports.getAppointmentType = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var appointmentId, isAfterFollowUpDate;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            appointmentId = req.params.id;
            _context.next = 4;
            return (0, _bluebird.resolve)(_fee.FeePrescription.getAppointmentType(appointmentId));

          case 4:
            isAfterFollowUpDate = _context.sent;


            res.json({
              timestamp: Date.now(),
              isAfterFollowUpDate: isAfterFollowUpDate
            });
            _context.next = 11;
            break;

          case 8:
            _context.prev = 8;
            _context.t0 = _context['catch'](0);

            res.json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 8]]);
  }));

  return function getAppointmentType(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var _fee = require('./fee.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=fee.controller.js.map
