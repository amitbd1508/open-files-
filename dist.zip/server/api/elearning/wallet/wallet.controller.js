'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.services = exports.getUsersHistoryById = exports.getUsersBalanceById = exports.validateCashoutRequest = exports.saveCashoutRequest = exports.findCashoutRequest = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Actions
 */
var findCashoutRequest = exports.findCashoutRequest = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, limit, skip, cashoutRequests, count;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            limit = req.query.limit || 20;
            skip = req.query.skip || 0;
            _context.next = 7;
            return (0, _bluebird.resolve)(_wallet.CashoutRequest.findCashoutRequest(skip, limit, startDate, endDate));

          case 7:
            cashoutRequests = _context.sent;
            _context.next = 10;
            return (0, _bluebird.resolve)(_wallet.CashoutRequest.count());

          case 10:
            count = _context.sent;


            res.json({
              timestamp: Date.now(),
              cashoutRequests: cashoutRequests,
              count: count
            });
            _context.next = 17;
            break;

          case 14:
            _context.prev = 14;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 17:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 14]]);
  }));

  return function findCashoutRequest(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var saveCashoutRequest = exports.saveCashoutRequest = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var formData, userId, cashoutRequest;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            formData = req.body;
            userId = req.params.id;
            _context2.next = 5;
            return (0, _bluebird.resolve)(_wallet.CashoutRequest.saveCashoutRequest(formData, userId));

          case 5:
            cashoutRequest = _context2.sent;


            res.json({
              timestamp: Date.now(),
              cashoutRequest: cashoutRequest
            });
            _context2.next = 12;
            break;

          case 9:
            _context2.prev = 9;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 12:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 9]]);
  }));

  return function saveCashoutRequest(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var validateCashoutRequest = exports.validateCashoutRequest = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var formData, requestId, userId, cashoutRequest;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            formData = req.body;
            requestId = req.params.id;
            userId = req.user._id;
            _context3.next = 6;
            return (0, _bluebird.resolve)(_wallet.CashoutRequest.validateCashoutRequest(requestId, formData, userId));

          case 6:
            cashoutRequest = _context3.sent;


            res.json({
              timestamp: Date.now(),
              cashoutRequest: cashoutRequest
            });
            _context3.next = 13;
            break;

          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 13:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 10]]);
  }));

  return function validateCashoutRequest(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var getUsersBalanceById = exports.getUsersBalanceById = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var userId, balance;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            userId = req.params.id;
            _context4.next = 4;
            return (0, _bluebird.resolve)(_wallet.Cashout.getUsersBalanceById(userId));

          case 4:
            balance = _context4.sent;


            res.json({
              timestamp: Date.now(),
              balance: balance
            });
            _context4.next = 11;
            break;

          case 8:
            _context4.prev = 8;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 11:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 8]]);
  }));

  return function getUsersBalanceById(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var getUsersHistoryById = exports.getUsersHistoryById = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var userId, startDate, endDate, limit, skip, history;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            userId = req.params.id;
            startDate = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate).toDate() : (0, _momentTimezone2.default)().startOf('month').toDate();
            endDate = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate).toDate() : (0, _momentTimezone2.default)().endOf('month').toDate();
            limit = req.query.limit || 100;
            skip = req.query.skip || 0;
            _context5.next = 8;
            return (0, _bluebird.resolve)(_wallet.WalletTransaction.getUsersHistoryById(userId, startDate, endDate, limit, skip));

          case 8:
            history = _context5.sent;


            res.json({
              timestamp: Date.now(),
              startOfMonthBalance: 0,
              endOfMonthBalance: 0,
              history: history
            });
            _context5.next = 15;
            break;

          case 12:
            _context5.prev = 12;
            _context5.t0 = _context5['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 15:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 12]]);
  }));

  return function getUsersHistoryById(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var services = exports.services = function () {
  var _ref6 = (0, _bluebird.method)(function (req, res) {
    try {
      var _services = environment.SERVICE_CATEGORY;

      res.json({
        timestamp: Date.now(),
        services: _services
      });
    } catch (error) {
      res.status(400).json({
        timestamp: Date.now(),
        error: error.toString()
      });
    }
  });

  return function services(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _wallet = require('./wallet.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../../config/environment');
//# sourceMappingURL=wallet.controller.js.map
