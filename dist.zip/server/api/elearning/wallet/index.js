'use strict';

/**
 * Imports
 */

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var controller = require('./wallet.controller');

var express = require('express');
var router = express.Router();

/**
 * Routes
 */
// Get all cashout request submitted by RMP for admin
router.get('/cashout/requests', auth.isAuthenticated(), controller.findCashoutRequest);

// Approve cashout request by admin from client side
router.put('/cashout/requests/:id/validate', auth.isAuthenticated(), controller.validateCashoutRequest);

// Save the cashout request from mobile
// Required field (phone, amount)
router.post('/cashout/requests/users/:id', controller.saveCashoutRequest);

// Get users balance by id
router.get('/balances/users/:id', controller.getUsersBalanceById);

// get users transaction history by user's id
router.get('/history/users/:id', controller.getUsersHistoryById);

// Get all the service name we are using in this project
router.get('/services', controller.services);
/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
