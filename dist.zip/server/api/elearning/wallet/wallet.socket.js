'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _wallet = require('./wallet.events');

var _wallet2 = _interopRequireDefault(_wallet);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  cashoutRequestCreate(socket);
  cashoutRequestUpdate(socket);
  cashoutRequestRemove(socket);
}

/**
 *
 * @param socket
 */
function cashoutRequestCreate(socket) {
  var listener = function listener() {
    socket.emit('elearning:wallet:cashout:request:create', {
      timestamp: Date.now()
    });
  };

  _wallet2.default.on('elearning:wallet:cashout:request:create', listener);

  socket.on('disconnect', function () {
    _wallet2.default.removeListener('elearning:wallet:cashout:request:create', listener);
  });
}

function cashoutRequestUpdate(socket) {
  var listener = function listener() {
    socket.emit('elearning:wallet:cashout:request:update', {
      timestamp: Date.now()
    });
  };

  _wallet2.default.on('elearning:wallet:cashout:request:update', listener);

  socket.on('disconnect', function () {
    _wallet2.default.removeListener('elearning:wallet:cashout:request:update', listener);
  });
}

function cashoutRequestRemove(socket) {
  var listener = function listener() {
    socket.emit('elearning:wallet:cashout:request:remove', {
      timestamp: Date.now()
    });
  };

  _wallet2.default.on('elearning:wallet:cashout:request:remove', listener);

  socket.on('disconnect', function () {
    _wallet2.default.removeListener('elearning:wallet:cashout:request:remove', listener);
  });
}
//# sourceMappingURL=wallet.socket.js.map
