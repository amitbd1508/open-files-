'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var WalletEvents = new _events.EventEmitter();

/**
 * Options
 */
WalletEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = WalletEvents;
//# sourceMappingURL=wallet.events.js.map
