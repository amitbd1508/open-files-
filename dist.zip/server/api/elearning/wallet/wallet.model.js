'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WalletUser = exports.WalletTransaction = exports.Cashout = exports.CashoutRequest = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var Promise = _interopRequireWildcard(_bluebird);

var findCashoutRequest = function () {
  var _ref = (0, _bluebird.method)(function (skip, limit, startDate, endDate) {
    var query = {
      requestedAt: {
        $gte: startDate,
        $lte: endDate
      }
    };

    return this.find(query).populate({
      path: 'requestedBy',
      select: 'name phone photo'
    }).limit(parseInt(limit)).skip(parseInt(skip)).sort({
      isApproved: 1,
      respondedAt: -1
    }).lean().exec();
  });

  return function findCashoutRequest(_x, _x2, _x3, _x4) {
    return _ref.apply(this, arguments);
  };
}();

var saveCashoutRequest = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData, userId) {
    var balance, cashoutRequest;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (formData.phone) {
              _context.next = 2;
              break;
            }

            throw new Error('Phone number is required');

          case 2:
            if (formData.amount) {
              _context.next = 4;
              break;
            }

            throw new Error('Amount is required');

          case 4:
            if (userId) {
              _context.next = 6;
              break;
            }

            throw new Error('User is required');

          case 6:
            _context.next = 8;
            return (0, _bluebird.resolve)(Cashout.getUsersBalanceById(userId));

          case 8:
            balance = _context.sent;

            if (!(balance.netBalance - balance.netAwaitingCashoutRequested < parseInt(formData.amount))) {
              _context.next = 11;
              break;
            }

            throw new Error('Insufficient balance');

          case 11:
            cashoutRequest = new this();


            cashoutRequest.requestedBy = userId;
            cashoutRequest.phone = formData.phone;
            cashoutRequest.amount = formData.amount;

            _context.next = 17;
            return (0, _bluebird.resolve)(cashoutRequest.save());

          case 17:

            _wallet2.default.emit('elearning:wallet:cashout:request:create');

            return _context.abrupt('return', cashoutRequest);

          case 19:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function saveCashoutRequest(_x5, _x6) {
    return _ref2.apply(this, arguments);
  };
}();

var validateCashoutRequest = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(requestId, formData, userId) {
    var cashoutRequest, requestedBy;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.findById(requestId).exec());

          case 2:
            cashoutRequest = _context2.sent;

            if (cashoutRequest) {
              _context2.next = 5;
              break;
            }

            throw new Error('Request not found');

          case 5:
            if (cashoutRequest.requestedBy) {
              _context2.next = 7;
              break;
            }

            throw new Error('Requested User not found');

          case 7:
            requestedBy = cashoutRequest.requestedBy;
            _context2.next = 10;
            return (0, _bluebird.resolve)(Cashout.validateRequestById(requestId, requestedBy, formData.isApproved, userId));

          case 10:

            cashoutRequest.isApproved = formData.isApproved || false;
            cashoutRequest.type = formData.type;
            cashoutRequest.note = formData.note;
            cashoutRequest.isResponded = true;

            _context2.next = 16;
            return (0, _bluebird.resolve)(cashoutRequest.save());

          case 16:

            _wallet2.default.emit('elearning:wallet:cashout:request:update');

            return _context2.abrupt('return', cashoutRequest);

          case 18:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function validateCashoutRequest(_x7, _x8, _x9) {
    return _ref3.apply(this, arguments);
  };
}();

var validateRequestById = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(requestId, requestedBy, isApproved, updatedBy) {
    var cashout;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(Cashout.findOne({
              requestId: requestId
            }).exec());

          case 2:
            cashout = _context3.sent;

            if (!(isApproved && !cashout)) {
              _context3.next = 10;
              break;
            }

            cashout = new Cashout();

            cashout.requestId = requestId;
            cashout.updatedBy = updatedBy;
            cashout.userId = requestedBy;

            _context3.next = 10;
            return (0, _bluebird.resolve)(cashout.save());

          case 10:
            if (!(!isApproved && cashout)) {
              _context3.next = 13;
              break;
            }

            _context3.next = 13;
            return (0, _bluebird.resolve)(Cashout.findByIdAndUpdate(cashout._id, {
              isActive: false,
              updatedBy: updatedBy
            }).exec());

          case 13:
            return _context3.abrupt('return', cashout);

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function validateRequestById(_x10, _x11, _x12, _x13) {
    return _ref4.apply(this, arguments);
  };
}();

var getUsersBalanceById = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(userId) {
    var user;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(WalletUser.findById(userId).exec());

          case 2:
            user = _context4.sent;

            if (user) {
              _context4.next = 5;
              break;
            }

            throw new Error('User not found');

          case 5:
            return _context4.abrupt('return', Promise.all([calculateCashout(userId), calculateRevenue(userId), calculateAwaitingCashoutRequest(userId)]).spread(function (netCashout, netRevenue, netAwaitingCashoutRequested) {
              return {
                netAwaitingCashoutRequested: netAwaitingCashoutRequested,
                netCashout: netCashout,
                netRevenue: netRevenue,
                netBalance: netRevenue - netCashout,
                netRemaining: netRevenue - netCashout - netAwaitingCashoutRequested
              };
            }));

          case 6:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function getUsersBalanceById(_x14) {
    return _ref5.apply(this, arguments);
  };
}();

var getUsersHistoryById = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(userId, startDate, endDate, limit, skip) {
    var transactions, cashOuts, cashOutRequest, history;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(getTransaction(userId, startDate, endDate, limit, skip));

          case 2:
            transactions = _context5.sent;
            _context5.next = 5;
            return (0, _bluebird.resolve)(getCashOuts(userId, startDate, endDate, limit, skip));

          case 5:
            cashOuts = _context5.sent;
            _context5.next = 8;
            return (0, _bluebird.resolve)(getCashOutsRequest(userId, startDate, endDate, limit, skip));

          case 8:
            cashOutRequest = _context5.sent;
            history = transactions.concat(cashOuts, cashOutRequest);
            return _context5.abrupt('return', _lodash2.default.sortBy(history, ['createdAt']));

          case 11:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function getUsersHistoryById(_x15, _x16, _x17, _x18, _x19) {
    return _ref6.apply(this, arguments);
  };
}();

var getCashOutsRequest = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(userId, startDate, endDate, limit, skip) {
    var queryCashOuts, cashOuts;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            queryCashOuts = {
              createdAt: {
                $gte: startDate,
                $lte: endDate
              },
              isResponded: false,
              requestedBy: objectId(userId)
            };
            _context6.next = 3;
            return (0, _bluebird.resolve)(CashoutRequest.find(queryCashOuts).populate({
              path: 'requestId'
            }).limit(parseInt(limit)).skip(parseInt(skip)).lean().exec());

          case 3:
            cashOuts = _context6.sent;
            _context6.next = 6;
            return (0, _bluebird.resolve)(Promise.map(cashOuts, function () {
              var _ref8 = (0, _bluebird.method)(function (cashout) {
                var local = {};
                local._id = cashout._id;
                local.title = 'ক্যাশ আউট';
                local.status = 'প্রক্রিয়াধীন';
                local.amount = '- ' + cashout.amount;
                local.phone = cashout.phone;
                local.createdAt = cashout.createdAt;
                local.updatedAt = cashout.updatedAt;
                return local;
              });

              return function (_x25) {
                return _ref8.apply(this, arguments);
              };
            }()));

          case 6:
            return _context6.abrupt('return', _context6.sent);

          case 7:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function getCashOutsRequest(_x20, _x21, _x22, _x23, _x24) {
    return _ref7.apply(this, arguments);
  };
}();

var getCashOuts = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(userId, startDate, endDate, limit, skip) {
    var queryCashOuts, cashOuts;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            queryCashOuts = {
              createdAt: {
                $gte: startDate,
                $lte: endDate
              },
              userId: objectId(userId)
            };
            _context7.next = 3;
            return (0, _bluebird.resolve)(Cashout.find(queryCashOuts).populate({
              path: 'requestId'
            }).limit(parseInt(limit)).skip(parseInt(skip)).lean().exec());

          case 3:
            cashOuts = _context7.sent;
            _context7.next = 6;
            return (0, _bluebird.resolve)(Promise.map(cashOuts, function () {
              var _ref10 = (0, _bluebird.method)(function (cashout) {
                var local = {};
                local._id = cashout._id;
                local.title = 'ক্যাশ আউট';
                local.amount = '- ' + cashout.requestId.amount;
                local.phone = cashout.requestId.phone;
                local.createdAt = cashout.createdAt;
                local.updatedAt = cashout.updatedAt;
                return local;
              });

              return function (_x31) {
                return _ref10.apply(this, arguments);
              };
            }()));

          case 6:
            return _context7.abrupt('return', _context7.sent);

          case 7:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function getCashOuts(_x26, _x27, _x28, _x29, _x30) {
    return _ref9.apply(this, arguments);
  };
}();

var getTransaction = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(userId, startDate, endDate, limit, skip) {
    var queryTransaction, transactions;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            queryTransaction = {
              createdAt: {
                $gte: startDate,
                $lte: endDate
              },
              isActive: true,
              userId: objectId(userId)
            };
            _context8.next = 3;
            return (0, _bluebird.resolve)(WalletTransaction.find(queryTransaction).populate({
              path: 'priceId'
            }).limit(parseInt(limit)).skip(parseInt(skip)).exec());

          case 3:
            transactions = _context8.sent;
            _context8.next = 6;
            return (0, _bluebird.resolve)(Promise.map(transactions, function () {
              var _ref12 = (0, _bluebird.method)(function (transaction) {
                var local = {};
                local._id = transaction._id;
                local.title = transaction.prescriptionCollectId ? 'প্রেসক্রিপশন' : 'রুগী রেফারেল';
                local.amount = '+ ' + transaction.priceId.amount;
                local.createdAt = transaction.createdAt;
                local.updatedAt = transaction.updatedAt;
                return local;
              });

              return function (_x37) {
                return _ref12.apply(this, arguments);
              };
            }()));

          case 6:
            return _context8.abrupt('return', _context8.sent);

          case 7:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function getTransaction(_x32, _x33, _x34, _x35, _x36) {
    return _ref11.apply(this, arguments);
  };
}();

/**
 * Exports
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _cashoutRequest = require('../../../schemas/elearning/cashout-request.schema');

var _cashoutRequest2 = _interopRequireDefault(_cashoutRequest);

var _transaction = require('../../../schemas/elearning/transaction.schema');

var _transaction2 = _interopRequireDefault(_transaction);

var _cashout = require('../../../schemas/elearning/cashout.schema');

var _cashout2 = _interopRequireDefault(_cashout);

var _user = require('../../../schemas/elearning/user.schema');

var _user2 = _interopRequireDefault(_user);

var _wallet = require('./wallet.events');

var _wallet2 = _interopRequireDefault(_wallet);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Schema static declaration
 */
_cashoutRequest2.default.static('findCashoutRequest', findCashoutRequest).static('saveCashoutRequest', saveCashoutRequest).static('validateCashoutRequest', validateCashoutRequest);

_cashout2.default.static('validateRequestById', validateRequestById).static('getUsersBalanceById', getUsersBalanceById);

_transaction2.default.static('getUsersHistoryById', getUsersHistoryById);

function calculateCashout(userId) {
  return Cashout.aggregate([{
    $match: {
      isActive: true,
      userId: objectId(userId)
    }
  }, {
    $lookup: {
      from: "e_learning_cashout_request",
      localField: "requestId",
      foreignField: "_id",
      as: "requestId"
    }
  }, {
    $unwind: {
      path: "$requestId"
    }
  }, {
    $group: {
      _id: null,
      amount: { $sum: '$requestId.amount' }
    }
  }]).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].amount;
    return 0;
  });
}

function calculateRevenue(userId) {
  return WalletTransaction.aggregate([{
    $match: {
      isActive: true,
      userId: objectId(userId)
    }
  }, {
    $lookup: {
      from: "e_learning_prices",
      localField: "priceId",
      foreignField: "_id",
      as: "priceId"
    }
  }, {
    $unwind: {
      path: "$priceId"
    }
  }, {
    $group: {
      _id: null,
      amount: { $sum: '$priceId.amount' }
    }
  }]).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].amount;
    return 0;
  });
}

function calculateAwaitingCashoutRequest(userId) {
  return CashoutRequest.aggregate([{
    $match: {
      isResponded: false,
      requestedBy: objectId(userId)
    }
  }, {
    $group: {
      _id: null,
      amount: { $sum: '$amount' }
    }
  }]).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].amount;
    return 0;
  });
}

var CashoutRequest = exports.CashoutRequest = _mongoose2.default.model('CashoutRequest', _cashoutRequest2.default, 'e_learning_cashout_request');
var Cashout = exports.Cashout = _mongoose2.default.model('Cashout', _cashout2.default, 'e_learning_cashout');
var WalletTransaction = exports.WalletTransaction = _mongoose2.default.model('ELTransaction', _transaction2.default, 'e_learning_transaction');
var WalletUser = exports.WalletUser = _mongoose2.default.model('WalletUser', _user2.default, 'e_learning_users');
//# sourceMappingURL=wallet.model.js.map
