'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.validatePatientReferral = exports.savePatientReferral = exports.index = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, limit, skip, count, patientReferrals;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            limit = req.query.limit || 20;
            skip = req.query.skip || 0;
            _context.next = 7;
            return (0, _bluebird.resolve)(_patientReferral.PatientReferral.count());

          case 7:
            count = _context.sent;
            _context.next = 10;
            return (0, _bluebird.resolve)(_patientReferral.PatientReferral.index(skip, limit, startDate, endDate));

          case 10:
            patientReferrals = _context.sent;


            res.json({
              timestamp: Date.now(),
              patientReferrals: patientReferrals,
              count: count
            });
            _context.next = 17;
            break;

          case 14:
            _context.prev = 14;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 17:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 14]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var savePatientReferral = exports.savePatientReferral = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var formData, submittedBy, patientReferral;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            formData = req.body;
            submittedBy = req.params.id;
            _context2.next = 5;
            return (0, _bluebird.resolve)(_patientReferral.PatientReferral.savePatientReferral(submittedBy, formData));

          case 5:
            patientReferral = _context2.sent;


            res.json({
              timestamp: Date.now(),
              patientReferral: patientReferral
            });
            _context2.next = 12;
            break;

          case 9:
            _context2.prev = 9;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 12:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 9]]);
  }));

  return function savePatientReferral(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var validatePatientReferral = exports.validatePatientReferral = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var isApproved, id, userId, patientReferral;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            isApproved = req.body.isApproved;
            id = req.params.id;
            userId = req.user._id;
            _context3.next = 6;
            return (0, _bluebird.resolve)(_patientReferral.PatientReferral.validatePatientReferral(id, isApproved, userId));

          case 6:
            patientReferral = _context3.sent;


            res.json({
              timestamp: Date.now(),
              patientReferral: patientReferral
            });
            _context3.next = 13;
            break;

          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 13:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 10]]);
  }));

  return function validatePatientReferral(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

exports.uploadPrescriptionImageToS3 = uploadPrescriptionImageToS3;

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _patientReferral = require('./patient-referral.model');

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Actions
 */

var environment = require('../../../config/environment/index');
_awsSdk2.default.config.update(environment.aws);

var patientReferralPhotoBucket = environment.aws.s3_bucket + '/e_learing_patient_referral';
var s3 = new _awsSdk2.default.S3({
  params: {
    Bucket: patientReferralPhotoBucket
  }
});

function uploadPrescriptionImageToS3(req, res, next) {
  var formData = req.body;
  var dateNow = Date.now();
  var base64Image = formData.imageURL;
  var submittedBy = req.params.id;

  if (!isValidBase64(base64Image)) {
    next();
  } else {
    var bufferImage = new Buffer(base64Image.replace(/^data:image\/\w+;base64,/, ""), 'base64');
    var option = {
      Key: submittedBy + '-' + dateNow + '.jpeg',
      Body: bufferImage,
      ContentEncoding: 'base64',
      ContentType: 'image/jpeg',
      ACL: 'public-read'
    };

    s3.putObject(option, function (err, data) {
      if (err) {
        console.error('Error in image uploading: ', data);
      } else {
        req.body.imageURL = 'https://s3.ap-south-1.amazonaws.com/' + patientReferralPhotoBucket + '/' + submittedBy + '-' + dateNow + '.jpeg';
      }
      next();
    });
  }
}

function isValidBase64(base64Image) {
  if (!base64Image) return false;

  return base64Image.includes("data:image/jpeg;base64");
}
//# sourceMappingURL=patient-referral.controller.js.map
