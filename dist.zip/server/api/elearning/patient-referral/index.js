'use strict';

/**
 * Imports
 */

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var controller = require('./patient-referral.controller');

var express = require('express');
var router = express.Router();

/**
 * Routes
 */

// Get all PatientReferral submitted bu RMP for admin
router.get('/', auth.isAuthenticated(), controller.index);

// Save the PatientReferral image from mobile
router.post('/users/:id', controller.uploadPrescriptionImageToS3, controller.savePatientReferral);

// Approve by admin from widget
router.put('/:id/validate', auth.isAuthenticated(), controller.validatePatientReferral);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
