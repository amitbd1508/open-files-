'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _patientReferral = require('./patient-referral.events');

var _patientReferral2 = _interopRequireDefault(_patientReferral);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('elearning:patient:referral:create', {
      timestamp: Date.now()
    });
  };

  _patientReferral2.default.on('elearning:patient:referral:create', listener);

  socket.on('disconnect', function () {
    _patientReferral2.default.removeListener('elearning:patient:referral:create', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('elearning:patient:referral:update', {
      timestamp: Date.now()
    });
  };

  _patientReferral2.default.on('elearning:patient:referral:update', listener);

  socket.on('disconnect', function () {
    _patientReferral2.default.removeListener('elearning:patient:referral:update', listener);
  });
}

function remove(socket) {
  var listener = function listener() {
    socket.emit('elearning:patient:referral:remove', {
      timestamp: Date.now()
    });
  };

  _patientReferral2.default.on('elearning:patient:referral:remove', listener);

  socket.on('disconnect', function () {
    _patientReferral2.default.removeListener('elearning:patient:referral:remove', listener);
  });
}
//# sourceMappingURL=patient-referral.socket.js.map
