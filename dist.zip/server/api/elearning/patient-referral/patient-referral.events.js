'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var PatientReferralEvents = new _events.EventEmitter();

/**
 * Options
 */
PatientReferralEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = PatientReferralEvents;
//# sourceMappingURL=patient-referral.events.js.map
