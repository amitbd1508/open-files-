'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PatientReferralTransaction = exports.ElearningPatient = exports.PatientReferral = undefined;

var _regenerator = require("babel-runtime/regenerator");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _keys = require("babel-runtime/core-js/object/keys");

var _keys2 = _interopRequireDefault(_keys);

var _bluebird = require("bluebird");

var index = function () {
  var _ref = (0, _bluebird.method)(function (skip, limit, startDate, endDate) {
    var query = {
      submittedAt: {
        $gte: startDate,
        $lte: endDate
      }
    };

    return this.find(query).populate({
      path: 'submittedBy',
      select: 'name phone photo'
    }).populate({
      path: 'priceId'
    }).populate({
      path: 'patientId'
    }).limit(parseInt(limit)).skip(parseInt(skip)).sort({
      isApproved: 1,
      submittedAt: -1
    }).lean().exec();
  });

  return function index(_x, _x2, _x3, _x4) {
    return _ref.apply(this, arguments);
  };
}();

var savePatientReferral = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(submittedBy, formData) {
    var serviceCategory, price, patient, patientReferral;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            serviceCategory = (0, _keys2.default)(environment.SERVICE_CATEGORY)[1];

            if (submittedBy) {
              _context.next = 3;
              break;
            }

            throw new Error('User id not found');

          case 3:
            _context.next = 5;
            return (0, _bluebird.resolve)(_price.Price.getDefaultPriceByCategory(serviceCategory));

          case 5:
            price = _context.sent;

            if (price) {
              _context.next = 8;
              break;
            }

            throw new Error('Price is not defined properly');

          case 8:
            _context.next = 10;
            return (0, _bluebird.resolve)(savePatient(formData));

          case 10:
            patient = _context.sent;
            patientReferral = new PatientReferral();


            patientReferral.priceId = price._id;
            patientReferral.patientId = patient._id;
            patientReferral.submittedBy = submittedBy;
            patientReferral.submittedAt = Date.now();

            _patientReferral4.default.emit('elearning:patient:referral:create');

            return _context.abrupt("return", patientReferral.save());

          case 18:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function savePatientReferral(_x5, _x6) {
    return _ref2.apply(this, arguments);
  };
}();

var savePatient = function () {
  var _ref3 = (0, _bluebird.method)(function (formData) {
    var patient = new ElearningPatient();

    patient.name = formData.name;
    patient.gender = formData.gender;
    patient.imageURL = formData.imageURL;
    patient.phone = formData.phone;
    patient.weight = formData.weight;
    patient.type = formData.type;
    patient.address = formData.address;
    patient.type = formData.type;
    patient.dob = (0, _momentTimezone2.default)().subtract(parseInt(formData.dob), 'y');

    return patient.save();
  });

  return function savePatient(_x7) {
    return _ref3.apply(this, arguments);
  };
}();

var validatePatientReferral = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(patientReferralId, isApproved, updatedBy) {
    var patientReferral, priceId, submittedBy;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(PatientReferral.findById(patientReferralId).exec());

          case 2:
            patientReferral = _context2.sent;

            if (patientReferral) {
              _context2.next = 5;
              break;
            }

            throw new Error('Patient Referral not found');

          case 5:
            priceId = patientReferral.priceId;
            submittedBy = patientReferral.submittedBy;
            _context2.next = 9;
            return (0, _bluebird.resolve)(validateByPatientReferralId(patientReferralId, submittedBy, isApproved, updatedBy, priceId));

          case 9:

            patientReferral.isApproved = isApproved;
            patientReferral.respondedBy = updatedBy;
            patientReferral.respondedAt = Date.now();

            _patientReferral4.default.emit('elearning:patient:referral:update');

            _context2.next = 15;
            return (0, _bluebird.resolve)(patientReferral.save());

          case 15:
            return _context2.abrupt("return", _context2.sent);

          case 16:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function validatePatientReferral(_x8, _x9, _x10) {
    return _ref4.apply(this, arguments);
  };
}();

var validateByPatientReferralId = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(patientReferralId, submittedBy, isApproved, updatedBy, priceId) {
    var transaction;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(PatientReferralTransaction.findOne({
              patientReferralId: patientReferralId
            }).exec());

          case 2:
            transaction = _context3.sent;

            if (!(isApproved && !transaction)) {
              _context3.next = 12;
              break;
            }

            transaction = new PatientReferralTransaction();
            transaction.priceId = priceId;
            transaction.updatedBy = updatedBy;
            transaction.userId = submittedBy;
            transaction.patientReferralId = patientReferralId;

            _context3.next = 11;
            return (0, _bluebird.resolve)(transaction.save());

          case 11:
            return _context3.abrupt("return", _context3.sent);

          case 12:
            if (!(!isApproved && transaction)) {
              _context3.next = 16;
              break;
            }

            _context3.next = 15;
            return (0, _bluebird.resolve)(PatientReferralTransaction.findByIdAndUpdate(transaction._id, {
              isActive: false,
              updatedBy: updatedBy,
              priceId: priceId
            }).exec());

          case 15:
            return _context3.abrupt("return", _context3.sent);

          case 16:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function validateByPatientReferralId(_x11, _x12, _x13, _x14, _x15) {
    return _ref5.apply(this, arguments);
  };
}();

/**
 * Exports
 */


var _mongoose = require("mongoose");

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require("moment-timezone");

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _price = require("../price/price.model");

var _patientReferral = require("../../../schemas/elearning/patient-referral.schema");

var _patientReferral2 = _interopRequireDefault(_patientReferral);

var _elearningPatient = require("../../../schemas/elearning/elearning-patient.schema");

var _elearningPatient2 = _interopRequireDefault(_elearningPatient);

var _transaction = require("../../../schemas/elearning/transaction.schema");

var _transaction2 = _interopRequireDefault(_transaction);

var _patientReferral3 = require("./patient-referral.events");

var _patientReferral4 = _interopRequireDefault(_patientReferral3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../../config/environment/index');

/**
 * Schema static declaration
 */
_patientReferral2.default.static('index', index).static('validatePatientReferral', validatePatientReferral).static('savePatientReferral', savePatientReferral);

var PatientReferral = exports.PatientReferral = _mongoose2.default.model('PatientReferral', _patientReferral2.default, 'e_learning_patient_referral');
var ElearningPatient = exports.ElearningPatient = _mongoose2.default.model('ElearningPatient', _elearningPatient2.default, 'e_learning_patient');
var PatientReferralTransaction = exports.PatientReferralTransaction = _mongoose2.default.model('PrescriptionCollectTransaction', _transaction2.default, 'e_learning_transaction');
//# sourceMappingURL=patient-referral.model.js.map
