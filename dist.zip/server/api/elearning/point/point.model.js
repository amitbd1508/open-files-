'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.listUserResults = exports.listUserPoints = exports.getUserPoints = exports.listQuizPoints = exports.listCasePoints = exports.getPublishedDateRangeForContent = exports.getPointsForContent = undefined;

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _bluebird = require('bluebird');

var _toConsumableArray2 = require('babel-runtime/helpers/toConsumableArray');

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Functions
 */

/**
 * Calculate points for a user for the given set of content
 *
 * FIXME: This algorithm is O(n) because it has a query per content item.
 * FIXME: Optimize speed by using one aggregate query for O(1).
 *
 * @param userPhone
 * @param contentItems
 * @returns {Promise<number>}
 */
var getPointsForContent = exports.getPointsForContent = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(userPhone, contentItems) {
    var _this = this;

    var pointsPerItem, points;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)((0, _bluebird.map)(contentItems, function () {
              var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(item) {
                var score;
                return _regenerator2.default.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        if (_typeform.TypeformForm.isUrl(item.embedUrl)) {
                          _context.next = 2;
                          break;
                        }

                        return _context.abrupt('return', 0);

                      case 2:
                        _context.next = 4;
                        return (0, _bluebird.resolve)(_typeform.TypeformResult.getHighestScore(_typeform.TypeformForm.getUid(item.embedUrl), userPhone));

                      case 4:
                        score = _context.sent;
                        return _context.abrupt('return', score / 100 * item.points || 0);

                      case 6:
                      case 'end':
                        return _context.stop();
                    }
                  }
                }, _callee, _this);
              }));

              return function (_x3) {
                return _ref2.apply(this, arguments);
              };
            }()));

          case 2:
            pointsPerItem = _context2.sent;
            points = pointsPerItem.reduce(function (totalPoints, currentPoints) {
              return totalPoints + currentPoints;
            }, 0);
            return _context2.abrupt('return', Math.floor(points));

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getPointsForContent(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Calculate published date range for the given set of content
 *
 * FIXME: This algorithm is O(n) because it has a query per content item.
 * FIXME: Optimize speed by using one aggregate query for O(1).
 *
 * @param contentItems
 * @returns {Promise<{startDate: Date, endDate: Date}>}
 */


var getPublishedDateRangeForContent = exports.getPublishedDateRangeForContent = function () {
  var _ref3 = (0, _bluebird.method)(function (contentItems) {
    var startDates = contentItems.map(function (item) {
      return item.publishDate;
    });
    var endDates = contentItems.map(function (item) {
      return item.unpublishDate;
    });

    startDates.sort(function (firstDate, secondDate) {
      return firstDate - secondDate;
    });
    endDates.sort(function (firstDate, secondDate) {
      return secondDate - firstDate;
    });

    var startDate = startDates.length > 0 ? startDates[0] : new Date();
    var endDate = endDates.length > 0 ? endDates[0] : new Date();

    return {
      startDate: startDate,
      endDate: endDate
    };
  });

  return function getPublishedDateRangeForContent(_x4) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Calculate points of all users for solving the currently published set of cases.
 *
 * FIXME: This algorithm is O(n^2) because it has a query per user per rugi.
 * FIXME: Optimize speed by using one aggregate query for O(1).
 *
 * @returns {Promise<{startDate: Date, endDate: Date, participants: Array<*>}>}
 */


var listCasePoints = exports.listCasePoints = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(date) {
    var _ref5,
        _this2 = this;

    var cases, rugies, dates, typeformUids, phoneNumbers, users, usersWithPoints;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(_case.Case.findPublished(date));

          case 2:
            cases = _context4.sent;
            rugies = (_ref5 = []).concat.apply(_ref5, (0, _toConsumableArray3.default)(cases.map(function (caseObj) {
              return caseObj.rugies;
            })));
            _context4.next = 6;
            return (0, _bluebird.resolve)(getPublishedDateRangeForContent(cases));

          case 6:
            dates = _context4.sent;
            typeformUids = rugies.filter(function (rugi) {
              return _typeform.TypeformForm.isUrl(rugi.embedUrl);
            }).map(function (rugi) {
              return _typeform.TypeformForm.getUid(rugi.embedUrl);
            });
            _context4.next = 10;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.getAllPhones(typeformUids));

          case 10:
            phoneNumbers = _context4.sent;
            _context4.next = 13;
            return (0, _bluebird.resolve)(_user.eLearningUser.findByPhone(phoneNumbers));

          case 13:
            users = _context4.sent;
            _context4.next = 16;
            return (0, _bluebird.resolve)((0, _bluebird.map)(users, function () {
              var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(user) {
                var points;
                return _regenerator2.default.wrap(function _callee3$(_context3) {
                  while (1) {
                    switch (_context3.prev = _context3.next) {
                      case 0:
                        _context3.next = 2;
                        return (0, _bluebird.resolve)(getPointsForContent(user.phone, rugies));

                      case 2:
                        points = _context3.sent;
                        return _context3.abrupt('return', _decorateUser(user, points));

                      case 4:
                      case 'end':
                        return _context3.stop();
                    }
                  }
                }, _callee3, _this2);
              }));

              return function (_x6) {
                return _ref6.apply(this, arguments);
              };
            }()));

          case 16:
            usersWithPoints = _context4.sent;


            usersWithPoints.sort(function (user1, user2) {
              return user2.points - user1.points;
            });

            return _context4.abrupt('return', {
              startDate: dates.startDate,
              endDate: dates.endDate,
              participants: usersWithPoints
            });

          case 19:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function listCasePoints(_x5) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Calculate points of all users for solving the currently published weekly quiz.
 *
 * FIXME: This algorithm is O(n) because it has a query per user.
 * FIXME: Optimize speed by using one aggregate query for O(1).
 *
 * @returns {Promise<Array<*>>}
 */


var listQuizPoints = exports.listQuizPoints = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6() {
    var _this3 = this;

    var quiz, phoneNumbers, users, usersWithPoints;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(_quiz.Quiz.lastQuiz());

          case 2:
            quiz = _context6.sent;

            if (_typeform.TypeformForm.isUrl(quiz.embedUrl)) {
              _context6.next = 5;
              break;
            }

            return _context6.abrupt('return', []);

          case 5:
            _context6.next = 7;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.getAllPhones(_typeform.TypeformForm.getUid(quiz.embedUrl)));

          case 7:
            phoneNumbers = _context6.sent;
            _context6.next = 10;
            return (0, _bluebird.resolve)(_user.eLearningUser.findByPhone(phoneNumbers));

          case 10:
            users = _context6.sent;
            _context6.next = 13;
            return (0, _bluebird.resolve)((0, _bluebird.map)(users, function () {
              var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(user) {
                var points;
                return _regenerator2.default.wrap(function _callee5$(_context5) {
                  while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        _context5.next = 2;
                        return (0, _bluebird.resolve)(getPointsForContent(user.phone, [quiz]));

                      case 2:
                        points = _context5.sent;
                        return _context5.abrupt('return', _decorateUser(user, points));

                      case 4:
                      case 'end':
                        return _context5.stop();
                    }
                  }
                }, _callee5, _this3);
              }));

              return function (_x7) {
                return _ref8.apply(this, arguments);
              };
            }()));

          case 13:
            usersWithPoints = _context6.sent;


            // Sort by points in descending order
            usersWithPoints.sort(function (user1, user2) {
              return user2.points - user1.points;
            });

            return _context6.abrupt('return', usersWithPoints);

          case 16:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function listQuizPoints() {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Calculate total points of a user.
 *
 * FIXME: This algorithm is O(n) because it has a query per content item.
 * FIXME: Optimize speed by using one aggregate query for O(1).
 *
 * @param userPhone
 * @returns {Promise<number>}
 */


var getUserPoints = exports.getUserPoints = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(userPhone) {
    var levels, rugies, content;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _bluebird.resolve)(_level.Level.list());

          case 2:
            levels = _context7.sent;
            _context7.next = 5;
            return (0, _bluebird.resolve)(_rugi.Rugi.list());

          case 5:
            rugies = _context7.sent;
            content = [].concat(levels, rugies);
            return _context7.abrupt('return', getPointsForContent(userPhone, content));

          case 8:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function getUserPoints(_x8) {
    return _ref9.apply(this, arguments);
  };
}();

/**
 * Calculate total points of all users.
 *
 * FIXME: This algorithm is O(n^2) because it has a query per user per content item.
 * FIXME: Optimize speed by using one aggregate query for O(1).
 *
 * @returns {Promise<Array<*>>}
 */


var listUserPoints = exports.listUserPoints = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9() {
    var _this4 = this;

    var levels, rugies, content, users, usersWithPoints;
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.next = 2;
            return (0, _bluebird.resolve)(_level.Level.list());

          case 2:
            levels = _context9.sent;
            _context9.next = 5;
            return (0, _bluebird.resolve)(_rugi.Rugi.list());

          case 5:
            rugies = _context9.sent;
            content = [].concat(levels, rugies);
            _context9.next = 9;
            return (0, _bluebird.resolve)(_user.eLearningUser.list());

          case 9:
            users = _context9.sent;
            _context9.next = 12;
            return (0, _bluebird.resolve)((0, _bluebird.each)(users, function () {
              var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(user) {
                var points;
                return _regenerator2.default.wrap(function _callee8$(_context8) {
                  while (1) {
                    switch (_context8.prev = _context8.next) {
                      case 0:
                        _context8.next = 2;
                        return (0, _bluebird.resolve)(getPointsForContent(user.phone, content));

                      case 2:
                        points = _context8.sent;
                        return _context8.abrupt('return', _decorateUser(user, points));

                      case 4:
                      case 'end':
                        return _context8.stop();
                    }
                  }
                }, _callee8, _this4);
              }));

              return function (_x9) {
                return _ref11.apply(this, arguments);
              };
            }()));

          case 12:
            usersWithPoints = _context9.sent;


            // Eliminate users with no points
            usersWithPoints = usersWithPoints.filter(function (userWithPoints) {
              return userWithPoints.points > 0;
            });

            // Sort by points in descending order
            usersWithPoints.sort(function (user1, user2) {
              return user2.points - user1.points;
            });

            return _context9.abrupt('return', usersWithPoints);

          case 16:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this);
  }));

  return function listUserPoints() {
    return _ref10.apply(this, arguments);
  };
}();

/**
 * @param user
 * @param points
 * @returns {*}
 */


/**
 * Compile typeform submissions of all users for all content.
 *
 * FIXME: This algorithm is O(n) because it has a query per content item.
 * FIXME: Optimize speed by using one aggregate query for O(1).
 * FIXME: Optimize memory by streaming the result.
 *
 * @returns {Promise<Array<*>>}
 */
var listUserResults = exports.listUserResults = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee11() {
    var _ref13,
        _ref14,
        _ref15,
        _this5 = this,
        _ref17;

    var systems, diseases, cases, itemGroups, itemGroupsWithLinks, itemsWithLinks1, weeklyQuizzes, itemsWithLinks2, itemsWithLinks, itemsWithTypeForms, itemsWithSubmissions, submissions;
    return _regenerator2.default.wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            _context11.next = 2;
            return (0, _bluebird.resolve)(_system.System.list());

          case 2:
            systems = _context11.sent;
            diseases = _filterDiseases(systems);
            cases = _filterCases(systems);
            itemGroups = (_ref13 = []).concat.apply(_ref13, (0, _toConsumableArray3.default)((_ref14 = []).concat.apply(_ref14, (0, _toConsumableArray3.default)(diseases).concat((0, _toConsumableArray3.default)(cases)))));
            itemGroupsWithLinks = itemGroups.map(function (itemGroup) {
              var content = {
                content_name: itemGroup.name,
                content_name_bn: itemGroup.name_bn,
                content_passing_score: itemGroup.passingScore,
                content_points: itemGroup.points,
                content_publish_date: itemGroup.publishDate ? (0, _momentTimezone2.default)(itemGroup.publishDate).tz('Asia/Dhaka').format() : '',
                content_archive_date: itemGroup.unpublishDate ? (0, _momentTimezone2.default)(itemGroup.unpublishDate).tz('Asia/Dhaka').format() : ''
              };

              var contentLinks = [{
                content_type: 'Article',
                content_url: itemGroup.embedUrlContent
              }, {
                content_type: 'Quiz',
                content_url: itemGroup.embedUrl
              }, {
                content_type: 'Feedback',
                content_url: itemGroup.embedUrlFeedback
              }];

              return contentLinks.filter(function (contentLink) {
                return !!contentLink.content_url;
              }).map(function (contentLink) {
                return (0, _assign2.default)({}, content, contentLink);
              });
            });
            itemsWithLinks1 = (_ref15 = []).concat.apply(_ref15, (0, _toConsumableArray3.default)(itemGroupsWithLinks));
            _context11.next = 10;
            return (0, _bluebird.resolve)(_quiz.Quiz.listQuizzes());

          case 10:
            weeklyQuizzes = _context11.sent;
            itemsWithLinks2 = weeklyQuizzes.map(function (quiz) {
              return {
                content_name: quiz.name,
                content_name_bn: quiz.name,
                content_passing_score: quiz.passingScore,
                content_points: quiz.points,
                content_publish_date: (0, _momentTimezone2.default)(quiz.startDate).tz('Asia/Dhaka').format(),
                content_archive_date: (0, _momentTimezone2.default)(quiz.endDate).tz('Asia/Dhaka').format(),

                content_type: 'Weekly Quiz',
                content_url: quiz.embedUrl
              };
            });
            itemsWithLinks = [].concat(itemsWithLinks1, itemsWithLinks2);
            itemsWithTypeForms = itemsWithLinks.filter(function (item) {
              return _typeform.TypeformForm.isUrl(item.content_url);
            }).sort(function (item1, item2) {
              return item1.content_url.localeCompare(item2.content_url);
            })
            // Remove duplicate content_url's
            .filter(function (item, idx, items) {
              return idx === 0 || item.content_url !== items[idx - 1].content_url;
            });
            _context11.next = 16;
            return (0, _bluebird.resolve)((0, _bluebird.map)(itemsWithTypeForms, function () {
              var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(item) {
                var typeformUid, typeformResults;
                return _regenerator2.default.wrap(function _callee10$(_context10) {
                  while (1) {
                    switch (_context10.prev = _context10.next) {
                      case 0:
                        typeformUid = _typeform.TypeformForm.getUid(item.content_url);
                        _context10.next = 3;
                        return (0, _bluebird.resolve)(_typeform.TypeformResult.findBy(typeformUid));

                      case 3:
                        typeformResults = _context10.sent;
                        return _context10.abrupt('return', typeformResults.map(function (result) {
                          var submission = {
                            user_phone: result.hidden.user_phone,
                            user_name: result.hidden.user_name,
                            user_is_hidden: result.hidden.user_is_hidden,
                            app_version: result.hidden.app_version,
                            app_token: result.hidden.app_token,

                            content_score: result.calculated.score ? result.calculated.score : 0,
                            content_land_date: (0, _momentTimezone2.default)(result.submitted_at).tz('Asia/Dhaka').format(),
                            content_submit_date: (0, _momentTimezone2.default)(result.landed_at).tz('Asia/Dhaka').format()
                          };

                          return (0, _assign2.default)({}, item, submission);
                        }));

                      case 5:
                      case 'end':
                        return _context10.stop();
                    }
                  }
                }, _callee10, _this5);
              }));

              return function (_x10) {
                return _ref16.apply(this, arguments);
              };
            }()));

          case 16:
            itemsWithSubmissions = _context11.sent;
            submissions = (_ref17 = []).concat.apply(_ref17, (0, _toConsumableArray3.default)(itemsWithSubmissions));
            return _context11.abrupt('return', submissions.sort(function (result1, result2) {
              return result2.content_submit_date.localeCompare(result1.content_submit_date);
            }));

          case 19:
          case 'end':
            return _context11.stop();
        }
      }
    }, _callee11, this);
  }));

  return function listUserResults() {
    return _ref12.apply(this, arguments);
  };
}();

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _user = require('../user/user.model');

var _level = require('../content/level/level.model');

var _rugi = require('../content/rugi/rugi.model');

var _system = require('../content/system/system.model');

var _case = require('../content/case/case.model');

var _quiz = require('../content/quiz/quiz.model');

var _typeform = require('../typeform/typeform.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _decorateUser(user, points) {
  return {
    name: user.name,
    phone: user.phone,
    photo: user.photo,
    address: user.address,
    active: user.active,
    isVisible: user.isVisible,
    createdAt: user.createdAt,
    appVersion: user.appVersion,
    appToken: user.appToken,
    points: points
  };
}

/**
 * @param systems
 * @returns {Array<*>}
 */
function _filterDiseases(systems) {
  return systems.map(function (system) {
    return system.diseases.map(function (disease) {
      return disease.levels.map(function (level) {
        level.name = system.title + ' | ' + disease.title + ' | ' + level.title;
        level.name_bn = system.title_bn + ' | ' + disease.title_bn + ' | ' + level.title_bn;
        return level;
      });
    });
  });
}

/**
 * @param systems
 * @returns {Array<*>}
 */
function _filterCases(systems) {
  return systems.map(function (system) {
    return system.cases.map(function (caseObj) {
      return caseObj.rugies.map(function (rugi) {
        rugi.name = system.title + ' | ' + caseObj.title + ' | ' + rugi.title;
        rugi.name_bn = system.title_bn + ' | ' + caseObj.title_bn + ' | ' + rugi.title_bn;
        return rugi;
      });
    });
  });
}
//# sourceMappingURL=point.model.js.map
