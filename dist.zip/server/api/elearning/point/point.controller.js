'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.resultsCSV = exports.results = exports.index = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var users;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)((0, _point.listUserPoints)());

          case 3:
            users = _context.sent;


            res.json({
              timestamp: Date.now(),
              users: users
            });
            _context.next = 11;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context['catch'](0);

            console.error("Points ERROR", _context.t0.message);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.stack
            });

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 7]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var results = exports.results = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var _results;

    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return (0, _bluebird.resolve)((0, _point.listUserResults)());

          case 3:
            _results = _context2.sent;


            res.json({
              timestamp: Date.now(),
              results: _results
            });
            _context2.next = 11;
            break;

          case 7:
            _context2.prev = 7;
            _context2.t0 = _context2['catch'](0);

            console.error("Results ERROR", _context2.t0.message);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.stack
            });

          case 11:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 7]]);
  }));

  return function results(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var resultsCSV = exports.resultsCSV = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var _results2, _resultsCSV;

    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return (0, _bluebird.resolve)((0, _point.listUserResults)());

          case 3:
            _results2 = _context3.sent;
            _resultsCSV = json2csv.parse(_results2, {
              withBOM: true
            });


            res.type('text/csv').send(_resultsCSV);
            _context3.next = 12;
            break;

          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3['catch'](0);

            console.error("Results ERROR", _context3.t0.message);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.stack
            });

          case 12:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 8]]);
  }));

  return function resultsCSV(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var _point = require('./point.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var json2csv = require('json2csv');
//# sourceMappingURL=point.controller.js.map
