'use strict';

/**
 * Imports
 */
var config = require('../../../config/environment');

exports = module.exports = {
  forWeeklyQuiz: function forWeeklyQuiz() {
    return forPage(config.eLearningPages.weeklyQuizPage);
  },
  forWeeklyQuizResult: function forWeeklyQuizResult() {
    return forPage(config.eLearningPages.weeklyQuizResultPage);
  },
  forLearnPage: function forLearnPage() {
    return forPage(config.eLearningPages.learnPage);
  },
  forDiseasePage: function forDiseasePage(systemId, diseaseId) {
    return forPage(config.eLearningPages.diseasePage + '/' + systemId + '/' + diseaseId);
  },
  forLevelPage: function forLevelPage(systemId, diseaseId, levelId) {
    return forPage(config.eLearningPages.levelPage + '/' + systemId + '/' + diseaseId + '/' + levelId);
  },
  forPracticalPage: function forPracticalPage() {
    return forPage(config.eLearningPages.practicalPage);
  },
  forCasePage: function forCasePage(systemId, caseItemId) {
    return forPage(config.eLearningPages.practicalPage + '/' + systemId + '/' + caseItemId);
  },
  forRugiPage: function forRugiPage(systemId, caseItemId, rugiId) {
    return forPage(config.eLearningPages.rugiPage + '/' + systemId + '/' + caseItemId + '/' + rugiId);
  },
  forHealthTipPage: function forHealthTipPage(healthTipId) {
    return forPage(config.eLearningPages.healthTipPage + '/' + healthTipId);
  },
  forProductPage: function forProductPage(productId) {
    return forPage(config.eLearningPages.productPage + '/' + productId);
  },
  forCourseCompanyPage: function forCourseCompanyPage(companyId) {
    return forPage(config.eLearningPages.courseCompanyPage + '/' + companyId);
  },
  forChapterPage: function forChapterPage(companyId, chapterId) {
    return forPage(config.eLearningPages.chapterPage + '/' + companyId + '/' + chapterId);
  },
  forLessonPage: function forLessonPage(companyId, chapterId, lessonId) {
    return forPage(config.eLearningPages.lessonPage + '/' + companyId + '/' + chapterId + '/' + lessonId);
  }
};

function forPage(segment) {
  return '' + config.firebase.dynamicLink.root + segment;
}
//# sourceMappingURL=deepLinks.js.map
