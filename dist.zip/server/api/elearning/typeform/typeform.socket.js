'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _typeform = require('./typeform.events');

var _typeform2 = _interopRequireDefault(_typeform);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  duplicate(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(typeformResult) {
    socket.emit('typeformResult:create', {
      timestamp: Date.now(),
      typeformResult: typeformResult
    });
  };

  _typeform2.default.on('typeformResult:create', listener);

  socket.on('disconnect', function () {
    _typeform2.default.removeListener('typeformResult:create', listener);
  });
}

function duplicate(socket) {
  var listener = function listener(typeformResult) {
    socket.emit('typeformResult:duplicate', {
      timestamp: Date.now(),
      typeformResult: typeformResult
    });
  };

  _typeform2.default.on('typeformResult:duplicate', listener);

  socket.on('disconnect', function () {
    _typeform2.default.removeListener('typeformResult:duplicate', listener);
  });
}
//# sourceMappingURL=typeform.socket.js.map
