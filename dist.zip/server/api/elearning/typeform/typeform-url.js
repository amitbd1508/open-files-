'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.allUids = exports.allUrls = undefined;

var _regenerator = require("babel-runtime/regenerator");

var _regenerator2 = _interopRequireDefault(_regenerator);

var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _bluebird = require("bluebird");

/**
 * Get all typeform urls used in content
 *
 * @returns {Promise<Array<string>>}
 */
var allUrls = exports.allUrls = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
    var _ref2;

    var contentGroups, contentItems;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)((0, _bluebird.all)([_level.Level.list(), _rugi.Rugi.list(), _quiz.Quiz.listQuizzes()]));

          case 2:
            contentGroups = _context.sent;
            contentItems = (_ref2 = []).concat.apply(_ref2, (0, _toConsumableArray3.default)(contentGroups));
            return _context.abrupt("return", contentItems.map(function (item) {
              return item.embedUrl ? item.embedUrl : null;
            }).filter(function (url) {
              return isUrl(url);
            }));

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function allUrls() {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Get all typeform uids used in content
 *
 * @returns {Promise<Array<string>>}
 */


var allUids = exports.allUids = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
    var urls;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(allUrls());

          case 2:
            urls = _context2.sent;
            return _context2.abrupt("return", urls.map(function (url) {
              return getUid(url);
            }));

          case 4:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function allUids() {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Format urls in a piece of content
 *
 * @param content
 * @return {*}
 */


exports.isUrl = isUrl;
exports.getUid = getUid;
exports.formatUrl = formatUrl;
exports.formatUrls = formatUrls;

var _level = require("../content/level/level.model");

var _rugi = require("../content/rugi/rugi.model");

var _quiz = require("../content/quiz/quiz.model");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Functions
 */

/**
 * Validate if a url is a typeform url.
 *
 * @param url
 * @returns {boolean}
 */
function isUrl(url) {
  return !!url && url.toLowerCase().includes('typeform.com');
}

/**
 * Get typeform uid from a typeform url
 *
 * @param url
 * @return {string}
 */
function getUid(url) {
  return url.split('/')[4].substr(0, 6);
}

/**
 * Format a potential typeform url
 *
 * @param url
 * @return {string}
 */
function formatUrl(url) {
  return url.split('?')[0];
}function formatUrls(content) {
  if (content.embedUrl) content.embedUrl = formatUrl(content.embedUrl);

  if (content.embedUrlContent) content.embedUrlContent = formatUrl(content.embedUrlContent);

  if (content.embedUrlFeedback) content.embedUrlFeedback = formatUrl(content.embedUrlFeedback);

  return content;
}
//# sourceMappingURL=typeform-url.js.map
