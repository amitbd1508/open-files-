'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TypeformForm = exports.TypeformResult = undefined;

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _typeform = require('../../../schemas/elearning/typeform.schema');

var _typeformUrl = require('./typeform-url');

var tfUrl = _interopRequireWildcard(_typeformUrl);

var _typeformForm = require('./typeform-form');

var tfForm = _interopRequireWildcard(_typeformForm);

var _typeformResult = require('./typeform-result');

var tfResult = _interopRequireWildcard(_typeformResult);

var _typeformStats = require('./typeform-stats');

var tfStats = _interopRequireWildcard(_typeformStats);

var _typeformBulk = require('./typeform-bulk');

var tfBulk = _interopRequireWildcard(_typeformBulk);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_typeform.TypeformResultSchema.static('list', tfResult.list).static('create', tfResult.create).static('createFromEvent', tfResult.createFromEvent).static('pull', tfResult.pull).static('findBy', tfResult.findBy).static('findByWithAnswers', tfResult.findByWithAnswers).static('importResponses', tfResult.importResponses).static('importResponsesForUrl', tfResult.importResponsesForUrl).static('importResponsesPage', tfResult.importResponsesPage).static('bulkImportResponses', tfBulk.bulkImportResponses).static('getLatestStats', tfStats.getLatestStats).static('getTotalAttempts', tfStats.getTotalAttempts).static('getHighestScore', tfStats.getHighestScore).static('getAllPhones', tfStats.getAllPhones);

_typeform.TypeformFormSchema.static('isUrl', tfUrl.isUrl).static('getUid', tfUrl.getUid).static('allUrls', tfUrl.allUrls).static('allUids', tfUrl.allUids).static('formatUrls', tfUrl.formatUrls).static('setHidden', tfForm.setHidden).static('setHiddenForUrl', tfForm.setHiddenForUrl).static('setWebhook', tfForm.setWebhook).static('setWebhookForUrl', tfForm.setWebhookForUrl).static('bulkSetHidden', tfBulk.bulkSetHidden).static('bulkSetWebhook', tfBulk.bulkSetWebhook);

/**
 * Models
 */
var TypeformResult = exports.TypeformResult = _mongoose2.default.model('TypeformResult', _typeform.TypeformResultSchema, 'e_learning_typeformResult');
var TypeformForm = exports.TypeformForm = _mongoose2.default.model('TypeformForm', _typeform.TypeformFormSchema, 'e_learning_typeformForm');
//# sourceMappingURL=typeform.model.js.map
