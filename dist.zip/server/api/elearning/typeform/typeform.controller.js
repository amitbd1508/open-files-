'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.bulkSetWebhook = exports.bulkSetHidden = exports.bulkImportResponses = exports.create = exports.index = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

/**
 * List all typeform results.
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */
var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var limit, skip, typeformResults;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            limit = parseInt(req.query.limit) || 50;
            skip = parseInt(req.query.skip) || 0;
            _context.next = 5;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.list(limit, skip));

          case 5:
            typeformResults = _context.sent;


            res.json({
              timestamp: Date.now(),
              typeformResults: typeformResults
            });
            _context.next = 12;
            break;

          case 9:
            _context.prev = 9;
            _context.t0 = _context['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context.t0.stack
            });

          case 12:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 9]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Create a typeform result. Avoid duplication.
 * This is called as a webhook from the TypeForm website.
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var create = exports.create = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var typeformResult;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.createFromEvent(req.body));

          case 3:
            typeformResult = _context2.sent;


            res.json({
              timestamp: Date.now(),
              typeformResult: typeformResult
            });
            _context2.next = 10;
            break;

          case 7:
            _context2.prev = 7;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.stack
            });

          case 10:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 7]]);
  }));

  return function create(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Bulk import all typeform responses. Avoid duplication.
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var bulkImportResponses = exports.bulkImportResponses = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;

            res.type('text/plain');
            _context3.next = 4;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.bulkImportResponses(res));

          case 4:
            res.end();
            _context3.next = 10;
            break;

          case 7:
            _context3.prev = 7;
            _context3.t0 = _context3['catch'](0);

            res.status(500).type('text/plain').send(_context3.t0.stack);

          case 10:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 7]]);
  }));

  return function bulkImportResponses(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Bulk set hidden fields to all typeforms.
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var bulkSetHidden = exports.bulkSetHidden = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;

            res.type('text/plain');
            _context4.next = 4;
            return (0, _bluebird.resolve)(_typeform.TypeformForm.bulkSetHidden(res));

          case 4:
            res.end();
            _context4.next = 10;
            break;

          case 7:
            _context4.prev = 7;
            _context4.t0 = _context4['catch'](0);

            res.status(500).type('text/plain').send(_context4.t0.stack);

          case 10:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 7]]);
  }));

  return function bulkSetHidden(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Bulk set a webhook for all typeforms.
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var bulkSetWebhook = exports.bulkSetWebhook = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;

            res.type('text/plain');
            _context5.next = 4;
            return (0, _bluebird.resolve)(_typeform.TypeformForm.bulkSetWebhook(res));

          case 4:
            res.end();
            _context5.next = 10;
            break;

          case 7:
            _context5.prev = 7;
            _context5.t0 = _context5['catch'](0);

            res.status(500).type('text/plain').send(_context5.t0.stack);

          case 10:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 7]]);
  }));

  return function bulkSetWebhook(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var _typeform = require('./typeform.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=typeform.controller.js.map
