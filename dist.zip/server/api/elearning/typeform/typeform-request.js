'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.requestPromiseRetry = undefined;

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

/**
 * Start a request with potential retries.
 *
 * @param options
 * @returns {Promise<*|void>}
 */
var requestPromiseRetry = exports.requestPromiseRetry = function () {
  var _ref = (0, _bluebird.method)(function (options) {
    return _requestPromiseAttempt(options, 0);
  });

  return function requestPromiseRetry(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Make a request attempt and retry until we run out of retries.
 *
 * @param options
 * @param attempt
 * @returns {Promise<*|void>}
 * @private
 */


var _requestPromiseAttempt = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(options, attempt) {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;

            if (!(attempt > 0)) {
              _context.next = 4;
              break;
            }

            _context.next = 4;
            return (0, _bluebird.resolve)(_pause(attempt));

          case 4:
            _context.next = 6;
            return (0, _bluebird.resolve)((0, _requestPromise2.default)(options));

          case 6:
            return _context.abrupt('return', _context.sent);

          case 9:
            _context.prev = 9;
            _context.t0 = _context['catch'](0);

            if (!(attempt > MAX_RETRIES)) {
              _context.next = 14;
              break;
            }

            console.log('Request ERROR', options.method, options.url, _context.t0.message);

            throw _context.t0;

          case 14:
            _context.next = 16;
            return (0, _bluebird.resolve)(_requestPromiseAttempt(options, attempt + 1));

          case 16:
            return _context.abrupt('return', _context.sent);

          case 17:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 9]]);
  }));

  return function _requestPromiseAttempt(_x2, _x3) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Pause for exponentially longer times between retries
 *
 * @param attempt
 * @returns {Promise}
 * @private
 */


var _pause = function () {
  var _ref3 = (0, _bluebird.method)(function (attempt) {
    var delay = Math.pow(EXPONENTIAL_BACKOFF, attempt - 1) * DELAY_BETWEEN_RETRIES;

    // console.log('Request Delay', delay);

    return new _promise2.default(function (resolve) {
      setTimeout(function () {
        return resolve();
      }, delay);
    });
  });

  return function _pause(_x4) {
    return _ref3.apply(this, arguments);
  };
}();

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */

var MAX_RETRIES = 4;
var DELAY_BETWEEN_RETRIES = 1000;
var EXPONENTIAL_BACKOFF = 1.5;
//# sourceMappingURL=typeform-request.js.map
