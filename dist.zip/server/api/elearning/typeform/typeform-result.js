'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.importResponsesPage = exports.importResponsesForUrl = exports.importResponses = exports.findByWithAnswers = exports.findBy = exports.pull = exports.createFromEvent = exports.create = exports.list = undefined;

var _bluebird = require('bluebird');

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Functions
 */

/**
 * List all typeform results.
 *
 * @param limit
 * @param skip
 * @return {Promise<void>}
 */
var list = exports.list = function () {
  var _ref = (0, _bluebird.method)(function (limit, skip) {
    return this.find().sort({
      createdAt: -1
    }).limit(limit).skip(skip).lean().exec();
  });

  return function list(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Create a typeform result. Avoid duplication.
 *
 * @param typeformResultData
 * @return {Promise<TypeformResult>}
 */


var create = exports.create = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(typeformResultData) {
    var typeformResultInput, typeformResult, _typeformResult;

    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            // Validate typeform result data
            typeformResultInput = new this(typeformResultData);
            _context.next = 3;
            return (0, _bluebird.resolve)(typeformResultInput.validate());

          case 3:
            _context.next = 5;
            return (0, _bluebird.resolve)(this.findOne({
              'token': typeformResultInput.token
            }).exec());

          case 5:
            typeformResult = _context.sent;

            if (!typeformResult) {
              _context.next = 10;
              break;
            }

            _typeform3.default.emit('typeformResult:duplicate', typeformResult);
            _context.next = 14;
            break;

          case 10:
            _context.next = 12;
            return (0, _bluebird.resolve)(typeformResultInput.save());

          case 12:
            _typeformResult = _context.sent;

            _typeform3.default.emit('typeformResult:create', _typeformResult);

          case 14:
            return _context.abrupt('return', typeformResult);

          case 15:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x3) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Create a typeform result from a typeform event. Avoid duplication.
 * This is called as a webhook from the TypeForm website.
 *
 * @param typeformEventData
 * @returns {Promise<void>}
 */


var createFromEvent = exports.createFromEvent = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(typeformEventData) {
    var typeformEvent;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            // Validate typeform event data
            typeformEvent = new TypeformEvent(typeformEventData);
            _context2.next = 3;
            return (0, _bluebird.resolve)(typeformEvent.validate());

          case 3:
            return _context2.abrupt('return', this.create(typeformEvent.form_response.toJSON()));

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function createFromEvent(_x4) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Pull a typeform response of a typeform. Avoid duplication.
 *
 * @param uid
 * @param userPhone
 * @param appToken
 * @return {Promise<TypeformResult>}
 */


var pull = exports.pull = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(uid, userPhone, appToken) {
    var typeformResponseData, typeformResponse, typeformResultData;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return (0, _bluebird.resolve)((0, _typeformRequest.requestPromiseRetry)({
              method: 'GET',
              url: TYPEFORM_API_BASE_URL + '/' + uid + '/responses?completed=true&page_size=1&query=' + appToken,
              headers: {
                'Authorization': 'bearer ' + TYPEFORM_API_TOKEN
              },
              json: true
            }));

          case 3:
            typeformResponseData = _context3.sent;


            // Validate typeform response data
            typeformResponse = new TypeformResponse(typeformResponseData);
            _context3.next = 7;
            return (0, _bluebird.resolve)(typeformResponse.validate());

          case 7:

            // Fill in missing properties
            typeformResultData = (0, _assign2.default)({}, typeformResponse.toJSON().items[0], {
              form_id: uid
            });
            _context3.next = 10;
            return (0, _bluebird.resolve)(this.create(typeformResultData));

          case 10:
            return _context3.abrupt('return', _context3.sent);

          case 13:
            _context3.prev = 13;
            _context3.t0 = _context3['catch'](0);

            console.log('TypeForm Pull ERROR', _context3.t0.message);

          case 16:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 13]]);
  }));

  return function pull(_x5, _x6, _x7) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * @param uid
 * @param userPhone
 * @param appToken
 * @returns {*}
 */


/**
 * Get typeform results filtered by typeform uid, user phone, and app token.
 * Answers ARE NOT included.
 *
 * FIXME: Optimize memory by using projection for necessary data only (e.g. phone, score, count of answers, etc)
 *
 * @param uid
 * @param userPhone
 * @param appToken
 * @return {Promise<Array<TypeformResult>>}
 */
var findBy = exports.findBy = function () {
  var _ref5 = (0, _bluebird.method)(function (uid, userPhone, appToken) {
    var query = _findByQuery(uid, userPhone, appToken);

    return this.find(query).select('-answers').sort({ 'submitted_at': -1 }).lean().exec();
  });

  return function findBy(_x8, _x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

/**
 * Get typeform results filtered by typeform uid, user phone, and app token.
 * Answers ARE included.
 *
 * FIXME: Optimize memory by using projection for necessary data only (e.g. phone, score, count of answers, etc)
 * FIXME: Also include questions.
 *
 * @param uid
 * @param userPhone
 * @param appToken
 * @return {Promise<Array<TypeformResult>>}
 */


var findByWithAnswers = exports.findByWithAnswers = function () {
  var _ref6 = (0, _bluebird.method)(function (uid, userPhone, appToken) {
    var query = _findByQuery(uid, userPhone, appToken);

    return this.find(query).sort({ 'submitted_at': -1 }).lean().exec();
  });

  return function findByWithAnswers(_x11, _x12, _x13) {
    return _ref6.apply(this, arguments);
  };
}();

/**
 * Import all typeform responses of a typeform. Avoid duplication.
 *
 * @param uid
 * @returns {Promise<string>}
 */


var importResponses = exports.importResponses = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(uid) {
    var log, logAndLast;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            log = [];
            _context4.next = 3;
            return (0, _bluebird.resolve)(this.importResponsesPage(uid));

          case 3:
            logAndLast = _context4.sent;

            log.push(logAndLast.log);

          case 5:
            if (!(logAndLast.last !== null)) {
              _context4.next = 12;
              break;
            }

            _context4.next = 8;
            return (0, _bluebird.resolve)(this.importResponsesPage(uid, logAndLast.last));

          case 8:
            logAndLast = _context4.sent;

            log.push(logAndLast.log);
            _context4.next = 5;
            break;

          case 12:
            return _context4.abrupt('return', log.join('\n'));

          case 13:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function importResponses(_x14) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Import all typeform responses of a potential typeform url. Avoid duplication.
 *
 * @param url
 * @returns {Promise<string>}
 */


var importResponsesForUrl = exports.importResponsesForUrl = function () {
  var _ref8 = (0, _bluebird.method)(function (url) {
    if (!tfUrl.isUrl(url)) return (0, _bluebird.resolve)(['ERROR: Typeform has invalid url ' + url]);

    return this.importResponses(tfUrl.getUid(url));
  });

  return function importResponsesForUrl(_x15) {
    return _ref8.apply(this, arguments);
  };
}();

/**
 * Import a page of typeform responses of a typeform. Avoid duplication.
 *
 * @param uid
 * @param afterToken
 * @returns {Promise<{log: string, last: string|null}>}
 */


var importResponsesPage = exports.importResponsesPage = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(uid, afterToken) {
    var _this = this;

    var url, typeformResponseData, typeformResponse, logs, totalCount, successCount, lastToken;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.prev = 0;

            // Url for only completed typeforms, with 1000 (max) per page
            // Include "after" parameter only if the value is provided
            url = TYPEFORM_API_BASE_URL + '/' + uid + '/responses?completed=true&page_size=1000';

            if (afterToken) url = url + '&after=' + afterToken;

            // Retrieve a page of typeform responses
            // REMINDER: Typeform gives an ERROR if you provide header "Content-Type: application/json"
            // when doing this API call (but not other GET API calls with no body). We consider it a BUG.
            _context6.next = 5;
            return (0, _bluebird.resolve)((0, _typeformRequest.requestPromiseRetry)({
              method: 'GET',
              url: url,
              headers: {
                'Authorization': 'bearer ' + TYPEFORM_API_TOKEN
              },
              json: true
            }));

          case 5:
            typeformResponseData = _context6.sent;


            // Validate typeform response data
            typeformResponse = new TypeformResponse(typeformResponseData);
            _context6.next = 9;
            return (0, _bluebird.resolve)(typeformResponse.validate());

          case 9:
            if (!(typeformResponse.items.length === 0)) {
              _context6.next = 15;
              break;
            }

            if (!afterToken) {
              _context6.next = 14;
              break;
            }

            return _context6.abrupt('return', {
              log: '....Typeform ' + uid + ' has no more responses to import after ' + afterToken.substr(0, 6),
              last: null
            });

          case 14:
            return _context6.abrupt('return', {
              log: 'Typeform ' + uid + ' has no responses to import at all',
              last: null
            });

          case 15:
            _context6.next = 17;
            return (0, _bluebird.resolve)((0, _bluebird.map)(typeformResponse.toJSON().items, function () {
              var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(item) {
                var typeformResultData;
                return _regenerator2.default.wrap(function _callee5$(_context5) {
                  while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        _context5.prev = 0;

                        // Fill in missing properties
                        typeformResultData = (0, _assign2.default)({}, item, {
                          form_id: uid
                        });
                        _context5.next = 4;
                        return (0, _bluebird.resolve)(_this.create(typeformResultData));

                      case 4:
                        return _context5.abrupt('return', true);

                      case 7:
                        _context5.prev = 7;
                        _context5.t0 = _context5['catch'](0);

                        console.log('Typeform Import ERROR', _context5.t0.message);

                        return _context5.abrupt('return', false);

                      case 11:
                      case 'end':
                        return _context5.stop();
                    }
                  }
                }, _callee5, _this, [[0, 7]]);
              }));

              return function (_x18) {
                return _ref10.apply(this, arguments);
              };
            }()));

          case 17:
            logs = _context6.sent;


            // Keep note of the count of success, count of failures, and last token
            totalCount = logs.length;
            successCount = logs.filter(function (log) {
              return !!log;
            }).length;
            lastToken = typeformResponse.items.slice(-1)[0].token;

            if (!afterToken) {
              _context6.next = 25;
              break;
            }

            return _context6.abrupt('return', {
              log: '....Typeform ' + uid + ' responses (' + successCount + ' of ' + totalCount + ') were imported after ' + afterToken.substr(0, 6) + ' to ' + lastToken.substr(0, 6),
              last: lastToken
            });

          case 25:
            return _context6.abrupt('return', {
              log: 'Typeform ' + uid + ' responses (' + successCount + ' of ' + totalCount + ') were imported to ' + lastToken.substr(0, 6),
              last: lastToken
            });

          case 26:
            _context6.next = 36;
            break;

          case 28:
            _context6.prev = 28;
            _context6.t0 = _context6['catch'](0);

            console.log('Typeform Import ERROR', _context6.t0.message);

            if (!afterToken) {
              _context6.next = 35;
              break;
            }

            return _context6.abrupt('return', {
              log: '....ERROR: Typeform ' + uid + ' responses could not be imported after ' + afterToken.substr(0, 6) + ', ' + _context6.t0.message,
              last: null
            });

          case 35:
            return _context6.abrupt('return', {
              log: 'ERROR: Typeform ' + uid + ' responses could not be imported at all, ' + _context6.t0.message,
              last: null
            });

          case 36:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[0, 28]]);
  }));

  return function importResponsesPage(_x16, _x17) {
    return _ref9.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _typeformRequest = require('./typeform-request');

var _typeform = require('../../../schemas/elearning/typeform.schema');

var _typeform2 = require('./typeform.events');

var _typeform3 = _interopRequireDefault(_typeform2);

var _typeformUrl = require('./typeform-url');

var tfUrl = _interopRequireWildcard(_typeformUrl);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */

var TYPEFORM_API_BASE_URL = process.env.TYPEFORM_API_BASE_URL;
var TYPEFORM_API_TOKEN = process.env.TYPEFORM_API_TOKEN;

/**
 * Models
 */
var TypeformResponse = _mongoose2.default.model('TypeformResponse', _typeform.TypeformResponseSchema);
var TypeformEvent = _mongoose2.default.model('TypeformEvent', _typeform.TypeformEventSchema);function _findByQuery(uid, userPhone, appToken) {
  var query = {};

  if (uid) {
    if (Array.isArray(uid)) query['form_id'] = { $in: uid };else query['form_id'] = uid;
  }
  if (userPhone) {
    if (Array.isArray(uid)) query['hidden.user_phone'] = { $in: userPhone };else query['hidden.user_phone'] = userPhone;
  }
  if (appToken) {
    if (Array.isArray(uid)) query['hidden.app_token'] = { $in: appToken };else query['hidden.app_token'] = appToken;
  }

  return query;
}
//# sourceMappingURL=typeform-result.js.map
