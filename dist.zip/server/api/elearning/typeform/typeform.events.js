'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var TypeformEvents = new _events.EventEmitter();

/**
 * Options
 */
TypeformEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = TypeformEvents;
//# sourceMappingURL=typeform.events.js.map
