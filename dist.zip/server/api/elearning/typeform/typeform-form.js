'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setWebhookForUrl = exports.setWebhook = exports.setHiddenForUrl = exports.setHidden = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

// This tag is used in the TypeForm Admin UI

/**
 * Functions
 */

/**
 * Set hidden fields to a typeform.
 *
 * @param uid
 * @returns {Promise<string>}
 */
var setHidden = exports.setHidden = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(uid) {
    var typeformForm;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)((0, _typeformRequest.requestPromiseRetry)({
              method: 'GET',
              url: TYPEFORM_API_BASE_URL + '/' + uid,
              headers: {
                'Authorization': 'bearer ' + TYPEFORM_API_TOKEN
              },
              json: true
            }));

          case 3:
            typeformForm = _context.sent;


            // Patch typeform to set hidden fields
            typeformForm.hidden = TYPEFORM_HIDDEN_FIELDS;

            _context.next = 7;
            return (0, _bluebird.resolve)((0, _typeformRequest.requestPromiseRetry)({
              method: 'PUT',
              url: TYPEFORM_API_BASE_URL + '/' + uid,
              headers: {
                'Authorization': 'bearer ' + TYPEFORM_API_TOKEN
              },
              body: typeformForm,
              json: true
            }));

          case 7:
            return _context.abrupt('return', 'Typeform ' + uid + ' hidden fields were set');

          case 10:
            _context.prev = 10;
            _context.t0 = _context['catch'](0);
            return _context.abrupt('return', 'ERROR: Typeform ' + uid + ' hidden fields could not be set, ' + _context.t0.message);

          case 13:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 10]]);
  }));

  return function setHidden(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Add hidden fields to a potential typeform url.
 *
 * @param url
 * @returns {Promise<string>}
 */


var setHiddenForUrl = exports.setHiddenForUrl = function () {
  var _ref2 = (0, _bluebird.method)(function (url) {
    if (!tfUrl.isUrl(url)) return (0, _bluebird.resolve)(['ERROR: Typeform has invalid url ' + url]);

    return this.setHidden(tfUrl.getUid(url));
  });

  return function setHiddenForUrl(_x2) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Set a webhook for a typeform.
 *
 * @param uid
 * @returns {Promise<string>}
 */


var setWebhook = exports.setWebhook = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(uid) {
    var typeformWebhooks;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return (0, _bluebird.resolve)((0, _typeformRequest.requestPromiseRetry)({
              method: 'GET',
              url: TYPEFORM_API_BASE_URL + '/' + uid + '/webhooks',
              headers: {
                'Authorization': 'bearer ' + TYPEFORM_WEBHOOK_TOKEN
              },
              json: true
            }));

          case 3:
            typeformWebhooks = _context2.sent;
            _context2.next = 6;
            return (0, _bluebird.resolve)((0, _bluebird.map)(typeformWebhooks, function () {
              var _ref4 = (0, _bluebird.method)(function (webhook) {
                // Remove DEFAULT webhook
                if (webhook.tag === TYPEFORM_WEBHOOK_DEFAULT_TAG) {
                  return (0, _typeformRequest.requestPromiseRetry)({
                    method: 'DELETE',
                    url: TYPEFORM_API_BASE_URL + '/' + webhook.form_id + '/webhooks/' + webhook.tag,
                    headers: {
                      'Authorization': 'bearer ' + TYPEFORM_WEBHOOK_TOKEN
                    }
                  });
                }
              });

              return function (_x4) {
                return _ref4.apply(this, arguments);
              };
            }()));

          case 6:
            _context2.next = 8;
            return (0, _bluebird.resolve)((0, _typeformRequest.requestPromiseRetry)({
              method: 'PUT',
              url: TYPEFORM_API_BASE_URL + '/' + uid + '/webhooks/' + TYPEFORM_WEBHOOK_TAG,
              headers: {
                'Authorization': 'bearer ' + TYPEFORM_WEBHOOK_TOKEN
              },
              body: {
                'url': TYPEFORM_WEBHOOK_URL,
                'enabled': true
              },
              json: true
            }));

          case 8:
            return _context2.abrupt('return', 'Typeform ' + uid + ' webhook was added to ' + TYPEFORM_WEBHOOK_TAG);

          case 11:
            _context2.prev = 11;
            _context2.t0 = _context2['catch'](0);
            return _context2.abrupt('return', 'ERROR: Typeform ' + uid + ' webhook could not be added to ' + TYPEFORM_WEBHOOK_TAG + ', ' + _context2.t0.message);

          case 14:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 11]]);
  }));

  return function setWebhook(_x3) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Set a webhook for a potential typeform url.
 *
 * @param url
 * @returns {Promise<string>}
 */


var setWebhookForUrl = exports.setWebhookForUrl = function () {
  var _ref5 = (0, _bluebird.method)(function (url) {
    if (!tfUrl.isUrl(url)) return (0, _bluebird.resolve)(['ERROR: Typeform has invalid url ' + url]);

    return this.setWebhook(tfUrl.getUid(url));
  });

  return function setWebhookForUrl(_x5) {
    return _ref5.apply(this, arguments);
  };
}();

var _typeformRequest = require('./typeform-request');

var _typeformUrl = require('./typeform-url');

var tfUrl = _interopRequireWildcard(_typeformUrl);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */

var TYPEFORM_API_BASE_URL = process.env.TYPEFORM_API_BASE_URL;
var TYPEFORM_API_TOKEN = process.env.TYPEFORM_API_TOKEN;
var TYPEFORM_WEBHOOK_URL = process.env.TYPEFORM_WEBHOOK_URL;
var TYPEFORM_WEBHOOK_TOKEN = process.env.TYPEFORM_WEBHOOK_TOKEN;
var TYPEFORM_WEBHOOK_TAG = process.env.TYPEFORM_WEBHOOK_TAG;

var TYPEFORM_HIDDEN_FIELDS = ['user_phone', 'user_name', 'user_is_hidden', 'app_token', 'app_version'];
var TYPEFORM_WEBHOOK_DEFAULT_TAG = 'phoenix';
//# sourceMappingURL=typeform-form.js.map
