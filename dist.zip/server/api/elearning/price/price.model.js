'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Price = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */
var createPrice = function () {
  var _ref = (0, _bluebird.method)(function (formData, userID) {
    var price = new Price();

    price.amount = formData.amount;
    price.isDefault = formData.isDefault || false;
    price.category = formData.category;
    price.createdBy = userID;

    _price4.default.emit('eLearning:price:create');

    return price.save();
  });

  return function createPrice(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var getPrices = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(limit, skip) {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Price.find().populate('createdBy').sort({
              category: 1,
              amount: 1,
              isDefault: 1
            }).limit(parseInt(limit)).skip(parseInt(skip)).exec());

          case 2:
            return _context.abrupt('return', _context.sent);

          case 3:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function getPrices(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var getPriceByService = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(serviceName) {
    var price;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            if (serviceName) {
              _context2.next = 2;
              break;
            }

            throw new Error('Service Name missing');

          case 2:
            _context2.next = 4;
            return (0, _bluebird.resolve)(Price.findOne({
              isDefault: true,
              category: serviceName
            }).select('amount').sort({
              amount: 1
            }).lean().exec());

          case 4:
            price = _context2.sent;

            if (price) {
              _context2.next = 7;
              break;
            }

            throw new Error('Price is not set by admin');

          case 7:
            return _context2.abrupt('return', price.amount);

          case 8:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getPriceByService(_x5) {
    return _ref3.apply(this, arguments);
  };
}();

// Get the price filtered by service category and the smallest amount of price
// User must set a default price for each category


var getDefaultPriceByCategory = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(serviceCategory) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            if (serviceCategory) {
              _context3.next = 2;
              break;
            }

            throw new Error('Service Name missing');

          case 2:
            _context3.next = 4;
            return (0, _bluebird.resolve)(Price.findOne({
              category: serviceCategory,
              isDefault: true
            }).sort({
              isDefault: 1,
              amount: 1
            }).exec());

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getDefaultPriceByCategory(_x6) {
    return _ref4.apply(this, arguments);
  };
}();

var updatePriceById = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(priceId, formData) {
    var price;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.findById(priceId).exec());

          case 2:
            price = _context4.sent;

            if (price) {
              _context4.next = 5;
              break;
            }

            throw new Error('Price not found');

          case 5:

            price.amount = formData.amount || 0;
            price.isDefault = formData.isDefault || false;
            price.category = formData.category;

            _context4.next = 10;
            return (0, _bluebird.resolve)(price.save());

          case 10:

            _price4.default.emit('eLearning:price:update');

            return _context4.abrupt('return', price);

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function updatePriceById(_x7, _x8) {
    return _ref5.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _price = require('../../../schemas/elearning/price.schema');

var _price2 = _interopRequireDefault(_price);

var _price3 = require('./price.events');

var _price4 = _interopRequireDefault(_price3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Schema
 */
_price2.default.static('createPrice', createPrice).static('getPrices', getPrices).static('getPriceByService', getPriceByService).static('updatePriceById', updatePriceById).static('getDefaultPriceByCategory', getDefaultPriceByCategory);var Price = exports.Price = _mongoose2.default.model('Price', _price2.default, 'e_learning_prices');
//# sourceMappingURL=price.model.js.map
