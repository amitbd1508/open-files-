'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _price = require('./price.events');

var _price2 = _interopRequireDefault(_price);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
}

/**
 * Socket messages
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('eLearning:price:create', {
      timestamp: Date.now()
    });
  };

  _price2.default.on('eLearning:price:create', listener);

  socket.on('disconnect', function () {
    _price2.default.removeListener('eLearning:price:create', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('eLearning:price:update', {
      timestamp: Date.now()
    });
  };

  _price2.default.on('eLearning:price:update', listener);

  socket.on('disconnect', function () {
    _price2.default.removeListener('eLearning:price:update', listener);
  });
}
//# sourceMappingURL=price.socket.js.map
