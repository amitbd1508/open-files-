'use strict';

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Imports
 */
var express = require('express');
var controller = require('./price.controller');

var router = express.Router();
/**
 * Routes
 */

// Saves a newly created price
router.post('/', auth.isAuthenticated(), controller.createPrice);

// Fetch the list of all prices
router.get('/', auth.isAuthenticated(), controller.getPrices);

// Update price
router.put('/:id', auth.isAuthenticated(), controller.updatePriceById);

// Get default price by service name
router.get('/services/:serviceName', controller.getPriceByService);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
