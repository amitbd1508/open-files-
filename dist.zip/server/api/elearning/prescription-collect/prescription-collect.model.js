'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ELTransaction = exports.PrescriptionCollect = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _bluebird = require('bluebird');

var index = function () {
  var _ref = (0, _bluebird.method)(function (skip, limit, startDate, endDate, approvalStatus, userIds) {

    var query = {
      submittedAt: {
        $gte: startDate,
        $lte: endDate
      }
    };

    if (userIds) {
      userIds = _lodash2.default.isArray(userIds) ? userIds : [userIds];
      userIds = userIds.map(function (id) {
        return objectId(id);
      });

      if (userIds) {
        query.submittedBy = { $in: userIds };
      }
    }

    if (approvalStatus === "Approved" || approvalStatus === "Rejected") {
      query.isApproved = approvalStatus === "Approved";
      query.respondedBy = { $ne: null };
    } else if (approvalStatus === "Awaiting") {
      query.respondedBy = null;
    }

    return this.find(query).populate({
      path: 'submittedBy',
      select: 'name phone photo'
    }).populate({
      path: 'priceId'
    }).limit(parseInt(limit)).skip(parseInt(skip)).sort({
      isApproved: 1,
      submittedAt: -1
    }).lean().exec();
  });

  return function index(_x, _x2, _x3, _x4, _x5, _x6) {
    return _ref.apply(this, arguments);
  };
}();

var savePrescription = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(submittedBy, formData) {
    var serviceCategory, price, prescription;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            serviceCategory = (0, _keys2.default)(environment.SERVICE_CATEGORY)[0];

            if (submittedBy) {
              _context.next = 3;
              break;
            }

            throw new Error('User id not found');

          case 3:
            _context.next = 5;
            return (0, _bluebird.resolve)(_price.Price.getDefaultPriceByCategory(serviceCategory));

          case 5:
            price = _context.sent;

            if (price) {
              _context.next = 8;
              break;
            }

            throw new Error('Price is not defined properly');

          case 8:
            prescription = new this();


            prescription.priceId = price._id;
            prescription.imageURL = formData.imageURL;
            prescription.submittedBy = submittedBy;
            prescription.submittedAt = Date.now();

            _prescriptionCollect4.default.emit('elearning:prescription:collect:create');

            return _context.abrupt('return', prescription.save());

          case 15:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function savePrescription(_x7, _x8) {
    return _ref2.apply(this, arguments);
  };
}();

var validatePrescription = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(prescriptionCollectId, isApproved, updatedBy) {
    var prescription, priceId, submittedBy;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.findById(prescriptionCollectId).exec());

          case 2:
            prescription = _context2.sent;

            if (prescription) {
              _context2.next = 5;
              break;
            }

            throw new Error('Prescription not found');

          case 5:
            priceId = prescription.priceId;
            submittedBy = prescription.submittedBy;
            _context2.next = 9;
            return (0, _bluebird.resolve)(ELTransaction.validateByPrescriptionCollectId(prescriptionCollectId, submittedBy, isApproved, updatedBy, priceId));

          case 9:

            prescription.isApproved = isApproved;
            prescription.respondedBy = updatedBy;
            prescription.respondedAt = Date.now();

            _prescriptionCollect4.default.emit('elearning:prescription:collect:update');

            return _context2.abrupt('return', prescription.save());

          case 14:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function validatePrescription(_x9, _x10, _x11) {
    return _ref3.apply(this, arguments);
  };
}();

var validateByPrescriptionCollectId = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(prescriptionCollectId, submittedBy, isApproved, updatedBy, priceId) {
    var transaction;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(ELTransaction.findOne({
              prescriptionCollectId: prescriptionCollectId
            }).exec());

          case 2:
            transaction = _context3.sent;

            if (!(isApproved && !transaction)) {
              _context3.next = 11;
              break;
            }

            transaction = new ELTransaction();
            transaction.priceId = priceId;
            transaction.updatedBy = updatedBy;
            transaction.userId = submittedBy;
            transaction.prescriptionCollectId = prescriptionCollectId;

            _context3.next = 11;
            return (0, _bluebird.resolve)(transaction.save());

          case 11:
            if (!(!isApproved && transaction)) {
              _context3.next = 14;
              break;
            }

            _context3.next = 14;
            return (0, _bluebird.resolve)(ELTransaction.findByIdAndUpdate(transaction._id, {
              isActive: false,
              updatedBy: updatedBy,
              priceId: priceId
            }).exec());

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function validateByPrescriptionCollectId(_x12, _x13, _x14, _x15, _x16) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Returns number of approved , rejected and awaiting prescription of
 * a user by his Id.
 */


var getUserPrescriptionStatistics = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(userId, startDate, endDate) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(netApprovedPrescriptions(userId, startDate, endDate));

          case 2:
            _context4.t0 = _context4.sent;
            _context4.next = 5;
            return (0, _bluebird.resolve)(netRejectedPrescriptions(userId, startDate, endDate));

          case 5:
            _context4.t1 = _context4.sent;
            _context4.next = 8;
            return (0, _bluebird.resolve)(netAwaitingPrescriptions(userId, startDate, endDate));

          case 8:
            _context4.t2 = _context4.sent;
            return _context4.abrupt('return', {
              netApprovedPrescriptions: _context4.t0,
              netRejectedPrescriptions: _context4.t1,
              netAwaitingPrescriptions: _context4.t2
            });

          case 10:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function getUserPrescriptionStatistics(_x17, _x18, _x19) {
    return _ref5.apply(this, arguments);
  };
}();

var netApprovedPrescriptions = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(userId, startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            query = {};

            query.isApproved = true;
            if (userId) query.submittedBy = userId;
            if (startDate && endDate) query.submittedAt = {
              $gte: startDate,
              $lte: endDate
            };

            _context5.next = 6;
            return (0, _bluebird.resolve)(PrescriptionCollect.count(query));

          case 6:
            return _context5.abrupt('return', _context5.sent);

          case 7:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function netApprovedPrescriptions(_x20, _x21, _x22) {
    return _ref6.apply(this, arguments);
  };
}();

var netRejectedPrescriptions = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(userId, startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            query = {};

            query.isApproved = false;
            query.respondedBy = {
              $exists: true
            };
            if (userId) query.submittedBy = userId;

            if (startDate && endDate) query.submittedAt = {
              $gte: startDate,
              $lte: endDate
            };

            _context6.next = 7;
            return (0, _bluebird.resolve)(PrescriptionCollect.count(query));

          case 7:
            return _context6.abrupt('return', _context6.sent);

          case 8:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function netRejectedPrescriptions(_x23, _x24, _x25) {
    return _ref7.apply(this, arguments);
  };
}();

var netAwaitingPrescriptions = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(userId, startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            query = {};

            query.respondedBy = {
              $exists: false
            };
            if (userId) query.submittedBy = userId;

            if (startDate && endDate) query.submittedAt = {
              $gte: startDate,
              $lte: endDate
            };

            _context7.next = 6;
            return (0, _bluebird.resolve)(PrescriptionCollect.count(query));

          case 6:
            return _context7.abrupt('return', _context7.sent);

          case 7:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function netAwaitingPrescriptions(_x26, _x27, _x28) {
    return _ref8.apply(this, arguments);
  };
}();

/**
 * Exports
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _prescriptionCollect = require('../../../schemas/elearning/prescription-collect.schema');

var _prescriptionCollect2 = _interopRequireDefault(_prescriptionCollect);

var _transaction = require('../../../schemas/elearning/transaction.schema');

var _transaction2 = _interopRequireDefault(_transaction);

var _prescriptionCollect3 = require('./prescription-collect.events');

var _prescriptionCollect4 = _interopRequireDefault(_prescriptionCollect3);

var _price = require('../price/price.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../../config/environment');
var objectId = require('mongoose').Types.ObjectId;

/**
 * Schema static declaration
 */
_prescriptionCollect2.default.static('index', index).static('savePrescription', savePrescription).static('validatePrescription', validatePrescription).static('getUserPrescriptionStatistics', getUserPrescriptionStatistics);

_transaction2.default.static('validateByPrescriptionCollectId', validateByPrescriptionCollectId);

var PrescriptionCollect = exports.PrescriptionCollect = _mongoose2.default.model('PrescriptionCollect', _prescriptionCollect2.default, 'e_learning_prescription_collect');
var ELTransaction = exports.ELTransaction = _mongoose2.default.model('PrescriptionCollectTransaction', _transaction2.default, 'e_learning_transaction');
//# sourceMappingURL=prescription-collect.model.js.map
