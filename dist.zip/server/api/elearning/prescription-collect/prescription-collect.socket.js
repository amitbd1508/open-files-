'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _prescriptionCollect = require('./prescription-collect.events');

var _prescriptionCollect2 = _interopRequireDefault(_prescriptionCollect);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('elearning:prescription:collect:create', {
      timestamp: Date.now()
    });
  };

  _prescriptionCollect2.default.on('elearning:prescription:collect:create', listener);

  socket.on('disconnect', function () {
    _prescriptionCollect2.default.removeListener('elearning:prescription:collect:create', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('elearning:prescription:collect:update', {
      timestamp: Date.now()
    });
  };

  _prescriptionCollect2.default.on('elearning:prescription:collect:update', listener);

  socket.on('disconnect', function () {
    _prescriptionCollect2.default.removeListener('elearning:prescription:collect:update', listener);
  });
}

function remove(socket) {
  var listener = function listener() {
    socket.emit('elearning:prescription:collect:remove', {
      timestamp: Date.now()
    });
  };

  _prescriptionCollect2.default.on('elearning:prescription:collect:remove', listener);

  socket.on('disconnect', function () {
    _prescriptionCollect2.default.removeListener('elearning:prescription:collect:remove', listener);
  });
}
//# sourceMappingURL=prescription-collect.socket.js.map
