'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var PrescriptionCollectEvents = new _events.EventEmitter();

/**
 * Options
 */
PrescriptionCollectEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = PrescriptionCollectEvents;
//# sourceMappingURL=prescription-collect.events.js.map
