'use strict';

/**
 * Imports
 */

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./firebase-admin.controller');


var router = express.Router();

/**
 * Routes
 */
// Get all the pushed messages
router.get('/notifications', auth.isAuthenticated(), controller.index);

// Send the push notification
router.post('/notifications', auth.isAuthenticated(), controller.sendNotification);

// Send the push notification
router.post('/notifications/bulk', controller.sendBulkNotification);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
