'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.sendBulkNotification = exports.sendNotification = exports.index = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */
var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, limit, skip, count, notifications;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            limit = req.query.limit || 20;
            skip = req.query.skip || 0;
            _context.next = 7;
            return (0, _bluebird.resolve)(_firebaseAdmin.CloudNotification.count());

          case 7:
            count = _context.sent;
            _context.next = 10;
            return (0, _bluebird.resolve)(_firebaseAdmin.CloudNotification.findByQuery(skip, limit, startDate, endDate));

          case 10:
            notifications = _context.sent;


            res.json({
              timestamp: Date.now(),
              notifications: notifications,
              count: count
            });
            _context.next = 17;
            break;

          case 14:
            _context.prev = 14;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 17:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 14]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var sendNotification = exports.sendNotification = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var formData, notification;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            formData = req.body;


            formData.title = req.body.title || 'প্রযত্ন';
            formData.body = req.body.body || 'প্রযত্নের সাথে থাকার জন্য ধন্যবাদ।';
            formData.token = req.body.token;
            formData.package_name = environment.firebase.appId;
            formData.priority = req.body.priority || 'high';
            formData.sound = req.body.sound || 'default';
            formData.time_to_live = req.body.time_to_live || 1;
            formData.deep_link = req.body.deep_link || '';

            _context2.next = 12;
            return (0, _bluebird.resolve)(_firebaseAdmin.Firebase.sendNotification(formData));

          case 12:
            notification = _context2.sent;


            res.json({
              timestamp: Date.now(),
              notification: notification
            });
            _context2.next = 19;
            break;

          case 16:
            _context2.prev = 16;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.stack
            });

          case 19:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 16]]);
  }));

  return function sendNotification(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var sendBulkNotification = exports.sendBulkNotification = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var formData, notification;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            formData = req.body;
            _context3.next = 4;
            return (0, _bluebird.resolve)(_firebaseAdmin.CloudNotification.sendBulkNotification(formData));

          case 4:
            notification = _context3.sent;


            res.json({
              timestamp: Date.now(),
              notification: notification
            });
            _context3.next = 11;
            break;

          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 8]]);
  }));

  return function sendBulkNotification(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var _firebaseAdmin = require('./firebase-admin.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../../config/environment');
//# sourceMappingURL=firebase-admin.controller.js.map
