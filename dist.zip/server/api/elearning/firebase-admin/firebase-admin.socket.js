'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _firebaseAdmin = require('./firebase-admin.events');

var _firebaseAdmin2 = _interopRequireDefault(_firebaseAdmin);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  save(socket);
  sentSuccess(socket);
  sentFailed(socket);
}

/**
 * Socket Messages
 */
function save(socket) {
  var listener = function listener() {
    socket.emit('cloud:notification:save', {
      timestamp: Date.now()
    });
  };

  _firebaseAdmin2.default.on('cloud:notification:save', listener);

  socket.on('disconnect', function () {
    _firebaseAdmin2.default.removeListener('cloud:notification:save', listener);
  });
}

function sentSuccess(socket) {
  var listener = function listener() {
    socket.emit('cloud:notification:sent:success', {
      timestamp: Date.now()
    });
  };

  _firebaseAdmin2.default.on('cloud:notification:sent:success', listener);

  socket.on('disconnect', function () {
    _firebaseAdmin2.default.removeListener('cloud:notification:sent:success', listener);
  });
}

function sentFailed(socket) {
  var listener = function listener() {
    socket.emit('cloud:notification:sent:failed', {
      timestamp: Date.now()
    });
  };

  _firebaseAdmin2.default.on('cloud:notification:sent:failed', listener);

  socket.on('disconnect', function () {
    _firebaseAdmin2.default.removeListener('cloud:notification:sent:failed', listener);
  });
}
//# sourceMappingURL=firebase-admin.socket.js.map
