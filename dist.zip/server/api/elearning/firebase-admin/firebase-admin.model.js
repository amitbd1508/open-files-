'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Firebase = exports.FirebaseUser = exports.CloudNotification = exports.findByQuery = exports.sendBulkNotification = exports.saveNotification = undefined;

var _bluebird = require('bluebird');

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var sendNotification = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData) {
    var payload, notification;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            payload = {
              "ttl": formData.time_to_live,
              "priority": formData.priority,
              "restricted_package_name": formData.package_name,
              "notification": {
                "title": formData.title,
                "body": formData.body,
                "click_action": "FCM_PLUGIN_ACTIVITY",
                "sound": formData.sound
              },

              "data": {
                "title": formData.title,
                "body": formData.body,
                "deep_link": formData.deep_link
              }
            };


            if (!formData.token) payload.condition = '\'' + formData.package_name + '\' in topics';else {
              payload.to = formData.token;
            }

            _context.next = 4;
            return (0, _bluebird.resolve)(saveNotification(payload));

          case 4:
            notification = _context.sent;
            _context.next = 7;
            return (0, _bluebird.resolve)(FirebaseSendNotification(payload));

          case 7:
            notification.response = _context.sent;
            _context.next = 10;
            return (0, _bluebird.resolve)(notification.save());

          case 10:
            return _context.abrupt('return', _context.sent);

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function sendNotification(_x) {
    return _ref.apply(this, arguments);
  };
}();

var FirebaseSendNotification = function () {
  var _ref2 = (0, _bluebird.method)(function (payload) {
    var options = {
      method: 'POST',
      uri: environment.FCM_GOOGLE_API,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'key=' + environment.FCM_GOOGLE_API_AUTHORIZATION_KEY
      },
      body: payload,
      json: true
    };

    return new _promise2.default(function (resolve, reject) {
      request(options).then(function (response) {
        console.log('Firebase 🔥 Successfully sent message:', response);

        _firebaseAdmin3.default.emit('cloud:notification:sent:success');
        resolve(response);
      }).catch(function (error) {
        console.log('Firebase 🔥 Error sending message:', error);

        _firebaseAdmin3.default.emit('cloud:notification:sent:failed');
        reject(error);
      });
    });
  });

  return function FirebaseSendNotification(_x2) {
    return _ref2.apply(this, arguments);
  };
}();

var saveNotification = exports.saveNotification = function () {
  var _ref3 = (0, _bluebird.method)(function (message) {
    var notification = new CloudNotification(message);

    _firebaseAdmin3.default.emit('cloud:notification:save');

    return notification.save();
  });

  return function saveNotification(_x3) {
    return _ref3.apply(this, arguments);
  };
}();

var sendBulkNotification = exports.sendBulkNotification = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(formData) {
    var _this = this;

    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)((0, _bluebird.map)(formData, function () {
              var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(user) {
                var payload, notification;
                return _regenerator2.default.wrap(function _callee2$(_context2) {
                  while (1) {
                    switch (_context2.prev = _context2.next) {
                      case 0:
                        payload = {
                          "ttl": user.time_to_live,
                          "priority": user.priority || 'high',
                          "restricted_package_name": environment.firebase.appId,
                          "notification": {
                            "title": user.title || 'প্রযত্ন',
                            "body": user.body || 'প্রযত্নের সাথে থাকার জন্য ধন্যবাদ।',
                            "click_action": "FCM_PLUGIN_ACTIVITY",
                            "sound": user.sound
                          },

                          "data": {
                            "title": user.title || 'প্রযত্ন',
                            "body": user.body || 'প্রযত্নের সাথে থাকার জন্য ধন্যবাদ।',
                            "deep_link": user.deep_link || ''
                          }
                        };

                        if (user.phone) {
                          _context2.next = 3;
                          break;
                        }

                        throw new Error('User phone missing');

                      case 3:
                        _context2.next = 5;
                        return (0, _bluebird.resolve)(getTokenByPhone(user.phone));

                      case 5:
                        payload.to = _context2.sent;
                        _context2.next = 8;
                        return (0, _bluebird.resolve)(saveNotification(payload));

                      case 8:
                        notification = _context2.sent;
                        _context2.next = 11;
                        return (0, _bluebird.resolve)(FirebaseSendNotification(payload));

                      case 11:
                        notification.response = _context2.sent;
                        _context2.next = 14;
                        return (0, _bluebird.resolve)(notification.save());

                      case 14:
                        return _context2.abrupt('return', _context2.sent);

                      case 15:
                      case 'end':
                        return _context2.stop();
                    }
                  }
                }, _callee2, _this);
              }));

              return function (_x5) {
                return _ref5.apply(this, arguments);
              };
            }()));

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function sendBulkNotification(_x4) {
    return _ref4.apply(this, arguments);
  };
}();

var getTokenByPhone = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(phone) {
    var user;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(FirebaseUser.findOne({
              phone: { '$regex': phone, '$options': 'i' }
            }).exec());

          case 2:
            user = _context4.sent;

            if (user) {
              _context4.next = 5;
              break;
            }

            throw new Error('User not found ' + phone);

          case 5:
            return _context4.abrupt('return', user.appToken);

          case 6:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function getTokenByPhone(_x6) {
    return _ref6.apply(this, arguments);
  };
}();

var findByQuery = exports.findByQuery = function () {
  var _ref7 = (0, _bluebird.method)(function (skip, limit, startDate, endDate) {
    var query = {
      createdAt: {
        $gte: startDate,
        $lte: endDate
      }
    };

    return this.find(query).skip(parseInt(skip)).limit(parseInt(limit)).sort('-createdAt').lean().exec();
  });

  return function findByQuery(_x7, _x8, _x9, _x10) {
    return _ref7.apply(this, arguments);
  };
}();

var _cloudNotification = require('../../../schemas/elearning/cloud-notification.schema');

var _cloudNotification2 = _interopRequireDefault(_cloudNotification);

var _firebaseAdmin = require('firebase-admin');

var admin = _interopRequireWildcard(_firebaseAdmin);

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _firebaseAdmin2 = require('./firebase-admin.events');

var _firebaseAdmin3 = _interopRequireDefault(_firebaseAdmin2);

var _user = require('../../../schemas/elearning/user.schema');

var _user2 = _interopRequireDefault(_user);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var request = require('request-promise');
var environment = require('../../../config/environment');

admin.initializeApp({
  credential: admin.credential.cert(environment.FIREBASE)
});

_cloudNotification2.default.static('saveNotification', saveNotification).static('sendBulkNotification', sendBulkNotification).static('findByQuery', findByQuery);

var CloudNotification = exports.CloudNotification = _mongoose2.default.model('CloudNotificationSchema', _cloudNotification2.default, 'cloud-notification');
var FirebaseUser = exports.FirebaseUser = _mongoose2.default.model('FirebaseUser', _user2.default, 'e_learning_users');

var Firebase = exports.Firebase = {
  sendNotification: sendNotification,
  FirebaseSendNotification: FirebaseSendNotification
};
//# sourceMappingURL=firebase-admin.model.js.map
