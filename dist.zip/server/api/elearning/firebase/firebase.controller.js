'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.index = undefined;

var _bluebird = require('bluebird');

var index = exports.index = function () {
  var _ref = (0, _bluebird.method)(function (req, res) {
    try {
      var config = environment.firebase;

      res.json({
        timestamp: Date.now(),
        config: config
      });
    } catch (error) {
      console.error("Firebase ERROR", error.message);

      res.status(400).json({
        timestamp: Date.now(),
        error: error.stack
      });
    }
  });

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var environment = require('../../../config/environment');
//# sourceMappingURL=firebase.controller.js.map
