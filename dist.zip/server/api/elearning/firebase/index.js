'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./firebase.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', controller.index);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
