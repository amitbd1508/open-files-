'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.uploading = exports.loadingImageUpdate = exports.loadingImageUpload = exports.remove = exports.update = exports.createLoadingImage = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var loadingImages;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)(_loadingImage.LoadingImage.findLoadingImages());

          case 3:
            loadingImages = _context.sent;


            res.json({
              timestamp: Date.now(),
              loadingImages: loadingImages
            });
            _context.next = 10;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 10:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 7]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var createLoadingImage = exports.createLoadingImage = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var loadingImageBody, loadingImage;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            loadingImageBody = req.body;


            loadingImageBody.createdBy = req.user._id;

            _context2.prev = 2;
            _context2.next = 5;
            return (0, _bluebird.resolve)(_loadingImage.LoadingImage.createLoadingImage(loadingImageBody));

          case 5:
            loadingImage = _context2.sent;


            res.json({
              timestamp: Date.now(),
              loadingImage: loadingImage
            });
            _context2.next = 12;
            break;

          case 9:
            _context2.prev = 9;
            _context2.t0 = _context2['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 12:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[2, 9]]);
  }));

  return function createLoadingImage(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var update = exports.update = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var loadingImageId, formBody, loadingImage;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            if (!req.params.id) res.status(400).end();
            if (!req.body) res.status(400).end();

            loadingImageId = req.params.id;
            formBody = req.body;


            formBody.createdBy = req.user._id;

            _context3.prev = 5;
            _context3.next = 8;
            return (0, _bluebird.resolve)(_loadingImage.LoadingImage.update(loadingImageId, formBody));

          case 8:
            loadingImage = _context3.sent;


            res.json({
              timestamp: new Date(),
              loadingImage: loadingImage
            });
            _context3.next = 15;
            break;

          case 12:
            _context3.prev = 12;
            _context3.t0 = _context3['catch'](5);

            res.status(400).json({
              timestamp: new Date(),
              error: _context3.t0.toString()
            });

          case 15:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[5, 12]]);
  }));

  return function update(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var remove = exports.remove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var loadingImageId, loadingImage;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            loadingImageId = req.params.id;

            if (!loadingImageId) res.status(400).end();

            _context4.prev = 2;
            _context4.next = 5;
            return (0, _bluebird.resolve)(_loadingImage.LoadingImage.remove(loadingImageId));

          case 5:
            loadingImage = _context4.sent;


            res.json({
              timestamp: new Date(),
              loadingImage: loadingImage
            });
            _context4.next = 12;
            break;

          case 9:
            _context4.prev = 9;
            _context4.t0 = _context4['catch'](2);

            res.status(400).json({
              timestamp: new Date(),
              error: _context4.t0
            });

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[2, 9]]);
  }));

  return function remove(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var loadingImageUpload = exports.loadingImageUpload = function () {
  var _ref5 = (0, _bluebird.method)(function (req, res) {
    try {
      var location = req.file.location;

      res.json({
        timestamp: new Date(),
        location: location
      });
    } catch (error) {
      res.status(400).json({
        timestamp: Date.now(),
        error: error.toString()
      });
    }
  });

  return function loadingImageUpload(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var loadingImageUpdate = exports.loadingImageUpdate = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var location, loadingImageId, loadingImage;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            location = req.file.location;
            loadingImageId = req.params.id;
            _context5.next = 5;
            return (0, _bluebird.resolve)(_loadingImage.LoadingImage.update(loadingImageId, { imageUrl: location }));

          case 5:
            loadingImage = _context5.sent;


            res.json({
              timestamp: new Date(),
              loadingImage: loadingImage
            });
            _context5.next = 12;
            break;

          case 9:
            _context5.prev = 9;
            _context5.t0 = _context5['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 12:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 9]]);
  }));

  return function loadingImageUpdate(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var _loadingImage = require('./loading-image.model');

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var multer = require('multer');
var multerS3 = require('multer-s3');
var environment = require('../../../config/environment');

_awsSdk2.default.config.update(environment.aws);
var s3 = new _awsSdk2.default.S3();

var AWSS3Bucket = environment.aws.s3_bucket + '/loading-image';

var uploading = exports.uploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: '' + AWSS3Bucket,
    location: function location(req, file, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function key(req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('file');
//# sourceMappingURL=loading-image.controller.js.map
