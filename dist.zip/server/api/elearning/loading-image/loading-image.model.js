'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.LoadingImage = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var createLoadingImage = function () {
  var _ref = (0, _bluebird.method)(function (formData) {
    var loadingImage = new LoadingImage(formData);

    _loadingImage4.default.emit('loading-image:create');

    return loadingImage.save();
  });

  return function createLoadingImage(_x) {
    return _ref.apply(this, arguments);
  };
}();

var findLoadingImages = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
    var loadingImages;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.find().sort('-createdAt').populate({
              path: 'createdBy',
              select: 'fullname'
            }).lean().exec());

          case 2:
            loadingImages = _context.sent;
            return _context.abrupt('return', loadingImages);

          case 4:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findLoadingImages() {
    return _ref2.apply(this, arguments);
  };
}();

var update = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(loadingImageId, formData) {
    var loadingImage;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(loadingImageId, formData, { new: true }).lean().exec());

          case 2:
            loadingImage = _context2.sent;


            _loadingImage4.default.emit('loading-image:update');

            return _context2.abrupt('return', loadingImage);

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function update(_x2, _x3) {
    return _ref3.apply(this, arguments);
  };
}();

var remove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(loadingImageId) {
    var loadingImage;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(this.findOneAndRemove({
              _id: loadingImageId
            }).exec());

          case 2:
            loadingImage = _context3.sent;


            _loadingImage4.default.emit('loading-image:remove');

            return _context3.abrupt('return', loadingImage);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function remove(_x4) {
    return _ref4.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _loadingImage = require('../../../schemas/elearning/loading-image.schema');

var _loadingImage2 = _interopRequireDefault(_loadingImage);

var _loadingImage3 = require('./loading-image.events');

var _loadingImage4 = _interopRequireDefault(_loadingImage3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_loadingImage2.default.static('createLoadingImage', createLoadingImage).static('findLoadingImages', findLoadingImages).static('update', update).static('remove', remove);

var LoadingImage = exports.LoadingImage = _mongoose2.default.model('LoadingImage', _loadingImage2.default, 'e_learning_loading_image');
//# sourceMappingURL=loading-image.model.js.map
