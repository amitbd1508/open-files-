'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _loadingImage = require('./loading-image.events');

var _loadingImage2 = _interopRequireDefault(_loadingImage);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(healthTip) {
    socket.emit('loading-image:create', {
      timestamp: Date.now(),
      healthTip: healthTip
    });
  };

  _loadingImage2.default.on('loading-image:create', listener);

  socket.on('disconnect', function () {
    _loadingImage2.default.removeListener('loading-image:create', listener);
  });
}

function update(socket) {
  var listener = function listener(healthTip) {
    socket.emit('loading-image:update', {
      timestamp: Date.now(),
      healthTip: healthTip
    });
  };

  _loadingImage2.default.on('loading-image:update', listener);

  socket.on('disconnect', function () {
    _loadingImage2.default.removeListener('loading-image:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(healthTip) {
    socket.emit('loading-image:remove', {
      timestamp: Date.now(),
      healthTip: healthTip
    });
  };

  _loadingImage2.default.on('loading-image:remove', listener);

  socket.on('disconnect', function () {
    _loadingImage2.default.removeListener('loading-image:remove', listener);
  });
}
//# sourceMappingURL=loading-image.socket.js.map
