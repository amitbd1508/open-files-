'use strict';

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Imports
 */
var express = require('express');
var controller = require('./loading-image.controller');

var router = express.Router();

/**
 * Routes
 */
// Get all loading images
router.get('/', controller.index);

// Create loading image
router.post('/', auth.isAuthenticated(), controller.createLoadingImage);

// Updates an existing loading image
router.put('/:id', auth.isAuthenticated(), controller.update);

// Deletes an existing loading image
router.delete('/:id', auth.isAuthenticated(), controller.remove);

// Upload loading image image
router.post('/images', auth.isAuthenticated(), controller.uploading, controller.loadingImageUpload);

// Update loading image image
router.put('/images/:id', auth.isAuthenticated(), controller.uploading, controller.loadingImageUpdate);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
