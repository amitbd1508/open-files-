'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var LoadingImageEvents = new _events.EventEmitter();

/**
 * Options
 */
LoadingImageEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = LoadingImageEvents;
//# sourceMappingURL=loading-image.events.js.map
