'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _product = require('./product.events');

var _product2 = _interopRequireDefault(_product);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(product) {
    socket.emit('elearning:products:create', {
      timestamp: Date.now(),
      product: product
    });
  };

  _product2.default.on('elearning:products:create', listener);

  socket.on('disconnect', function () {
    _product2.default.removeListener('elearning:products:create', listener);
  });
}

function update(socket) {
  var listener = function listener(product) {
    socket.emit('elearning:products:update', {
      timestamp: Date.now(),
      product: product
    });
  };

  _product2.default.on('elearning:products:update', listener);

  socket.on('disconnect', function () {
    _product2.default.removeListener('elearning:products:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(product) {
    socket.emit('elearning:products:remove', {
      timestamp: Date.now(),
      product: product
    });
  };

  _product2.default.on('elearning:products:remove', listener);

  socket.on('disconnect', function () {
    _product2.default.removeListener('elearning:products:remove', listener);
  });
}
//# sourceMappingURL=product.socket.js.map
