'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var ProductEvents = new _events.EventEmitter();

/**
 * Options
 */
ProductEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = ProductEvents;
//# sourceMappingURL=product.events.js.map
