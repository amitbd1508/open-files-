'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Product = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 *
 * @param formBody
 * @returns {Promise<*>}
 */
var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formBody) {
    var product;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            product = new Product(formBody);
            _context.next = 3;
            return (0, _bluebird.resolve)(product.save());

          case 3:

            _product2.default.emit('elearning:products:create');

            return _context.abrupt('return', product);

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 *
 * @returns {Promise<void>}
 */


var findProducts = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(startDate, endDate, limit, skip) {
    var query, products;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(addFilters(startDate, endDate));

          case 2:
            query = _context2.sent;
            _context2.next = 5;
            return (0, _bluebird.resolve)(Product.find(query).sort({
              isActive: -1,
              order: 1
            }).limit(parseInt(limit)).skip(parseInt(skip)).lean().exec());

          case 5:
            products = _context2.sent;
            _context2.next = 8;
            return (0, _bluebird.resolve)(addDeepLink(products));

          case 8:
            products = _context2.sent;
            return _context2.abrupt('return', products);

          case 10:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findProducts(_x2, _x3, _x4, _x5) {
    return _ref2.apply(this, arguments);
  };
}();

var addDeepLink = function () {
  var _ref3 = (0, _bluebird.method)(function (products) {
    return products.map(function (product) {
      product.deepLink = _deepLinks2.default.forProductPage(product._id);
      return product;
    });
  });

  return function addDeepLink(_x6) {
    return _ref3.apply(this, arguments);
  };
}();

var countByFilters = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(addFilters(startDate, endDate));

          case 2:
            query = _context3.sent;
            _context3.next = 5;
            return (0, _bluebird.resolve)(Product.count(query).lean().exec());

          case 5:
            return _context3.abrupt('return', _context3.sent);

          case 6:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function countByFilters(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var addFilters = function () {
  var _ref5 = (0, _bluebird.method)(function (startDate, endDate) {
    var query = {};

    if (startDate && endDate) {
      query.createdAt = {
        $gte: startDate,
        $lte: endDate
      };
    }

    return query;
  });

  return function addFilters(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

/**
 *
 * @returns {Promise<void>}
 */


var list = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4() {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Product.find({
              isActive: true
            }).sort({
              order: 'asc'
            }).lean().exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function list() {
    return _ref6.apply(this, arguments);
  };
}();

/**
 *
 * @param productId
 * @param formData
 * @returns {Promise<void>}
 */


var update = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(productId, formData) {
    var product;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(Product.findByIdAndUpdate(productId, formData, {
              new: true
            }).lean().exec());

          case 2:
            product = _context5.sent;


            _product2.default.emit('elearning:products:update');

            return _context5.abrupt('return', product);

          case 5:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function update(_x11, _x12) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 *
 * @param productId
 * @returns {Promise<void>}
 */


var remove = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(productId) {
    var product;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(Product.findOneAndUpdate({
              _id: productId
            }, {
              isActive: false
            }, {
              new: true
            }).lean().exec());

          case 2:
            product = _context6.sent;


            _product2.default.emit('elearning:products:remove');

            return _context6.abrupt('return', product);

          case 5:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function remove(_x13) {
    return _ref8.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _products = require('../../../schemas/elearning/products.schema');

var _products2 = _interopRequireDefault(_products);

var _product = require('./product.events');

var _product2 = _interopRequireDefault(_product);

var _deepLinks = require('../deepLinks/deepLinks');

var _deepLinks2 = _interopRequireDefault(_deepLinks);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_products2.default.static('create', create).static('list', list).static('findProducts', findProducts).static('countByFilters', countByFilters).static('update', update).static('remove', remove);var Product = exports.Product = _mongoose2.default.model('Product', _products2.default, 'e_learning_products');
//# sourceMappingURL=product.model.js.map
