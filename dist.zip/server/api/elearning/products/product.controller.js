'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.bannerUploading = exports.uploading = exports.productBannerUpdate = exports.productImageUpdate = exports.productImageUpload = exports.remove = exports.update = exports.create = exports.findProducts = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var products;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)(_product.Product.list());

          case 3:
            products = _context.sent;


            res.json({
              timestamp: Date.now(),
              products: products
            });
            _context.next = 10;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 10:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 7]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var findProducts = exports.findProducts = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var startDate, endDate, limit, skip, count, products;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            limit = req.query.limit || 50;
            skip = req.query.skip || 0;
            _context2.next = 7;
            return (0, _bluebird.resolve)(_product.Product.countByFilters(startDate, endDate, limit, skip));

          case 7:
            count = _context2.sent;
            _context2.next = 10;
            return (0, _bluebird.resolve)(_product.Product.findProducts(startDate, endDate, limit, skip));

          case 10:
            products = _context2.sent;


            res.json({
              timestamp: Date.now(),
              products: products,
              count: count
            });
            _context2.next = 17;
            break;

          case 14:
            _context2.prev = 14;
            _context2.t0 = _context2['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 17:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 14]]);
  }));

  return function findProducts(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var create = exports.create = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var formBody, product;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            formBody = req.body;
            _context3.next = 4;
            return (0, _bluebird.resolve)(_product.Product.create(formBody));

          case 4:
            product = _context3.sent;


            res.json({
              timestamp: Date.now(),
              product: product
            });
            _context3.next = 11;
            break;

          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 8]]);
  }));

  return function create(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var update = exports.update = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var productId, formBody, product;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            if (!req.params.id) res.status(400).end();
            if (!req.body) res.status(400).end();

            productId = req.params.id;
            formBody = req.body;
            _context4.prev = 4;
            _context4.next = 7;
            return (0, _bluebird.resolve)(_product.Product.update(productId, formBody));

          case 7:
            product = _context4.sent;


            res.json({
              timestamp: new Date(),
              product: product
            });
            _context4.next = 14;
            break;

          case 11:
            _context4.prev = 11;
            _context4.t0 = _context4['catch'](4);

            res.status(400).json({
              timestamp: new Date(),
              error: _context4.t0.toString()
            });

          case 14:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[4, 11]]);
  }));

  return function update(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var remove = exports.remove = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var productId, product;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            productId = req.params.id;

            if (!productId) res.status(400).end();

            _context5.prev = 2;
            _context5.next = 5;
            return (0, _bluebird.resolve)(_product.Product.remove(productId));

          case 5:
            product = _context5.sent;


            res.json({
              timestamp: new Date(),
              product: product
            });
            _context5.next = 12;
            break;

          case 9:
            _context5.prev = 9;
            _context5.t0 = _context5['catch'](2);

            res.status(400).json({
              timestamp: new Date(),
              error: _context5.t0
            });

          case 12:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[2, 9]]);
  }));

  return function remove(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var productImageUpload = exports.productImageUpload = function () {
  var _ref6 = (0, _bluebird.method)(function (req, res) {
    try {
      var location = req.file.location;
      res.json({
        timestamp: new Date(),
        location: location
      });
    } catch (error) {
      res.status(400).json({
        timestamp: Date.now(),
        error: error.toString()
      });
    }
  });

  return function productImageUpload(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var productImageUpdate = exports.productImageUpdate = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var location, productId, product;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.prev = 0;
            location = req.file.location;
            productId = req.params.id;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_product.Product.update(productId, { imageURL: location }));

          case 5:
            product = _context6.sent;


            res.json({
              timestamp: new Date(),
              product: product
            });
            _context6.next = 12;
            break;

          case 9:
            _context6.prev = 9;
            _context6.t0 = _context6['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0.toString()
            });

          case 12:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[0, 9]]);
  }));

  return function productImageUpdate(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var productBannerUpdate = exports.productBannerUpdate = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var location, productId, product;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.prev = 0;
            location = req.file.location;
            productId = req.params.id;
            _context7.next = 5;
            return (0, _bluebird.resolve)(_product.Product.update(productId, { bannerURL: location }));

          case 5:
            product = _context7.sent;


            res.json({
              timestamp: new Date(),
              product: product
            });
            _context7.next = 12;
            break;

          case 9:
            _context7.prev = 9;
            _context7.t0 = _context7['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context7.t0.toString()
            });

          case 12:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[0, 9]]);
  }));

  return function productBannerUpdate(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

var _product = require('./product.model');

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var multer = require('multer');
var multerS3 = require('multer-s3');
var environment = require('../../../config/environment');

_awsSdk2.default.config.update(environment.aws);
var s3 = new _awsSdk2.default.S3();
/**
 *
 * @type {string}
 */
var AWSS3Bucket = environment.aws.s3_bucket + '/products';

var uploading = exports.uploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: AWSS3Bucket + '/images',
    location: function location(req, file, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function key(req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('file');

var bannerUploading = exports.bannerUploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: AWSS3Bucket + '/banner-images',
    location: function location(req, file, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function key(req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('banner');
//# sourceMappingURL=product.controller.js.map
