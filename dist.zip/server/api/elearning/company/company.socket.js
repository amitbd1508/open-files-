'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _company = require('./company.events');

var _company2 = _interopRequireDefault(_company);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(company) {
    socket.emit('eLearning:company:create', {
      timestamp: Date.now(),
      company: company
    });
  };

  _company2.default.on('eLearning:company:create', listener);

  socket.on('disconnect', function () {
    _company2.default.removeListener('eLearning:company:create', listener);
  });
}

function update(socket) {
  var listener = function listener(company) {
    socket.emit('eLearning:company:update', {
      timestamp: Date.now(),
      company: company
    });
  };

  _company2.default.on('eLearning:company:update', listener);

  socket.on('disconnect', function () {
    _company2.default.removeListener('eLearning:company:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(company) {
    socket.emit('eLearning:company:remove', {
      timestamp: Date.now(),
      company: company
    });
  };

  _company2.default.on('eLearning:company:remove', listener);

  socket.on('disconnect', function () {
    _company2.default.removeListener('eLearning:company:remove', listener);
  });
}
//# sourceMappingURL=company.socket.js.map
