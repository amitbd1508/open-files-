'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Company = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 *
 * @param formBody
 * @returns {Promise<*>}
 */
var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formBody) {
    var company;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            company = new Company(formBody);
            _context.next = 3;
            return (0, _bluebird.resolve)(company.save());

          case 3:

            _company2.default.emit('eLearning:company:create');

            return _context.abrupt('return', company);

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 *
 * @returns {Promise<void>}
 */


var list = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(limit, skip) {
    var companies;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(Company.find().limit(parseInt(limit)).skip(parseInt(skip)).sort({
              isActive: -1,
              createdAt: 1
            }).lean().exec());

          case 2:
            companies = _context2.sent;
            return _context2.abrupt('return', companies.map(function (company) {
              company.deepLink = _deepLinks2.default.forCourseCompanyPage(company._id);
              return company;
            }));

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function list(_x2, _x3) {
    return _ref2.apply(this, arguments);
  };
}();

/**?
 *
 * @returns {Promise<void>}
 */


var listWithCourses = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3() {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(Company.aggregate([{
              "$lookup": {
                "from": "e_learning_chapters",
                "let": {
                  "companyId": "$_id"
                },
                "pipeline": [{
                  "$lookup": {
                    "from": "e_learning_lessons",
                    "let": {
                      "chapterId": "$_id"
                    },
                    "pipeline": [{
                      "$match": {
                        "isActive": true
                      }
                    }, {
                      "$match": {
                        "$expr": {
                          "$eq": ["$chapterId", "$$chapterId"]
                        }
                      }
                    }, {
                      "$project": {
                        "chapterId": 0.0
                      }
                    }, {
                      "$sort": {
                        "order": 1.0
                      }
                    }],
                    "as": "lessons"
                  }
                }, {
                  "$match": {
                    "isActive": true
                  }
                }, {
                  "$unwind": {
                    "path": "$companies",
                    "includeArrayIndex": "arrayIndex",
                    "preserveNullAndEmptyArrays": false
                  }
                }, {
                  "$match": {
                    "$expr": {
                      "$eq": ["$companies.companyId", "$$companyId"]
                    }
                  }
                }, {
                  "$sort": {
                    "companies.order": 1.0
                  }
                }, {
                  "$addFields": {
                    "order": "$companies.order"
                  }
                }, {
                  "$project": {
                    "companies": 0.0
                  }
                }],
                "as": "chapters"
              }
            }, {
              "$match": {
                "isActive": true
              }
            }]));

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function listWithCourses() {
    return _ref3.apply(this, arguments);
  };
}();

/**
 *
 * @param companyId
 * @param formData
 * @returns {Promise<void>}
 */


var update = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(companyId, formData) {
    var company;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Company.findByIdAndUpdate(companyId, formData, {
              new: true
            }).lean().exec());

          case 2:
            company = _context4.sent;


            _company2.default.emit('eLearning:company:update');

            return _context4.abrupt('return', company);

          case 5:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function update(_x4, _x5) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 *
 * @param companyId
 * @returns {Promise<void>}
 */


var remove = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(companyId) {
    var company;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(Company.findOneAndUpdate({
              _id: companyId
            }, {
              isActive: false
            }, {
              new: true
            }).lean().exec());

          case 2:
            company = _context5.sent;


            _company2.default.emit('eLearning:company:remove');

            return _context5.abrupt('return', company);

          case 5:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function remove(_x6) {
    return _ref5.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _company = require('./company.events');

var _company2 = _interopRequireDefault(_company);

var _company3 = require('../../../schemas/elearning/company.schema');

var _company4 = _interopRequireDefault(_company3);

var _deepLinks = require('../deepLinks/deepLinks');

var _deepLinks2 = _interopRequireDefault(_deepLinks);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_company4.default.static('create', create).static('list', list).static('listWithCourses', listWithCourses).static('update', update).static('remove', remove);var Company = exports.Company = _mongoose2.default.model('Company', _company4.default, 'e_learning_companies');
//# sourceMappingURL=company.model.js.map
