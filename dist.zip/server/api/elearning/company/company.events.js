'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var CompanyEvents = new _events.EventEmitter();

/**
 * Options
 */
CompanyEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = CompanyEvents;
//# sourceMappingURL=company.events.js.map
