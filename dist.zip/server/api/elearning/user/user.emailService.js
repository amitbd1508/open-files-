'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.sendEmail = undefined;

var _bluebird = require('bluebird');

var sendEmail = exports.sendEmail = function () {
  var _ref = (0, _bluebird.method)(function (user) {
    var appVersion = user.appVersion ? user.appVersion : 'unknown';

    var mailOptions = {
      from: '"Projonto E-learning Notifications" <' + emailAddress + '>',
      to: 'elearning@jeeon.co', // list of receivers
      subject: 'New User Register',
      html: '<b>' + user.name + '</b>, with phone number <b>' + user.phone + '</b>, using app version <b>' + appVersion + '</b>, just registered!'
    };

    nodemailer.createTestAccount(function () {
      transporter.sendMail(mailOptions, function (error, info) {
        if (error) console.log('Registration Notification Error', error);else console.log('Registration Notification: %s', info.messageId, info.accepted);
      });
    });
  });

  return function sendEmail(_x) {
    return _ref.apply(this, arguments);
  };
}();

var nodemailer = require('nodemailer');
/*eslint-disable */
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'elearning.projotno@gmail.com',
    pass: 'Jeeon2018'
  }
});

var emailAddress = "elearning.projotno@gmail.com";
//# sourceMappingURL=user.emailService.js.map
