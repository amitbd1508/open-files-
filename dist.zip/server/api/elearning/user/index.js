'use strict';

/**
 * Imports
 */

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./user.controller');

var router = express.Router();

/**
 * Routes
 */

// Get list of users
router.get('/', controller.index);

// get all user name and id
router.get('/names', controller.getUsersNameAndId);

// Create a user
router.post('/', controller.create);

// Get list of users by name/phone/app version
router.get('/search', controller.findUsers);

// get all users last location
router.get('/locations', auth.isAuthenticated(), controller.getLocations);

// get geo codes
router.get('/geoCodes', controller.getGeoCodes);

// Retrieve user by phone number
router.get('/:phone', controller.retrieve);

// Update user by phone number
router.put('/:phone', controller.uploadProfileImageToS3, controller.updateByPhone);

// Update user by id
router.put('/update/:id', auth.isAuthenticated(), controller.uploadProfileImageToS3, controller.updateById);

// Delete user by phone number
router.delete('/:phone', controller.removeByPhone);

// Save user location by phone
router.post('/:phone/locations', controller.saveLocationsByUserId);

// get user locations by phone
router.get('/:phone/locations', controller.getLocationsByUserPhone);

// get user's number of completed diseases , cases and total points by phone
router.get('/statistics/:phone', controller.getUserStatistics);

// Save user pin code
router.put('/:id/pin', controller.savingUserPin);

// Update user groups using phone numbers
router.put('/groups/csv', auth.isAuthenticated(), controller.updateUsersGroupsByPhones);

// Validate pin
router.get('/:id/validate/pin', controller.validatePin);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
