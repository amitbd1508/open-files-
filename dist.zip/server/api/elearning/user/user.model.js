'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.eLearningLocations = exports.eLearningUser = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formBody) {
    var user;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            user = new eLearningUser(formBody);


            user.isVisible = true;

            _context.next = 4;
            return (0, _bluebird.resolve)(user.save());

          case 4:
            user = _context.sent;

            if (!user) {
              _context.next = 12;
              break;
            }

            _user4.default.emit('elearning:user:create', user);
            (0, _user5.sendEmail)(user);
            user = user.toObject();
            _context.next = 11;
            return (0, _bluebird.resolve)(isProfileCompleted(user));

          case 11:
            user.isProfileCompleted = _context.sent;

          case 12:
            return _context.abrupt('return', user);

          case 13:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var list = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.find().lean().exec());

          case 2:
            return _context2.abrupt('return', _context2.sent);

          case 3:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function list() {
    return _ref2.apply(this, arguments);
  };
}();

var getUsersNameAndId = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3() {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.find().select('name _id').lean().exec());

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getUsersNameAndId() {
    return _ref3.apply(this, arguments);
  };
}();

var findByPhone = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(phoneNumbers) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.find({
              phone: { $in: phoneNumbers }
            }).lean().exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findByPhone(_x2) {
    return _ref4.apply(this, arguments);
  };
}();

var findUsers = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(startDate, endDate, search, limit, skip, groupIds) {
    var query;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(addFilters(startDate, endDate, search, groupIds));

          case 2:
            query = _context5.sent;
            _context5.next = 5;
            return (0, _bluebird.resolve)(eLearningUser.find(query).populate('groupIds').limit(parseInt(limit)).skip(parseInt(skip)).sort({
              createdAt: -1
            }).lean().exec());

          case 5:
            return _context5.abrupt('return', _context5.sent);

          case 6:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findUsers(_x3, _x4, _x5, _x6, _x7, _x8) {
    return _ref5.apply(this, arguments);
  };
}();

var countByFilters = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(startDate, endDate, search, groupIds) {
    var query;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(addFilters(startDate, endDate, search, groupIds));

          case 2:
            query = _context6.sent;
            _context6.next = 5;
            return (0, _bluebird.resolve)(eLearningUser.count(query).lean().exec());

          case 5:
            return _context6.abrupt('return', _context6.sent);

          case 6:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function countByFilters(_x9, _x10, _x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var addFilters = function () {
  var _ref7 = (0, _bluebird.method)(function (startDate, endDate, search, groupIds) {
    var query = {};
    if (groupIds) {
      groupIds = _lodash2.default.isArray(groupIds) ? groupIds : [groupIds];
      groupIds = groupIds.map(function (id) {
        return objectId(id);
      });
      groupIds ? query.groupIds = { $in: groupIds } : '';
    }

    if (startDate && endDate) {
      query.updatedAt = {
        $gte: startDate,
        $lte: endDate
      };
    }

    if (search) {
      query = {
        '$or': [{ name: { '$regex': search, '$options': 'i' } }, { appVersion: { '$regex': search, '$options': 'i' } }, { phone: { '$regex': search, '$options': 'i' } }]
      };
    }

    return query;
  });

  return function addFilters(_x13, _x14, _x15, _x16) {
    return _ref7.apply(this, arguments);
  };
}();

var retrieve = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(userPhone) {
    var user;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.findOne({
              phone: userPhone
            }).populate({
              path: 'groupIds'
            }).lean().exec());

          case 2:
            user = _context7.sent;

            if (!user) {
              _context7.next = 12;
              break;
            }

            user.daysSinceSignup = (0, _momentTimezone2.default)().diff((0, _momentTimezone2.default)(user.createdAt), 'days');
            _context7.next = 7;
            return (0, _bluebird.resolve)(userGroupSort(user));

          case 7:
            user.groupIds = _context7.sent;
            _context7.next = 10;
            return (0, _bluebird.resolve)(isProfileCompleted(user));

          case 10:
            user.isProfileCompleted = _context7.sent;

            user.hasPin = !!user.pin;

          case 12:
            return _context7.abrupt('return', user);

          case 13:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function retrieve(_x17) {
    return _ref8.apply(this, arguments);
  };
}();

/**
 * FIXME : this function can be simplified
 * this function check of user curtain value filled up or not
 * @param user
 * @returns {Promise<boolean>}
 */


var isProfileCompleted = function () {
  var _ref9 = (0, _bluebird.method)(function (user) {
    return !!(user.address && user.address.districtCode && user.address.subDistrictCode && user.address.unionCode && user.designation && user.details.occupation);
  });

  return function isProfileCompleted(_x18) {
    return _ref9.apply(this, arguments);
  };
}();

var userGroupSort = function () {
  var _ref10 = (0, _bluebird.method)(function (user) {
    user.groupIds = user.groupIds.map(function (group) {
      return group.service;
    }, []);

    return user.groupIds = user.groupIds.filter(function (name) {
      return name !== undefined;
    });
  });

  return function userGroupSort(_x19) {
    return _ref10.apply(this, arguments);
  };
}();

var updateByPhone = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(userPhone, formData) {
    var user;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            _context8.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.findOne({
              phone: userPhone
            }).select('-pin').populate({
              path: 'groupIds'
            }).exec());

          case 2:
            user = _context8.sent;

            if (user) {
              _context8.next = 5;
              break;
            }

            throw new Error('User with phone ' + userPhone + ' not found');

          case 5:

            user.phone = formData.phone;
            user.name = formData.name;
            user.photo = formData.photo;
            user.age = formData.age;
            user.yearOfJoining = formData.yearOfJoining;
            user.designation = formData.designation;
            user.uuid = formData.uuid;
            user.address = formData.address;
            user.details = formData.details;
            user.appVersion = formData.appVersion;
            user.appToken = formData.appToken;
            user.fbAccountId = formData.fbAccountId;
            user.fbUserToken = formData.fbUserToken;
            user.daysSinceSignup = formData.daysSinceSignup;
            user.points = formData.points;

            _context8.next = 22;
            return (0, _bluebird.resolve)(user.save());

          case 22:

            if (user) _user4.default.emit('elearning:user:update', user);

            user = user.toObject();

            _context8.next = 26;
            return (0, _bluebird.resolve)(isProfileCompleted(user));

          case 26:
            user.isProfileCompleted = _context8.sent;
            _context8.next = 29;
            return (0, _bluebird.resolve)(userGroupSort(user));

          case 29:
            user.groupIds = _context8.sent;
            return _context8.abrupt('return', user);

          case 31:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function updateByPhone(_x20, _x21) {
    return _ref11.apply(this, arguments);
  };
}();

var updateUsersGroupsByPhones = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(userPhones, groupIds) {
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.next = 2;
            return (0, _bluebird.resolve)(userPhones.map(function (userPhone) {
              if (userPhone && !isNaN(userPhone)) {
                return updateUserGroupByPhone(userPhone, groupIds);
              }
            }));

          case 2:
            return _context9.abrupt('return', _context9.sent);

          case 3:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this);
  }));

  return function updateUsersGroupsByPhones(_x22, _x23) {
    return _ref12.apply(this, arguments);
  };
}();

var updateUserGroupByPhone = function () {
  var _ref13 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(userPhone, groupIds) {
    var user, updatedGroupIds;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            _context10.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.findOne({
              phone: { $regex: '.*' + userPhone + '.*' }
            }).exec());

          case 2:
            user = _context10.sent;

            if (!user) {
              _context10.next = 11;
              break;
            }

            // Get ids from user object and save it a temporary variable
            updatedGroupIds = user.groupIds.map(function (id) {
              return id.toString();
            });

            // get all ids from requested groupIds and save all in the temporary variable

            groupIds.forEach(function (id) {
              updatedGroupIds.push(id);
            });

            // Get unique ids from that temporary variable using lodash
            updatedGroupIds = _lodash2.default.uniq(updatedGroupIds);

            user.groupIds = updatedGroupIds;

            _context10.next = 10;
            return (0, _bluebird.resolve)(user.save());

          case 10:

            if (user) _user4.default.emit('elearning:user:update', user);

          case 11:
            return _context10.abrupt('return', user);

          case 12:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this);
  }));

  return function updateUserGroupByPhone(_x24, _x25) {
    return _ref13.apply(this, arguments);
  };
}();

var updateById = function () {
  var _ref14 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee11(userId, formData) {
    var user;
    return _regenerator2.default.wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            _context11.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.findById(userId).select('-pin').exec());

          case 2:
            user = _context11.sent;

            if (user) {
              _context11.next = 5;
              break;
            }

            throw new Error('User not found');

          case 5:

            user.phone = formData.phone;
            user.name = formData.name;
            user.photo = formData.photo;
            user.age = formData.age;
            user.yearOfJoining = formData.yearOfJoining;
            user.designation = formData.designation;
            user.uuid = formData.uuid;
            user.address = formData.address;
            user.details = formData.details;
            user.appVersion = formData.appVersion;
            user.appToken = formData.appToken;
            user.fbAccountId = formData.fbAccountId;
            user.fbUserToken = formData.fbUserToken;
            user.daysSinceSignup = formData.daysSinceSignup;
            user.points = formData.points;
            user.groupIds = formData.groupIds;
            user.pin = formData.pin;

            _context11.next = 24;
            return (0, _bluebird.resolve)(user.save());

          case 24:

            if (user) _user4.default.emit('elearning:user:update', user);

            return _context11.abrupt('return', user);

          case 26:
          case 'end':
            return _context11.stop();
        }
      }
    }, _callee11, this);
  }));

  return function updateById(_x26, _x27) {
    return _ref14.apply(this, arguments);
  };
}();

var removeByPhone = function () {
  var _ref15 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee12(userPhone) {
    var user;
    return _regenerator2.default.wrap(function _callee12$(_context12) {
      while (1) {
        switch (_context12.prev = _context12.next) {
          case 0:
            _context12.next = 2;
            return (0, _bluebird.resolve)(eLearningUser.findOneAndUpdate({
              phone: userPhone
            }, {
              active: false
            }, {
              new: true
            }).lean().exec());

          case 2:
            user = _context12.sent;


            if (user) _user4.default.emit('elearning:user:remove', user);

            return _context12.abrupt('return', user);

          case 5:
          case 'end':
            return _context12.stop();
        }
      }
    }, _callee12, this);
  }));

  return function removeByPhone(_x28) {
    return _ref15.apply(this, arguments);
  };
}();

var saveLocationsByUserPhone = function () {
  var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee13(phone, formData) {
    var location;
    return _regenerator2.default.wrap(function _callee13$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            if (formData.longitude) {
              _context13.next = 2;
              break;
            }

            throw new Error('Location data missing');

          case 2:
            if (formData.latitude) {
              _context13.next = 4;
              break;
            }

            throw new Error('Location data missing');

          case 4:
            location = new this();


            location.timestamp = formData.timestamp;
            location.speed = formData.speed;
            location.heading = formData.heading;
            location.accuracy = formData.accuracy;
            location.altitude = formData.altitude;
            location.altitudeAccuracy = formData.altitudeAccuracy;

            location.location.coordinates = [formData.longitude, formData.latitude];

            location.userPhone = phone;

            _context13.next = 15;
            return (0, _bluebird.resolve)(location.save());

          case 15:
            return _context13.abrupt('return', _context13.sent);

          case 16:
          case 'end':
            return _context13.stop();
        }
      }
    }, _callee13, this);
  }));

  return function saveLocationsByUserPhone(_x29, _x30) {
    return _ref16.apply(this, arguments);
  };
}();

var getLocationsByUserPhone = function () {
  var _ref17 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee14(phone) {
    return _regenerator2.default.wrap(function _callee14$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            _context14.next = 2;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: {
                userPhone: phone
              }
            }, {
              $lookup: {
                "from": "e_learning_users",
                "localField": "userPhone",
                "foreignField": "phone",
                "as": "userPhone"
              }
            }, {
              $unwind: {
                path: "$userPhone"
              }
            }]));

          case 2:
            return _context14.abrupt('return', _context14.sent);

          case 3:
          case 'end':
            return _context14.stop();
        }
      }
    }, _callee14, this);
  }));

  return function getLocationsByUserPhone(_x31) {
    return _ref17.apply(this, arguments);
  };
}();

var getLocations = function () {
  var _ref18 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee15(startDate, endDate) {
    var query;
    return _regenerator2.default.wrap(function _callee15$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            query = {};


            if (startDate && endDate) {
              query.createdAt = {
                $gte: startDate,
                $lte: endDate
              };
            }

            _context15.next = 4;
            return (0, _bluebird.resolve)(eLearningLocations.aggregate([{
              $sort: {
                "_id": 1
              }
            }, {
              $match: query
            }, {
              $lookup: {
                "from": "e_learning_users",
                "localField": "userPhone",
                "foreignField": "phone",
                "as": "userPhone"
              }
            }, {
              $unwind: {
                path: "$userPhone"
              }
            }, {
              $group: {
                _id: "$userPhone.phone",
                location: {
                  $last: "$location.coordinates"
                }
              }
            }, {
              $lookup: {
                "from": "e_learning_users",
                "localField": "_id",
                "foreignField": "phone",
                "as": "user"
              }
            }, {
              $unwind: {
                path: "$user"
              }
            }, {
              $project: {
                name: "$user.name",
                phone: "$user.phone",
                photo: { $ifNull: ["$user.photo", "https://projotno-server.s3.ap-south-1.amazonaws.com/profilePic/file-1480169219494.jpeg"] },
                appVersion: "$user.appVersion",
                updatedAt: "$user.updatedAt",
                createdAt: "$user.createdAt",
                location: "$location"
              }
            }]));

          case 4:
            return _context15.abrupt('return', _context15.sent);

          case 5:
          case 'end':
            return _context15.stop();
        }
      }
    }, _callee15, this);
  }));

  return function getLocations(_x32, _x33) {
    return _ref18.apply(this, arguments);
  };
}();

var getUserStatistics = function () {
  var _ref19 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee16(userPhone) {
    var userContentCompletion, userPoints;
    return _regenerator2.default.wrap(function _callee16$(_context16) {
      while (1) {
        switch (_context16.prev = _context16.next) {
          case 0:
            _context16.next = 2;
            return (0, _bluebird.resolve)(Score.getUserContentCompletion(userPhone));

          case 2:
            userContentCompletion = _context16.sent;
            _context16.next = 5;
            return (0, _bluebird.resolve)(Point.getUserPoints(userPhone));

          case 5:
            userPoints = _context16.sent;
            return _context16.abrupt('return', {
              completedDisease: userContentCompletion.completedDisease,
              completedCase: userContentCompletion.completedCase,
              points: userPoints
            });

          case 7:
          case 'end':
            return _context16.stop();
        }
      }
    }, _callee16, this);
  }));

  return function getUserStatistics(_x34) {
    return _ref19.apply(this, arguments);
  };
}();

var savingUserPin = function () {
  var _ref20 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee17(userId, pin) {
    var user;
    return _regenerator2.default.wrap(function _callee17$(_context17) {
      while (1) {
        switch (_context17.prev = _context17.next) {
          case 0:
            if (pin) {
              _context17.next = 2;
              break;
            }

            throw new Error("Pin not found");

          case 2:
            _context17.next = 4;
            return (0, _bluebird.resolve)(eLearningUser.findById(userId).exec());

          case 4:
            user = _context17.sent;

            if (user) {
              _context17.next = 7;
              break;
            }

            throw new Error("User not found");

          case 7:

            user.pin = pin;
            _context17.next = 10;
            return (0, _bluebird.resolve)(user.save());

          case 10:
            return _context17.abrupt('return', 'success');

          case 11:
          case 'end':
            return _context17.stop();
        }
      }
    }, _callee17, this);
  }));

  return function savingUserPin(_x35, _x36) {
    return _ref20.apply(this, arguments);
  };
}();

var validatePin = function () {
  var _ref21 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee18(userId, pin) {
    var user;
    return _regenerator2.default.wrap(function _callee18$(_context18) {
      while (1) {
        switch (_context18.prev = _context18.next) {
          case 0:
            if (pin) {
              _context18.next = 2;
              break;
            }

            throw new Error("Pin not found");

          case 2:
            _context18.next = 4;
            return (0, _bluebird.resolve)(eLearningUser.findById(userId).exec());

          case 4:
            user = _context18.sent;

            if (user) {
              _context18.next = 7;
              break;
            }

            throw new Error("User not found");

          case 7:
            return _context18.abrupt('return', user.pin === pin);

          case 8:
          case 'end':
            return _context18.stop();
        }
      }
    }, _callee18, this);
  }));

  return function validatePin(_x37, _x38) {
    return _ref21.apply(this, arguments);
  };
}();

/**
 * Models
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _location = require('../../../schemas/elearning/location.schema');

var _location2 = _interopRequireDefault(_location);

var _user = require('../../../schemas/elearning/user.schema');

var _user2 = _interopRequireDefault(_user);

var _user3 = require('./user.events');

var _user4 = _interopRequireDefault(_user3);

var _user5 = require('./user.emailService');

var _system = require('../content/system/system.score');

var Score = _interopRequireWildcard(_system);

var _point = require('../point/point.model');

var Point = _interopRequireWildcard(_point);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Statics
 */
_user2.default.static('create', create).static('list', list).static('findByPhone', findByPhone).static('findUsers', findUsers).static('countByFilters', countByFilters).static('retrieve', retrieve).static('updateByPhone', updateByPhone).static('updateById', updateById).static('removeByPhone', removeByPhone).static('savingUserPin', savingUserPin).static('validatePin', validatePin).static('getUsersNameAndId', getUsersNameAndId).static('updateUsersGroupsByPhones', updateUsersGroupsByPhones).static('getUserStatistics', getUserStatistics);

_location2.default.static('saveLocationsByUserPhone', saveLocationsByUserPhone).static('getLocationsByUserPhone', getLocationsByUserPhone).static('getLocations', getLocations);

var eLearningUser = exports.eLearningUser = _mongoose2.default.model('E_Learning_User', _user2.default, 'e_learning_users');
var eLearningLocations = exports.eLearningLocations = _mongoose2.default.model('E_Learning_Locations', _location2.default, 'e_learning_users_locations');

/**
 * Exports
 */
exports.default = eLearningUser;
//# sourceMappingURL=user.model.js.map
