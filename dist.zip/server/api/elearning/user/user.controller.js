'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.validatePin = exports.savingUserPin = exports.getUserStatistics = exports.getGeoCodes = exports.getLocations = exports.getLocationsByUserPhone = exports.saveLocationsByUserId = exports.removeByPhone = exports.updateById = exports.updateByPhone = exports.retrieve = exports.create = exports.findUsers = exports.updateUsersGroupsByPhones = exports.getUsersNameAndId = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */
var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var users;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)(_user.eLearningUser.list());

          case 3:
            users = _context.sent;


            res.json({
              timestamp: Date.now(),
              users: users
            });
            _context.next = 10;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 10:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 7]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var getUsersNameAndId = exports.getUsersNameAndId = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var users;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return (0, _bluebird.resolve)(_user.eLearningUser.getUsersNameAndId());

          case 3:
            users = _context2.sent;


            res.json({
              timestamp: Date.now(),
              users: users
            });
            _context2.next = 10;
            break;

          case 7:
            _context2.prev = 7;
            _context2.t0 = _context2['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 10:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 7]]);
  }));

  return function getUsersNameAndId(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

/*
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var updateUsersGroupsByPhones = exports.updateUsersGroupsByPhones = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var groupIds, userPhones, users;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            groupIds = req.body.groupIds;
            userPhones = req.body.userPhones;
            _context3.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningUser.updateUsersGroupsByPhones(userPhones, groupIds));

          case 5:
            users = _context3.sent;


            res.json({
              timestamp: Date.now(),
              users: users
            });
            _context3.next = 12;
            break;

          case 9:
            _context3.prev = 9;
            _context3.t0 = _context3['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 12:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 9]]);
  }));

  return function updateUsersGroupsByPhones(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findUsers = exports.findUsers = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var startDate, endDate, groupIds, limit, skip, query, count, users;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            groupIds = req.query.groupIds;
            limit = req.query.limit || 50;
            skip = req.query.skip || 0;
            query = req.query.query;
            _context4.next = 9;
            return (0, _bluebird.resolve)(_user.eLearningUser.countByFilters(startDate, endDate, query, groupIds));

          case 9:
            count = _context4.sent;
            _context4.next = 12;
            return (0, _bluebird.resolve)(_user.eLearningUser.findUsers(startDate, endDate, query, limit, skip, groupIds));

          case 12:
            users = _context4.sent;


            res.json({
              timestamp: Date.now(),
              users: users,
              count: count
            });
            _context4.next = 19;
            break;

          case 16:
            _context4.prev = 16;
            _context4.t0 = _context4['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 19:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 16]]);
  }));

  return function findUsers(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var create = exports.create = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var formBody, user;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            formBody = req.body;
            _context5.prev = 1;
            _context5.next = 4;
            return (0, _bluebird.resolve)(_user.eLearningUser.create(formBody));

          case 4:
            user = _context5.sent;


            if (!user) {
              res.status(400).json({
                timestamp: new Date(),
                error: 'User with phone ' + formBody.phone + ' could not be created'
              });
            } else {
              res.json({
                timestamp: Date.now(),
                user: user
              });
            }

            _context5.next = 12;
            break;

          case 8:
            _context5.prev = 8;
            _context5.t0 = _context5['catch'](1);

            //Checking duplicate user error code
            if (_context5.t0.code === 11000) {
              res.status(409).json({
                timestamp: Date.now(),
                error: 'User with phone ' + formBody.phone + ' already exists'
              });
            }

            res.status(500).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 12:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[1, 8]]);
  }));

  return function create(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var retrieve = exports.retrieve = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var userPhone, user;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            if (!req.params.phone) res.status(400).end();

            _context6.prev = 1;
            userPhone = req.params.phone;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningUser.retrieve(userPhone));

          case 5:
            user = _context6.sent;


            if (!user) {
              res.status(404).json({
                timestamp: new Date(),
                error: 'User with phone ' + userPhone + ' not found'
              });
            } else {
              res.json({
                timestamp: Date.now(),
                user: user
              });
            }

            _context6.next = 12;
            break;

          case 9:
            _context6.prev = 9;
            _context6.t0 = _context6['catch'](1);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context6.t0.toString()
            });

          case 12:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[1, 9]]);
  }));

  return function retrieve(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var updateByPhone = exports.updateByPhone = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var userPhone, formBody, user;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.prev = 0;
            userPhone = req.params.phone;
            formBody = req.body;
            _context7.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningUser.updateByPhone(userPhone, formBody));

          case 5:
            user = _context7.sent;


            res.json({
              timestamp: new Date(),
              user: user
            });
            _context7.next = 12;
            break;

          case 9:
            _context7.prev = 9;
            _context7.t0 = _context7['catch'](0);

            res.status(404).json({
              timestamp: new Date(),
              error: _context7.t0.toString()
            });

          case 12:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[0, 9]]);
  }));

  return function updateByPhone(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var updateById = exports.updateById = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(req, res) {
    var userId, formBody, user;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            _context8.prev = 0;
            userId = req.params.id;
            formBody = req.body;
            _context8.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningUser.updateById(userId, formBody));

          case 5:
            user = _context8.sent;


            res.json({
              timestamp: new Date(),
              user: user
            });
            _context8.next = 12;
            break;

          case 9:
            _context8.prev = 9;
            _context8.t0 = _context8['catch'](0);

            res.status(404).json({
              timestamp: new Date(),
              error: _context8.t0.toString()
            });

          case 12:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this, [[0, 9]]);
  }));

  return function updateById(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var removeByPhone = exports.removeByPhone = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(req, res) {
    var userPhone, user;
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            if (!req.params.phone) res.status(400).end();

            _context9.prev = 1;
            userPhone = req.params.phone;
            _context9.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningUser.removeByPhone(userPhone));

          case 5:
            user = _context9.sent;


            if (!user) {
              res.status(404).json({
                timestamp: new Date(),
                error: 'User with phone ' + userPhone + ' not found'
              });
            }

            res.json({
              timestamp: new Date(),
              user: user
            });
            _context9.next = 13;
            break;

          case 10:
            _context9.prev = 10;
            _context9.t0 = _context9['catch'](1);

            res.status(500).json({
              timestamp: new Date(),
              error: _context9.t0.toString()
            });

          case 13:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this, [[1, 10]]);
  }));

  return function removeByPhone(_x17, _x18) {
    return _ref9.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var saveLocationsByUserId = exports.saveLocationsByUserId = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(req, res) {
    var phone, formData, locations;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            if (!req.params.phone) res.status(400).end();

            _context10.prev = 1;
            phone = req.params.phone;
            formData = req.body;
            _context10.next = 6;
            return (0, _bluebird.resolve)(_user.eLearningLocations.saveLocationsByUserPhone(phone, formData));

          case 6:
            locations = _context10.sent;


            res.json({
              timestamp: new Date(),
              locations: locations
            });
            _context10.next = 13;
            break;

          case 10:
            _context10.prev = 10;
            _context10.t0 = _context10['catch'](1);

            res.status(500).json({
              timestamp: new Date(),
              error: _context10.t0.toString()
            });

          case 13:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this, [[1, 10]]);
  }));

  return function saveLocationsByUserId(_x19, _x20) {
    return _ref10.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var getLocationsByUserPhone = exports.getLocationsByUserPhone = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee11(req, res) {
    var phone, locations;
    return _regenerator2.default.wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            if (!req.params.phone) res.status(400).end();

            _context11.prev = 1;
            phone = req.params.phone;
            _context11.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningLocations.getLocationsByUserPhone(phone));

          case 5:
            locations = _context11.sent;


            res.json({
              timestamp: new Date(),
              locations: locations
            });
            _context11.next = 12;
            break;

          case 9:
            _context11.prev = 9;
            _context11.t0 = _context11['catch'](1);

            res.status(500).json({
              timestamp: new Date(),
              error: _context11.t0.toString()
            });

          case 12:
          case 'end':
            return _context11.stop();
        }
      }
    }, _callee11, this, [[1, 9]]);
  }));

  return function getLocationsByUserPhone(_x21, _x22) {
    return _ref11.apply(this, arguments);
  };
}();

/**
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var getLocations = exports.getLocations = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee12(req, res) {
    var startDate, endDate, locations;
    return _regenerator2.default.wrap(function _callee12$(_context12) {
      while (1) {
        switch (_context12.prev = _context12.next) {
          case 0:
            if (!req.query.startDate) res.status(400).end();
            if (!req.query.endDate) res.status(400).end();

            _context12.prev = 2;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            _context12.next = 7;
            return (0, _bluebird.resolve)(_user.eLearningLocations.getLocations(startDate, endDate));

          case 7:
            locations = _context12.sent;


            res.json({
              timestamp: new Date(),
              locations: locations
            });
            _context12.next = 14;
            break;

          case 11:
            _context12.prev = 11;
            _context12.t0 = _context12['catch'](2);

            res.status(500).json({
              timestamp: new Date(),
              error: _context12.t0.toString()
            });

          case 14:
          case 'end':
            return _context12.stop();
        }
      }
    }, _callee12, this, [[2, 11]]);
  }));

  return function getLocations(_x23, _x24) {
    return _ref12.apply(this, arguments);
  };
}();

var getGeoCodes = exports.getGeoCodes = function () {
  var _ref13 = (0, _bluebird.method)(function (req, res) {
    try {
      res.json({
        timestamp: new Date(),
        geoCodes: _user3.default
      });
    } catch (error) {
      res.status(500).json({
        timestamp: new Date(),
        error: error.toString()
      });
    }
  });

  return function getGeoCodes(_x25, _x26) {
    return _ref13.apply(this, arguments);
  };
}();

var getUserStatistics = exports.getUserStatistics = function () {
  var _ref14 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee13(req, res) {
    var phone, statistics;
    return _regenerator2.default.wrap(function _callee13$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            _context13.prev = 0;
            phone = req.params.phone;
            _context13.next = 4;
            return (0, _bluebird.resolve)(_user.eLearningUser.getUserStatistics(phone));

          case 4:
            statistics = _context13.sent;


            res.json({
              timestamp: Date.now(),
              statistics: statistics
            });
            _context13.next = 11;
            break;

          case 8:
            _context13.prev = 8;
            _context13.t0 = _context13['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context13.t0.toString()
            });

          case 11:
          case 'end':
            return _context13.stop();
        }
      }
    }, _callee13, this, [[0, 8]]);
  }));

  return function getUserStatistics(_x27, _x28) {
    return _ref14.apply(this, arguments);
  };
}();

var savingUserPin = exports.savingUserPin = function () {
  var _ref15 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee14(req, res) {
    var newPin, userId, pin;
    return _regenerator2.default.wrap(function _callee14$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            _context14.prev = 0;
            newPin = req.body.pin;
            userId = req.params.id;
            _context14.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningUser.savingUserPin(userId, newPin));

          case 5:
            pin = _context14.sent;


            res.json({
              timestamp: new Date(),
              pin: pin
            });
            _context14.next = 12;
            break;

          case 9:
            _context14.prev = 9;
            _context14.t0 = _context14['catch'](0);

            res.status(500).json({
              timestamp: new Date(),
              error: _context14.t0.toString()
            });

          case 12:
          case 'end':
            return _context14.stop();
        }
      }
    }, _callee14, this, [[0, 9]]);
  }));

  return function savingUserPin(_x29, _x30) {
    return _ref15.apply(this, arguments);
  };
}();

var validatePin = exports.validatePin = function () {
  var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee15(req, res) {
    var pin, userId, status;
    return _regenerator2.default.wrap(function _callee15$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            _context15.prev = 0;
            pin = req.query.pin;
            userId = req.params.id;
            _context15.next = 5;
            return (0, _bluebird.resolve)(_user.eLearningUser.validatePin(userId, pin));

          case 5:
            status = _context15.sent;


            res.json(status);
            _context15.next = 12;
            break;

          case 9:
            _context15.prev = 9;
            _context15.t0 = _context15['catch'](0);

            res.status(500).json({
              timestamp: new Date(),
              error: _context15.t0.toString()
            });

          case 12:
          case 'end':
            return _context15.stop();
        }
      }
    }, _callee15, this, [[0, 9]]);
  }));

  return function validatePin(_x31, _x32) {
    return _ref16.apply(this, arguments);
  };
}();

exports.uploadProfileImageToS3 = uploadProfileImageToS3;

var _user = require('./user.model');

var _user2 = require('./user.geoCode');

var _user3 = _interopRequireDefault(_user2);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../../config/environment');
_awsSdk2.default.config.update(environment.aws);
var userProfilePhotoBucket = environment.aws.s3_bucket + '/e_learing_profile_picture';
var s3 = new _awsSdk2.default.S3({
  params: {
    Bucket: userProfilePhotoBucket
  }
});function uploadProfileImageToS3(req, res, next) {

  var user = req.body;
  var dateNow = Date.now();
  var base64Image = user.photo;
  var phone = req.params.phone;

  //We only get base64 image when user change the image
  if (!base64Image || !isValidBase64(base64Image)) {
    next();
  } else {
    var bufferImage = new Buffer(base64Image.replace(/^data:image\/\w+;base64,/, ""), 'base64');
    var option = {
      Key: phone + '-' + dateNow + '.jpeg',
      Body: bufferImage,
      ContentEncoding: 'base64',
      ContentType: 'image/jpeg',
      ACL: 'public-read'
    };

    s3.putObject(option, function (err, data) {
      if (err) {
        console.error('Error in image uploading: ', data);
      } else {
        console.log('Image upload success: ', data);

        req.body.photo = 'https://s3.ap-south-1.amazonaws.com/' + userProfilePhotoBucket + '/' + phone + '-' + dateNow + '.jpeg';
      }
      next();
    });
  }
}

function isValidBase64(base64Image) {
  if (base64Image.includes("data:image/jpeg;base64")) return true;
  return false;
}
//# sourceMappingURL=user.controller.js.map
