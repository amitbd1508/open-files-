"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var user = {
  "_id": "5b18f25566e7e700143c8b6a",
  "name": "test-robot",
  "phone": "01717777777",
  "address": {
    "districtCode": 19,
    "subDistrictCode": 31,
    "unionCode": 3,
    "_id": "5b18f25566e7e700143c8b6c"
  },
  "details": {
    "occupation": "Drug Seller",
    "reference": null,
    "_id": "5b18f25566e7e700143c8b6b"
  },
  "appVersion": "com.jeeon.projotno.elearning.browser-0.0.0-v0",
  "fbUserToken": null,
  "active": true,
  "isVisible": false,
  "uuid": null,
  "groupIds": []
};

var seedData = exports.seedData = {
  user: user
};
//# sourceMappingURL=user.seed.js.map
