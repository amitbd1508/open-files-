'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _user = require('./user.events');

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function update(socket) {
  var listener = function listener(user) {
    socket.emit('elearning:user:update', {
      timestamp: Date.now(),
      user: user
    });
  };

  _user2.default.on('elearning:user:update', listener);

  socket.on('disconnect', function () {
    _user2.default.removeListener('elearning:user:update', listener);
  });
}

function create(socket) {
  var listener = function listener(user) {
    socket.emit('elearning:user:create', {
      timestamp: Date.now(),
      user: user
    });
  };

  _user2.default.on('elearning:user:create', listener);

  socket.on('disconnect', function () {
    _user2.default.removeListener('elearning:user:create', listener);
  });
}

function remove(socket) {
  var listener = function listener(user) {
    socket.emit('elearning:user:remove', {
      timestamp: Date.now(),
      user: user
    });
  };

  _user2.default.on('elearning:user:remove', listener);

  socket.on('disconnect', function () {
    _user2.default.removeListener('elearning:user:remove', listener);
  });
}
//# sourceMappingURL=user.socket.js.map
