'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var UserEvents = new _events.EventEmitter();

/**
 * Options
 */
UserEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = UserEvents;
//# sourceMappingURL=user.events.js.map
