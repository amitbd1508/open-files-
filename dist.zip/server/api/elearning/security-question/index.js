'use strict';

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Imports
 */
var express = require('express');
var controller = require('./security-question.controller');

var router = express.Router();

/**
 * Routes
 */

// Get all saved questions in array
router.get('/', controller.index);

// Save new question
router.post('/', auth.isAuthenticated(), controller.saveQuestion);

// Update question by Id
router.put('/:id', auth.isAuthenticated(), controller.updateQuestionById);

// Delete question by question id
router.delete('/:id', auth.isAuthenticated(), controller.removeQuestionById);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
