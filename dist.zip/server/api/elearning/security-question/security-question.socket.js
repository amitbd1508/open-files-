'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _securityQuestion = require('./security-question.events');

var _securityQuestion2 = _interopRequireDefault(_securityQuestion);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  remove(socket);
  update(socket);
}

/**
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('security-question:create', {
      timestamp: Date.now()
    });
  };

  _securityQuestion2.default.on('security-question:create', listener);

  socket.on('disconnect', function () {
    _securityQuestion2.default.removeListener('security-question:create', listener);
  });
}

function remove(socket) {
  var listener = function listener() {
    socket.emit('security-question:remove', {
      timestamp: Date.now()
    });
  };

  _securityQuestion2.default.on('security-question:remove', listener);

  socket.on('disconnect', function () {
    _securityQuestion2.default.removeListener('security-question:remove', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('security-question:update', {
      timestamp: Date.now()
    });
  };

  _securityQuestion2.default.on('security-question:update', listener);

  socket.on('disconnect', function () {
    _securityQuestion2.default.removeListener('security-question:update', listener);
  });
}
//# sourceMappingURL=security-question.socket.js.map
