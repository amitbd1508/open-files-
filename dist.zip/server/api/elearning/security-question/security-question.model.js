'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SecurityQuestion = exports.removeQuestionById = exports.updateQuestionById = exports.saveQuestion = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.find({
              isActive: true
            }).populate({
              path: 'createdBy',
              select: 'fullname'
            }).sort('-createdAt').lean().exec());

          case 2:
            return _context.abrupt('return', _context.sent);

          case 3:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function index() {
    return _ref.apply(this, arguments);
  };
}();

var saveQuestion = exports.saveQuestion = function () {
  var _ref2 = (0, _bluebird.method)(function (userId, formBody) {
    var question = new SecurityQuestion(formBody);

    question.createdBy = userId;

    _securityQuestion2.default.emit('security-question:create');

    return question.save();
  });

  return function saveQuestion(_x, _x2) {
    return _ref2.apply(this, arguments);
  };
}();

var updateQuestionById = exports.updateQuestionById = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(questionId, updatedQuestion) {
    var question;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(questionId, updatedQuestion, {
              new: true
            }).lean().exec());

          case 2:
            question = _context2.sent;


            _securityQuestion2.default.emit('security-question:update');

            return _context2.abrupt('return', question);

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function updateQuestionById(_x3, _x4) {
    return _ref3.apply(this, arguments);
  };
}();

var removeQuestionById = exports.removeQuestionById = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(questionId) {
    var question;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            question = this.findById(questionId).exec();


            question.isActive = false;

            _context3.next = 4;
            return (0, _bluebird.resolve)(question.save());

          case 4:

            _securityQuestion2.default.emit('security-question:remove');

            return _context3.abrupt('return', question);

          case 6:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function removeQuestionById(_x5) {
    return _ref4.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _securityQuestion = require('./security-question.events');

var _securityQuestion2 = _interopRequireDefault(_securityQuestion);

var _securityQuestion3 = require('../../../schemas/elearning/security-question.schema');

var _securityQuestion4 = _interopRequireDefault(_securityQuestion3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_securityQuestion4.default.static('index', index).static('saveQuestion', saveQuestion).static('updateQuestionById', updateQuestionById).static('removeQuestionById', removeQuestionById);var SecurityQuestion = exports.SecurityQuestion = _mongoose2.default.model('SecurityQuestion', _securityQuestion4.default, 'e_learning_security_question');
//# sourceMappingURL=security-question.model.js.map
