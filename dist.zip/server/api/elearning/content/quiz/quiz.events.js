'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var QuizEvents = new _events.EventEmitter();

/**
 * Options
 */
QuizEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = QuizEvents;
//# sourceMappingURL=quiz.events.js.map
