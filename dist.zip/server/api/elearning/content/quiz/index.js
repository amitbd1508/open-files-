'use strict';

/**
 * Imports
 */

var _auth = require('../../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./quiz.controller');

var router = express.Router();

/**
 * Routes
 */

// saves a newly created quiz
router.post('/', auth.isAuthenticated(), controller.createQuiz);

// list of all quizzes
router.get('/', auth.isAuthenticated(), controller.listQuizzes);

// updates an existing quiz
router.put('/:id', auth.isAuthenticated(), controller.updateQuiz);

// deletes an existing quiz
router.delete('/:id', auth.isAuthenticated(), controller.removeQuiz);

// returns the quiz of the current week
router.get('/current/:phone', controller.currentQuiz);

// returns the quiz of last week of the current week
router.get('/last', controller.lastQuiz);

// returns the result of latest quiz
router.get('/last/result', controller.lastQuizResult);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
