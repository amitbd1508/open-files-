'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _quiz = require('./quiz.events');

var _quiz2 = _interopRequireDefault(_quiz);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket messages
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('eLearning:quiz:create', {
      timestamp: Date.now()
    });
  };

  _quiz2.default.on('eLearning:quiz:create', listener);

  socket.on('disconnect', function () {
    _quiz2.default.removeListener('eLearning:quiz:create', listener);
  });
}

function remove(socket) {
  var listener = function listener() {
    socket.emit('eLearning:quiz:remove', {
      timestamp: Date.now()
    });
  };

  _quiz2.default.on('eLearning:quiz:remove', listener);

  socket.on('disconnect', function () {
    _quiz2.default.removeListener('eLearning:quiz:remove', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('eLearning:quiz:update', {
      timestamp: Date.now()
    });
  };

  _quiz2.default.on('eLearning:quiz:update', listener);

  socket.on('disconnect', function () {
    _quiz2.default.removeListener('eLearning:quiz:update', listener);
  });
}
//# sourceMappingURL=quiz.socket.js.map
