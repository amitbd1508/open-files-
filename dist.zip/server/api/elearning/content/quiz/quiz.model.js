'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Quiz = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Functions
 */

var createQuiz = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(quizInfo) {
    var quiz;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            quizInfo = _typeform.TypeformForm.formatUrls(quizInfo);

            _context.next = 3;
            return (0, _bluebird.resolve)(Quiz(quizInfo).save());

          case 3:
            quiz = _context.sent;


            _typeform.TypeformForm.setHiddenForUrl(quiz.embedUrl);
            _typeform.TypeformForm.setWebhookForUrl(quiz.embedUrl);

            _typeform.TypeformResult.importResponsesForUrl(quiz.embedUrl);

            _quiz4.default.emit('eLearning:quiz:create', quiz);

            return _context.abrupt('return', quiz);

          case 9:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function createQuiz(_x) {
    return _ref.apply(this, arguments);
  };
}();

var listQuizzes = function () {
  var _ref2 = (0, _bluebird.method)(function () {
    return Quiz.find().sort({ startDate: -1 }).lean().exec();
  });

  return function listQuizzes() {
    return _ref2.apply(this, arguments);
  };
}();

var updateQuiz = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(quizId, updateQuizInfo) {
    var quiz;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            updateQuizInfo = _typeform.TypeformForm.formatUrls(updateQuizInfo);

            _context2.next = 3;
            return (0, _bluebird.resolve)(Quiz.findByIdAndUpdate(quizId, updateQuizInfo, { new: true }).lean().exec());

          case 3:
            quiz = _context2.sent;


            _typeform.TypeformForm.setHiddenForUrl(quiz.embedUrl);
            _typeform.TypeformForm.setWebhookForUrl(quiz.embedUrl);

            _typeform.TypeformResult.importResponsesForUrl(quiz.embedUrl);

            _quiz4.default.emit('eLearning:quiz:update', quiz);

            return _context2.abrupt('return', quiz);

          case 9:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function updateQuiz(_x2, _x3) {
    return _ref3.apply(this, arguments);
  };
}();

var removeQuiz = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(quizId) {
    var quiz;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(Quiz.findByIdAndRemove(quizId).exec());

          case 2:
            quiz = _context3.sent;


            _quiz4.default.emit('eLearning:quiz:remove');

            return _context3.abrupt('return', quiz);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function removeQuiz(_x4) {
    return _ref4.apply(this, arguments);
  };
}();

var currentQuiz = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(userPhone) {
    var today, quiz;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            today = Date.now();
            _context4.next = 3;
            return (0, _bluebird.resolve)(Quiz.findOne().where('startDate').lte(today).where('endDate').gte(today).lean().exec());

          case 3:
            quiz = _context4.sent;

            if (!quiz) {
              _context4.next = 11;
              break;
            }

            _context4.next = 7;
            return (0, _bluebird.resolve)(_canParticipateInWeeklyQuiz(userPhone, quiz.embedUrl));

          case 7:
            quiz.canParticipateInQuiz = _context4.sent;
            _context4.next = 10;
            return (0, _bluebird.resolve)(_deepLinks2.default.forWeeklyQuiz());

          case 10:
            quiz.deepLink = _context4.sent;

          case 11:
            return _context4.abrupt('return', quiz);

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function currentQuiz(_x5) {
    return _ref5.apply(this, arguments);
  };
}();

var _canParticipateInWeeklyQuiz = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(userPhone, quizEmbedUrl) {
    var totalAttempts;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            if (_typeform.TypeformForm.isUrl(quizEmbedUrl)) {
              _context5.next = 2;
              break;
            }

            return _context5.abrupt('return', false);

          case 2:
            _context5.next = 4;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.getTotalAttempts(_typeform.TypeformForm.getUid(quizEmbedUrl), userPhone));

          case 4:
            totalAttempts = _context5.sent;
            return _context5.abrupt('return', totalAttempts < MAX_NUMBER_OF_ATTEMPT_IN_QUIZ);

          case 6:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function _canParticipateInWeeklyQuiz(_x6, _x7) {
    return _ref6.apply(this, arguments);
  };
}();

var lastQuiz = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6() {
    var today;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            today = Date.now();
            _context6.next = 3;
            return (0, _bluebird.resolve)(Quiz.findOne({
              endDate: {
                $lt: today
              }
            }).sort({ endDate: -1 }).lean().exec());

          case 3:
            return _context6.abrupt('return', _context6.sent);

          case 4:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function lastQuiz() {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Models
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _quiz = require('../../../../schemas/elearning/quiz.schema');

var _quiz2 = _interopRequireDefault(_quiz);

var _quiz3 = require('./quiz.events');

var _quiz4 = _interopRequireDefault(_quiz3);

var _deepLinks = require('../../deepLinks/deepLinks');

var _deepLinks2 = _interopRequireDefault(_deepLinks);

var _typeform = require('../../typeform/typeform.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */
var MAX_NUMBER_OF_ATTEMPT_IN_QUIZ = 1;

/**
 * Statics
 */
_quiz2.default.static('createQuiz', createQuiz).static('listQuizzes', listQuizzes).static('updateQuiz', updateQuiz).static('removeQuiz', removeQuiz).static('currentQuiz', currentQuiz).static('lastQuiz', lastQuiz);var Quiz = exports.Quiz = _mongoose2.default.model('Quiz', _quiz2.default, 'e_learning_quizzes');
//# sourceMappingURL=quiz.model.js.map
