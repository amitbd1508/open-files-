'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HealthTips = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

var create = function () {
  var _ref = (0, _bluebird.method)(function (formData) {
    var healthTip = new HealthTips(formData);

    _healthTips4.default.emit('health-tips:create');

    return healthTip.save();
  });

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var findHealthTips = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(startDate, endDate, limit, skip) {
    var startOfWeek, endOfWeek, query, healthTips;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            startOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            endOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : startOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : endOfWeek;

            _context.next = 6;
            return (0, _bluebird.resolve)(filters(startDate, endDate));

          case 6:
            query = _context.sent;
            _context.next = 9;
            return (0, _bluebird.resolve)(HealthTips.find(query).limit(parseInt(limit)).skip(parseInt(skip)).sort('-startDate').lean().exec());

          case 9:
            healthTips = _context.sent;
            return _context.abrupt('return', healthTips.map(function (healthTip) {
              healthTip.deepLink = _deepLinks2.default.forHealthTipPage(healthTip._id);
              return healthTip;
            }));

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findHealthTips(_x2, _x3, _x4, _x5) {
    return _ref2.apply(this, arguments);
  };
}();

var findTodaysHealthTip = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
    var today;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            today = Date.now();
            _context2.next = 3;
            return (0, _bluebird.resolve)(HealthTips.findOne().where('startDate').lte(today).where('endDate').gte(today).sort('-startDate').lean().exec());

          case 3:
            return _context2.abrupt('return', _context2.sent);

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findTodaysHealthTip() {
    return _ref3.apply(this, arguments);
  };
}();

var update = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(healthTipId, formData) {
    var healthTip;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(HealthTips.findByIdAndUpdate(healthTipId, formData, { new: true }).exec());

          case 2:
            healthTip = _context3.sent;


            _healthTips4.default.emit('health-tips:update');

            return _context3.abrupt('return', healthTip);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function update(_x6, _x7) {
    return _ref4.apply(this, arguments);
  };
}();

var remove = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(healthTipId) {
    var healthTip;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(HealthTips.findOneAndRemove({
              _id: healthTipId
            }).exec());

          case 2:
            healthTip = _context4.sent;
            _context4.next = 5;
            return (0, _bluebird.resolve)(_homeSlider.HomeSlider.removeByContentTypeAndId('healthTips', healthTipId));

          case 5:

            _healthTips4.default.emit('health-tips:remove');

            return _context4.abrupt('return', healthTip);

          case 7:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function remove(_x8) {
    return _ref5.apply(this, arguments);
  };
}();

var findHealthTipsCount = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(startDate, endDate) {
    var dateStartOfWeek, dateEndOfWeek, query;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            dateStartOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            dateEndOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : dateStartOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : dateEndOfWeek;

            query = {
              createdAt: {
                $gte: startDate,
                $lte: endDate
              }
            };
            _context5.next = 7;
            return (0, _bluebird.resolve)(HealthTips.count(query).exec());

          case 7:
            return _context5.abrupt('return', _context5.sent);

          case 8:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findHealthTipsCount(_x9, _x10) {
    return _ref6.apply(this, arguments);
  };
}();

var filters = function () {
  var _ref7 = (0, _bluebird.method)(function (startDate, endDate) {
    return {
      createdAt: {
        $gte: startDate,
        $lte: endDate
      }
    };
  });

  return function filters(_x11, _x12) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Models
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _healthTips = require('../../../../schemas/elearning/health-tips.schema');

var _healthTips2 = _interopRequireDefault(_healthTips);

var _healthTips3 = require('./health-tips.events');

var _healthTips4 = _interopRequireDefault(_healthTips3);

var _homeSlider = require('../../home-slider/home-slider.model');

var _deepLinks = require('../../deepLinks/deepLinks');

var _deepLinks2 = _interopRequireDefault(_deepLinks);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_healthTips2.default.static('create', create).static('findHealthTips', findHealthTips).static('findHealthTipsCount', findHealthTipsCount).static('findTodaysHealthTip', findTodaysHealthTip).static('update', update).static('remove', remove);var HealthTips = exports.HealthTips = _mongoose2.default.model('HealthTips', _healthTips2.default, 'e_learning_health_tips');
//# sourceMappingURL=health-tips.model.js.map
