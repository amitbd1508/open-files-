'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var HealthTipsEvents = new _events.EventEmitter();

/**
 * Options
 */
HealthTipsEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = HealthTipsEvents;
//# sourceMappingURL=health-tips.events.js.map
