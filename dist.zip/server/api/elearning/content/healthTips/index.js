'use strict';

/**
 * Imports
 */

var _auth = require('../../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./health-tips.controller');

var router = express.Router();

/**
 * Routes
 */

// Get all health tips
router.get('/', auth.isAuthenticated(), controller.index);

// Create health tip
router.post('/', auth.isAuthenticated(), controller.create);

// Get today's health tip
router.get('/today', controller.findTodaysHealthTip);

// Updates an existing health tip
router.put('/:id', auth.isAuthenticated(), controller.update);

// Deletes an existing health tip
router.delete('/:id', auth.isAuthenticated(), controller.remove);

// Upload health tip image
router.post('/images', auth.isAuthenticated(), controller.uploading, controller.healthTipsImageUpload);

// Upload health tip banner image
router.post('/banner', auth.isAuthenticated(), controller.bannerUploading, controller.healthTipsImageUpload);

// Update health tip image
router.put('/images/:id', auth.isAuthenticated(), controller.uploading, controller.healthTipsImageUpdate);

// Upload health tip banner image
router.put('/banner/:id', auth.isAuthenticated(), controller.bannerUploading, controller.healthTipsBannerUpdate);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
