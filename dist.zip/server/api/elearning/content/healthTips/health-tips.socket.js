'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _healthTips = require('./health-tips.events');

var _healthTips2 = _interopRequireDefault(_healthTips);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(healthTip) {
    socket.emit('health-tips:create', {
      timestamp: Date.now(),
      healthTip: healthTip
    });
  };

  _healthTips2.default.on('health-tips:create', listener);

  socket.on('disconnect', function () {
    _healthTips2.default.removeListener('health-tips:create', listener);
  });
}

function update(socket) {
  var listener = function listener(healthTip) {
    socket.emit('health-tips:update', {
      timestamp: Date.now(),
      healthTip: healthTip
    });
  };

  _healthTips2.default.on('health-tips:update', listener);

  socket.on('disconnect', function () {
    _healthTips2.default.removeListener('health-tips:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(healthTip) {
    socket.emit('health-tips:remove', {
      timestamp: Date.now(),
      healthTip: healthTip
    });
  };

  _healthTips2.default.on('health-tips:remove', listener);

  socket.on('disconnect', function () {
    _healthTips2.default.removeListener('health-tips:remove', listener);
  });
}
//# sourceMappingURL=health-tips.socket.js.map
