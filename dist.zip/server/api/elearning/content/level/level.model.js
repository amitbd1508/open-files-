'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Level = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

var list = function () {
  var _ref = (0, _bluebird.method)(function () {
    return Level.find({ active: true }).lean().exec();
  });

  return function list() {
    return _ref.apply(this, arguments);
  };
}();

var latest = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(levelId, userPhone, appToken) {
    var level, typeformUid, levelResult;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Level.findOne({ active: true, _id: levelId }).exec());

          case 2:
            level = _context.sent;
            typeformUid = _typeform.TypeformForm.getUid(level.embedUrl);
            _context.next = 6;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.getLatestStats(typeformUid, userPhone, appToken, level.passingScore));

          case 6:
            levelResult = _context.sent;

            if (!(levelResult.totalAttempts === 0)) {
              _context.next = 13;
              break;
            }

            _context.next = 10;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.pull(typeformUid, userPhone, appToken));

          case 10:
            _context.next = 12;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.getLatestStats(typeformUid, userPhone, appToken, level.passingScore));

          case 12:
            levelResult = _context.sent;

          case 13:
            return _context.abrupt('return', _decorateLevel(level, levelResult));

          case 14:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function latest(_x, _x2, _x3) {
    return _ref2.apply(this, arguments);
  };
}();

var create = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(diseaseId, levelContent) {
    var level;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            levelContent.publishDate = _momentTimezone2.default.tz(levelContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();
            levelContent = _typeform.TypeformForm.formatUrls(levelContent);

            _context2.next = 4;
            return (0, _bluebird.resolve)(Level(levelContent).save());

          case 4:
            level = _context2.sent;
            _context2.next = 7;
            return (0, _bluebird.resolve)(_saveLevelId(diseaseId, level._id));

          case 7:

            _typeform.TypeformForm.setHiddenForUrl(level.embedUrl);
            _typeform.TypeformForm.setHiddenForUrl(level.embedUrlContent);
            _typeform.TypeformForm.setHiddenForUrl(level.embedUrlFeedback);

            _typeform.TypeformForm.setWebhookForUrl(level.embedUrl);

            _typeform.TypeformResult.importResponsesForUrl(level.embedUrl);

            _level4.default.emit('level:create', level);

            return _context2.abrupt('return', level);

          case 14:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function create(_x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}();

var update = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(levelId, levelContent) {
    var level;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            levelContent.publishDate = _momentTimezone2.default.tz(levelContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();
            levelContent = _typeform.TypeformForm.formatUrls(levelContent);

            _context3.next = 4;
            return (0, _bluebird.resolve)(Level.findByIdAndUpdate(levelId, levelContent, { new: true }).exec());

          case 4:
            level = _context3.sent;


            _typeform.TypeformForm.setHiddenForUrl(level.embedUrl);
            _typeform.TypeformForm.setHiddenForUrl(level.embedUrlContent);
            _typeform.TypeformForm.setHiddenForUrl(level.embedUrlFeedback);

            _typeform.TypeformForm.setWebhookForUrl(level.embedUrl);

            _typeform.TypeformResult.importResponsesForUrl(level.embedUrl);

            _level4.default.emit('level:update', level);

            return _context3.abrupt('return', level);

          case 12:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function update(_x6, _x7) {
    return _ref4.apply(this, arguments);
  };
}();

var _saveLevelId = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(diseaseId, levelId) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(_disease.Disease.findByIdAndUpdate(diseaseId, {
              $push: {
                levels: levelId
              }
            }).exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function _saveLevelId(_x8, _x9) {
    return _ref5.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _level = require('../../../../schemas/elearning/level.schema');

var _level2 = _interopRequireDefault(_level);

var _level3 = require('./level.events');

var _level4 = _interopRequireDefault(_level3);

var _disease = require('../disease/disease.model');

var _typeform = require('../../typeform/typeform.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_level2.default.static('list', list).static('latest', latest).static('create', create).static('update', update);

function _decorateLevel(level, levelResult) {
  return {
    _id: level._id,

    updatedAt: level.updatedAt,
    createdAt: level.createdAt,

    embedUrl: level.embedUrl,
    embedUrlContent: level.embedUrlContent,
    embedUrlFeedback: level.embedUrlFeedback,
    isScrollingDisabledForEmbedUrl: level.isScrollingDisabledForEmbedUrl,
    isScrollingDisabledForEmbedUrlContent: level.isScrollingDisabledForEmbedUrlContent,
    isScrollingDisabledForEmbedUrlFeedback: level.isScrollingDisabledForEmbedUrlFeedback,

    title: level.title,
    title_bn: level.title_bn,
    imageUrl: level.imageUrl,
    points: level.points,
    passingScore: level.passingScore,
    publishDate: level.publishDate,

    score: levelResult.score,
    totalQuestions: levelResult.totalQuestions,
    correctAnswers: levelResult.correctAnswers,
    totalAttempts: levelResult.totalAttempts,
    passingAttempts: levelResult.passingAttempts,

    order: level.order,
    active: level.active
  };
}

/**
 * Models
 */
var Level = exports.Level = _mongoose2.default.model('Level', _level2.default, 'e_learning_levels');
//# sourceMappingURL=level.model.js.map
