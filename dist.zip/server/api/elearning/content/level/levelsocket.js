'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _level = require('./level.events');

var _level2 = _interopRequireDefault(_level);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(level) {
    socket.emit('level:create', {
      timestamp: Date.now(),
      level: level
    });
  };

  _level2.default.on('level:create', listener);

  socket.on('disconnect', function () {
    _level2.default.removeListener('level:create', listener);
  });
}

function update(socket) {
  var listener = function listener(level) {
    socket.emit('level:update', {
      timestamp: Date.now(),
      level: level
    });
  };

  _level2.default.on('level:update', listener);

  socket.on('disconnect', function () {
    _level2.default.removeListener('level:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(level) {
    socket.emit('level:remove', {
      timestamp: Date.now(),
      level: level
    });
  };

  _level2.default.on('level:remove', listener);

  socket.on('disconnect', function () {
    _level2.default.removeListener('level:remove', listener);
  });
}
//# sourceMappingURL=levelsocket.js.map
