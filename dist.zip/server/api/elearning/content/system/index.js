'use strict';

/**
 * Imports
 */

var _auth = require('../../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./system.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', controller.index);
router.post('/', auth.isAuthenticated(), controller.create);
router.put('/:id', auth.isAuthenticated(), controller.update);
router.delete('/:id', auth.isAuthenticated(), controller.remove);

router.post('/images', auth.isAuthenticated(), controller.uploading, controller.systemImageUpload);
router.post('/banner', auth.isAuthenticated(), controller.bannerUploading, controller.systemImageUpload);

router.put('/images/:id', auth.isAuthenticated(), controller.uploading, controller.systemImageUpdate);
router.put('/banner/:id', auth.isAuthenticated(), controller.bannerUploading, controller.systemBannerUpdate);

router.get('/summary', auth.isAuthenticated(), controller.summary);
router.get('/summary.json', auth.isAuthenticated(), controller.summary);
router.get('/summary.csv', auth.isAuthenticated(), controller.summaryCSV);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
