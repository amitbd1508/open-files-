'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.System = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

var create = function () {
  var _ref = (0, _bluebird.method)(function (systemContent) {
    systemContent.publishDate = _momentTimezone2.default.tz(systemContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();

    var system = new System(systemContent).save();

    _system4.default.emit('system:create', system);

    return system;
  });

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var list = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
    var systems;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(System.find({ 'active': true }).populate({
              path: 'diseases',
              match: { active: true },
              options: { sort: { order: 'asc' } },
              populate: {
                path: 'levels',
                match: { active: true },
                options: { sort: { order: 'asc' } }
              }
            }).populate({
              path: 'cases',
              match: { active: true },
              options: { sort: { order: 'asc' } },
              populate: {
                path: 'rugies',
                match: { active: true },
                options: { sort: { order: 'asc' } }
              }
            }).sort({ order: 'asc' }).lean().exec());

          case 2:
            systems = _context.sent;
            _context.next = 5;
            return (0, _bluebird.resolve)(_addDeepLink(systems));

          case 5:
            systems = _context.sent;
            return _context.abrupt('return', systems);

          case 7:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function list() {
    return _ref2.apply(this, arguments);
  };
}();

var _addDeepLink = function () {
  var _ref3 = (0, _bluebird.method)(function (systems) {
    return systems.map(function (system) {
      system.diseases.map(function (disease) {
        disease.deepLink = _deepLinks2.default.forDiseasePage(system._id, disease._id);

        disease.levels.map(function (level) {
          level.deepLink = _deepLinks2.default.forLevelPage(system._id, disease._id, level._id);
          return level;
        }, []);

        return disease;
      }, []);

      system.cases.map(function (caseItem) {
        caseItem.deepLink = _deepLinks2.default.forCasePage(system._id, caseItem._id);

        caseItem.rugies.map(function (rugi) {
          rugi.deepLink = _deepLinks2.default.forRugiPage(system._id, caseItem._id, rugi._id);
          return rugi;
        }, []);

        return caseItem;
      }, []);

      return system;
    }, []);
  });

  return function _addDeepLink(_x2) {
    return _ref3.apply(this, arguments);
  };
}();

var update = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(systemId, systemContent) {
    var system;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            systemContent.publishDate = _momentTimezone2.default.tz(systemContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();

            _context2.next = 3;
            return (0, _bluebird.resolve)(System.findByIdAndUpdate(systemId, systemContent, { new: true }).exec());

          case 3:
            system = _context2.sent;


            _system4.default.emit('system:update', system);

            return _context2.abrupt('return', system);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function update(_x3, _x4) {
    return _ref4.apply(this, arguments);
  };
}();

var remove = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(systemId) {
    var system;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(System.findByIdAndUpdate(systemId, {
              active: false
            }).exec());

          case 2:
            system = _context3.sent;


            _system4.default.emit('system:remove', system);

            return _context3.abrupt('return', system);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function remove(_x5) {
    return _ref5.apply(this, arguments);
  };
}();

var listForUser = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(userPhone, systems) {
    var _this = this;

    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.next = 2;
            return (0, _bluebird.resolve)(Score.sortSystems(systems).then(function () {
              var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(sortedSystems) {
                return _regenerator2.default.wrap(function _callee4$(_context4) {
                  while (1) {
                    switch (_context4.prev = _context4.next) {
                      case 0:
                        _context4.next = 2;
                        return (0, _bluebird.resolve)(Score.decorateSystemsWithScore(userPhone, sortedSystems));

                      case 2:
                        return _context4.abrupt('return', _context4.sent);

                      case 3:
                      case 'end':
                        return _context4.stop();
                    }
                  }
                }, _callee4, _this);
              }));

              return function (_x8) {
                return _ref7.apply(this, arguments);
              };
            }()).then(function () {
              var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(systemsWithScore) {
                return _regenerator2.default.wrap(function _callee5$(_context5) {
                  while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        _context5.next = 2;
                        return (0, _bluebird.resolve)(Score.decorateSystemsWithIsPublished(systemsWithScore));

                      case 2:
                        return _context5.abrupt('return', _context5.sent);

                      case 3:
                      case 'end':
                        return _context5.stop();
                    }
                  }
                }, _callee5, _this);
              }));

              return function (_x9) {
                return _ref8.apply(this, arguments);
              };
            }()).then(function () {
              var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(systemsWithIsPublished) {
                return _regenerator2.default.wrap(function _callee6$(_context6) {
                  while (1) {
                    switch (_context6.prev = _context6.next) {
                      case 0:
                        _context6.next = 2;
                        return (0, _bluebird.resolve)(Score.decorateSystemsWithIsNew(systemsWithIsPublished));

                      case 2:
                        return _context6.abrupt('return', _context6.sent);

                      case 3:
                      case 'end':
                        return _context6.stop();
                    }
                  }
                }, _callee6, _this);
              }));

              return function (_x10) {
                return _ref9.apply(this, arguments);
              };
            }()).then(function () {
              var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(systemsWithIsNew) {
                return _regenerator2.default.wrap(function _callee7$(_context7) {
                  while (1) {
                    switch (_context7.prev = _context7.next) {
                      case 0:
                        _context7.next = 2;
                        return (0, _bluebird.resolve)(Score.decorateSystemsWithIsPassed(systemsWithIsNew));

                      case 2:
                        return _context7.abrupt('return', _context7.sent);

                      case 3:
                      case 'end':
                        return _context7.stop();
                    }
                  }
                }, _callee7, _this);
              }));

              return function (_x11) {
                return _ref10.apply(this, arguments);
              };
            }()).then(function () {
              var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(systemsWithIsPassed) {
                return _regenerator2.default.wrap(function _callee8$(_context8) {
                  while (1) {
                    switch (_context8.prev = _context8.next) {
                      case 0:
                        _context8.next = 2;
                        return (0, _bluebird.resolve)(Score.decorateSystemsWithIsUnlocked(systemsWithIsPassed));

                      case 2:
                        return _context8.abrupt('return', _context8.sent);

                      case 3:
                      case 'end':
                        return _context8.stop();
                    }
                  }
                }, _callee8, _this);
              }));

              return function (_x12) {
                return _ref11.apply(this, arguments);
              };
            }()));

          case 2:
            return _context9.abrupt('return', _context9.sent);

          case 3:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this);
  }));

  return function listForUser(_x6, _x7) {
    return _ref6.apply(this, arguments);
  };
}();

var summary = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10() {
    var contentItems;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            _context10.next = 2;
            return (0, _bluebird.resolve)(this.aggregate([{
              $lookup: {
                "from": "e_learning_diseases",
                "localField": "diseases",
                "foreignField": "_id",
                "as": "diseases"
              }
            }, {
              $unwind: {
                path: "$diseases"
              }
            }, {
              $lookup: {
                "from": "e_learning_cases",
                "localField": "cases",
                "foreignField": "_id",
                "as": "cases"
              }
            }, {
              $unwind: {
                path: "$cases"
              }
            }, {
              $lookup: {
                "from": "e_learning_levels",
                "localField": "diseases.levels",
                "foreignField": "_id",
                "as": "diseases.levels"
              }
            }, {
              $unwind: {
                path: "$diseases.levels"
              }
            }, {
              $lookup: {
                "from": "e_learning_rugies",
                "localField": "cases.rugies",
                "foreignField": "_id",
                "as": "cases.rugies"
              }
            }, {
              $unwind: {
                path: "$cases.rugies"
              }
            }, {
              $project: {
                title: {
                  $concat: ["$title", " | ", "$diseases.title", " | ", "$diseases.levels.title", " | ", "$cases.title", " | ", "$cases.rugies.title"]
                },
                title_bn: {
                  $concat: ["$title_bn", " | ", "$diseases.title_bn", " | ", "$diseases.levels.title_bn", " | ", "$cases.title_bn", " | ", "$cases.rugies.title_bn"]
                },
                // Published at
                system_publishedAt: "$publishDate",
                disease_publishedAt: '$diseases.publishDate',
                disease_level_publishedAt: '$diseases.levels.publishDate',
                case_publishedAt: '$cases.publishDate',
                case_rugi_publishedAt: '$cases.rugies.publishDate',
                // Created at
                system_createdAt: '$createdAt',
                disease_createdAt: '$diseases.createdAt',
                disease_level_createdAt: '$diseases.levels.createdAt',
                case_createdAt: '$cases.createdAt',
                case_rugi_createdAt: '$cases.rugies.createdAt',
                // Updated at
                system_updatedAt: '$updatedAt',
                disease_updatedAt: '$diseases.updatedAt',
                disease_level_updatedAt: '$diseases.levels.updatedAt',
                case_updatedAt: '$cases.updatedAt',
                case_rugi_updatedAt: '$cases.rugies.updatedAt'
              }
            }]));

          case 2:
            contentItems = _context10.sent;
            _context10.next = 5;
            return (0, _bluebird.resolve)(_humanizeDates(contentItems));

          case 5:
            return _context10.abrupt('return', _context10.sent);

          case 6:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this);
  }));

  return function summary() {
    return _ref12.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _system = require('../../../../schemas/elearning/system.schema');

var _system2 = _interopRequireDefault(_system);

var _system3 = require('./system.events');

var _system4 = _interopRequireDefault(_system3);

var _deepLinks = require('../../deepLinks/deepLinks');

var _deepLinks2 = _interopRequireDefault(_deepLinks);

var _system5 = require('./system.score');

var Score = _interopRequireWildcard(_system5);

var _environment = require('../../../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */
var TIMEZONE = _environment2.default.scheduleTimeZone;

/**
 * Statics
 */
_system2.default.static('create', create).static('list', list).static('update', update).static('remove', remove).static('listForUser', listForUser).static('summary', summary);

function _humanizeDates(systems) {
  return systems.map(function (system) {
    system.system_publishedAt = (0, _momentTimezone2.default)(system.system_publishedAt).tz(TIMEZONE).toString();
    system.disease_publishedAt = (0, _momentTimezone2.default)(system.disease_publishedAt).tz(TIMEZONE).toString();
    system.disease_level_publishedAt = (0, _momentTimezone2.default)(system.disease_level_publishedAt).tz(TIMEZONE).toString();
    system.case_publishedAt = (0, _momentTimezone2.default)(system.case_publishedAt).tz(TIMEZONE).toString();
    system.case_rugi_publishedAt = (0, _momentTimezone2.default)(system.case_rugi_publishedAt).tz(TIMEZONE).toString();

    system.system_createdAt = (0, _momentTimezone2.default)(system.system_createdAt).tz(TIMEZONE).toString();
    system.disease_createdAt = (0, _momentTimezone2.default)(system.disease_createdAt).tz(TIMEZONE).toString();
    system.disease_level_createdAt = (0, _momentTimezone2.default)(system.disease_level_createdAt).tz(TIMEZONE).toString();
    system.case_createdAt = (0, _momentTimezone2.default)(system.case_createdAt).tz(TIMEZONE).toString();
    system.case_rugi_createdAt = (0, _momentTimezone2.default)(system.case_rugi_createdAt).tz(TIMEZONE).toString();

    system.system_updatedAt = (0, _momentTimezone2.default)(system.system_updatedAt).tz(TIMEZONE).toString();
    system.disease_updatedAt = (0, _momentTimezone2.default)(system.disease_updatedAt).tz(TIMEZONE).toString();
    system.disease_level_updatedAt = (0, _momentTimezone2.default)(system.disease_level_updatedAt).tz(TIMEZONE).toString();
    system.case_updatedAt = (0, _momentTimezone2.default)(system.case_updatedAt).tz(TIMEZONE).toString();
    system.case_rugi_updatedAt = (0, _momentTimezone2.default)(system.case_rugi_updatedAt).tz(TIMEZONE).toString();

    return system;
  });
}

/**
 * Models
 */
var System = exports.System = _mongoose2.default.model('System', _system2.default, 'e_learning_systems');
//# sourceMappingURL=system.model.js.map
