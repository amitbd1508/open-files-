'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var SystemEvents = new _events.EventEmitter();

/**
 * Options
 */
SystemEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = SystemEvents;
//# sourceMappingURL=system.events.js.map
