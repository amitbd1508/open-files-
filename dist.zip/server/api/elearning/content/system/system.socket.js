'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _system = require('./system.events');

var _system2 = _interopRequireDefault(_system);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(system) {
    socket.emit('system:create', {
      timestamp: Date.now(),
      system: system
    });
  };

  _system2.default.on('system:create', listener);

  socket.on('disconnect', function () {
    _system2.default.removeListener('system:create', listener);
  });
}

function update(socket) {
  var listener = function listener(system) {
    socket.emit('system:update', {
      timestamp: Date.now(),
      system: system
    });
  };

  _system2.default.on('system:update', listener);

  socket.on('disconnect', function () {
    _system2.default.removeListener('system:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(system) {
    socket.emit('system:remove', {
      timestamp: Date.now(),
      system: system
    });
  };

  _system2.default.on('system:remove', listener);

  socket.on('disconnect', function () {
    _system2.default.removeListener('system:remove', listener);
  });
}
//# sourceMappingURL=system.socket.js.map
