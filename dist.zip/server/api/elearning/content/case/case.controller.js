'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.caseBannerUploading = exports.caseUploading = exports.caseBannerUpdate = exports.caseImageUpdate = exports.caseImageUpload = exports.destroy = exports.update = exports.create = exports.load = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Functions
 */

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var cases;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)(_case.Case.find({ 'active': true }).populate('rugies').lean().exec());

          case 3:
            cases = _context.sent;


            res.json({
              timestamp: Date.now(),
              cases: cases
            });
            _context.next = 10;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.stack
            });

          case 10:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 7]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var load = exports.load = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var caseId, caseItem;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            caseId = req.params.id;


            if (!caseId) res.status(400).end();

            _context2.prev = 2;
            _context2.next = 5;
            return (0, _bluebird.resolve)(_case.Case.find({ '_id': caseId, 'active': true }).populate('rugies').lean().exec());

          case 5:
            caseItem = _context2.sent;


            res.json({
              timestamp: Date.now(),
              caseItem: caseItem
            });
            _context2.next = 12;
            break;

          case 9:
            _context2.prev = 9;
            _context2.t0 = _context2['catch'](2);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context2.t0.stack
            });

          case 12:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[2, 9]]);
  }));

  return function load(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var create = exports.create = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var systemId, caseItem;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            systemId = req.params.systemId;


            if (!systemId) res.status(400).end();

            _context3.prev = 2;
            _context3.next = 5;
            return (0, _bluebird.resolve)(_case.Case.create(systemId, req.body));

          case 5:
            caseItem = _context3.sent;


            res.json({
              timestamp: Date.now(),
              caseItem: caseItem
            });
            _context3.next = 12;
            break;

          case 9:
            _context3.prev = 9;
            _context3.t0 = _context3['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.stack
            });

          case 12:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[2, 9]]);
  }));

  return function create(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var update = exports.update = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var caseId, caseItem;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            caseId = req.params.id;


            if (!caseId) res.status(400).end();

            _context4.prev = 2;
            _context4.next = 5;
            return (0, _bluebird.resolve)(_case.Case.update(caseId, req.body));

          case 5:
            caseItem = _context4.sent;


            res.json({
              timestamp: new Date(),
              caseItem: caseItem
            });
            _context4.next = 12;
            break;

          case 9:
            _context4.prev = 9;
            _context4.t0 = _context4['catch'](2);

            res.status(400).json({
              timestamp: new Date(),
              error: _context4.t0.stack
            });

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[2, 9]]);
  }));

  return function update(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var destroy = exports.destroy = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var caseId, caseItem;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            caseId = req.params.id;


            if (!caseId) res.status(400).end();

            _context5.prev = 2;
            _context5.next = 5;
            return (0, _bluebird.resolve)(_case.Case.findByIdAndUpdate(caseId, {
              active: false
            }));

          case 5:
            caseItem = _context5.sent;
            _context5.next = 8;
            return (0, _bluebird.resolve)(_homeSlider.HomeSlider.removeByContentTypeAndId('case', caseId));

          case 8:

            _case3.default.emit('case:remove', caseItem);

            res.json({
              timestamp: new Date(),
              caseItem: caseItem
            });
            _context5.next = 15;
            break;

          case 12:
            _context5.prev = 12;
            _context5.t0 = _context5['catch'](2);

            res.status(400).json({
              timestamp: new Date(),
              error: _context5.t0.stack
            });

          case 15:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[2, 12]]);
  }));

  return function destroy(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var caseImageUpload = exports.caseImageUpload = function () {
  var _ref6 = (0, _bluebird.method)(function (req, res) {
    try {
      var location = req.file.location;

      res.json({
        timestamp: new Date(),
        location: location
      });
    } catch (error) {
      res.status(400).json({
        timestamp: Date.now(),
        error: error.stack
      });
    }
  });

  return function caseImageUpload(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var caseImageUpdate = exports.caseImageUpdate = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var location, caseId, caseItem;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.prev = 0;
            location = req.file.location;
            caseId = req.params.id;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_case.Case.findByIdAndUpdate(caseId, { imageUrl: location }));

          case 5:
            caseItem = _context6.sent;


            _case3.default.emit('case:update');

            res.json({
              timestamp: new Date(),
              caseItem: caseItem
            });
            _context6.next = 13;
            break;

          case 10:
            _context6.prev = 10;
            _context6.t0 = _context6['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0.stack
            });

          case 13:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[0, 10]]);
  }));

  return function caseImageUpdate(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var caseBannerUpdate = exports.caseBannerUpdate = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var location, caseId, caseItem;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.prev = 0;
            location = req.file.location;
            caseId = req.params.id;
            _context7.next = 5;
            return (0, _bluebird.resolve)(_case.Case.findByIdAndUpdate(caseId, { bannerUrl: location }));

          case 5:
            caseItem = _context7.sent;


            _case3.default.emit('case:update');

            res.json({
              timestamp: new Date(),
              caseItem: caseItem
            });
            _context7.next = 13;
            break;

          case 10:
            _context7.prev = 10;
            _context7.t0 = _context7['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context7.t0.stack
            });

          case 13:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[0, 10]]);
  }));

  return function caseBannerUpdate(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _case = require('./case.model');

var _case2 = require('./case.events');

var _case3 = _interopRequireDefault(_case2);

var _homeSlider = require('../../home-slider/home-slider.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var multer = require('multer');
var multerS3 = require('multer-s3');

var environment = require('../../../../config/environment');

_awsSdk2.default.config.update(environment.aws);
var s3 = new _awsSdk2.default.S3();var caseUploading = exports.caseUploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: environment.aws.s3_bucket,
    location: function location(req, caseImg, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, caseImg, cb) {
      cb(null, { fieldName: caseImg.fieldname });
    },
    key: function key(req, caseImg, cb) {
      cb(null, caseImg.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('caseImg');

var caseBannerUploading = exports.caseBannerUploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: environment.aws.s3_bucket,
    location: function location(req, caseImg, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, caseImg, cb) {
      cb(null, { fieldName: caseImg.fieldname });
    },
    key: function key(req, caseImg, cb) {
      cb(null, caseImg.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('caseBannerImg');
//# sourceMappingURL=case.controller.js.map
