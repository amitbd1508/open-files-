'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var CaseEvents = new _events.EventEmitter();

/**
 * Options
 */
CaseEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = CaseEvents;
//# sourceMappingURL=case.events.js.map
