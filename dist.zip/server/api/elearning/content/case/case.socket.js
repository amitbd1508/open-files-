'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _case = require('./case.events');

var _case2 = _interopRequireDefault(_case);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(caseItem) {
    socket.emit('case:create', {
      timestamp: Date.now(),
      caseItem: caseItem
    });
  };

  _case2.default.on('case:create', listener);

  socket.on('disconnect', function () {
    _case2.default.removeListener('case:create', listener);
  });
}

function update(socket) {
  var listener = function listener(caseItem) {
    socket.emit('case:update', {
      timestamp: Date.now(),
      caseItem: caseItem
    });
  };

  _case2.default.on('case:update', listener);

  socket.on('disconnect', function () {
    _case2.default.removeListener('case:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(caseItem) {
    socket.emit('case:remove', {
      timestamp: Date.now(),
      caseItem: caseItem
    });
  };

  _case2.default.on('case:remove', listener);

  socket.on('disconnect', function () {
    _case2.default.removeListener('case:remove', listener);
  });
}
//# sourceMappingURL=case.socket.js.map
