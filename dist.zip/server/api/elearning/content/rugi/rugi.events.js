'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var RugiEvents = new _events.EventEmitter();

/**
 * Options
 */
RugiEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = RugiEvents;
//# sourceMappingURL=rugi.events.js.map
