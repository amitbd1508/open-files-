'use strict';

/**
 * Imports
 */

var _auth = require('../../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./rugi.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', auth.isAuthenticated(), controller.index);
router.get('/:id/latest', controller.latest);
router.post('/:caseId', auth.isAuthenticated(), controller.create);
router.put('/:id', auth.isAuthenticated(), controller.update);
router.delete('/:id', auth.isAuthenticated(), controller.remove);

router.post('/images/upload', auth.isAuthenticated(), controller.rugiUploading, controller.rugiImageUpload);
router.put('/images/update/:id', auth.isAuthenticated(), controller.rugiUploading, controller.rugiImageUpdate);

router.put('/banner/update/:id', auth.isAuthenticated(), controller.rugiBannerUploading, controller.rugiBannerUpdate);

router.get('/day', controller.listByDate);
router.get('/day/results', controller.resultsByDate);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
