'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Rugi = undefined;

var _toConsumableArray2 = require('babel-runtime/helpers/toConsumableArray');

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

var list = function () {
  var _ref = (0, _bluebird.method)(function () {
    return Rugi.find({ active: true }).lean().exec();
  });

  return function list() {
    return _ref.apply(this, arguments);
  };
}();

var latest = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(rugiId, userPhone, appToken) {
    var rugi, typeformUid, rugiResult;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Rugi.findOne({ active: true, _id: rugiId }).exec());

          case 2:
            rugi = _context.sent;
            typeformUid = _typeform.TypeformForm.getUid(rugi.embedUrl);
            _context.next = 6;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.getLatestStats(typeformUid, userPhone, appToken, rugi.passingScore));

          case 6:
            rugiResult = _context.sent;

            if (!(rugiResult.totalAttempts === 0)) {
              _context.next = 13;
              break;
            }

            _context.next = 10;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.pull(typeformUid, userPhone, appToken));

          case 10:
            _context.next = 12;
            return (0, _bluebird.resolve)(_typeform.TypeformResult.getLatestStats(typeformUid, userPhone, appToken, rugi.passingScore));

          case 12:
            rugiResult = _context.sent;

          case 13:
            return _context.abrupt('return', _decorateRugi(rugi, rugiResult));

          case 14:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function latest(_x, _x2, _x3) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Get all rugies that are published at the given date.
 *
 * @param date
 * @returns {Promise<{startDate: *, endDate: *, rugies: *[]}>}
 */


var listByDate = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(date) {
    var _ref4;

    var cases, rugies, dates;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(_case.Case.findPublished(date));

          case 2:
            cases = _context2.sent;
            rugies = (_ref4 = []).concat.apply(_ref4, (0, _toConsumableArray3.default)(cases.map(function (caseObj) {
              return caseObj.rugies;
            })));
            _context2.next = 6;
            return (0, _bluebird.resolve)((0, _point.getPublishedDateRangeForContent)(cases));

          case 6:
            dates = _context2.sent;
            return _context2.abrupt('return', {
              startDate: dates.startDate,
              endDate: dates.endDate,
              rugies: rugies
            });

          case 8:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function listByDate(_x4) {
    return _ref3.apply(this, arguments);
  };
}();

var create = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(caseId, rugiContent) {
    var rugi;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            rugiContent.publishDate = _momentTimezone2.default.tz(rugiContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();
            rugiContent = _typeform.TypeformForm.formatUrls(rugiContent);

            _context3.next = 4;
            return (0, _bluebird.resolve)(Rugi(rugiContent).save());

          case 4:
            rugi = _context3.sent;
            _context3.next = 7;
            return (0, _bluebird.resolve)(_saveRugiId(caseId, rugi._id));

          case 7:

            _typeform.TypeformForm.setHiddenForUrl(rugi.embedUrl);
            _typeform.TypeformForm.setHiddenForUrl(rugi.embedUrlContent);
            _typeform.TypeformForm.setHiddenForUrl(rugi.embedUrlFeedback);

            _typeform.TypeformForm.setWebhookForUrl(rugi.embedUrl);

            _typeform.TypeformResult.importResponsesForUrl(rugi.embedUrl);

            _rugi4.default.emit('rugi:create', rugi);

            return _context3.abrupt('return', rugi);

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function create(_x5, _x6) {
    return _ref5.apply(this, arguments);
  };
}();

var update = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(rugiId, rugiContent) {
    var rugi;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            rugiContent.publishDate = _momentTimezone2.default.tz(rugiContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();
            rugiContent = _typeform.TypeformForm.formatUrls(rugiContent);

            _context4.next = 4;
            return (0, _bluebird.resolve)(Rugi.findByIdAndUpdate(rugiId, rugiContent, { new: true }).exec());

          case 4:
            rugi = _context4.sent;


            _typeform.TypeformForm.setHiddenForUrl(rugi.embedUrl);
            _typeform.TypeformForm.setHiddenForUrl(rugi.embedUrlContent);
            _typeform.TypeformForm.setHiddenForUrl(rugi.embedUrlFeedback);

            _typeform.TypeformForm.setWebhookForUrl(rugi.embedUrl);

            _typeform.TypeformResult.importResponsesForUrl(rugi.embedUrl);

            _rugi4.default.emit('rugi:update', rugi);

            return _context4.abrupt('return', rugi);

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function update(_x7, _x8) {
    return _ref6.apply(this, arguments);
  };
}();

var _saveRugiId = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(caseId, rugiId) {
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(_case.Case.findByIdAndUpdate(caseId, {
              $push: {
                rugies: rugiId
              }
            }).exec());

          case 2:
            return _context5.abrupt('return', _context5.sent);

          case 3:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function _saveRugiId(_x9, _x10) {
    return _ref7.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _rugi = require('../../../../schemas/elearning/rugi.schema');

var _rugi2 = _interopRequireDefault(_rugi);

var _rugi3 = require('./rugi.events');

var _rugi4 = _interopRequireDefault(_rugi3);

var _case = require('../case/case.model');

var _typeform = require('../../typeform/typeform.model');

var _point = require('../../point/point.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_rugi2.default.static('list', list).static('latest', latest).static('listByDate', listByDate).static('create', create).static('update', update);

function _decorateRugi(rugi, rugiResult) {
  return {
    _id: rugi._id,

    updatedAt: rugi.updatedAt,
    createdAt: rugi.createdAt,

    embedUrl: rugi.embedUrl,
    embedUrlContent: rugi.embedUrlContent,
    embedUrlFeedback: rugi.embedUrlFeedback,
    isScrollingDisabledForEmbedUrl: rugi.isScrollingDisabledForEmbedUrl,
    isScrollingDisabledForEmbedUrlContent: rugi.isScrollingDisabledForEmbedUrlContent,
    isScrollingDisabledForEmbedUrlFeedback: rugi.isScrollingDisabledForEmbedUrlFeedback,

    title: rugi.title,
    title_bn: rugi.title_bn,
    imageUrl: rugi.imageUrl,
    points: rugi.points,
    passingScore: rugi.passingScore,
    publishDate: rugi.publishDate,

    score: rugiResult.score,
    totalQuestions: rugiResult.totalQuestions,
    correctAnswers: rugiResult.correctAnswers,
    totalAttempts: rugiResult.totalAttempts,
    passingAttempts: rugiResult.passingAttempts,

    order: rugi.order,
    active: rugi.active
  };
}

/**
 * Models
 */
var Rugi = exports.Rugi = _mongoose2.default.model('Rugi', _rugi2.default, 'e_learning_rugies');
//# sourceMappingURL=rugi.model.js.map
