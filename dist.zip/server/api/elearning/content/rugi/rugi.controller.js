'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.rugiBannerUploading = exports.rugiUploading = exports.rugiBannerUpdate = exports.rugiImageUpdate = exports.rugiImageUpload = exports.remove = exports.update = exports.create = exports.resultsByDate = exports.listByDate = exports.latest = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Functions
 */

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var rugies;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)(_rugi.Rugi.list());

          case 3:
            rugies = _context.sent;


            res.json({
              timestamp: Date.now(),
              rugies: rugies
            });
            _context.next = 10;
            break;

          case 7:
            _context.prev = 7;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.stack
            });

          case 10:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 7]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var latest = exports.latest = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var rugiId, userPhone, appToken, rugi;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            rugiId = req.params.id;
            userPhone = req.query.user_phone;
            appToken = req.query.app_token;
            _context2.prev = 3;
            _context2.next = 6;
            return (0, _bluebird.resolve)(_rugi.Rugi.latest(rugiId, userPhone, appToken));

          case 6:
            rugi = _context2.sent;


            res.json({
              timestamp: Date.now(),
              rugi: rugi
            });
            _context2.next = 13;
            break;

          case 10:
            _context2.prev = 10;
            _context2.t0 = _context2['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.stack
            });

          case 13:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[3, 10]]);
  }));

  return function latest(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Get all the available rugies to solve on a particular day, default: today.
 *
 * @param req
 * @param res
 * @returns {Promise<void>}
 */


var listByDate = exports.listByDate = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var date, result;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            date = req.query.date || Date.now();
            _context3.prev = 1;
            _context3.next = 4;
            return (0, _bluebird.resolve)(_rugi.Rugi.listByDate((0, _momentTimezone2.default)(date)));

          case 4:
            result = _context3.sent;


            res.json({
              timestamp: Date.now(),
              startDate: result.startDate,
              endDate: result.endDate,
              rugies: result.rugies
            });
            _context3.next = 11;
            break;

          case 8:
            _context3.prev = 8;
            _context3.t0 = _context3['catch'](1);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.stack
            });

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[1, 8]]);
  }));

  return function listByDate(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var resultsByDate = exports.resultsByDate = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var date, result;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            date = req.query.date || Date.now();
            _context4.prev = 1;
            _context4.next = 4;
            return (0, _bluebird.resolve)((0, _point.listCasePoints)((0, _momentTimezone2.default)(date)));

          case 4:
            result = _context4.sent;


            res.json({
              timestamp: Date.now(),
              startDate: result.startDate,
              endDate: result.endDate,
              participants: result.participants
            });
            _context4.next = 11;
            break;

          case 8:
            _context4.prev = 8;
            _context4.t0 = _context4['catch'](1);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.stack
            });

          case 11:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[1, 8]]);
  }));

  return function resultsByDate(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var create = exports.create = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var caseId, rugi;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            caseId = req.params.caseId;


            if (!caseId) res.status(400).end();

            _context5.prev = 2;
            _context5.next = 5;
            return (0, _bluebird.resolve)(_rugi.Rugi.create(caseId, req.body));

          case 5:
            rugi = _context5.sent;


            res.json({
              timestamp: Date.now(),
              rugi: rugi
            });
            _context5.next = 12;
            break;

          case 9:
            _context5.prev = 9;
            _context5.t0 = _context5['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.stack
            });

          case 12:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[2, 9]]);
  }));

  return function create(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var update = exports.update = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var rugiId, rugi;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            rugiId = req.params.id;


            if (!rugiId) res.status(400).end();

            _context6.prev = 2;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_rugi.Rugi.update(rugiId, req.body));

          case 5:
            rugi = _context6.sent;


            res.json({
              timestamp: new Date(),
              rugi: rugi
            });
            _context6.next = 12;
            break;

          case 9:
            _context6.prev = 9;
            _context6.t0 = _context6['catch'](2);

            res.status(400).json({
              timestamp: new Date(),
              error: _context6.t0.stack
            });

          case 12:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[2, 9]]);
  }));

  return function update(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var remove = exports.remove = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var rugiId, rugi;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            rugiId = req.params.id;


            if (!rugiId) res.status(400).end();

            _context7.prev = 2;
            _context7.next = 5;
            return (0, _bluebird.resolve)(_rugi.Rugi.findByIdAndUpdate(rugiId, {
              active: false
            }));

          case 5:
            rugi = _context7.sent;
            _context7.next = 8;
            return (0, _bluebird.resolve)(_homeSlider.HomeSlider.removeByContentTypeAndId('rugi', rugiId));

          case 8:

            _rugi3.default.emit('rugi:remove');

            res.json({
              timestamp: new Date(),
              rugi: rugi
            });
            _context7.next = 15;
            break;

          case 12:
            _context7.prev = 12;
            _context7.t0 = _context7['catch'](2);

            res.status(400).json({
              timestamp: new Date(),
              error: _context7.t0.stack
            });

          case 15:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[2, 12]]);
  }));

  return function remove(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var rugiImageUpload = exports.rugiImageUpload = function () {
  var _ref8 = (0, _bluebird.method)(function (req, res) {
    try {
      var location = req.file.location;
      res.json({
        timestamp: new Date(),
        location: location
      });
    } catch (error) {
      res.status(400).json({
        timestamp: Date.now(),
        error: error.stack
      });
    }
  });

  return function rugiImageUpload(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

var rugiImageUpdate = exports.rugiImageUpdate = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(req, res) {
    var location, rugiId, rugi;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            _context8.prev = 0;
            location = req.file.location;
            rugiId = req.params.id;
            _context8.next = 5;
            return (0, _bluebird.resolve)(_rugi.Rugi.findByIdAndUpdate(rugiId, { imageUrl: location }));

          case 5:
            rugi = _context8.sent;

            _rugi3.default.emit('rugi:update');
            res.json({
              timestamp: new Date(),
              rugi: rugi
            });
            _context8.next = 13;
            break;

          case 10:
            _context8.prev = 10;
            _context8.t0 = _context8['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context8.t0.stack
            });

          case 13:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this, [[0, 10]]);
  }));

  return function rugiImageUpdate(_x17, _x18) {
    return _ref9.apply(this, arguments);
  };
}();

var rugiBannerUpdate = exports.rugiBannerUpdate = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(req, res) {
    var location, rugiId, rugi;
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.prev = 0;
            location = req.file.location;
            rugiId = req.params.id;
            _context9.next = 5;
            return (0, _bluebird.resolve)(_rugi.Rugi.findByIdAndUpdate(rugiId, { bannerUrl: location }));

          case 5:
            rugi = _context9.sent;


            _rugi3.default.emit('rugi:update');

            res.json({
              timestamp: new Date(),
              rugi: rugi
            });
            _context9.next = 13;
            break;

          case 10:
            _context9.prev = 10;
            _context9.t0 = _context9['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context9.t0.stack
            });

          case 13:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this, [[0, 10]]);
  }));

  return function rugiBannerUpdate(_x19, _x20) {
    return _ref10.apply(this, arguments);
  };
}();

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _rugi = require('./rugi.model');

var _rugi2 = require('./rugi.events');

var _rugi3 = _interopRequireDefault(_rugi2);

var _homeSlider = require('../../home-slider/home-slider.model');

var _point = require('../../point/point.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var multer = require('multer');
var multerS3 = require('multer-s3');

var environment = require('../../../../config/environment');

_awsSdk2.default.config.update(environment.aws);
var s3 = new _awsSdk2.default.S3();var rugiUploading = exports.rugiUploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: environment.aws.s3_bucket,
    location: function location(req, rugiImg, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, rugiImg, cb) {
      cb(null, { fieldName: rugiImg.fieldname });
    },
    key: function key(req, rugiImg, cb) {
      cb(null, rugiImg.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('rugiImg');

var rugiBannerUploading = exports.rugiBannerUploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: environment.aws.s3_bucket,
    location: function location(req, rugiImg, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, rugiImg, cb) {
      cb(null, { fieldName: rugiImg.fieldname });
    },
    key: function key(req, rugiImg, cb) {
      cb(null, rugiImg.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('rugiBannerImg');
//# sourceMappingURL=rugi.controller.js.map
