'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _rugi = require('./rugi.events');

var _rugi2 = _interopRequireDefault(_rugi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(rugi) {
    socket.emit('rugi:create', {
      timestamp: Date.now(),
      rugi: rugi
    });
  };

  _rugi2.default.on('rugi:create', listener);

  socket.on('disconnect', function () {
    _rugi2.default.removeListener('rugi:create', listener);
  });
}

function update(socket) {
  var listener = function listener(rugi) {
    socket.emit('rugi:update', {
      timestamp: Date.now(),
      rugi: rugi
    });
  };

  _rugi2.default.on('rugi:update', listener);

  socket.on('disconnect', function () {
    _rugi2.default.removeListener('rugi:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(rugi) {
    socket.emit('rugi:remove', {
      timestamp: Date.now(),
      rugi: rugi
    });
  };

  _rugi2.default.on('rugi:remove', listener);

  socket.on('disconnect', function () {
    _rugi2.default.removeListener('rugi:remove', listener);
  });
}
//# sourceMappingURL=rugi.socket.js.map
