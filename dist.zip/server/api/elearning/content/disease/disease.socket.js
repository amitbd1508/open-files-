'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _disease = require('./disease.events');

var _disease2 = _interopRequireDefault(_disease);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(disease) {
    socket.emit('disease:create', {
      timestamp: Date.now(),
      disease: disease
    });
  };

  _disease2.default.on('disease:create', listener);

  socket.on('disconnect', function () {
    _disease2.default.removeListener('disease:create', listener);
  });
}

function update(socket) {
  var listener = function listener(disease) {
    socket.emit('disease:update', {
      timestamp: Date.now(),
      disease: disease
    });
  };

  _disease2.default.on('disease:update', listener);

  socket.on('disconnect', function () {
    _disease2.default.removeListener('disease:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(disease) {
    socket.emit('disease:remove', {
      timestamp: Date.now(),
      disease: disease
    });
  };

  _disease2.default.on('disease:remove', listener);

  socket.on('disconnect', function () {
    _disease2.default.removeListener('disease:remove', listener);
  });
}
//# sourceMappingURL=disease.socket.js.map
