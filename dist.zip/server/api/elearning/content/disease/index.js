'use strict';

/**
 * Imports
 */

var _auth = require('../../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./disease.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', auth.isAuthenticated(), controller.index);
router.get('/:id', auth.isAuthenticated(), controller.load);
router.post('/:systemId', auth.isAuthenticated(), controller.create);
router.put('/:id', auth.isAuthenticated(), controller.update);
router.delete('/:id', auth.isAuthenticated(), controller.destroy);

router.post('/images/upload', auth.isAuthenticated(), controller.diseaseUploading, controller.diseaseImageUpload);
router.put('/images/update/:id', auth.isAuthenticated(), controller.diseaseUploading, controller.diseaseImageUpdate);

router.put('/banner/update/:id', auth.isAuthenticated(), controller.diseaseBannerUploading, controller.diseaseBannerUpdate);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
