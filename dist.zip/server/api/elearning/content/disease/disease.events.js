'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var DiseaseEvents = new _events.EventEmitter();

/**
 * Options
 */
DiseaseEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = DiseaseEvents;
//# sourceMappingURL=disease.events.js.map
