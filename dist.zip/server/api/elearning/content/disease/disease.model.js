'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Disease = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */

var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(systemId, diseaseContent) {
    var disease;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            diseaseContent.publishDate = _momentTimezone2.default.tz(diseaseContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();

            _context.next = 3;
            return (0, _bluebird.resolve)(Disease(diseaseContent).save());

          case 3:
            disease = _context.sent;
            _context.next = 6;
            return (0, _bluebird.resolve)(_saveDiseaseId(systemId, disease._id));

          case 6:

            _disease2.default.emit('disease:create', disease);

            return _context.abrupt('return', disease);

          case 8:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var update = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(diseaseId, diseaseContent) {
    var disease;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            diseaseContent.publishDate = _momentTimezone2.default.tz(diseaseContent.publishDate, 'Asia/Dhaka').startOf('day').toDate();

            _context2.next = 3;
            return (0, _bluebird.resolve)(Disease.findByIdAndUpdate(diseaseId, diseaseContent, { new: true }).exec());

          case 3:
            disease = _context2.sent;


            _disease2.default.emit('disease:update', disease);

            return _context2.abrupt('return', disease);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function update(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var _saveDiseaseId = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(systemId, diseaseId) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(_system.System.findByIdAndUpdate(systemId, {
              $push: {
                diseases: diseaseId
              }
            }).exec());

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function _saveDiseaseId(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Models
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _diseases = require('../../../../schemas/elearning/diseases.schema');

var _diseases2 = _interopRequireDefault(_diseases);

var _disease = require('./disease.events');

var _disease2 = _interopRequireDefault(_disease);

var _system = require('../system/system.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_diseases2.default.static('create', create).static('update', update);var Disease = exports.Disease = _mongoose2.default.model('Disease', _diseases2.default, 'e_learning_diseases');
//# sourceMappingURL=disease.model.js.map
