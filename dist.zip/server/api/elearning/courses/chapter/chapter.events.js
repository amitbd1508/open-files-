'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var ChapterEvents = new _events.EventEmitter();

/**
 * Options
 */
ChapterEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = ChapterEvents;
//# sourceMappingURL=chapter.events.js.map
