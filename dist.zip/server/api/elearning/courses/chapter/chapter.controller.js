'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.bannerUploading = exports.uploading = exports.chapterBannerUpdate = exports.chapterImageUpdate = exports.chapterImageUpload = exports.remove = exports.update = exports.create = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var limit, skip, companyIds, chapters, count;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            limit = req.query.limit || 50;
            skip = req.query.skip || 0;
            companyIds = req.query.companyIds;
            _context.next = 6;
            return (0, _bluebird.resolve)(_chapter.Chapter.list(limit, skip, companyIds));

          case 6:
            chapters = _context.sent;
            count = chapters.length;


            res.json({
              timestamp: Date.now(),
              chapters: chapters,
              count: count
            });
            _context.next = 14;
            break;

          case 11:
            _context.prev = 11;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 14:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 11]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var create = exports.create = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var formBody, chapter;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            formBody = req.body;
            _context2.next = 4;
            return (0, _bluebird.resolve)(_chapter.Chapter.create(formBody));

          case 4:
            chapter = _context2.sent;


            res.json({
              timestamp: Date.now(),
              chapter: chapter
            });
            _context2.next = 11;
            break;

          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 11:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 8]]);
  }));

  return function create(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var update = exports.update = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var chapterId, formBody, chapter;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            if (!req.params.id) res.status(400).end();
            if (!req.body) res.status(400).end();

            chapterId = req.params.id;
            formBody = req.body;
            _context3.prev = 4;
            _context3.next = 7;
            return (0, _bluebird.resolve)(_chapter.Chapter.update(chapterId, formBody));

          case 7:
            chapter = _context3.sent;


            res.json({
              timestamp: new Date(),
              chapter: chapter
            });
            _context3.next = 14;
            break;

          case 11:
            _context3.prev = 11;
            _context3.t0 = _context3['catch'](4);

            res.status(400).json({
              timestamp: new Date(),
              error: _context3.t0.toString()
            });

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[4, 11]]);
  }));

  return function update(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var remove = exports.remove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var chapterId, chapter;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            chapterId = req.params.id;

            if (!chapterId) res.status(400).end();

            _context4.prev = 2;
            _context4.next = 5;
            return (0, _bluebird.resolve)(_chapter.Chapter.remove(chapterId));

          case 5:
            chapter = _context4.sent;


            res.json({
              timestamp: new Date(),
              chapter: chapter
            });
            _context4.next = 12;
            break;

          case 9:
            _context4.prev = 9;
            _context4.t0 = _context4['catch'](2);

            res.status(400).json({
              timestamp: new Date(),
              error: _context4.t0
            });

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[2, 9]]);
  }));

  return function remove(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var chapterImageUpload = exports.chapterImageUpload = function () {
  var _ref5 = (0, _bluebird.method)(function (req, res) {
    try {
      var location = req.file.location;
      res.json({
        timestamp: new Date(),
        location: location
      });
    } catch (error) {
      res.status(400).json({
        timestamp: Date.now(),
        error: error.toString()
      });
    }
  });

  return function chapterImageUpload(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var chapterImageUpdate = exports.chapterImageUpdate = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var location, chapterId, chapter;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            location = req.file.location;
            chapterId = req.params.id;
            _context5.next = 5;
            return (0, _bluebird.resolve)(_chapter.Chapter.update(chapterId, { imageURL: location }));

          case 5:
            chapter = _context5.sent;


            res.json({
              timestamp: new Date(),
              chapter: chapter
            });
            _context5.next = 12;
            break;

          case 9:
            _context5.prev = 9;
            _context5.t0 = _context5['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 12:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 9]]);
  }));

  return function chapterImageUpdate(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var chapterBannerUpdate = exports.chapterBannerUpdate = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var location, chapterId, chapter;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.prev = 0;
            location = req.file.location;
            chapterId = req.params.id;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_chapter.Chapter.update(chapterId, { bannerURL: location }));

          case 5:
            chapter = _context6.sent;


            res.json({
              timestamp: new Date(),
              chapter: chapter
            });
            _context6.next = 12;
            break;

          case 9:
            _context6.prev = 9;
            _context6.t0 = _context6['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0.toString()
            });

          case 12:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[0, 9]]);
  }));

  return function chapterBannerUpdate(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var _chapter = require('./chapter.model');

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var multer = require('multer');
var multerS3 = require('multer-s3');
var environment = require('../../../../config/environment/index');

_awsSdk2.default.config.update(environment.aws);
var s3 = new _awsSdk2.default.S3();
var AWSS3Bucket = environment.aws.s3_bucket + '/chapter';

var uploading = exports.uploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: AWSS3Bucket + '/images',
    location: function location(req, file, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function key(req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('file');

var bannerUploading = exports.bannerUploading = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: AWSS3Bucket + '/banner-images',
    location: function location(req, file, cb) {
      cb(null, req.params.location);
    },
    metadata: function metadata(req, file, cb) {
      cb(null, { fieldName: file.fieldname });
    },
    key: function key(req, file, cb) {
      cb(null, file.fieldname + '-' + Date.now() + '.jpeg');
    }
  })
}).single('banner');
//# sourceMappingURL=chapter.controller.js.map
