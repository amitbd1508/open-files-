'use strict';

var _auth = require('../../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Imports
 */
var express = require('express');
var controller = require('./chapter.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', controller.index);

router.post('/', auth.isAuthenticated(), controller.create);

router.put('/:id', auth.isAuthenticated(), controller.update);

router.delete('/:id', auth.isAuthenticated(), controller.remove);

router.post('/images', auth.isAuthenticated(), controller.uploading, controller.chapterImageUpload);

router.post('/banner', auth.isAuthenticated(), controller.bannerUploading, controller.chapterBannerUpdate);

router.put('/images/:id', auth.isAuthenticated(), controller.uploading, controller.chapterImageUpdate);

router.put('/banner/:id', auth.isAuthenticated(), controller.bannerUploading, controller.chapterBannerUpdate);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
