'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _chapter = require('./chapter.events');

var _chapter2 = _interopRequireDefault(_chapter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(chapter) {
    socket.emit('elearning:courses:chapters:create', {
      timestamp: Date.now(),
      chapter: chapter
    });
  };

  _chapter2.default.on('elearning:courses:chapters:create', listener);

  socket.on('disconnect', function () {
    _chapter2.default.removeListener('elearning:courses:chapters:create', listener);
  });
}

function update(socket) {
  var listener = function listener(chapter) {
    socket.emit('elearning:courses:chapters:update', {
      timestamp: Date.now(),
      chapter: chapter
    });
  };

  _chapter2.default.on('elearning:courses:chapters:update', listener);

  socket.on('disconnect', function () {
    _chapter2.default.removeListener('elearning:courses:chapters:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(chapter) {
    socket.emit('elearning:courses:chapters:remove', {
      timestamp: Date.now(),
      chapter: chapter
    });
  };

  _chapter2.default.on('elearning:courses:chapters:remove', listener);

  socket.on('disconnect', function () {
    _chapter2.default.removeListener('elearning:courses:chapters:remove', listener);
  });
}
//# sourceMappingURL=chapter.socket.js.map
