'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Lesson = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * @param formBody
 * @returns {Promise<*>}
 */
var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formBody) {
    var lesson;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            formBody.publishedAt = _momentTimezone2.default.tz(formBody.publishedAt, 'Asia/Dhaka').startOf('day').toDate();

            lesson = new Lesson(formBody);
            _context.next = 4;
            return (0, _bluebird.resolve)(lesson.save());

          case 4:

            _lesson4.default.emit('elearning:courses:lessons:create');

            return _context.abrupt('return', lesson);

          case 6:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * @param limit
 * @param skip
 * @returns {Promise<void>}
 */


var getLessons = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(limit, skip) {
    var lessons;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(Lesson.find({
              isActive: true
            }).populate({
              path: 'chapterId',
              options: { sort: { order: 'asc' } },
              populate: {
                path: 'companies.companyId',
                options: { isActive: true }
              }
            }).sort({
              order: 'asc'
            }).limit(parseInt(limit)).skip(parseInt(skip)).lean().exec());

          case 2:
            lessons = _context2.sent;


            lessons.map(function (lesson) {
              lesson.chapterId.companies.map(function (company) {
                company.deepLink = _deepLinks2.default.forLessonPage(company.companyId._id, lesson.chapterId._id, lesson._id);
              });
            });

            return _context2.abrupt('return', lessons);

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getLessons(_x2, _x3) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * @param lessonId
 * @param formBody
 * @returns {Promise<void>}
 */


var update = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(lessonId, formBody) {
    var lesson;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            formBody.publishedAt = _momentTimezone2.default.tz(formBody.publishedAt, 'Asia/Dhaka').startOf('day').toDate();

            _context3.next = 3;
            return (0, _bluebird.resolve)(Lesson.findByIdAndUpdate(lessonId, formBody, {
              new: true
            }).lean().exec());

          case 3:
            lesson = _context3.sent;


            _lesson4.default.emit('elearning:courses:lessons:update');

            return _context3.abrupt('return', lesson);

          case 6:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function update(_x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * @param lessonId
 * @returns {Promise<void>}
 */


var remove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(lessonId) {
    var lesson;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Lesson.findOneAndUpdate({
              _id: lessonId
            }, {
              isActive: false
            }, {
              new: true
            }).lean().exec());

          case 2:
            lesson = _context4.sent;


            _lesson4.default.emit('elearning:courses:lessons:remove');

            return _context4.abrupt('return', lesson);

          case 5:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function remove(_x6) {
    return _ref4.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _lesson = require('../../../../schemas/elearning/lesson.schema');

var _lesson2 = _interopRequireDefault(_lesson);

var _lesson3 = require('./lesson.events');

var _lesson4 = _interopRequireDefault(_lesson3);

var _deepLinks = require('../../deepLinks/deepLinks');

var _deepLinks2 = _interopRequireDefault(_deepLinks);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_lesson2.default.static('create', create).static('getLessons', getLessons).static('update', update).static('remove', remove);var Lesson = exports.Lesson = _mongoose2.default.model('Lesson', _lesson2.default, 'e_learning_lessons');
//# sourceMappingURL=lesson.model.js.map
