'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _lesson = require('./lesson.events');

var _lesson2 = _interopRequireDefault(_lesson);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket Messages
 */

function create(socket) {
  var listener = function listener(lesson) {
    socket.emit('elearning:courses:lessons:create', {
      timestamp: Date.now(),
      lesson: lesson
    });
  };

  _lesson2.default.on('elearning:courses:lessons:create', listener);

  socket.on('disconnect', function () {
    _lesson2.default.removeListener('elearning:courses:lessons:create', listener);
  });
}

function update(socket) {
  var listener = function listener(lesson) {
    socket.emit('elearning:courses:lessons:update', {
      timestamp: Date.now(),
      lesson: lesson
    });
  };

  _lesson2.default.on('elearning:courses:lessons:update', listener);

  socket.on('disconnect', function () {
    _lesson2.default.removeListener('elearning:courses:lessons:update', listener);
  });
}

function remove(socket) {
  var listener = function listener(lesson) {
    socket.emit('elearning:courses:lessons:remove', {
      timestamp: Date.now(),
      lesson: lesson
    });
  };

  _lesson2.default.on('elearning:courses:lessons:remove', listener);

  socket.on('disconnect', function () {
    _lesson2.default.removeListener('elearning:courses:lessons:remove', listener);
  });
}
//# sourceMappingURL=lesson.socket.js.map
