'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var LessonEvents = new _events.EventEmitter();

/**
 * Options
 */
LessonEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = LessonEvents;
//# sourceMappingURL=lesson.events.js.map
