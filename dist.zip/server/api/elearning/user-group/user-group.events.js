'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var UserGroupEvents = new _events.EventEmitter();
/**
 * Options
 */
UserGroupEvents.setMaxListeners(0);
/**
 * Exports
 */
exports.default = UserGroupEvents;
//# sourceMappingURL=user-group.events.js.map
