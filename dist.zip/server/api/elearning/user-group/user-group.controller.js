'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.sendGroupNotification = exports.remove = exports.updateUserGroupById = exports.getUserGroups = exports.createUserGroup = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var createUserGroup = exports.createUserGroup = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var formBody, userId, userGroup;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            formBody = req.body;
            userId = req.user._id;
            _context.next = 5;
            return (0, _bluebird.resolve)(_userGroup.UserGroup.createUserGroup(formBody, userId));

          case 5:
            userGroup = _context.sent;


            res.status(201).json({
              timestamp: Date.now(),
              userGroup: userGroup
            });
            _context.next = 12;
            break;

          case 9:
            _context.prev = 9;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 12:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 9]]);
  }));

  return function createUserGroup(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var getUserGroups = exports.getUserGroups = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var limit, skip, userGroups, count;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            limit = req.query.limit || 50;
            skip = req.query.skip || 0;
            _context2.next = 5;
            return (0, _bluebird.resolve)(_userGroup.UserGroup.getUserGroups(limit, skip));

          case 5:
            userGroups = _context2.sent;
            _context2.next = 8;
            return (0, _bluebird.resolve)(_userGroup.UserGroup.getActiveGroupCount());

          case 8:
            count = _context2.sent;


            res.status(200).json({
              timestamp: Date.now(),
              userGroups: userGroups,
              count: count
            });
            _context2.next = 15;
            break;

          case 12:
            _context2.prev = 12;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 15:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 12]]);
  }));

  return function getUserGroups(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var updateUserGroupById = exports.updateUserGroupById = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var id, formBody, userGroup;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            id = req.params.id;
            formBody = req.body;
            _context3.next = 5;
            return (0, _bluebird.resolve)(_userGroup.UserGroup.updateUserGroupById(id, formBody));

          case 5:
            userGroup = _context3.sent;


            res.json({
              timestamp: Date.now(),
              userGroup: userGroup
            });
            _context3.next = 12;
            break;

          case 9:
            _context3.prev = 9;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 12:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 9]]);
  }));

  return function updateUserGroupById(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var remove = exports.remove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var id, userGroup;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            id = req.params.id;
            _context4.next = 4;
            return (0, _bluebird.resolve)(_userGroup.UserGroup.remove(id));

          case 4:
            userGroup = _context4.sent;


            res.json({
              timestamp: Date.now(),
              userGroup: userGroup
            });
            _context4.next = 11;
            break;

          case 8:
            _context4.prev = 8;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 11:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 8]]);
  }));

  return function remove(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var sendGroupNotification = exports.sendGroupNotification = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var formData, notifications;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            formData = {};


            formData.groupIds = req.body.groupIds;
            formData.title = req.body.title || 'প্রযত্ন';
            formData.body = req.body.body || 'প্রযত্নের সাথে থাকার জন্য ধন্যবাদ।';
            formData.token = req.body.token;
            formData.package_name = environment.firebase.appId;
            formData.priority = req.body.priority || 'high';
            formData.sound = req.body.sound || 'default';
            formData.time_to_live = req.body.time_to_live || 1;
            formData.deep_link = req.body.deep_link || '';

            _context5.next = 13;
            return (0, _bluebird.resolve)(_userGroup.UserGroup.sendGroupNotification(formData));

          case 13:
            notifications = _context5.sent;


            res.json({
              timestamp: Date.now(),
              notifications: notifications
            });
            _context5.next = 20;
            break;

          case 17:
            _context5.prev = 17;
            _context5.t0 = _context5['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 20:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 17]]);
  }));

  return function sendGroupNotification(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var _userGroup = require('./user-group.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../../config/environment');
//# sourceMappingURL=user-group.controller.js.map
