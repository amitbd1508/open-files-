'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _userGroup = require('./user-group.events');

var _userGroup2 = _interopRequireDefault(_userGroup);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  update(socket);
  remove(socket);
}

/**
 * Socket messages
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('eLearning:user:group:create', {
      timestamp: Date.now()
    });
  };

  _userGroup2.default.on('eLearning:user:group:create', listener);

  socket.on('disconnect', function () {
    _userGroup2.default.removeListener('eLearning:user:group:create', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('eLearning:user:group:update', {
      timestamp: Date.now()
    });
  };

  _userGroup2.default.on('eLearning:user:group:update', listener);

  socket.on('disconnect', function () {
    _userGroup2.default.removeListener('eLearning:user:group:update', listener);
  });
}

function remove(socket) {
  var listener = function listener() {
    socket.emit('eLearning:user:group:remove', {
      timestamp: Date.now()
    });
  };

  _userGroup2.default.on('eLearning:user:group:remove', listener);

  socket.on('disconnect', function () {
    _userGroup2.default.removeListener('eLearning:user:group:remove', listener);
  });
}
//# sourceMappingURL=user-group.socket.js.map
