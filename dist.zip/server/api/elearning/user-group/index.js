'use strict';

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Imports
 */
var express = require('express');
var controller = require('./user-group.controller');

var router = express.Router();
/**
 * Routes
 */

// Saves a newly created user group
router.post('/', auth.isAuthenticated(), controller.createUserGroup);

// Fetches the list of all user groups
router.get('/', auth.isAuthenticated(), controller.getUserGroups);

// Updates the user group by ID
router.put('/:id', auth.isAuthenticated(), controller.updateUserGroupById);

// Deletes the user group by ID
router.delete('/:id', auth.isAuthenticated(), controller.remove);

// Send push notification to user groups
router.post('/notifications', auth.isAuthenticated(), controller.sendGroupNotification);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
