'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UserGroup = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Functions
 */

/**
 *
 * @param formData
 * @param userID
 * @returns {Promise<*>}
 */
var createUserGroup = function () {
  var _ref = (0, _bluebird.method)(function (formData, userID) {
    var userGroup = new UserGroup();

    userGroup.name = formData.name;
    userGroup.service = formData.service;
    userGroup.createdBy = userID;

    _userGroup2.default.emit('eLearning:user:group:create');

    return userGroup.save();
  });

  return function createUserGroup(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 *
 * @param limit
 * @param skip
 * @returns {Promise<void>}
 */


var getUserGroups = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(limit, skip) {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(UserGroup.find().sort({
              isActive: -1,
              createdAt: -1
            }).limit(parseInt(limit)).skip(parseInt(skip)).lean().exec());

          case 2:
            return _context.abrupt('return', _context.sent);

          case 3:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function getUserGroups(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 *
 * @returns {Promise<*>}
 */


var getActiveGroupCount = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(UserGroup.count({
              isActive: true
            }));

          case 2:
            return _context2.abrupt('return', _context2.sent);

          case 3:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getActiveGroupCount() {
    return _ref3.apply(this, arguments);
  };
}();

/**
 *
 * @param groupId
 * @param formData
 * @returns {Promise<void>}
 */


var updateUserGroupById = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(groupId, formData) {
    var userGroup;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(this.findById(groupId).exec());

          case 2:
            userGroup = _context3.sent;

            if (userGroup) {
              _context3.next = 5;
              break;
            }

            throw new Error('Group not found');

          case 5:

            userGroup.name = formData.name;
            userGroup.service = formData.service;

            _context3.next = 9;
            return (0, _bluebird.resolve)(userGroup.save());

          case 9:

            _userGroup2.default.emit('eLearning:user:group:update');

            return _context3.abrupt('return', userGroup);

          case 11:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function updateUserGroupById(_x5, _x6) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 *
 * @param groupId
 * @returns {Promise<void>}
 */


var remove = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(groupId) {
    var userGroup;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.findById(groupId).exec());

          case 2:
            userGroup = _context4.sent;

            if (userGroup) {
              _context4.next = 5;
              break;
            }

            throw new Error('UserGroup not found');

          case 5:

            userGroup.isActive = false;

            _context4.next = 8;
            return (0, _bluebird.resolve)(userGroup.save());

          case 8:

            _userGroup2.default.emit('eLearning:user:group:remove');

            return _context4.abrupt('return', userGroup);

          case 10:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function remove(_x7) {
    return _ref5.apply(this, arguments);
  };
}();

var sendGroupNotification = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(formData) {
    var _this = this;

    var appTokens;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            if (formData.groupIds) {
              _context6.next = 2;
              break;
            }

            throw new Error('Group not found');

          case 2:
            _context6.next = 4;
            return (0, _bluebird.resolve)((0, _bluebird.all)(formData.groupIds.map(function () {
              var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(groupId) {
                return _regenerator2.default.wrap(function _callee5$(_context5) {
                  while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        _context5.next = 2;
                        return (0, _bluebird.resolve)(getUserAppTokensByGroupId(groupId, formData));

                      case 2:
                        return _context5.abrupt('return', _context5.sent);

                      case 3:
                      case 'end':
                        return _context5.stop();
                    }
                  }
                }, _callee5, _this);
              }));

              return function (_x9) {
                return _ref7.apply(this, arguments);
              };
            }())));

          case 4:
            appTokens = _context6.sent;


            appTokens = _lodash2.default.flatten(appTokens);
            appTokens = _lodash2.default.uniq(appTokens);

            _context6.next = 9;
            return (0, _bluebird.resolve)(sendAndSaveNotification(appTokens, formData));

          case 9:
            return _context6.abrupt('return', appTokens);

          case 10:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function sendGroupNotification(_x8) {
    return _ref6.apply(this, arguments);
  };
}();

var getUserAppTokensByGroupId = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(groupId) {
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _bluebird.resolve)(User.find({
              groupIds: {
                $in: [objectId(groupId)]
              }
            }).exec().filter(function (user) {
              return user.appToken;
            }).map(function (user) {
              return user.appToken;
            }));

          case 2:
            return _context7.abrupt('return', _context7.sent);

          case 3:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function getUserAppTokensByGroupId(_x10) {
    return _ref8.apply(this, arguments);
  };
}();

var sendAndSaveNotification = function () {
  var _ref9 = (0, _bluebird.method)(function (appTokens, formData) {
    var _this2 = this;

    appTokens.forEach(function () {
      var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(token) {
        var payload, notification;
        return _regenerator2.default.wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                payload = {
                  "to": token,
                  "ttl": formData.time_to_live,
                  "priority": formData.priority,
                  "restricted_package_name": formData.package_name,
                  "notification": {
                    "title": formData.title,
                    "body": formData.body,
                    "click_action": "FCM_PLUGIN_ACTIVITY",
                    "sound": formData.sound
                  },

                  "data": {
                    "title": formData.title,
                    "body": formData.body,
                    "deep_link": formData.deep_link
                  }
                };
                notification = new _firebaseAdmin.CloudNotification(payload);
                _context8.next = 4;
                return (0, _bluebird.resolve)(_firebaseAdmin.Firebase.FirebaseSendNotification(payload));

              case 4:
                notification.response = _context8.sent;
                _context8.next = 7;
                return (0, _bluebird.resolve)(notification.save());

              case 7:
                return _context8.abrupt('return', _context8.sent);

              case 8:
              case 'end':
                return _context8.stop();
            }
          }
        }, _callee8, _this2);
      }));

      return function (_x13) {
        return _ref10.apply(this, arguments);
      };
    }());
  });

  return function sendAndSaveNotification(_x11, _x12) {
    return _ref9.apply(this, arguments);
  };
}();

/**
 * Exports
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _userGroup = require('./user-group.events');

var _userGroup2 = _interopRequireDefault(_userGroup);

var _userGroup3 = require('../../../schemas/elearning/user-group.schema');

var _userGroup4 = _interopRequireDefault(_userGroup3);

var _user = require('../../../schemas/elearning/user.schema');

var _user2 = _interopRequireDefault(_user);

var _firebaseAdmin = require('../firebase-admin/firebase-admin.model');

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Schema
 */
_userGroup4.default.static('updateUserGroupById', updateUserGroupById).static('getActiveGroupCount', getActiveGroupCount).static('createUserGroup', createUserGroup).static('getUserGroups', getUserGroups).static('sendGroupNotification', sendGroupNotification).static('remove', remove);var UserGroup = exports.UserGroup = _mongoose2.default.model('UserGroup', _userGroup4.default, 'e_learning_user_groups');
var User = _mongoose2.default.model('ELearningUsers', _user2.default, 'e_learning_users');
//# sourceMappingURL=user-group.model.js.map
