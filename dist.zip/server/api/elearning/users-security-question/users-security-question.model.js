'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UsersSecurityQuestions = exports.Questions = exports.getUsersQuestionsCount = exports.disableSecurityQuestions = exports.getUsersQuestionsAndAnswers = exports.saveUsersQuestion = exports.userSecurityQuestions = exports.getSecurityQuestions = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var getSecurityQuestions = exports.getSecurityQuestions = function () {
  var _ref = (0, _bluebird.method)(function (limit, skip) {
    return this.find({
      isActive: true
    }).limit(parseInt(limit)).skip(parseInt(skip)).lean().exec();
  });

  return function getSecurityQuestions(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var userSecurityQuestions = exports.userSecurityQuestions = function () {
  var _ref2 = (0, _bluebird.method)(function (userId, formBody) {
    var _this = this;

    if ((0, _keys2.default)(formBody).length <= 0) throw new Error('Answer not found');

    (0, _keys2.default)(formBody).forEach(function () {
      var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(questionId) {
        return _regenerator2.default.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return (0, _bluebird.resolve)(saveUsersQuestion(userId, questionId, formBody[questionId]));

              case 2:
              case 'end':
                return _context.stop();
            }
          }
        }, _callee, _this);
      }));

      return function (_x5) {
        return _ref3.apply(this, arguments);
      };
    }());
  });

  return function userSecurityQuestions(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var saveUsersQuestion = exports.saveUsersQuestion = function () {
  var _ref4 = (0, _bluebird.method)(function (userId, questionId, answer) {
    var usersSecurityQuestion = new UsersSecurityQuestions();

    usersSecurityQuestion.userId = userId;
    usersSecurityQuestion.questionId = questionId;
    usersSecurityQuestion.answer = answer;
    usersSecurityQuestion.isActive = true;

    _usersSecurityQuestion2.default.emit('elearning:users:security:question:create');

    return usersSecurityQuestion.save();
  });

  return function saveUsersQuestion(_x6, _x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var getUsersQuestionsAndAnswers = exports.getUsersQuestionsAndAnswers = function () {
  var _ref5 = (0, _bluebird.method)(function (userId) {
    return this.find({
      userId: userId,
      isActive: true
    }).populate({
      path: 'questionId',
      select: 'question_bn'
    }).lean().exec();
  });

  return function getUsersQuestionsAndAnswers(_x9) {
    return _ref5.apply(this, arguments);
  };
}();

var disableSecurityQuestions = exports.disableSecurityQuestions = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(securityQuestionId) {
    var securityQuestion;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(UsersSecurityQuestions.findById(securityQuestionId).exec());

          case 2:
            securityQuestion = _context2.sent;

            if (securityQuestion) {
              _context2.next = 5;
              break;
            }

            throw new Error('securityQuestion Not found');

          case 5:

            securityQuestion.isActive = false;

            _context2.next = 8;
            return (0, _bluebird.resolve)(securityQuestion.save());

          case 8:

            _usersSecurityQuestion2.default.emit('elearning:users:security:question:remove');

            return _context2.abrupt('return', securityQuestion);

          case 10:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function disableSecurityQuestions(_x10) {
    return _ref6.apply(this, arguments);
  };
}();

var getUsersQuestionsCount = exports.getUsersQuestionsCount = function () {
  var _ref7 = (0, _bluebird.method)(function (userId) {
    return this.count({
      userId: userId,
      isActive: true
    }).exec();
  });

  return function getUsersQuestionsCount(_x11) {
    return _ref7.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _usersSecurityQuestion = require('./users-security-question.events');

var _usersSecurityQuestion2 = _interopRequireDefault(_usersSecurityQuestion);

var _securityQuestion = require('../../../schemas/elearning/security-question.schema');

var _securityQuestion2 = _interopRequireDefault(_securityQuestion);

var _usersSecurityQuestion3 = require('../../../schemas/elearning/users-security-question.schema');

var _usersSecurityQuestion4 = _interopRequireDefault(_usersSecurityQuestion3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_securityQuestion2.default.static('getSecurityQuestions', getSecurityQuestions);

_usersSecurityQuestion4.default.static('saveUsersQuestion', saveUsersQuestion).static('userSecurityQuestions', userSecurityQuestions).static('disableSecurityQuestions', disableSecurityQuestions).static('getUsersQuestionsAndAnswers', getUsersQuestionsAndAnswers).static('getUsersQuestionsCount', getUsersQuestionsCount);

var Questions = exports.Questions = _mongoose2.default.model('Questions', _securityQuestion2.default, 'e_learning_security_question');
var UsersSecurityQuestions = exports.UsersSecurityQuestions = _mongoose2.default.model('UsersSecurityQuestions', _usersSecurityQuestion4.default, 'e_learning_users_security_question');
//# sourceMappingURL=users-security-question.model.js.map
