'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var UsersSecurityQuestionEvents = new _events.EventEmitter();

/**
 * Options
 */
UsersSecurityQuestionEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = UsersSecurityQuestionEvents;
//# sourceMappingURL=users-security-question.events.js.map
