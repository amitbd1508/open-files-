'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _usersSecurityQuestion = require('./users-security-question.events');

var _usersSecurityQuestion2 = _interopRequireDefault(_usersSecurityQuestion);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  remove(socket);
}

/**
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('elearning:users:security:question:create', {
      timestamp: Date.now()
    });
  };

  _usersSecurityQuestion2.default.on('elearning:users:security:question:create', listener);

  socket.on('disconnect', function () {
    _usersSecurityQuestion2.default.removeListener('elearning:users:security:question:create', listener);
  });
}

function remove(socket) {
  var listener = function listener() {
    socket.emit('elearning:users:security:question:remove', {
      timestamp: Date.now()
    });
  };

  _usersSecurityQuestion2.default.on('elearning:users:security:question:remove', listener);

  socket.on('disconnect', function () {
    _usersSecurityQuestion2.default.removeListener('elearning:users:security:question:remove', listener);
  });
}
//# sourceMappingURL=users-security-question.socket.js.map
