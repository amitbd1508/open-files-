'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./users-security-question.controller');

var router = express.Router();

/**
 * Routes
 */

// Get all saved questions in array
router.get('/', controller.getSecurityQuestions);

// Disable user security question
router.delete('/:id', controller.disableSecurityQuestions);

// Save user's new question with answer
router.post('/users/:id', controller.saveUsersQuestion);

// Gets user's all questions and answers
router.get('/users/:id', controller.getUsersQuestionsAndAnswers);

// Gets the number of security questions of user
router.get('/users/:id/count', controller.getUsersQuestionsCount);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
