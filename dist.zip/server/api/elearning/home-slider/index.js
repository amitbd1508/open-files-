'use strict';

var _auth = require('../../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Imports
 */
var express = require('express');
var controller = require('./home-slider.controller');

var router = express.Router();

/**
 * Routes
 */

// Get all saved slider in array
router.get('/', controller.index);

// Save new slide with custom title and description and deepLink
router.post('/', auth.isAuthenticated(), controller.saveSlider);

// Save new slide with content type and with its id
router.post('/:contentType/:contentId', auth.isAuthenticated(), controller.saveSliderByContentId);

// Update slider by Id
router.put('/:id', auth.isAuthenticated(), controller.updateSlider);

// Delete slider by slider id
router.delete('/:id', auth.isAuthenticated(), controller.removeSlider);

// Upload Banner Image
router.post('/images', auth.isAuthenticated(), controller.bannerUploading, controller.bannerImageUpload);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
