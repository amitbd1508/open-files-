'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HomeSlider = exports.getSystemByCaseId = exports.getSystemByDiseaseId = exports.getDiseaseByLevelId = exports.getCaseByRugiId = exports.updateSliderById = exports.removeByContentTypeAndId = exports.removeSlider = exports.saveSlider = exports.saveSliderByContentId = exports.index = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(limit, skip) {
    var sliders;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.find().limit(parseInt(limit)).skip(parseInt(skip)).populate('rugiId levelId diseaseId caseId healthTipId').sort('order').lean().exec());

          case 2:
            sliders = _context.sent;
            _context.next = 5;
            return (0, _bluebird.resolve)(refineSliders(sliders));

          case 5:
            return _context.abrupt('return', _context.sent);

          case 6:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var refineSliders = function () {
  var _ref2 = (0, _bluebird.method)(function (sliders) {

    return sliders.map(function (content) {
      var filtered = {};
      filtered.order = content.order;
      filtered._id = content._id;
      filtered.deepLink = content.deepLink;
      if (!_lodash2.default.isEmpty(content.rugiId)) {

        filtered.content_type = 'rugi';
        filtered.content_id = content.rugiId._id;
        filtered.title = content.rugiId.title;
        filtered.title_bn = content.rugiId.title_bn;
        filtered.description = content.rugiId.description;
        filtered.description_bn = content.rugiId.description_bn;
        filtered.bannerUrl = content.rugiId.bannerUrl;
      } else if (!_lodash2.default.isEmpty(content.levelId)) {

        filtered.content_type = 'level';
        filtered.content_id = content.levelId._id;
        filtered.title = content.levelId.title;
        filtered.title_bn = content.levelId.title_bn;
        filtered.description = content.levelId.description;
        filtered.description_bn = content.levelId.description_bn;
        filtered.bannerUrl = content.levelId.bannerUrl;
      } else if (!_lodash2.default.isEmpty(content.diseaseId)) {

        filtered.content_type = 'disease';
        filtered.content_id = content.diseaseId._id;
        filtered.title = content.diseaseId.title;
        filtered.title_bn = content.diseaseId.title_bn;
        filtered.description = content.diseaseId.description;
        filtered.description_bn = content.diseaseId.description_bn;
        filtered.bannerUrl = content.diseaseId.bannerUrl;
      } else if (!_lodash2.default.isEmpty(content.caseId)) {

        filtered.content_type = 'caseItem';
        filtered.content_id = content.caseId._id;
        filtered.title = content.caseId.title;
        filtered.title_bn = content.caseId.title_bn;
        filtered.description = content.caseId.description;
        filtered.description_bn = content.caseId.description_bn;
        filtered.bannerUrl = content.caseId.bannerUrl;
      } else if (!_lodash2.default.isEmpty(content.healthTipId)) {

        filtered.content_type = 'health-tip';
        filtered.content_id = content.healthTipId._id;
        filtered.title = content.healthTipId.title;
        filtered.title_bn = content.healthTipId.title_bn;
        filtered.description = content.healthTipId.description;
        filtered.description_bn = content.healthTipId.description_bn;
        filtered.bannerUrl = content.healthTipId.bannerUrl;
      } else {
        filtered._id = content._id;
        filtered.title = content.title;
        filtered.title_bn = content.title_bn;
        filtered.description = content.description;
        filtered.description_bn = content.description_bn;
        filtered.bannerUrl = content.bannerUrl;
        filtered.deepLink = content.deepLink;
      }

      return filtered;
    });
  });

  return function refineSliders(_x3) {
    return _ref2.apply(this, arguments);
  };
}();

var saveSliderByContentId = exports.saveSliderByContentId = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(contentType, contentId, userId) {
    var slider, caseItem, system, disease, _system, _system2, _system3;

    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            slider = new HomeSlider();

            slider.userId = userId;

            if (!(contentType === 'rugi')) {
              _context2.next = 13;
              break;
            }

            _context2.next = 5;
            return (0, _bluebird.resolve)(getCaseByRugiId(contentId));

          case 5:
            caseItem = _context2.sent;
            _context2.next = 8;
            return (0, _bluebird.resolve)(getSystemByCaseId(caseItem._id));

          case 8:
            system = _context2.sent;

            slider.deepLink = _deepLinks2.default.forRugiPage(system._id, caseItem._id, contentId);
            slider.rugiId = contentId;

            _context2.next = 41;
            break;

          case 13:
            if (!(contentType === 'level')) {
              _context2.next = 24;
              break;
            }

            _context2.next = 16;
            return (0, _bluebird.resolve)(getDiseaseByLevelId(contentId));

          case 16:
            disease = _context2.sent;
            _context2.next = 19;
            return (0, _bluebird.resolve)(getSystemByDiseaseId(disease._id));

          case 19:
            _system = _context2.sent;

            slider.deepLink = _deepLinks2.default.forLevelPage(_system._id, disease._id, contentId);
            slider.levelId = contentId;

            _context2.next = 41;
            break;

          case 24:
            if (!(contentType === 'disease')) {
              _context2.next = 32;
              break;
            }

            _context2.next = 27;
            return (0, _bluebird.resolve)(getSystemByDiseaseId(contentId));

          case 27:
            _system2 = _context2.sent;

            slider.deepLink = _deepLinks2.default.forDiseasePage(_system2._id, contentId);
            slider.diseaseId = contentId;

            _context2.next = 41;
            break;

          case 32:
            if (!(contentType === 'case')) {
              _context2.next = 40;
              break;
            }

            _context2.next = 35;
            return (0, _bluebird.resolve)(getSystemByCaseId(contentId));

          case 35:
            _system3 = _context2.sent;

            slider.deepLink = _deepLinks2.default.forCasePage(_system3._id, contentId);
            slider.caseId = contentId;

            _context2.next = 41;
            break;

          case 40:
            if (contentType === 'healthTips') {
              slider.deepLink = _deepLinks2.default.forHealthTipPage(contentId);
              slider.healthTipId = contentId;
            }

          case 41:
            _homeSlider4.default.emit('home:slider:create');

            return _context2.abrupt('return', slider.save());

          case 43:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function saveSliderByContentId(_x4, _x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var saveSlider = exports.saveSlider = function () {
  var _ref4 = (0, _bluebird.method)(function (formData, userId) {
    var slider = new HomeSlider();
    slider.userId = userId;

    slider.order = formData.order;
    slider.title = formData.title;
    slider.title_bn = formData.title_bn;
    slider.description = formData.description;
    slider.description_bn = formData.description_bn;
    slider.deepLink = formData.deepLink;
    slider.bannerUrl = formData.bannerUrl;

    _homeSlider4.default.emit('home:slider:create');

    return slider.save();
  });

  return function saveSlider(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var removeSlider = exports.removeSlider = function () {
  var _ref5 = (0, _bluebird.method)(function (sliderId) {
    _homeSlider4.default.emit('home:slider:remove');

    return this.findByIdAndRemove(sliderId).exec();
  });

  return function removeSlider(_x9) {
    return _ref5.apply(this, arguments);
  };
}();

var removeByContentTypeAndId = exports.removeByContentTypeAndId = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(contentType, contentId) {
    var slider;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            slider = void 0;

            if (!(contentType === 'rugi')) {
              _context3.next = 7;
              break;
            }

            _context3.next = 4;
            return (0, _bluebird.resolve)(this.findOne({
              rugiId: contentId
            }).exec());

          case 4:
            slider = _context3.sent;
            _context3.next = 29;
            break;

          case 7:
            if (!(contentType === 'level')) {
              _context3.next = 13;
              break;
            }

            _context3.next = 10;
            return (0, _bluebird.resolve)(this.findOne({
              levelId: contentId
            }).exec());

          case 10:
            slider = _context3.sent;
            _context3.next = 29;
            break;

          case 13:
            if (!(contentType === 'disease')) {
              _context3.next = 19;
              break;
            }

            _context3.next = 16;
            return (0, _bluebird.resolve)(this.findOne({
              diseaseId: contentId
            }).exec());

          case 16:
            slider = _context3.sent;
            _context3.next = 29;
            break;

          case 19:
            if (!(contentType === 'case')) {
              _context3.next = 25;
              break;
            }

            _context3.next = 22;
            return (0, _bluebird.resolve)(this.findOne({
              caseId: contentId
            }).exec());

          case 22:
            slider = _context3.sent;
            _context3.next = 29;
            break;

          case 25:
            if (!(contentType === 'healthTips')) {
              _context3.next = 29;
              break;
            }

            _context3.next = 28;
            return (0, _bluebird.resolve)(this.findOne({
              healthTipId: contentId
            }).exec());

          case 28:
            slider = _context3.sent;

          case 29:

            _homeSlider4.default.emit('home:slider:remove');

            _context3.next = 32;
            return (0, _bluebird.resolve)(this.findByIdAndRemove(slider._id).exec());

          case 32:
            return _context3.abrupt('return', _context3.sent);

          case 33:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function removeByContentTypeAndId(_x10, _x11) {
    return _ref6.apply(this, arguments);
  };
}();

var updateSliderById = exports.updateSliderById = function () {
  var _ref7 = (0, _bluebird.method)(function (sliderId, formBody) {
    _homeSlider4.default.emit('home:slider:update');

    return this.findByIdAndUpdate(sliderId, { order: formBody.order }).exec();
  });

  return function updateSliderById(_x12, _x13) {
    return _ref7.apply(this, arguments);
  };
}();

var getCaseByRugiId = exports.getCaseByRugiId = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(rugiId) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Case.findOne({
              rugies: {
                "$elemMatch": {
                  "$in": [objectId(rugiId)]
                }
              }
            }).lean().exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function getCaseByRugiId(_x14) {
    return _ref8.apply(this, arguments);
  };
}();

var getDiseaseByLevelId = exports.getDiseaseByLevelId = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(levelId) {
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(Disease.findOne({
              levels: {
                "$elemMatch": {
                  "$in": [objectId(levelId)]
                }
              }
            }).lean().exec());

          case 2:
            return _context5.abrupt('return', _context5.sent);

          case 3:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function getDiseaseByLevelId(_x15) {
    return _ref9.apply(this, arguments);
  };
}();

var getSystemByDiseaseId = exports.getSystemByDiseaseId = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(diseaseId) {
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(System.findOne({
              diseases: {
                "$elemMatch": {
                  "$in": [objectId(diseaseId)]
                }
              }
            }).lean().exec());

          case 2:
            return _context6.abrupt('return', _context6.sent);

          case 3:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function getSystemByDiseaseId(_x16) {
    return _ref10.apply(this, arguments);
  };
}();

var getSystemByCaseId = exports.getSystemByCaseId = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(caseId) {
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _bluebird.resolve)(System.findOne({
              cases: {
                "$elemMatch": {
                  "$in": [objectId(caseId)]
                }
              }
            }).lean().exec());

          case 2:
            return _context7.abrupt('return', _context7.sent);

          case 3:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function getSystemByCaseId(_x17) {
    return _ref11.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _deepLinks = require('../deepLinks/deepLinks');

var _deepLinks2 = _interopRequireDefault(_deepLinks);

var _homeSlider = require('../../../schemas/elearning/home-slider.schema');

var _homeSlider2 = _interopRequireDefault(_homeSlider);

var _case = require('../../../schemas/elearning/case.schema');

var _case2 = _interopRequireDefault(_case);

var _system4 = require('../../../schemas/elearning/system.schema');

var _system5 = _interopRequireDefault(_system4);

var _homeSlider3 = require('./home-slider.events');

var _homeSlider4 = _interopRequireDefault(_homeSlider3);

var _diseases = require('../../../schemas/elearning/diseases.schema');

var _diseases2 = _interopRequireDefault(_diseases);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Statics
 */
_homeSlider2.default.static('index', index).static('saveSlider', saveSlider).static('removeSlider', removeSlider).static('updateSliderById', updateSliderById).static('saveSliderByContentId', saveSliderByContentId).static('removeByContentTypeAndId', removeByContentTypeAndId);

var HomeSlider = exports.HomeSlider = _mongoose2.default.model('SliderSchema', _homeSlider2.default, 'e_learning_home_slider');
var Case = _mongoose2.default.model('CaseSchema', _case2.default, 'e_learning_cases');
var Disease = _mongoose2.default.model('DiseaseSchema', _diseases2.default, 'e_learning_diseases');
var System = _mongoose2.default.model('SystemSchema', _system5.default, 'e_learning_systems');
//# sourceMappingURL=home-slider.model.js.map
