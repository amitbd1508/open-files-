'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _homeSlider = require('./home-slider.events');

var _homeSlider2 = _interopRequireDefault(_homeSlider);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
  remove(socket);
  update(socket);
}

/**
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('home:slider:create', {
      timestamp: Date.now()
    });
  };

  _homeSlider2.default.on('home:slider:create', listener);

  socket.on('disconnect', function () {
    _homeSlider2.default.removeListener('home:slider:create', listener);
  });
}

function remove(socket) {
  var listener = function listener() {
    socket.emit('home:slider:remove', {
      timestamp: Date.now()
    });
  };

  _homeSlider2.default.on('home:slider:remove', listener);

  socket.on('disconnect', function () {
    _homeSlider2.default.removeListener('home:slider:remove', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('home:slider:update', {
      timestamp: Date.now()
    });
  };

  _homeSlider2.default.on('home:slider:update', listener);

  socket.on('disconnect', function () {
    _homeSlider2.default.removeListener('home:slider:update', listener);
  });
}
//# sourceMappingURL=home-slider.socket.js.map
