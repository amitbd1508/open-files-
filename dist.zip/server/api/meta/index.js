'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./meta.controller');
var router = express.Router();

/**
 * Routes
 */
router.get('/patients/source', controller.getPatientSource);
router.get('/patients/histogram', controller.getPatientHistogram);
router.get('/patients/servedPerCenter', controller.getAveragePrescriptionServedPerCenter);
router.get('/patients/organicFlow', controller.getOrganicPatientFlow);
router.get('/patients/organicFlow/:rmpId', controller.getOrganicPatientFlowByRMP);
router.get('/patients/cumulativeFlow', controller.getCumulativeFlow);
router.get('/patients/cumulativeFlow/:rmpId', controller.getCumulativeFlowByRMP);
router.get('/consultation/:doctorId', controller.consultaionTimeByDoctor);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
