'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.consultaionTimeByDoctor = consultaionTimeByDoctor;
exports.getPatientSource = getPatientSource;
exports.getPatientHistogram = getPatientHistogram;
exports.getAveragePrescriptionServedPerCenter = getAveragePrescriptionServedPerCenter;
exports.getOrganicPatientFlow = getOrganicPatientFlow;
exports.getOrganicPatientFlowByRMP = getOrganicPatientFlowByRMP;
exports.getCumulativeFlow = getCumulativeFlow;
exports.getCumulativeFlowByRMP = getCumulativeFlowByRMP;

var _meta = require('./meta.model');

var Meta = _interopRequireWildcard(_meta);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Actions
 */
function consultaionTimeByDoctor(req, res) {
  var from = req.query.from ? (0, _momentTimezone2.default)(req.query.from).toDate() : (0, _momentTimezone2.default)().startOf('day').toDate();
  var to = req.query.to ? (0, _momentTimezone2.default)(req.query.to).toDate() : (0, _momentTimezone2.default)().endOf('day').toDate();
  var doctorId = req.params.doctorId ? req.params.doctorId : req.user._id;
  Meta.consultaionTimeByDoctor(from, to, doctorId).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}

function getPatientSource(req, res) {
  var fromMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate) : (0, _momentTimezone2.default)().startOf('month');
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');

  Meta.getPatientSource(fromMoment, toMoment).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}

function getPatientHistogram(req, res) {
  var fromMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate) : (0, _momentTimezone2.default)().startOf('month');
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');
  Meta.getPatientHistogram(fromMoment, toMoment).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}

function getAveragePrescriptionServedPerCenter(req, res) {
  var fromMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate) : (0, _momentTimezone2.default)().startOf('month');
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');
  Meta.getAveragePrescriptionServedPerCenter(fromMoment, toMoment).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}

function getOrganicPatientFlow(req, res) {
  var fromMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate) : (0, _momentTimezone2.default)().startOf('month');
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');
  Meta.getOrganicPatientFlow(fromMoment, toMoment).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}

function getOrganicPatientFlowByRMP(req, res) {
  var fromMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate) : (0, _momentTimezone2.default)().startOf('month');
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');
  var rmpId = req.params.rmpId;
  Meta.getOrganicPatientFlowByRMP(fromMoment, toMoment, rmpId).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}

function getCumulativeFlow(req, res) {
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');
  Meta.getCumulativeFlow(toMoment).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}

function getCumulativeFlowByRMP(req, res) {
  var toMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');
  var rmpId = req.params.rmpId;
  Meta.getCumulativeFlowByRMP(toMoment, rmpId).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      reports: reports
    });
  });
}
//# sourceMappingURL=meta.controller.js.map
