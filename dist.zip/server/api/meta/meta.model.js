'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.consultaionTimeByDoctor = consultaionTimeByDoctor;
exports.getPatientSource = getPatientSource;
exports.getPatientHistogram = getPatientHistogram;
exports.getAveragePrescriptionServedPerCenter = getAveragePrescriptionServedPerCenter;
exports.getOrganicPatientFlow = getOrganicPatientFlow;
exports.getCumulativeFlow = getCumulativeFlow;
exports.getCumulativeFlowByRMP = getCumulativeFlowByRMP;
exports.getOrganicPatientFlowByRMP = getOrganicPatientFlowByRMP;

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _patient = require('../../schemas/patient.schema');

var _patient2 = _interopRequireDefault(_patient);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/*
** Models
*/
var Patient = _mongoose2.default.model('MetaPatient', _patient2.default, 'patients');
var Prescription = _mongoose2.default.model('MetaPrescription', _prescription2.default, 'prescriptions');

function consultaionTimeByDoctor(from, to, doctorId) {
  return getConsultaionTime(from, to, doctorId);
}
function getPatientSource(fromMoment, toMoment) {
  var fMoment = fromMoment.clone();
  var tMoment = toMoment.clone();
  return patientSource(fMoment, tMoment);
}

function getPatientHistogram(fromMoment, toMoment) {
  var fMoment = fromMoment.clone();
  var tMoment = toMoment.clone();
  return patientHistogram(fMoment, tMoment);
}

function getAveragePrescriptionServedPerCenter(fromMoment, toMoment) {
  var fMoment = fromMoment.clone();
  var tMoment = toMoment.clone();
  return averagePrescriptionServedPerCenter(fMoment, tMoment);
}

function getOrganicPatientFlow(fromMoment, toMoment) {
  var fMoment = fromMoment.clone();
  var tMoment = toMoment.clone();
  return organicPatientFlow(fMoment, tMoment);
}

function getCumulativeFlow(toMoment) {
  var tMoment = toMoment.clone();
  return cumulativeFlow(tMoment);
}

function getCumulativeFlowByRMP(toMoment, rmpId) {
  var tMoment = toMoment.clone();
  return cumulativeFlowByRMP(tMoment, rmpId);
}

function getOrganicPatientFlowByRMP(fromMoment, toMoment, rmpId) {
  var fMoment = fromMoment.clone();
  var tMoment = toMoment.clone();
  return organicPatientFlowByRMP(fMoment, tMoment, rmpId);
}

function getConsultaionTime(from, to, doctorId) {
  return Prescription.aggregate([{
    $match: {
      doctors_id: objectId(doctorId),
      is_pdfready: true,
      opened: { $gte: from, $lt: to }
    }
  }, {
    $group: {
      _id: {
        hour: { $hour: "$publishAt" }
      },
      total: { $sum: 1 }
    }
  }]);
}

function patientSource(fromMoment, toMoment) {
  return Patient.aggregate([{
    $match: {
      registered_at: { $gt: fromMoment.toDate(), $lte: toMoment.toDate() },
      reference: { $exists: true }
    }
  }, {
    $project: {
      reference: 1
    }
  }, {
    $group: {
      _id: '$reference',
      count: { $sum: 1 }
    }
  }]);
}

function patientHistogram(fromMoment, toMoment) {
  return Prescription.aggregate([{
    $match: {
      is_followup: false,
      is_referred: false,
      is_pdfready: true,
      created_at: { $gt: fromMoment.toDate(), $lte: toMoment.toDate() }
    }
  }, {
    $group: {
      _id: '$patients_id',
      count: { $sum: 1 }
    }
  }, {
    $group: {
      _id: '$count',
      numberOfPatients: { $sum: 1 }
    }
  }, {
    $sort: {
      _id: 1
    }
  }]);
}

function averagePrescriptionServedPerCenter(fromMoment, toMoment) {
  return Prescription.aggregate([{
    $match: {
      is_pdfready: true,
      created_at: { $gt: fromMoment.toDate(), $lte: toMoment.toDate() }
    }
  }, {
    $lookup: {
      from: 'users',
      localField: 'rmp_id',
      foreignField: '_id',
      as: 'theRMP'
    }
  }, {
    $unwind: {
      path: '$theRMP'
    }
  }, {
    $project: {
      center: '$theRMP.center',
      created_at: 1
    }
  }, {
    $group: {
      _id: {
        year: { $year: '$created_at' },
        month: { $month: '$created_at' },
        day: { $dayOfMonth: '$created_at' }
      },
      numberOfPrescriptionOnTheDay: { $sum: 1 },
      centers: { $push: '$center' }
    }
  }, {
    $group: {
      _id: {
        year: '$_id.year',
        month: '$_id.month'
      },
      totalPrescriptionInMonth: { $sum: '$numberOfPrescriptionOnTheDay' },
      totalActiveDays: { $sum: 1 },
      centers: { $addToSet: '$centers' }
    }
  }, {
    $sort: {
      _id: 1
    }
  }]);
}

function organicPatientFlow(fromMoment, toMoment) {
  return Prescription.aggregate([{
    $match: {
      is_pdfready: true
    }
  }, {
    $lookup: {
      from: 'patients',
      localField: 'patients_id',
      foreignField: '_id',
      as: 'thePatient'
    }
  }, {
    $unwind: {
      path: '$thePatient'
    }
  }, {
    $project: {
      'thePatient._id': 1,
      'thePatient.reference': 1,
      isOrganic: { $cond: { if: { $eq: ['$thePatient.reference', 'প্রতিবেশি'] }, then: 1, else: { $cond: { if: { $eq: ['$thePatient.reference', 'পরিবারের সদস্য'] }, then: 1, else: 0 } } } },
      'thePatient.registered_at': 1
    }
  }, {
    $match: {
      'thePatient.registered_at': { $gt: fromMoment.toDate(), $lte: toMoment.toDate() }
    }
  }, {
    $group: {
      _id: {
        year: { $year: '$thePatient.registered_at' },
        month: { $month: '$thePatient.registered_at' },
        week: { $week: '$thePatient.registered_at' }
      },
      numberOfTotalPatientsOnTheWeek: { $sum: 1 },
      numberOrganicPatientsOnTheWeek: { $sum: '$isOrganic' }
    }
  }, {
    $sort: {
      '_id.year': 1,
      '_id.week': 1
    }
  }]);
}

function organicPatientFlowByRMP(fromMoment, toMoment, rmpId) {
  return Prescription.aggregate([{
    $match: {
      is_pdfready: true,
      rmp_id: objectId(rmpId)
    }
  }, {
    $lookup: {
      from: 'patients',
      localField: 'patients_id',
      foreignField: '_id',
      as: 'thePatient'
    }
  }, {
    $unwind: {
      path: '$thePatient'
    }
  }, {
    $project: {
      'thePatient._id': 1,
      'thePatient.reference': 1,
      isOrganic: { $cond: { if: { $eq: ['$thePatient.reference', 'প্রতিবেশি'] }, then: 1, else: { $cond: { if: { $eq: ['$thePatient.reference', 'পরিবারের সদস্য'] }, then: 1, else: 0 } } } },
      'thePatient.registered_at': 1
    }
  }, {
    $match: {
      'thePatient.registered_at': { $gt: fromMoment.toDate(), $lte: toMoment.toDate() }
    }
  }, {
    $group: {
      _id: {
        year: { $year: '$thePatient.registered_at' },
        month: { $month: '$thePatient.registered_at' },
        week: { $week: '$thePatient.registered_at' }
      },
      numberOfTotalPatientsOnTheWeek: { $sum: 1 },
      numberOrganicPatientsOnTheWeek: { $sum: '$isOrganic' }
    }
  }, {
    $sort: {
      '_id.year': 1,
      '_id.week': 1
    }
  }]);
}

function cumulativeFlow(toMoment) {
  return Prescription.aggregate([{
    $match: {
      is_pdfready: true
    }
  }, {
    $lookup: {
      from: 'patients',
      localField: 'patients_id',
      foreignField: '_id',
      as: 'thePatient'
    }
  }, {
    $unwind: {
      path: '$thePatient'
    }
  }, {
    $project: {
      'thePatient._id': 1,
      'thePatient.reference': 1,
      isOrganic: { $cond: { if: { $eq: ['$thePatient.reference', 'প্রতিবেশি'] }, then: 1, else: { $cond: { if: { $eq: ['$thePatient.reference', 'পরিবারের সদস্য'] }, then: 1, else: 0 } } } },
      'thePatient.registered_at': 1,
      created_at: 1
    }
  }, {
    $match: {
      'thePatient.registered_at': { $lte: toMoment.toDate() }
    }
  }, {
    $group: {
      _id: {
        year: { $year: '$created_at' },
        month: { $month: '$created_at' },
        week: { $week: '$created_at' }
      },
      numberOfTotalPatientsOnTheWeek: { $sum: 1 },
      numberOrganicPatientsOnTheWeek: { $sum: '$isOrganic' }
    }
  }, {
    $group: {
      _id: null,
      numberOfTotalPatients: { $sum: '$numberOfTotalPatientsOnTheWeek' },
      numberOrganicPatients: { $sum: '$numberOrganicPatientsOnTheWeek' }
    }
  }]);
}

function cumulativeFlowByRMP(toMoment, rmpId) {
  return Prescription.aggregate([{
    $match: {
      is_pdfready: true,
      rmp_id: objectId(rmpId)
    }
  }, {
    $lookup: {
      from: 'patients',
      localField: 'patients_id',
      foreignField: '_id',
      as: 'thePatient'
    }
  }, {
    $unwind: {
      path: '$thePatient'
    }
  }, {
    $project: {
      'thePatient._id': 1,
      'thePatient.reference': 1,
      isOrganic: { $cond: { if: { $eq: ['$thePatient.reference', 'প্রতিবেশি'] }, then: 1, else: { $cond: { if: { $eq: ['$thePatient.reference', 'পরিবারের সদস্য'] }, then: 1, else: 0 } } } },
      'thePatient.registered_at': 1,
      created_at: 1
    }
  }, {
    $match: {
      'thePatient.registered_at': { $lte: toMoment.toDate() }
    }
  }, {
    $group: {
      _id: {
        year: { $year: '$created_at' },
        month: { $month: '$created_at' },
        week: { $week: '$created_at' }
      },
      numberOfTotalPatientsOnTheWeek: { $sum: 1 },
      numberOrganicPatientsOnTheWeek: { $sum: '$isOrganic' }
    }
  }, {
    $group: {
      _id: null,
      numberOfTotalPatients: { $sum: '$numberOfTotalPatientsOnTheWeek' },
      numberOrganicPatients: { $sum: '$numberOrganicPatientsOnTheWeek' }
    }
  }]);
}
//# sourceMappingURL=meta.model.js.map
