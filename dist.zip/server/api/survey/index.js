'use strict';

/**
 * Imports
 */

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./survey.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/stats/users', controller.stats);
router.get('/:surveyType', controller.list);

router.post('/:surveyType/:prescriptionId/start', auth.isAuthenticated(), controller.start);
router.post('/:surveyType/:prescriptionId/in-progress', auth.isAuthenticated(), controller.inProgress);
router.post('/:surveyType/:prescriptionId/cancel', auth.isAuthenticated(), controller.cancel);
router.post('/:surveyType/:prescriptionId/submit', controller.submit);

router.get('/PPRO/:doctorId', auth.isAuthenticated(), controller.PPROByDoctorId);
router.get('/PPROByDiagnoses/diagnoses', auth.hasUserType(['admin', 'cca']), controller.PPROByDiagnoses);
router.get('/PPROByAppointments/appointments', auth.hasUserType(['admin', 'cca']), controller.PPROByAppointments);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
