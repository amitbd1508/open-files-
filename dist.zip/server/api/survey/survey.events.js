'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var SurveyEvents = new _events.EventEmitter();

/**
 * Options
 */
SurveyEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = SurveyEvents;
//# sourceMappingURL=survey.events.js.map
