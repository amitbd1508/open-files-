'use strict';

/* eslint-disable no-unused-vars, no-undef */

// add a trigger in app script to call onSubmit function on form submit
function onSubmit(e) {
  var prescriptionId = e.response.getItemResponses()[1].getResponse();

  var surveyType = 'pss';
  var url = 'http://projotno-dashboard-demo.herokuapp.com/api/survey/' + surveyType + '/' + prescriptionId + '/submit';

  UrlFetchApp.fetch(url, { method: 'POST' });
}
//# sourceMappingURL=appScript.js.map
