'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _survey = require('./survey.events');

var _survey2 = _interopRequireDefault(_survey);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  start(socket);
  cancel(socket);
  submit(socket);
}

/**
 * Socket Messages
 */

/**
 * Start Survey Message
 *
 * @param socket
 */
function start(socket) {
  var listener = function listener(survey) {
    socket.emit('survey:start', {
      timestamp: Date.now(),
      survey: survey
    });
  };

  _survey2.default.on('survey:start', listener);

  socket.on('disconnect', function () {
    _survey2.default.removeListener('survey:start', listener);
  });
}

/**
 * Cancel Survey Message
 *
 * @param socket
 */
function cancel(socket) {
  var listener = function listener(survey) {
    socket.emit('survey:cancel', {
      timestamp: Date.now(),
      survey: survey
    });
  };

  _survey2.default.on('survey:cancel', listener);

  socket.on('disconnect', function () {
    _survey2.default.removeListener('survey:cancel', listener);
  });
}

/**
 * Submit Survey Message
 *
 * @param socket
 */
function submit(socket) {
  var listener = function listener(survey) {
    socket.emit('survey:submit', {
      timestamp: Date.now(),
      survey: survey
    });
  };

  _survey2.default.on('survey:submit', listener);

  socket.on('disconnect', function () {
    _survey2.default.removeListener('survey:submit', listener);
  });
}
//# sourceMappingURL=survey.socket.js.map
