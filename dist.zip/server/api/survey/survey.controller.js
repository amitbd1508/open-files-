'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.stats = exports.PPROByAppointments = exports.PPROByDiagnoses = exports.PPROByDoctorId = exports.submit = exports.cancel = exports.inProgress = exports.start = exports.list = undefined;

var _bluebird = require('bluebird');

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _slicedToArray2 = require('babel-runtime/helpers/slicedToArray');

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _entries = require('babel-runtime/core-js/object/entries');

var _entries2 = _interopRequireDefault(_entries);

var _getIterator2 = require('babel-runtime/core-js/get-iterator');

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _set = require('babel-runtime/core-js/set');

var _set2 = _interopRequireDefault(_set);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var list = exports.list = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var surveyType, startDiff, endDiff, startDate, endDate, doctorIds, rmpIds, sheetIds, surveys, pssSheetIds;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            surveyType = req.params.surveyType;
            startDiff = void 0;
            endDiff = void 0;
            _context.t0 = surveyType;
            _context.next = _context.t0 === 'pss' ? 6 : _context.t0 === 'pos' ? 9 : _context.t0 === 'rps' ? 12 : _context.t0 === 'fps' ? 12 : 15;
            break;

          case 6:
            startDiff = 4;
            endDiff = 1;
            return _context.abrupt('break', 15);

          case 9:
            startDiff = 14;
            endDiff = 11;
            return _context.abrupt('break', 15);

          case 12:
            startDiff = 10;
            endDiff = 7;
            return _context.abrupt('break', 15);

          case 15:
            startDate = (0, _momentTimezone2.default)(req.query.startDate).startOf('day').subtract(startDiff, 'days').toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).startOf('day').subtract(endDiff, 'days').toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            _context.next = 21;
            return (0, _bluebird.resolve)(listOfIdsFromSheet(surveyType));

          case 21:
            sheetIds = _context.sent;
            _context.prev = 22;
            _context.next = 25;
            return (0, _bluebird.resolve)(_prescription.Prescription.findSurveyList(startDate, endDate, surveyType, doctorIds, rmpIds).filter(function (p) {
              return !sheetIds.has(p._id.toString());
            }).filter(function (p) {
              return !(p._id.toString() in surveysInProgress[surveyType]);
            }));

          case 25:
            surveys = _context.sent;

            if (!(surveyType === 'pos')) {
              _context.next = 31;
              break;
            }

            _context.next = 29;
            return (0, _bluebird.resolve)(listOfIdsFromSheet('pss'));

          case 29:
            pssSheetIds = _context.sent;

            surveys = surveys.filter(function (p) {
              return pssSheetIds.has(p._id.toString());
            });

          case 31:

            res.json({
              timestamp: Date.now(),
              startDate: startDate,
              endDate: endDate,
              surveyType: surveyType,
              surveys: surveys
            });
            _context.next = 37;
            break;

          case 34:
            _context.prev = 34;
            _context.t1 = _context['catch'](22);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t1
            });

          case 37:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[22, 34]]);
  }));

  return function list(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var start = exports.start = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var surveyType, prescriptionId, userName, prescription, patientGender, patientAge, formUrl;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            surveyType = req.params.surveyType;
            prescriptionId = req.params.prescriptionId;
            userName = req.user.name;

            if (!(['pss', 'pos', 'rps', 'fps'].indexOf(surveyType) < 0)) {
              _context2.next = 5;
              break;
            }

            return _context2.abrupt('return', res.status('400').end());

          case 5:
            if (prescriptionId) {
              _context2.next = 7;
              break;
            }

            return _context2.abrupt('return', res.status('400').end());

          case 7:
            if (!(prescriptionId in surveysInProgress[surveyType])) {
              _context2.next = 9;
              break;
            }

            return _context2.abrupt('return', res.status('404').end());

          case 9:

            surveysInProgress[surveyType][prescriptionId] = Date.now();

            _survey2.default.emit('survey:start', {
              surveyType: surveyType,
              prescriptionId: prescriptionId
            });

            _context2.next = 13;
            return (0, _bluebird.resolve)(_prescription.Prescription.findByIdForPdf(prescriptionId));

          case 13:
            prescription = _context2.sent;

            if (prescription) {
              _context2.next = 16;
              break;
            }

            return _context2.abrupt('return', res.status('404').end());

          case 16:
            patientGender = '';

            if (prescription.patients_id.gender) patientGender = prescription.patients_id.gender === 'male' ? 'পুরুষ' : 'মহিলা';

            patientAge = '';

            if (prescription.patients_id.dob) patientAge = (0, _momentTimezone2.default)().diff(prescription.patients_id.dob, 'years');

            formUrl = formUrlTemplates[surveyType].replace('$PRE_NAME$', userName).replace('$PRESCRIPTION_ID$', prescription._id || '').replace('$PORIJON_PHONE$', prescription.patients_id.phone || '').replace('$PORIJON_NAME$', prescription.patients_id.fullname || '').replace('$PORIJON_SEX$', patientGender).replace('$PORIJON_AGE$', patientAge).replace('$SB_NAME$', prescription.rmp_id.fullname || '').replace('$DOCTOR_NAME$', prescription.doctors_id.fullname || '');


            res.json({
              timestamp: Date.now(),
              survey: {
                surveyType: surveyType,
                prescriptionId: prescriptionId
              },
              formUrl: formUrl
            });

          case 22:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function start(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var inProgress = exports.inProgress = function () {
  var _ref3 = (0, _bluebird.method)(function (req, res) {
    var surveyType = req.params.surveyType;
    var prescriptionId = req.params.prescriptionId;

    if (['pss', 'pos', 'rps', 'fps'].indexOf(surveyType) < 0) return res.status('400').end();
    if (!prescriptionId) return res.status('400').end();

    if (!(prescriptionId in surveysInProgress[surveyType])) return res.status('404').end();

    surveysInProgress[surveyType][prescriptionId] = Date.now();

    _survey2.default.emit('survey:start', {
      surveyType: surveyType,
      prescriptionId: prescriptionId
    });

    res.status(200).end();
  });

  return function inProgress(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var cancel = exports.cancel = function () {
  var _ref4 = (0, _bluebird.method)(function (req, res) {
    var surveyType = req.params.surveyType;
    var prescriptionId = req.params.prescriptionId;

    if (['pss', 'pos', 'rps', 'fps'].indexOf(surveyType) < 0) return res.status('400').end();
    if (!prescriptionId) return res.status('400').end();

    if (!(prescriptionId in surveysInProgress[surveyType])) return res.status('404').end();

    delete surveysInProgress[surveyType][prescriptionId];

    _survey2.default.emit('survey:cancel', {
      surveyType: surveyType,
      prescriptionId: prescriptionId
    });

    res.status(200).end();
  });

  return function cancel(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var submit = exports.submit = function () {
  var _ref5 = (0, _bluebird.method)(function (req, res) {
    var surveyType = req.params.surveyType;
    var prescriptionId = req.params.prescriptionId;

    if (['pss', 'pos', 'rps', 'fps'].indexOf(surveyType) < 0) return res.status('400').end();
    if (!prescriptionId) return res.status('400').end();

    if (!(prescriptionId in surveysInProgress[surveyType])) return res.status('404').end();

    delete surveysInProgress[surveyType][prescriptionId];

    _survey2.default.emit('survey:submit', {
      surveyType: surveyType,
      prescriptionId: prescriptionId
    });

    res.status(200).end();
  });

  return function submit(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var PPROByDoctorId = exports.PPROByDoctorId = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var surveyType, range, doctorId, startDate, endDate, surveys, countPrescriptions, conditions, pssSheetIds, prescriptions;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            surveyType = 'pos';
            range = 'C:J';
            doctorId = req.params.doctorId === 'undefined' ? req.user._id : req.params.doctorId;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            _context3.prev = 5;
            _context3.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findSurveyList(startDate, endDate, surveyType, doctorId));

          case 8:
            surveys = _context3.sent;
            countPrescriptions = surveys.length;
            _context3.next = 12;
            return (0, _bluebird.resolve)(listOfConditionsFromSheet(surveyType, range));

          case 12:
            conditions = _context3.sent;
            _context3.next = 15;
            return (0, _bluebird.resolve)(listOfIdsFromSheet('pos'));

          case 15:
            pssSheetIds = _context3.sent;

            surveys = surveys.filter(function (p) {
              return pssSheetIds.has(p._id.toString());
            });

            prescriptions = surveys.map(function (prescription) {
              return {
                prescription: prescription,
                condition: conditions[7][conditions[0].indexOf(prescription._id.toString())]
              };
            });


            res.json({
              timestamp: Date.now(),
              startDate: startDate,
              endDate: endDate,
              prescriptions: prescriptions,
              conditions: conditions[7].slice(1),
              surveyed: prescriptions.length,
              countPrescriptions: countPrescriptions
            });
            _context3.next = 24;
            break;

          case 21:
            _context3.prev = 21;
            _context3.t0 = _context3['catch'](5);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0
            });

          case 24:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[5, 21]]);
  }));

  return function PPROByDoctorId(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var PPROByDiagnoses = exports.PPROByDiagnoses = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var startDate, endDate, diagnosisIds, doctorIds, rmpIds, surveyType, range, countPrescriptionByMonths, surveys, countPrescriptions, countPrescription, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, _step$value, key, value, conditions, pssSheetIds, prescriptions, uniqueConditions;

    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            diagnosisIds = req.query.diagnosisIds || '';
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            surveyType = 'pos';
            range = 'C:J';
            countPrescriptionByMonths = [];
            _context4.prev = 8;

            diagnosisIds = _lodash2.default.isArray(diagnosisIds) ? diagnosisIds : [diagnosisIds];

            _context4.next = 12;
            return (0, _bluebird.resolve)(_prescription.Prescription.findSurveyListForPPRO(startDate, endDate, surveyType, doctorIds, rmpIds));

          case 12:
            surveys = _context4.sent;
            countPrescriptions = surveys.length;


            surveys.map(function (prescription) {
              prescription.months = (0, _momentTimezone2.default)(prescription.publishAt).get('months');
              return prescription;
            });

            countPrescription = _lodash2.default.groupBy(surveys, 'months');
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            _context4.prev = 19;


            for (_iterator = (0, _getIterator3.default)((0, _entries2.default)(countPrescription)); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              _step$value = (0, _slicedToArray3.default)(_step.value, 2), key = _step$value[0], value = _step$value[1];

              countPrescriptionByMonths[key] = value.length;
            }

            _context4.next = 27;
            break;

          case 23:
            _context4.prev = 23;
            _context4.t0 = _context4['catch'](19);
            _didIteratorError = true;
            _iteratorError = _context4.t0;

          case 27:
            _context4.prev = 27;
            _context4.prev = 28;

            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }

          case 30:
            _context4.prev = 30;

            if (!_didIteratorError) {
              _context4.next = 33;
              break;
            }

            throw _iteratorError;

          case 33:
            return _context4.finish(30);

          case 34:
            return _context4.finish(27);

          case 35:
            _context4.next = 37;
            return (0, _bluebird.resolve)(listOfConditionsFromSheet(surveyType, range));

          case 37:
            conditions = _context4.sent;
            _context4.next = 40;
            return (0, _bluebird.resolve)(listOfIdsFromSheet('pos'));

          case 40:
            pssSheetIds = _context4.sent;

            surveys = surveys.filter(function (p) {
              return pssSheetIds.has(p._id.toString());
            });
            surveys = surveys.filter(function (p) {
              var result = true;
              p.diagnoses.provisional.forEach(function (provisional) {
                diagnosisIds.forEach(function (id) {
                  if (!id) {
                    result = true;
                  } else {
                    if (provisional._id.toString() === id.toString()) {
                      return result = true;
                    } else {
                      result = false;
                    }
                  }
                });
              });
              return result;
            });

            prescriptions = surveys.map(function (prescription) {
              var condition = conditions[7][conditions[0].indexOf(prescription._id.toString())];
              var unicodeSum = 0;
              for (var i = 0; i < condition.length; i++) {
                unicodeSum += condition.charAt(i).charCodeAt();
              }return {
                conditions: condition,
                unicodeSum: unicodeSum,
                months: prescription.months
              };
            });
            uniqueConditions = _lodash2.default.groupBy(prescriptions, 'months');


            res.json({
              timestamp: Date.now(),
              startDate: startDate,
              endDate: endDate,
              surveyed: prescriptions.length,
              countPrescriptions: countPrescriptions,
              uniqueConditions: uniqueConditions,
              countPrescriptionByMonths: countPrescriptionByMonths
            });
            _context4.next = 51;
            break;

          case 48:
            _context4.prev = 48;
            _context4.t1 = _context4['catch'](8);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t1.toString()
            });

          case 51:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[8, 48], [19, 23, 27, 35], [28,, 30, 34]]);
  }));

  return function PPROByDiagnoses(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var PPROByAppointments = exports.PPROByAppointments = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var startDate, endDate, doctorIds, rmpIds, surveyType, range, surveys, countPrescriptions, conditions, fpsSheetIds, prescriptions, uniquePatient;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            surveyType = 'fps';
            range = 'C:K';
            _context5.prev = 6;
            _context5.next = 9;
            return (0, _bluebird.resolve)(_prescription.Prescription.findSurveyListForPPROByAppointments(startDate, endDate, surveyType, doctorIds, rmpIds));

          case 9:
            surveys = _context5.sent;
            countPrescriptions = surveys.length;
            _context5.next = 13;
            return (0, _bluebird.resolve)(listOfConditionsFromSheet(surveyType, range));

          case 13:
            conditions = _context5.sent;
            _context5.next = 16;
            return (0, _bluebird.resolve)(listOfIdsFromSheet(surveyType));

          case 16:
            fpsSheetIds = _context5.sent;

            surveys = surveys.filter(function (p) {
              return fpsSheetIds.has(p._id.toString());
            });

            prescriptions = surveys.map(function (prescription) {
              prescription.conditions = conditions[8][conditions[0].indexOf(prescription._id.toString())];
              prescription.followUpCount = conditions[7][conditions[0].indexOf(prescription._id.toString())];

              var condition = conditions[8][conditions[0].indexOf(prescription._id.toString())];

              var unicodeSum = 0;
              for (var i = 0; i < condition.length; i++) {
                unicodeSum = unicodeSum + condition.charAt(i).charCodeAt();
              }

              prescription.conditionUnicodeSum = unicodeSum;
              return prescription;
            });
            uniquePatient = _lodash2.default.groupBy(surveys, 'followUpCount');


            res.json({
              timestamp: Date.now(),
              startDate: startDate,
              endDate: endDate,
              countPrescriptions: countPrescriptions,
              uniquePatient: uniquePatient,
              prescriptions: prescriptions
            });
            _context5.next = 26;
            break;

          case 23:
            _context5.prev = 23;
            _context5.t0 = _context5['catch'](6);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0
            });

          case 26:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[6, 23]]);
  }));

  return function PPROByAppointments(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

// Auto-cancel surveys that have not given the in-progress heartbeat for five minutes.


var stats = exports.stats = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var startDate, endDate, surveyStats, results, uniqueNames;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)(req.query.startDate);
            endDate = (0, _momentTimezone2.default)(req.query.endDate);
            surveyStats = [];
            _context6.next = 5;
            return (0, _bluebird.resolve)((0, _bluebird.all)((0, _keys2.default)(GOOGLE_SHEET_IDS).map(function (t) {
              return getStat(t, startDate, endDate);
            })));

          case 5:
            results = _context6.sent;
            uniqueNames = new _set2.default();

            results.map(function (result) {
              (0, _keys2.default)(result).forEach(function (name) {
                if (name !== 'surveyType') {
                  uniqueNames.add(name);
                }
              });
            });

            uniqueNames.forEach(function (agent) {
              var tempObj = {};
              tempObj.agentName = agent;
              tempObj.counts = {};
              results.map(function (result) {
                if (result[tempObj.agentName] === undefined) {
                  tempObj.counts[result.surveyType] = 0;
                } else {
                  tempObj.counts[result.surveyType] = result[tempObj.agentName];
                }
              });
              surveyStats.push(tempObj);
            });

            res.json({
              timestamp: Date.now(),
              startDate: startDate,
              endDate: endDate,
              surveyStats: surveyStats
            });

          case 10:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function stats(_x17, _x18) {
    return _ref9.apply(this, arguments);
  };
}();

var _prescription = require('../prescription/prescription.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _survey = require('./survey.events');

var _survey2 = _interopRequireDefault(_survey);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var environment = require('../../config/environment');
var google = require('googleapis');

/**
 * Constants
 */
var GOOGLE_JWT_KEY = environment.GOOGLE_JWT_KEY;
var GOOGLE_API_SCOPES = environment.GOOGLE_API_SCOPES;
var GOOGLE_SHEET_IDS = environment.GOOGLE_SHEET_IDS;

/**
 * Actions
 */
var GOOGLE_JWT_CLIENT = new google.auth.JWT(GOOGLE_JWT_KEY.client_email, null, GOOGLE_JWT_KEY.private_key, GOOGLE_API_SCOPES, null);

GOOGLE_JWT_CLIENT.authorize(function (err) {
  if (err) console.error(err);
});

// FIXME: This should be in the model layer, NOT controller
function listOfIdsFromSheet(surveyType) {
  return new _promise2.default(function (resolve, reject) {
    var sheets = google.sheets('v4');
    sheets.spreadsheets.values.get({
      auth: GOOGLE_JWT_CLIENT,
      spreadsheetId: GOOGLE_SHEET_IDS[surveyType],
      range: 'C:C'
    }, function (err, response) {
      if (err) {
        reject(err);
      } else {
        resolve(new _set2.default(response.values.reduce(function (a, b) {
          return a.concat(b);
        })));
      }
    });
  });
}

// FIXME: This should be in the model layer, NOT controller
function listOfConditionsFromSheet(surveyType, range) {
  return new _promise2.default(function (resolve, reject) {
    var sheets = google.sheets('v4');
    sheets.spreadsheets.values.get({
      auth: GOOGLE_JWT_CLIENT,
      spreadsheetId: GOOGLE_SHEET_IDS[surveyType],
      range: range,
      majorDimension: 'COLUMNS'
    }, function (err, response) {
      if (err) {
        reject(err);
      } else {
        resolve(response.values);
      }
    });
  });
}

var formUrlTemplates = {
  pss: 'https://docs.google.com/forms/d/e/1FAIpQLSddYx3zeazGW1sk8xI1bVcAd0yoEcyx8CoDYTVtwX3uVzeBKQ/viewform?embedded=true&usp=pp_url&entry.355835947=$PRE_NAME$&entry.1941365279=$PRESCRIPTION_ID$&entry.830107137=$PORIJON_PHONE$&entry.739819642=$PORIJON_NAME$&entry.1680782149=$PORIJON_SEX$&entry.1487458262=$PORIJON_AGE$&entry.796707805=$SB_NAME$&entry.609276889=$DOCTOR_NAME$&entry.1834356135&entry.786109726&entry.1179437329',
  pos: 'https://docs.google.com/forms/d/e/1FAIpQLSfV7tCt7U7kgMRwLsPX0g7fVxdvITU-HVNdz56oRDpTv_6kEw/viewform?embedded=true&usp=pp_url&entry.355835947=$PRE_NAME$&entry.1941365279=$PRESCRIPTION_ID$&entry.830107137=$PORIJON_PHONE$&entry.739819642=$PORIJON_NAME$&entry.1680782149=$PORIJON_SEX$&entry.1487458262=$PORIJON_AGE$&entry.796707805=$SB_NAME$&entry.1433762100=$DOCTOR_NAME$&entry.1800402992&entry.2002524680&entry.589516659',
  fps: 'https://docs.google.com/forms/d/e/1FAIpQLSfW6kX0s2T4ObXD1qgvw1c1gvMOKJzRzWTvsF57ablw9db6Pw/viewform?embedded=true&usp=pp_url&entry.355835947=$PRE_NAME$&entry.1941365279=$PRESCRIPTION_ID$&entry.830107137=$PORIJON_PHONE$&entry.739819642=$PORIJON_NAME$&entry.1680782149=$PORIJON_SEX$&entry.1487458262=$PORIJON_AGE$&entry.796707805=$SB_NAME$&entry.1433762100=$DOCTOR_NAME$&entry.1432938927&entry.2002524680&entry.589516659',
  rps: 'https://docs.google.com/forms/d/e/1FAIpQLSdxGHGZah5Gtg1IHEmEIElkB114d1S56r64OeTCN_K848e7Sg/viewform?embedded=true&usp=pp_url&entry.1483906947=$PRE_NAME$&entry.1769720022=$PRESCRIPTION_ID$&entry.1056318905=$PORIJON_NAME$&entry.1361319721=$PORIJON_SEX$&entry.1652503785=$PORIJON_AGE$&entry.228300287=$PORIJON_PHONE$&entry.588082100&entry.1742246883&entry.1683889741&entry.1845228825&entry.607240382&entry.670367494&entry.275905239'
};

var surveysInProgress = {
  pss: {},
  pos: {},
  rps: {},
  fps: {}
};

setInterval(function () {
  var now = Date.now();

  (0, _keys2.default)(surveysInProgress).forEach(function (surveyType) {
    (0, _keys2.default)(surveysInProgress[surveyType]).forEach(function (prescriptionId) {
      if (now - surveysInProgress[surveyType][prescriptionId] > 300000) {
        delete surveysInProgress[surveyType][prescriptionId];

        _survey2.default.emit('survey:cancel', {
          surveyType: surveyType,
          prescriptionId: prescriptionId
        });
      }
    });
  });
}, 60000);

function getStat(surveyType, startDate, endDate) {
  return new _promise2.default(function (resolve, reject) {
    var sheets = google.sheets('v4');
    var range = surveyType === 'rps' ? 'A:Q' : 'A:B';
    var googleConfig = {
      auth: GOOGLE_JWT_CLIENT,
      spreadsheetId: GOOGLE_SHEET_IDS[surveyType],
      range: range
    };
    sheets.spreadsheets.values.get(googleConfig, function (err, response) {
      if (err) {
        reject(err);
      } else {
        var result = response.values;
        result.shift();
        var uniqueNames = new _set2.default();
        var agents = {};
        var preNameColumnNumber = 1;
        if (surveyType === 'rps') {
          preNameColumnNumber = 16;
        }
        result.map(function (a) {
          var date = void 0;

          //In google sheet fps has MM/DD/YYYY formet but all are in same formet DD/MM/YY
          if (surveyType == 'fps') date = (0, _momentTimezone2.default)(a[0], "MM/DD/YYYY HH:mm:ss");else date = (0, _momentTimezone2.default)(a[0], "DD/MM/YYYY HH:mm:ss");

          //which have no PRE name it returns undefined so we change it to Name Less
          if (date >= startDate && date <= endDate) {
            if (a[preNameColumnNumber] === undefined) a[preNameColumnNumber] = '';
            if (uniqueNames.has(a[preNameColumnNumber])) {
              agents[a[preNameColumnNumber]] = agents[a[preNameColumnNumber]] + 1;
            } else {
              uniqueNames.add(a[preNameColumnNumber]);
              agents[a[preNameColumnNumber]] = 1;
            }
          }
        });
        agents['surveyType'] = surveyType;
        resolve(agents);
      }
    });
  });
}
//# sourceMappingURL=survey.controller.js.map
