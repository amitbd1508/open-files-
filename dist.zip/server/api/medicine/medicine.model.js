'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DrugAvailability = exports.DrugCompany = exports.DrugGeneric = exports.Drugs = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var byBrand = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            limit = parseInt(limit);

            query = {
              trade_name: {
                '$regex': searchQuery,
                '$options': 'i'
              }
            };
            _context.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $limit: limit
            }, {
              $lookup: {
                "from": "genericdrugs",
                "localField": "generic_id",
                "foreignField": "generic_id",
                "as": "generic"
              }
            }, {
              $unwind: {
                path: "$generic",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $lookup: {
                "from": "companies",
                "localField": "company_id",
                "foreignField": "company_id",
                "as": "company"
              }
            }, {
              $unwind: {
                path: "$company",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $project: {
                _id: 1,
                trade_name: "$trade_name",
                genericName: "$generic.generic_name",
                companyName: "$company.company_name",
                strength: "$strength",
                formulation: "$formulation",
                indication: "$generic.indication",
                price: "$price",
                packSize: "$packSize"
              }
            }]));

          case 4:
            return _context.abrupt('return', _context.sent);

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function byBrand(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var byGeneric = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            limit = parseInt(limit);

            query = {
              generic_name: {
                '$regex': searchQuery,
                '$options': 'i'
              }
            };
            _context2.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $limit: limit
            }, {
              $lookup: {
                "from": "drugs",
                "localField": "generic_id",
                "foreignField": "generic_id",
                "as": "drugs"
              }
            }, {
              $unwind: { path: "$drugs" }
            }, {
              $lookup: {
                "from": "companies",
                "localField": "drugs.company_id",
                "foreignField": "company_id",
                "as": "drugs.company"
              }
            }, {
              $unwind: {
                path: "$drugs.company",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $project: {
                _id: "$drugs._id",
                trade_name: "$drugs.trade_name",
                strength: "$drugs.strength",
                genericName: "$generic_name",
                companyName: "$drugs.company.company_name",
                formulation: "$drugs.formulation",
                indication: "$indication",
                price: "$drugs.price",
                packSize: "$drugs.packSize"
              }
            }, {
              $sort: {
                genericName: 1
              }
            }]));

          case 4:
            return _context2.abrupt('return', _context2.sent);

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function byGeneric(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var byIndication = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            limit = parseInt(limit);

            query = {
              indication: {
                '$regex': searchQuery,
                '$options': 'i'
              }
            };
            _context3.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $limit: limit
            }, {
              $lookup: {
                "from": "drugs",
                "localField": "generic_id",
                "foreignField": "generic_id",
                "as": "drugs"
              }
            }, {
              $unwind: { path: "$drugs" }
            }, {
              $lookup: {
                "from": "companies",
                "localField": "drugs.company_id",
                "foreignField": "company_id",
                "as": "drugs.company"
              }
            }, {
              $unwind: {
                path: "$drugs.company",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $project: {
                _id: "$drugs._id",
                trade_name: "$drugs.trade_name",
                strength: "$drugs.strength",
                genericName: "$generic_name",
                companyName: "$drugs.company.company_name",
                formulation: "$drugs.formulation",
                indication: "$indication",
                price: "$drugs.price",
                packSize: "$drugs.packSize"
              }
            }, {
              $sort: {
                genericName: 1
              }
            }]));

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function byIndication(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findPending = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(limit, skip) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            limit = parseInt(limit) || 10;
            skip = parseInt(skip) || 0;

            _context4.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: {
                isApproved: false
              }
            }, {
              $limit: limit
            }, {
              $skip: skip
            }, {
              $lookup: {
                "from": "genericdrugs",
                "localField": "generic_id",
                "foreignField": "generic_id",
                "as": "generic"
              }
            }, {
              $unwind: {
                path: "$generic",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $lookup: {
                "from": "companies",
                "localField": "company_id",
                "foreignField": "company_id",
                "as": "company"
              }
            }, {
              $unwind: {
                path: "$company",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $lookup: {
                "from": "users",
                "localField": "userId",
                "foreignField": "_id",
                "as": "user"
              }
            }, {
              $unwind: {
                path: "$user",
                preserveNullAndEmptyArrays: false
              }
            }, {
              $project: {
                _id: 1,
                tradeName: "$trade_name",
                genericName: "$generic.generic_name",
                companyName: "$company.company_name",
                strength: "$strength",
                formulation: "$formulation",
                indication: "$generic.indication",
                price: "$price",
                packSize: "$packSize",
                fullName: "$user.fullname",
                created_at: "$created_at",
                isApproved: "$isApproved"
              }
            }]));

          case 4:
            return _context4.abrupt('return', _context4.sent);

          case 5:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findPending(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var byName = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            limit = parseInt(limit);

            query = {
              generic_name: {
                '$regex': searchQuery,
                '$options': 'i'
              }
            };
            _context5.next = 4;
            return (0, _bluebird.resolve)(this.find(query).limit(limit).select('generic_name generic_id').sort({ generic_name: 1 }).lean().exec());

          case 4:
            return _context5.abrupt('return', _context5.sent);

          case 5:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function byName(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var companyByName = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            limit = parseInt(limit);

            query = {
              company_name: {
                '$regex': searchQuery,
                '$options': 'i'
              }
            };
            _context6.next = 4;
            return (0, _bluebird.resolve)(this.find(query).limit(limit).sort({ company_name: 1 }).lean().exec());

          case 4:
            return _context6.abrupt('return', _context6.sent);

          case 5:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function companyByName(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var suggestionsByAppointmentId = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(appointmentId) {
    var appointment, prescriptions;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.next = 2;
            return (0, _bluebird.resolve)(_prescription.Appointment.findById(appointmentId).select('patients_id start').lean().exec());

          case 2:
            appointment = _context7.sent;
            _context7.next = 5;
            return (0, _bluebird.resolve)(_prescription.Prescription.find({
              is_pdfready: true,
              publishAt: {
                $lt: appointment.start
              },
              patients_id: appointment.patients_id
            }).lean().exec());

          case 5:
            prescriptions = _context7.sent;
            return _context7.abrupt('return', prescriptions.map(function (prescription) {
              return prescription.instruction;
            }).reduce(function (accumulator, medicine) {
              return accumulator.concat(medicine);
            }, []).reduce(function (accumulator, medicine) {
              return accumulator.concat(accumulator.find(function (testMedicine) {
                return testMedicine.selected[0]._id === medicine.selected[0]._id;
              }) ? [] : [medicine]);
            }, []));

          case 7:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function suggestionsByAppointmentId(_x13) {
    return _ref7.apply(this, arguments);
  };
}();

var findDrugsAvailability = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(startDate, endDate, rmpIds, doctorIds) {
    var limit = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 50;
    var skip = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0;
    var dateStartOfWeek, dateEndOfWeek, query;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            dateStartOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            dateEndOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : dateStartOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : dateEndOfWeek;

            _context8.next = 6;
            return (0, _bluebird.resolve)(filters(startDate, endDate, rmpIds, doctorIds));

          case 6:
            query = _context8.sent;
            _context8.next = 9;
            return (0, _bluebird.resolve)(DrugAvailability.find(query).populate({
              path: 'patientId',
              select: 'fullname profilepiclink gender phone dob serialnumber village'
            }).populate({
              path: 'doctorId',
              select: 'fullname profile_url specialized'
            }).populate({
              path: 'drugId',
              select: 'trade_name source generic_id formulation'
            }).populate({
              path: 'prescriptionId',
              select: 'publishAt'
            }).populate({
              path: 'rmpId',
              select: 'fullname profile_url phone'
            }).limit(parseInt(limit)).skip(parseInt(skip)).sort('-createdAt').exec());

          case 9:
            return _context8.abrupt('return', _context8.sent);

          case 10:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function findDrugsAvailability(_x14, _x15, _x16, _x17, _x18, _x19) {
    return _ref8.apply(this, arguments);
  };
}();

var findCount = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(startDate, endDate, rmpIds, doctorIds) {
    var dateStartOfWeek, dateEndOfWeek, query;
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            dateStartOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            dateEndOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : dateStartOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : dateEndOfWeek;

            _context9.next = 6;
            return (0, _bluebird.resolve)(filters(startDate, endDate, rmpIds, doctorIds));

          case 6:
            query = _context9.sent;
            _context9.next = 9;
            return (0, _bluebird.resolve)(DrugAvailability.count(query).exec());

          case 9:
            return _context9.abrupt('return', _context9.sent);

          case 10:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this);
  }));

  return function findCount(_x22, _x23, _x24, _x25) {
    return _ref9.apply(this, arguments);
  };
}();

var filters = function () {
  var _ref10 = (0, _bluebird.method)(function (startDate, endDate, rmpIds, doctorIds) {
    var query = {
      createdAt: {
        $gte: startDate,
        $lte: endDate
      }
    };
    if (doctorIds) {
      doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
      doctorIds = doctorIds.map(function (id) {
        return objectId(id);
      });
      doctorIds ? query.doctorId = { $in: doctorIds } : '';
    }
    if (rmpIds) {
      rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
      rmpIds = rmpIds.map(function (id) {
        return objectId(id);
      });
      rmpIds ? query.rmpId = { $in: rmpIds } : '';
    }
    return query;
  });

  return function filters(_x26, _x27, _x28, _x29) {
    return _ref10.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _drug = require('../../schemas/drug.schema');

var _drug2 = _interopRequireDefault(_drug);

var _drugGeneric = require('../../schemas/drug-generic.schema');

var _drugGeneric2 = _interopRequireDefault(_drugGeneric);

var _drugCompany = require('../../schemas/drug-company.schema');

var _drugCompany2 = _interopRequireDefault(_drugCompany);

var _drugsAvailability = require('../../schemas/drugs-availability.schema');

var _drugsAvailability2 = _interopRequireDefault(_drugsAvailability);

var _prescription = require('../prescription/prescription.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Statics
 */
_drug2.default.static('byBrand', byBrand).static('suggestionsByAppointmentId', suggestionsByAppointmentId).static('findPending', findPending);

_drugGeneric2.default.static('byGeneric', byGeneric).static('byName', byName).static('byIndication', byIndication);

_drugCompany2.default.static('companyByName', companyByName);

_drugsAvailability2.default.static('findDrugsAvailability', findDrugsAvailability).static('findCount', findCount);

var Drugs = exports.Drugs = _mongoose2.default.model('Drugs', _drug2.default, 'drugs');
var DrugGeneric = exports.DrugGeneric = _mongoose2.default.model('DrugGeneric', _drugGeneric2.default, 'genericdrugs');
var DrugCompany = exports.DrugCompany = _mongoose2.default.model('DrugCompany', _drugCompany2.default, 'companies');
var DrugAvailability = exports.DrugAvailability = _mongoose2.default.model('DrugAvailability', _drugsAvailability2.default, 'drugs-availability');
//# sourceMappingURL=medicine.model.js.map
