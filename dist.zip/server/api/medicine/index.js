'use strict';

/**
 * Imports
 */

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./medicine.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/byBrand', auth.isAuthenticated(), controller.byBrand);
router.get('/byGeneric', auth.isAuthenticated(), controller.byGeneric);
router.get('/byIndication', auth.isAuthenticated(), controller.byIndication);

router.get('/generic/byName', auth.isAuthenticated(), controller.genericByName);
router.get('/company/byName', auth.isAuthenticated(), controller.companyByName);

router.get('/suggestions/:appointmentId', auth.isAuthenticated(), controller.suggestions);
router.get('/findPending', auth.isAuthenticated(), controller.findPending);

router.get('/drug/byId/:Id', auth.isAuthenticated(), controller.drugById);
router.post('/', auth.isAuthenticated(), controller.drugSave);
router.put('/:Id', auth.isAuthenticated(), controller.drugUpdate);

router.get('/generic/byGenericId/:genericId', auth.isAuthenticated(), controller.byGenericId);
router.get('/company/byCompanyId/:companyId', auth.isAuthenticated(), controller.byCompanyId);

router.get('/availability', auth.hasUserType(['admin']), controller.findDrugsAvailabilityAndCount);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
