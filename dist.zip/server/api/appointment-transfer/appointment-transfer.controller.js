'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cancelById = exports.rejectByRequestId = exports.transferByRequestId = exports.createTransferRequest = exports.getTodaysAppointmentsByDoctorId = exports.getTransferRequestsByDoctorId = exports.getTodaysDoctors = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var getTodaysDoctors = exports.getTodaysDoctors = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var dateStartOfDay, dateNow, dateEndOfDay, doctors;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            dateStartOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').startOf('day').toDate();
            dateNow = (0, _momentTimezone2.default)().toDate();
            dateEndOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').endOf('day').toDate();
            _context.next = 6;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.findAvailableDoctors(dateNow, dateStartOfDay, dateEndOfDay));

          case 6:
            doctors = _context.sent;


            res.json({
              timestamp: Date.now(),
              doctors: doctors
            });
            _context.next = 13;
            break;

          case 10:
            _context.prev = 10;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0
            });

          case 13:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 10]]);
  }));

  return function getTodaysDoctors(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var getTransferRequestsByDoctorId = exports.getTransferRequestsByDoctorId = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var toDoctorId, transferLogs;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            toDoctorId = req.params.toDoctorId;


            if (!toDoctorId) res.status(400).end();

            _context2.prev = 2;
            _context2.next = 5;
            return (0, _bluebird.resolve)(_appointmentTransfer.TransferLogs.getTransferRequestsByDoctorId(toDoctorId));

          case 5:
            transferLogs = _context2.sent;


            res.json({
              timestamp: Date.now(),
              transferLogs: transferLogs
            });
            _context2.next = 12;
            break;

          case 9:
            _context2.prev = 9;
            _context2.t0 = _context2['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0
            });

          case 12:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[2, 9]]);
  }));

  return function getTransferRequestsByDoctorId(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var getTodaysAppointmentsByDoctorId = exports.getTodaysAppointmentsByDoctorId = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var query, dateStartOfHour, dateEndOfDay, doctorId, appointments;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            query = {};
            dateStartOfHour = (0, _momentTimezone2.default)().tz('Asia/Dhaka').startOf('hour').toDate();
            dateEndOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').endOf('day').toDate();
            doctorId = req.params.doctorId;


            if (!doctorId) res.status(400).end();

            query.doctors_id = doctorId;
            query.start = {
              $gte: dateStartOfHour,
              $lte: dateEndOfDay
            };

            _context3.prev = 7;
            _context3.next = 10;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.getAppointmentsByDoctorId(query));

          case 10:
            appointments = _context3.sent;


            res.json({
              timestamp: Date.now(),
              appointments: appointments
            });
            _context3.next = 17;
            break;

          case 14:
            _context3.prev = 14;
            _context3.t0 = _context3['catch'](7);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0
            });

          case 17:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[7, 14]]);
  }));

  return function getTodaysAppointmentsByDoctorId(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var createTransferRequest = exports.createTransferRequest = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var userId, fromAppointmentId, toAppointmentId, toDoctorId, createdFor, transferLog;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            userId = req.user._id;

            if (!userId) res.status(400).end();

            _context4.prev = 2;
            fromAppointmentId = req.body.fromAppointmentId;
            toAppointmentId = req.body.toAppointmentId;
            toDoctorId = req.body.toDoctorId;
            createdFor = req.body.requestedFor;
            _context4.next = 9;
            return (0, _bluebird.resolve)(_appointmentTransfer.TransferLogs.createTransferRequest(fromAppointmentId, toAppointmentId, toDoctorId, createdFor, userId));

          case 9:
            transferLog = _context4.sent;


            res.json({
              timestamp: Date.now(),
              transferLog: transferLog
            });
            _context4.next = 16;
            break;

          case 13:
            _context4.prev = 13;
            _context4.t0 = _context4['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0
            });

          case 16:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[2, 13]]);
  }));

  return function createTransferRequest(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var transferByRequestId = exports.transferByRequestId = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var requestId, userId, transferLog;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            requestId = req.params.requestId;
            userId = req.user._id;


            if (!userId) res.status(400).end();

            _context5.prev = 3;
            _context5.next = 6;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.transferByRequestId(requestId, userId));

          case 6:
            transferLog = _context5.sent;


            res.json({
              timestamp: Date.now(),
              transferLog: transferLog
            });
            _context5.next = 13;
            break;

          case 10:
            _context5.prev = 10;
            _context5.t0 = _context5['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0
            });

          case 13:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[3, 10]]);
  }));

  return function transferByRequestId(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var rejectByRequestId = exports.rejectByRequestId = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var requestId, respondedFor, userId, transferLog;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            requestId = req.params.requestId;
            respondedFor = req.body.rejectedFor;
            userId = req.user._id;


            if (!userId) res.status(400).end();

            _context6.prev = 4;
            _context6.next = 7;
            return (0, _bluebird.resolve)(_appointmentTransfer.TransferLogs.rejectByRequestId(requestId, respondedFor, userId));

          case 7:
            transferLog = _context6.sent;


            res.json({
              timestamp: Date.now(),
              transferLog: transferLog
            });
            _context6.next = 14;
            break;

          case 11:
            _context6.prev = 11;
            _context6.t0 = _context6['catch'](4);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0
            });

          case 14:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[4, 11]]);
  }));

  return function rejectByRequestId(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var cancelById = exports.cancelById = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var appointmentId, reason, userId, appointment;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            appointmentId = req.params.appointmentId;
            reason = req.body.reason;
            userId = req.user._id;


            if (!appointmentId) res.status(400).end();

            _context7.prev = 4;
            _context7.next = 7;
            return (0, _bluebird.resolve)(_appointmentTransfer.AppointmentTransfer.cancelById(appointmentId, userId, reason));

          case 7:
            appointment = _context7.sent;


            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context7.next = 14;
            break;

          case 11:
            _context7.prev = 11;
            _context7.t0 = _context7['catch'](4);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context7.t0
            });

          case 14:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[4, 11]]);
  }));

  return function cancelById(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var _appointmentTransfer = require('./appointment-transfer.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=appointment-transfer.controller.js.map
