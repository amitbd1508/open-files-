'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var AppointmentTransferEvents = new _events.EventEmitter();

/**
 * Options
 */
AppointmentTransferEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = AppointmentTransferEvents;
//# sourceMappingURL=appointment-transfer.events.js.map
