"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.seedData = undefined;

var _momentTimezone = require("moment-timezone");

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var admin = {
  "_id": "57f1fca7e9360900111d84bc",
  "fullname": 'admin',
  "username": 'admin@jeeon.co',
  "email": 'admin@jeeon.co',
  "userType": 'admin',
  "password": 'password',
  "role": 5,
  "is_admin": true
};

var rmp = {
  "_id": "5805e6d5995bb80011fba444",
  "fullname": 'rmp',
  "username": 'rmp@jeeon.com',
  "email": 'rmp@jeeon.co',
  "userType": 'rmp',
  "password": 'password',
  "role": 2
};

var fromDoctor = {
  "_id": "5805e6d5995bb80011fba974",
  "fullname": 'doctor',
  "username": 'fromDoctor@jeeon.com',
  "email": 'fromDoctor@jeeon.co',
  "userType": 'doctor',
  "password": 'password',
  "role": 2
};

var toDoctor = {
  "_id": "5805e6d5995bb89011fba975",
  "fullname": 'toDoctor',
  "username": 'toDoctor@jeeon.com',
  "email": 'toDoctor@jeeon.co',
  "userType": 'doctor',
  "password": 'password',
  "role": 2
};

var patient = {
  "_id": "58399528cc32be0011fe8951",
  "serialnumber": 'ADp:04770',
  "active": true,
  "fullname": 'patient',
  "phone": '01918580662',
  "dob": '2001-08-28T07:05:34.235Z'
};

var fromAppointment = {
  "_id": "57fa4f389946d20011448aef",
  "doctors_id": "5805e6d5995bb80011fba974",
  "rmp_id": "5805e6d5995bb80011fba444",
  "patients_id": "58399528cc32be0011fe8951",
  "start": (0, _momentTimezone2.default)().subtract(2, 'hours'),
  "end": (0, _momentTimezone2.default)().subtract(2, 'hours').add(20, 'minus'),
  "symptoms": [],
  "patients_images": ["https://projotno-server.s3.ap-south-1.amazonaws.com/appointmentdata/profile-1476612931321.jpeg"],
  "is_prescribed": false,
  "is_booked": true,
  "time_took": 151,
  "patient_weight": 44.3,
  "patient_temp": 98,
  "patient_systole": 128.1,
  "patient_pulse": 96
};

var toAppointment = {
  "_id": "57f34aa054809600116c909a",
  "doctors_id": "5805e6d5995bb89011fba975",
  "start": (0, _momentTimezone2.default)(),
  "end": (0, _momentTimezone2.default)().add(20, 'minute'),
  "symptoms": [],
  "patients_images": [],
  "is_prescribed": false,
  "is_booked": false
};

var seedData = exports.seedData = {
  admin: admin,
  rmp: rmp,
  fromDoctor: fromDoctor,
  toDoctor: toDoctor,
  patient: patient,
  fromAppointment: fromAppointment,
  toAppointment: toAppointment
};
//# sourceMappingURL=appointment-transfer.seed.js.map
