'use strict';

/**
 * Imports
 */

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./appointment-transfer.controller');

var router = express.Router();

/**
 * Routes
 */

router.post('/transferRequest', auth.isAuthenticated(), controller.createTransferRequest);
router.get('/transferRequest/:requestId', auth.isAuthenticated(), controller.transferByRequestId);
router.delete('/transferRequest/:requestId', auth.isAuthenticated(), controller.rejectByRequestId);

router.delete('/appointments/:appointmentId', auth.isUserType('admin'), controller.cancelById);
router.get('/getTodaysDoctors', auth.isAuthenticated(), controller.getTodaysDoctors);

router.get('/getTodaysAppointmentsByDoctor/:doctorId', auth.isAuthenticated(), controller.getTodaysAppointmentsByDoctorId);
router.get('/getTransferRequests/:toDoctorId', auth.isAuthenticated(), controller.getTransferRequestsByDoctorId);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
