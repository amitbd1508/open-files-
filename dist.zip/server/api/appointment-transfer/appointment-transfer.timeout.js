'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

exports.initialize = initialize;

var _appointmentTransfer = require('./appointment-transfer.model');

var _appointmentTransfer2 = require('./appointment-transfer.events');

var _appointmentTransfer3 = _interopRequireDefault(_appointmentTransfer2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */
var TIMEOUT = 120 * 1000;

/**
 *  Initialization
 */
function initialize(transferLog) {
  timeout(transferLog);
}

function timeout(transferLog) {
  var _this = this;

  setTimeout((0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(_appointmentTransfer.TransferLogs.timeoutByRequestId(transferLog._id));

          case 2:

            _appointmentTransfer3.default.emit('appointment:transfer:timeout', {
              _id: transferLog._id,
              toDoctorId: transferLog.toDoctorId,
              createdBy: transferLog.createdBy._id,
              toAppointmentId: transferLog.toAppointmentId._id,
              fromAppointmentId: transferLog.fromAppointmentId._id
            });

          case 3:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, _this);
  })), TIMEOUT);
}
//# sourceMappingURL=appointment-transfer.timeout.js.map
