'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TransferLogs = exports.TransferPrescription = exports.AppointmentTransfer = exports.TransferUser = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _slicedToArray2 = require('babel-runtime/helpers/slicedToArray');

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _bluebird = require('bluebird');

var findAvailableDoctors = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(dateNow, dateStartOfDay, dateEndOfDay) {
    var doctorIds;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (!dateStartOfDay) dateStartOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').startOf('day').toDate();
            if (!dateNow) dateNow = (0, _momentTimezone2.default)().toDate();
            if (!dateEndOfDay) dateEndOfDay = (0, _momentTimezone2.default)().tz('Asia/Dhaka').endOf('day').toDate();

            _context.next = 5;
            return (0, _bluebird.resolve)(AppointmentTransfer.find({
              end: {
                $gte: dateNow,
                $lte: dateEndOfDay
              }
            }).distinct('doctors_id').exec());

          case 5:
            doctorIds = _context.sent;
            _context.next = 8;
            return (0, _bluebird.resolve)((0, _bluebird.all)(doctorIds.map(function (doctorId) {
              var pDoctor = TransferUser.findById(doctorId).select('fullname identity specialized profile_url').lean().exec();

              var pStartAppointment = AppointmentTransfer.findOne({
                doctors_id: doctorId,
                start: {
                  $gte: dateStartOfDay,
                  $lte: dateEndOfDay
                }
              }).select('start').sort('start').lean().exec();

              var pEndAppointment = AppointmentTransfer.findOne({
                doctors_id: doctorId,
                end: {
                  $gte: dateStartOfDay,
                  $lte: dateEndOfDay
                }
              }).select('end').sort('-end').lean().exec();

              var pAvailableAppointmentCount = AppointmentTransfer.count({
                doctors_id: doctorId,
                start: {
                  $gte: dateNow,
                  $lte: dateEndOfDay
                },
                is_booked: false
              }).lean().exec();

              var pPendingAppointmentCount = AppointmentTransfer.count({
                doctors_id: doctorId,
                start: {
                  $gte: dateStartOfDay,
                  $lte: dateEndOfDay
                },
                is_booked: true,
                is_prescribed: false
              }).lean().exec();

              return (0, _bluebird.all)([pDoctor, pAvailableAppointmentCount, pPendingAppointmentCount, pStartAppointment, pEndAppointment]).then(function (_ref2) {
                var _ref3 = (0, _slicedToArray3.default)(_ref2, 5),
                    doctor = _ref3[0],
                    availableAppointmentCount = _ref3[1],
                    pendingAppointmentCount = _ref3[2],
                    startAppointment = _ref3[3],
                    endAppointment = _ref3[4];

                doctor.startTime = startAppointment.start;
                doctor.endTime = endAppointment.end;
                doctor.availableAppointmentCount = availableAppointmentCount;
                doctor.pendingAppointmentCount = pendingAppointmentCount;

                return doctor;
              });
            })));

          case 8:
            return _context.abrupt('return', _context.sent);

          case 9:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findAvailableDoctors(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

var getAppointmentsByDoctorId = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(query) {
    var dateNow, appointments;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            dateNow = (0, _momentTimezone2.default)().toDate();
            _context2.next = 3;
            return (0, _bluebird.resolve)(this.find(query).sort({
              'start': 'asc'
            }).lean().exec());

          case 3:
            appointments = _context2.sent;


            appointments = appointments.filter(function (appointment) {
              return !(0, _momentTimezone2.default)(appointment.end).isBefore(dateNow);
            });

            return _context2.abrupt('return', appointments);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getAppointmentsByDoctorId(_x4) {
    return _ref4.apply(this, arguments);
  };
}();

var getTransferRequestsByDoctorId = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(toDoctorId) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(this.find({
              toDoctorId: objectId(toDoctorId),
              isActive: true
            }).populate({
              path: 'fromAppointmentId',
              model: 'Appointment',
              populate: {
                path: 'patients_id',
                model: 'Patient'
              }
            }).populate({
              path: 'toAppointmentId',
              model: 'Appointment'
            }).populate({
              path: 'createdBy',
              model: 'User'
            }).exec());

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getTransferRequestsByDoctorId(_x5) {
    return _ref5.apply(this, arguments);
  };
}();

var createTransferRequest = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(fromAppointmentId, toAppointmentId, toDoctorId, createdFor, userId) {
    var transferRequest, transferLog;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            transferRequest = new TransferLogs({
              fromAppointmentId: fromAppointmentId,
              toAppointmentId: toAppointmentId,
              toDoctorId: toDoctorId,
              createdFor: createdFor,
              createdBy: userId
            });
            _context4.next = 3;
            return (0, _bluebird.resolve)(transferRequest.save());

          case 3:
            _context4.next = 5;
            return (0, _bluebird.resolve)(TransferLogs.findById(transferRequest._id).populate({
              path: 'fromAppointmentId',
              model: 'Appointment',
              populate: {
                path: 'patients_id',
                model: 'Patient'
              }
            }).populate({
              path: 'toAppointmentId',
              model: 'Appointment'
            }).populate({
              path: 'createdBy',
              model: 'User'
            }).exec());

          case 5:
            transferLog = _context4.sent;


            _appointmentTransfer2.default.emit('appointment:transfer:request', transferLog);

            timeout.initialize(transferLog);

            return _context4.abrupt('return', transferLog);

          case 9:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function createTransferRequest(_x6, _x7, _x8, _x9, _x10) {
    return _ref6.apply(this, arguments);
  };
}();

var transferByRequestId = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(requestId, userId) {
    var transferRequest, fromAppointmentId, toAppointmentId, _ref8, _ref9, fromAppointment, toAppointment, log;

    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            _context5.next = 3;
            return (0, _bluebird.resolve)(TransferLogs.findById(objectId(requestId)).exec());

          case 3:
            transferRequest = _context5.sent;
            fromAppointmentId = transferRequest.fromAppointmentId;
            toAppointmentId = transferRequest.toAppointmentId;
            _context5.next = 8;
            return (0, _bluebird.resolve)((0, _bluebird.all)([AppointmentTransfer.findById(fromAppointmentId), AppointmentTransfer.findById(toAppointmentId)]));

          case 8:
            _ref8 = _context5.sent;
            _ref9 = (0, _slicedToArray3.default)(_ref8, 2);
            fromAppointment = _ref9[0];
            toAppointment = _ref9[1];

            if (!toAppointment.is_booked) {
              _context5.next = 14;
              break;
            }

            throw new Error('Appointment Booked');

          case 14:
            _context5.next = 16;
            return (0, _bluebird.resolve)(transferByAppointment(fromAppointment, toAppointment));

          case 16:
            _context5.next = 18;
            return (0, _bluebird.resolve)(TransferPrescription.findOneAndUpdate({
              appointment_id: fromAppointment._id
            }, {
              $set: {
                appointment_id: toAppointment._id,
                rmp_id: toAppointment.rmp_id,
                doctors_id: toAppointment.doctors_id
              }
            }, {
              new: true
            }).lean().exec());

          case 18:
            _context5.next = 20;
            return (0, _bluebird.resolve)(cleanFrom(fromAppointment, toAppointment, userId));

          case 20:

            transferRequest.respondedAt = new Date();
            transferRequest.isActive = false;
            transferRequest.respondedBy = userId;
            transferRequest.responseType = 'accepted';

            _context5.next = 26;
            return (0, _bluebird.resolve)(transferRequest.save());

          case 26:
            log = _context5.sent;


            _appointmentTransfer2.default.emit('appointment:transfer:accepted', log);

            return _context5.abrupt('return', log);

          case 31:
            _context5.prev = 31;
            _context5.t0 = _context5['catch'](0);
            return _context5.abrupt('return', _context5.t0);

          case 34:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 31]]);
  }));

  return function transferByRequestId(_x11, _x12) {
    return _ref7.apply(this, arguments);
  };
}();

var rejectByRequestId = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(requestId, respondedFor, userId) {
    var transferRequest;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.prev = 0;
            _context6.next = 3;
            return (0, _bluebird.resolve)(this.findById(objectId(requestId)).exec());

          case 3:
            transferRequest = _context6.sent;


            transferRequest.respondedAt = new Date();
            transferRequest.isActive = false;
            transferRequest.respondedBy = userId;
            transferRequest.responseType = 'rejected';
            transferRequest.respondedFor = respondedFor;

            _context6.next = 11;
            return (0, _bluebird.resolve)(transferRequest.save());

          case 11:

            _appointmentTransfer2.default.emit('appointment:transfer:rejected', transferRequest);

            return _context6.abrupt('return', transferRequest);

          case 15:
            _context6.prev = 15;
            _context6.t0 = _context6['catch'](0);
            return _context6.abrupt('return', _context6.t0);

          case 18:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[0, 15]]);
  }));

  return function rejectByRequestId(_x13, _x14, _x15) {
    return _ref10.apply(this, arguments);
  };
}();

var timeoutByRequestId = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(requestId) {
    var transferRequest;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.prev = 0;
            _context7.next = 3;
            return (0, _bluebird.resolve)(TransferLogs.findById(objectId(requestId)).exec());

          case 3:
            transferRequest = _context7.sent;

            if (!transferRequest.isActive) {
              _context7.next = 11;
              break;
            }

            transferRequest.respondedAt = new Date();
            transferRequest.isActive = false;
            transferRequest.responseType = 'timeOut';

            _context7.next = 10;
            return (0, _bluebird.resolve)(transferRequest.save());

          case 10:
            transferRequest = _context7.sent;

          case 11:
            return _context7.abrupt('return', transferRequest);

          case 14:
            _context7.prev = 14;
            _context7.t0 = _context7['catch'](0);
            return _context7.abrupt('return', _context7.t0);

          case 17:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[0, 14]]);
  }));

  return function timeoutByRequestId(_x16) {
    return _ref11.apply(this, arguments);
  };
}();

/**
 *
 * @param fromAppointment
 * @param toAppointment
 * @param userId
 * @returns {Promise.<*>}
 */


var transferByAppointment = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(fromAppointment, toAppointment, userId) {
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:

            toAppointment.is_booked = true;
            toAppointment.patients_id = fromAppointment.patients_id;
            toAppointment.rmp_id = fromAppointment.rmp_id;
            toAppointment.patient_weight = fromAppointment.patient_weight;
            toAppointment.patients_images = fromAppointment.patients_images;
            toAppointment.patient_temp = fromAppointment.patient_temp;
            toAppointment.patient_pulse = fromAppointment.patient_pulse;
            toAppointment.symptoms = fromAppointment.symptoms;
            toAppointment.encoded_symptoms = fromAppointment.encoded_symptoms;
            toAppointment.patient_systole = fromAppointment.patient_systole;
            toAppointment.patient_diastole = fromAppointment.patient_diastole;
            toAppointment.patient_diabetic = fromAppointment.patient_diabetic;
            toAppointment.patient_glucose = fromAppointment.patient_glucose;
            toAppointment.time_took = fromAppointment.time_took;
            toAppointment.timestamp.book_by_rmp = fromAppointment.timestamp.book_by_rmp;
            toAppointment.source = fromAppointment.source;

            toAppointment.transfer.transferBy = userId;
            toAppointment.transfer.transferAt = new Date();

            _context8.next = 20;
            return (0, _bluebird.resolve)(toAppointment.save());

          case 20:
            return _context8.abrupt('return', _context8.sent);

          case 21:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function transferByAppointment(_x17, _x18, _x19) {
    return _ref12.apply(this, arguments);
  };
}();

/**
 *
 * @param fromAppointment
 * @returns {Promise.<*>}
 */


var cleanFrom = function () {
  var _ref13 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(fromAppointment) {
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:

            fromAppointment.is_booked = false;
            fromAppointment.is_prescribed = false;
            fromAppointment.patients_id = null;
            fromAppointment.rmp_id = null;
            fromAppointment.patient_weight = null;
            fromAppointment.patients_images = [];
            fromAppointment.patient_temp = null;
            fromAppointment.patient_pulse = null;
            fromAppointment.symptoms = [];
            fromAppointment.encoded_symptoms = [];
            fromAppointment.patient_systole = null;
            fromAppointment.patient_diastole = null;
            fromAppointment.patient_diabetic = null;
            fromAppointment.patient_glucose = null;
            fromAppointment.time_took = null;
            fromAppointment.timestamp.book_by_rmp = null;
            fromAppointment.source = null;

            _context9.next = 19;
            return (0, _bluebird.resolve)(fromAppointment.save());

          case 19:
            return _context9.abrupt('return', _context9.sent);

          case 20:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this);
  }));

  return function cleanFrom(_x20) {
    return _ref13.apply(this, arguments);
  };
}();

/**
 *
 * @param appointmentId
 * @param userId
 * @param reason
 * @returns {Promise.<*>}
 */


var cancelById = function () {
  var _ref14 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(appointmentId, userId, reason) {
    var appointment;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            _context10.next = 2;
            return (0, _bluebird.resolve)(AppointmentTransfer.findById(appointmentId).exec());

          case 2:
            appointment = _context10.sent;
            _context10.next = 5;
            return (0, _bluebird.resolve)(TransferPrescription.findOneAndRemove({
              appointment_id: appointmentId
            }).exec());

          case 5:

            appointment.cancel.accountable = userId;
            appointment.cancel.at = (0, _momentTimezone2.default)().toDate();
            appointment.cancel.reason = reason;

            _appointmentTransfer2.default.emit('appointment:cancel', appointment);

            return _context10.abrupt('return', cleanFrom(appointment));

          case 10:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this);
  }));

  return function cancelById(_x21, _x22, _x23) {
    return _ref14.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

var _appointment = require('../../schemas/appointment.schema');

var _appointment2 = _interopRequireDefault(_appointment);

var _transferLogs = require('../../schemas/transfer-logs.schema');

var _transferLogs2 = _interopRequireDefault(_transferLogs);

var _appointmentTransfer = require('./appointment-transfer.events');

var _appointmentTransfer2 = _interopRequireDefault(_appointmentTransfer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;
var timeout = require('./appointment-transfer.timeout');

/**
 * Statics
 */

_appointment2.default.static('transferByRequestId', transferByRequestId).static('cancelById', cancelById).static('findAvailableDoctors', findAvailableDoctors).static('getAppointmentsByDoctorId', getAppointmentsByDoctorId);

_transferLogs2.default.static('createTransferRequest', createTransferRequest).static('getTransferRequestsByDoctorId', getTransferRequestsByDoctorId).static('rejectByRequestId', rejectByRequestId).static('timeoutByRequestId', timeoutByRequestId);

var TransferUser = exports.TransferUser = _mongoose2.default.model('TransferUser', _user2.default, 'users');
var AppointmentTransfer = exports.AppointmentTransfer = _mongoose2.default.model('AppointmentTransfer', _appointment2.default, 'appointments');
var TransferPrescription = exports.TransferPrescription = _mongoose2.default.model('TransferPrescription', _prescription2.default, 'prescriptions');
var TransferLogs = exports.TransferLogs = _mongoose2.default.model('TransferLogs', _transferLogs2.default, 'transferLogs');
//# sourceMappingURL=appointment-transfer.model.js.map
