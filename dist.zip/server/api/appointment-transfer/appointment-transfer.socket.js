'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _appointmentTransfer = require('./appointment-transfer.events');

var _appointmentTransfer2 = _interopRequireDefault(_appointmentTransfer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  transferRequestSend(socket);
  transferRequestAccepted(socket);
  transferRequestRejected(socket);
  transferRequestTimeOut(socket);
  cancel(socket);
}

/**
 * Socket Messages
 */

function transferRequestSend(socket) {
  var listener = function listener(transferLog) {
    socket.emit('appointment:transfer:request', transferLog);
  };

  _appointmentTransfer2.default.on('appointment:transfer:request', listener);

  socket.on('disconnect', function () {
    _appointmentTransfer2.default.removeListener('appointment:transfer:request', listener);
  });
}

function transferRequestAccepted(socket) {
  var listener = function listener(transferLog) {
    socket.emit('appointment:transfer:accepted', transferLog);
  };

  _appointmentTransfer2.default.on('appointment:transfer:accepted', listener);

  socket.on('disconnect', function () {
    _appointmentTransfer2.default.removeListener('appointment:transfer:accepted', listener);
  });
}

function transferRequestRejected(socket) {
  var listener = function listener(transferLog) {
    socket.emit('appointment:transfer:rejected', transferLog);
  };

  _appointmentTransfer2.default.on('appointment:transfer:rejected', listener);

  socket.on('disconnect', function () {
    _appointmentTransfer2.default.removeListener('appointment:transfer:rejected', listener);
  });
}

function transferRequestTimeOut(socket) {
  var listener = function listener(transferLog) {
    socket.emit('appointment:transfer:timeout', transferLog);
  };

  _appointmentTransfer2.default.on('appointment:transfer:timeout', listener);

  socket.on('disconnect', function () {
    _appointmentTransfer2.default.removeListener('appointment:transfer:timeout', listener);
  });
}

function cancel(socket) {
  var listener = function listener(appointment) {
    socket.emit('appointment:cancel', appointment);
  };

  _appointmentTransfer2.default.on('appointment:cancel', listener);

  socket.on('disconnect', function () {
    _appointmentTransfer2.default.removeListener('appointment:cancel', listener);
  });
}
//# sourceMappingURL=appointment-transfer.socket.js.map
