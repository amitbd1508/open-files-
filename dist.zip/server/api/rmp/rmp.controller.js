'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.adjustment = exports.Balances = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */
var Balances = exports.Balances = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var _this = this;

    var dateStartOfMonth, dateEndOfMonth, startDate, endDate, isActive, rmps;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            dateStartOfMonth = (0, _momentTimezone2.default)().startOf('month').toDate();
            dateEndOfMonth = (0, _momentTimezone2.default)().endOf('month').toDate();
            startDate = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate).toDate() : dateStartOfMonth;
            endDate = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate).toDate() : dateEndOfMonth;
            isActive = req.query.isActive;
            _context2.next = 7;
            return (0, _bluebird.resolve)(_rmp.User.findRmps(isActive));

          case 7:
            rmps = _context2.sent;
            _context2.prev = 8;
            _context2.next = 11;
            return (0, _bluebird.resolve)((0, _bluebird.all)(rmps.map(function () {
              var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(rmp) {
                return _regenerator2.default.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.t0 = rmp.fullname;
                        _context.next = 3;
                        return (0, _bluebird.resolve)(rmp._calculateNetRevenue(rmp._id, startDate, endDate));

                      case 3:
                        _context.t1 = _context.sent;
                        _context.next = 6;
                        return (0, _bluebird.resolve)(rmp._calculateNetShare(rmp._id, startDate, endDate));

                      case 6:
                        _context.t2 = _context.sent;
                        _context.next = 9;
                        return (0, _bluebird.resolve)(rmp._calculateNetTransaction(rmp._id, startDate, endDate));

                      case 9:
                        _context.t3 = _context.sent;
                        _context.next = 12;
                        return (0, _bluebird.resolve)(rmp._calculateNetAdvance(rmp._id, startDate, endDate));

                      case 12:
                        _context.t4 = _context.sent;
                        _context.next = 15;
                        return (0, _bluebird.resolve)(rmp.calculatedBalance(startDate, endDate));

                      case 15:
                        _context.t5 = _context.sent;
                        return _context.abrupt('return', {
                          fullName: _context.t0,
                          calculated_revenue: _context.t1,
                          calculated_share: _context.t2,
                          calculated_adjustment: _context.t3,
                          calculated_bkash: _context.t4,
                          calculated_balance: _context.t5
                        });

                      case 17:
                      case 'end':
                        return _context.stop();
                    }
                  }
                }, _callee, _this);
              }));

              return function (_x3) {
                return _ref2.apply(this, arguments);
              };
            }())));

          case 11:
            rmps = _context2.sent;


            res.json({
              timestamp: Date.now(),
              rmps: rmps
            });
            _context2.next = 18;
            break;

          case 15:
            _context2.prev = 15;
            _context2.t0 = _context2['catch'](8);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 18:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[8, 15]]);
  }));

  return function Balances(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var adjustment = exports.adjustment = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var rmpId, ownerId, amount, reason, transaction;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            rmpId = req.body.rmpId;
            ownerId = req.user._id;
            amount = req.body.amount;
            reason = req.body.reason;
            _context3.next = 7;
            return (0, _bluebird.resolve)(_rmp.Adjustment.create(rmpId, ownerId, amount, reason));

          case 7:
            transaction = _context3.sent;


            res.json({
              timestamp: Date.now(),
              transaction: transaction
            });
            _context3.next = 14;
            break;

          case 11:
            _context3.prev = 11;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 11]]);
  }));

  return function adjustment(_x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}();

var _rmp = require('./rmp.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=rmp.controller.js.map
