'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.rmpPrescription = exports.Adjustment = exports.Transaction = exports.Payment = exports.User = exports.calculateRMPShare = exports._calculateNetTransaction = exports._calculateNetShare = exports._calculateNetRevenue = exports._calculateNetAdvance = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var _slicedToArray2 = require('babel-runtime/helpers/slicedToArray');

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var calculatedBalance = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(startDate, endDate) {
    var _ref2, _ref3, netAdvance, netRevenue, netShare, netTransaction;

    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            startDate = startDate ? startDate : (0, _momentTimezone2.default)().set('year', 2000).toDate();
            endDate = endDate ? endDate : (0, _momentTimezone2.default)().toDate();

            _context.next = 4;
            return (0, _bluebird.resolve)((0, _bluebird.all)([_calculateNetAdvance(this._id, startDate, endDate), _calculateNetRevenue(this._id, startDate, endDate), _calculateNetShare(this._id, startDate, endDate), _calculateNetTransaction(this._id, startDate, endDate)]));

          case 4:
            _ref2 = _context.sent;
            _ref3 = (0, _slicedToArray3.default)(_ref2, 4);
            netAdvance = _ref3[0];
            netRevenue = _ref3[1];
            netShare = _ref3[2];
            netTransaction = _ref3[3];
            return _context.abrupt('return', netAdvance + netShare + netTransaction - netRevenue);

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function calculatedBalance(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var _calculateNetAdvance = exports._calculateNetAdvance = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(rmpId, startDate, endDate) {
    var rows;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(Payment.aggregate({
              $match: {
                rmp_id: rmpId,
                created_at: {
                  $gte: startDate,
                  $lte: endDate
                }
              }
            }, {
              $group: {
                _id: null,
                advance: { $sum: '$amount' }
              }
            }).exec());

          case 2:
            rows = _context2.sent;

            if (!(rows.length > 0)) {
              _context2.next = 5;
              break;
            }

            return _context2.abrupt('return', rows[0].advance);

          case 5:
            return _context2.abrupt('return', 0);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function _calculateNetAdvance(_x3, _x4, _x5) {
    return _ref4.apply(this, arguments);
  };
}();

var _calculateNetRevenue = exports._calculateNetRevenue = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(rmpId, startDate, endDate) {
    var rows;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(Transaction.aggregate({
              $match: {
                rmp_id: rmpId,
                created_at: {
                  $gte: startDate,
                  $lte: endDate
                }
              }
            }, {
              $group: {
                _id: null,
                revenue: { $sum: '$total' }
              }
            }).exec());

          case 2:
            rows = _context3.sent;

            if (!(rows.length > 0)) {
              _context3.next = 5;
              break;
            }

            return _context3.abrupt('return', rows[0].revenue);

          case 5:
            return _context3.abrupt('return', 0);

          case 6:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function _calculateNetRevenue(_x6, _x7, _x8) {
    return _ref5.apply(this, arguments);
  };
}();

var _calculateNetShare = exports._calculateNetShare = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(rmpId, startDate, endDate) {
    var rows;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Transaction.aggregate({
              $match: {
                rmp_id: rmpId,
                created_at: {
                  $gte: startDate,
                  $lte: endDate
                }
              }
            }, {
              $group: {
                _id: null,
                share: { $sum: '$rmp_share' }
              }
            }).exec());

          case 2:
            rows = _context4.sent;

            if (!(rows.length > 0)) {
              _context4.next = 5;
              break;
            }

            return _context4.abrupt('return', rows[0].share);

          case 5:
            return _context4.abrupt('return', 0);

          case 6:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function _calculateNetShare(_x9, _x10, _x11) {
    return _ref6.apply(this, arguments);
  };
}();

var _calculateNetTransaction = exports._calculateNetTransaction = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(rmpId, startDate, endDate) {
    var rows;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(Adjustment.aggregate({
              $match: {
                rmp_id: rmpId,
                created_at: {
                  $gte: startDate,
                  $lte: endDate
                }
              }
            }, {
              $group: {
                _id: null,
                transaction: { $sum: '$amount' }
              }
            }).exec());

          case 2:
            rows = _context5.sent;

            if (!(rows.length > 0)) {
              _context5.next = 5;
              break;
            }

            return _context5.abrupt('return', rows[0].transaction);

          case 5:
            return _context5.abrupt('return', 0);

          case 6:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function _calculateNetTransaction(_x12, _x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Statics
 */


var findRmps = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(isActive) {
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(User.find({
              usertype: 'rmp',
              is_active: isActive == 'true'
            }).select('_id fullname account_balance is_active').sort('fullname _id is_active').exec());

          case 2:
            return _context6.abrupt('return', _context6.sent);

          case 3:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function findRmps(_x15) {
    return _ref8.apply(this, arguments);
  };
}();

var create = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(rmp_id, owner_id, amount, reason) {
    var adjustments;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            adjustments = new Adjustment({
              rmp_id: rmp_id,
              owner_id: owner_id,
              amount: amount,
              reason: reason
            });
            _context7.next = 3;
            return (0, _bluebird.resolve)(adjustments.save());

          case 3:
            return _context7.abrupt('return', _context7.sent);

          case 4:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function create(_x16, _x17, _x18, _x19) {
    return _ref9.apply(this, arguments);
  };
}();

var calculateRMPShare = exports.calculateRMPShare = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(prescriptionId) {
    var RMPShare, prescription, rmpShareFree, rmpShareNew, rmpShareFollowUpOrReferred, isFollowUp, isReferred, isFree, isAfterFollowUpDate, hasMedicine, condHash, condMap;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            RMPShare = 0;
            _context8.next = 3;
            return (0, _bluebird.resolve)(rmpPrescription.findById(prescriptionId).populate('rmp_id').exec());

          case 3:
            prescription = _context8.sent;

            if (prescription.payment_selected) {
              _context8.next = 20;
              break;
            }

            // There are 3 possible shares for the rmp
            rmpShareFree = 0;
            rmpShareNew = prescription.rmp_id.rmp_share_1;
            rmpShareFollowUpOrReferred = prescription.rmp_id.rmp_share_2;

            // There are 4 binary cases

            isFollowUp = prescription.is_followup;
            isReferred = prescription.is_referred;
            isFree = prescription.is_free;
            _context8.next = 13;
            return (0, _bluebird.resolve)(_fee.FeePrescription.getAppointmentType(prescription.appointment_id));

          case 13:
            isAfterFollowUpDate = _context8.sent;
            hasMedicine = prescription.instruction && prescription.instruction.length > 0;

            // Hash the 5 binary cases into a string index

            condHash = (isFollowUp ? '1' : '0') + ( // followUp - New
            isReferred ? '1' : '0') + (isFree ? '1' : '0') + (hasMedicine ? '1' : '0') + (isAfterFollowUpDate ? '1' : '0'); // new - followup

            // Condition table for all the cases

            condMap = {
              '00000': rmpShareFollowUpOrReferred,
              '00001': rmpShareNew,
              '00010': rmpShareNew,
              '00011': rmpShareNew,
              '00100': rmpShareFree,
              '00101': rmpShareFree,
              '00110': rmpShareFree,
              '00111': rmpShareFree,
              '01000': rmpShareFree,
              '01001': rmpShareFree,
              '01010': rmpShareFollowUpOrReferred,
              '01011': rmpShareFollowUpOrReferred,
              '01100': rmpShareFree,
              '01101': rmpShareFree,
              '01110': rmpShareFree,
              '01111': rmpShareFree,
              '10000': rmpShareFollowUpOrReferred,
              '10001': rmpShareNew,
              '10010': rmpShareFollowUpOrReferred,
              '10011': rmpShareNew,
              '10100': rmpShareFree,
              '10101': rmpShareFree,
              '10110': rmpShareFree,
              '10111': rmpShareFree,
              '11000': rmpShareFree,
              '11001': rmpShareFree,
              '11010': rmpShareFollowUpOrReferred,
              '11011': rmpShareFollowUpOrReferred,
              '11100': rmpShareFree,
              '11101': rmpShareFree,
              '11110': rmpShareFree,
              '11111': rmpShareFree
            };

            // Return the appropriate share

            return _context8.abrupt('return', condMap[condHash]);

          case 20:
            if (prescription.payment_selected === 'pricing 1') {
              RMPShare = prescription.rmp_id.rmp_share_1;
            } else if (prescription.payment_selected === 'pricing 2') {
              RMPShare = prescription.rmp_id.rmp_share_2;
            } else if (prescription.payment_selected === 'other') {
              if (prescription.fee === 0) {
                RMPShare = 0;
              } else if (parseInt(prescription.fee) > 100 && !prescription.is_followup) {
                RMPShare = prescription.rmp_id.rmp_share_1;
              } else if (prescription.fee > 100 && prescription.is_followup) {
                RMPShare = prescription.rmp_id.rmp_share_2;
              }
            }

          case 21:
            return _context8.abrupt('return', RMPShare);

          case 22:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function calculateRMPShare(_x20) {
    return _ref10.apply(this, arguments);
  };
}();

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

var _payment = require('../../schemas/payment.schema');

var _payment2 = _interopRequireDefault(_payment);

var _transaction = require('../../schemas/transaction.schema');

var _transaction2 = _interopRequireDefault(_transaction);

var _adjustment = require('../../schemas/adjustment.schema');

var _adjustment2 = _interopRequireDefault(_adjustment);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _fee = require('../fee/fee.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Methods
 */
_user2.default.method('calculatedBalance', calculatedBalance).method('_calculateNetAdvance', _calculateNetAdvance).method('_calculateNetRevenue', _calculateNetRevenue).method('_calculateNetShare', _calculateNetShare).method('_calculateNetTransaction', _calculateNetTransaction);

_user2.default.static('findRmps', findRmps).static('calculateRMPShare', calculateRMPShare);

_adjustment2.default.static('create', create);

_prescription2.default.static('create', create);

var User = exports.User = _mongoose2.default.model('RmpUser', _user2.default, 'users');
var Payment = exports.Payment = _mongoose2.default.model('RmpPayment', _payment2.default, 'payments');
var Transaction = exports.Transaction = _mongoose2.default.model('RmpTransaction', _transaction2.default, 'transactions');
var Adjustment = exports.Adjustment = _mongoose2.default.model('RmpAdjustment', _adjustment2.default, 'adjustments');
var rmpPrescription = exports.rmpPrescription = _mongoose2.default.model('rmpPrescription', _prescription2.default, 'prescriptions');
//# sourceMappingURL=rmp.model.js.map
