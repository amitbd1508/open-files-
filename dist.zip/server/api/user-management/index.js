'use strict';

/**
 * Imports
 */
// import * as auth from '../../auth/auth.service';

var express = require('express');
var controller = require('./user-management.controller');

var router = express.Router();

/**
 * Routes
 */

router.get('/users/:id/territories', controller.getTerritoryByUserId);

router.put('/users/:id/territories', controller.saveTerritoryByUserId);

router.get('/users/territories', controller.getTerritories);

router.get('/users', controller.getUsers);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
