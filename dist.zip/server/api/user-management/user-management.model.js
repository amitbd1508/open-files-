'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UserManagement = exports.getUsersIdWithTerritories = exports.getTerritories = exports.getTerritoryByUserId = exports.saveTerritoryByUserId = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */
var saveTerritoryByUserId = exports.saveTerritoryByUserId = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(userId, formBody) {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(userId, {
              'territories': formBody.territories
            }, {
              new: true
            }).lean().exec());

          case 2:
            return _context.abrupt('return', _context.sent);

          case 3:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function saveTerritoryByUserId(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var getTerritoryByUserId = exports.getTerritoryByUserId = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(userId) {
    var user;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.findById(userId).select('territories').exec());

          case 2:
            user = _context2.sent;
            return _context2.abrupt('return', user.territories);

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getTerritoryByUserId(_x3) {
    return _ref2.apply(this, arguments);
  };
}();

var getTerritories = exports.getTerritories = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3() {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(this.distinct('territories').exec());

          case 2:
            return _context3.abrupt('return', _context3.sent);

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getTerritories() {
    return _ref3.apply(this, arguments);
  };
}();

var getUsersIdWithTerritories = exports.getUsersIdWithTerritories = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4() {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.find({ "usertype": "rmp" }).select("territories").lean().exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function getUsersIdWithTerritories() {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Exports
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_user2.default.static('saveTerritoryByUserId', saveTerritoryByUserId).static('getTerritoryByUserId', getTerritoryByUserId).static('getTerritories', getTerritories).static('getUsersIdWithTerritories', getUsersIdWithTerritories);var UserManagement = exports.UserManagement = _mongoose2.default.model('UserManagement', _user2.default, 'users');
//# sourceMappingURL=user-management.model.js.map
