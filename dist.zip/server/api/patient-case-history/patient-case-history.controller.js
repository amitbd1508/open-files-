'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findByPatientIdAndGetCaseHistory = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var _slicedToArray2 = require('babel-runtime/helpers/slicedToArray');

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

/**
 * Actions
 */

var findByPatientIdAndGetCaseHistory = exports.findByPatientIdAndGetCaseHistory = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var _ref2, _ref3, patient, prescriptions;

    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            _context.next = 3;
            return (0, _bluebird.resolve)((0, _bluebird.all)([_patientCaseHistory.PatientCaseHistory.findById(req.params.patientId), _patientCaseHistory.PrescriptionCaseHistory.findByPatientIdAndGetCaseHistory(req.params.patientId)]));

          case 3:
            _ref2 = _context.sent;
            _ref3 = (0, _slicedToArray3.default)(_ref2, 2);
            patient = _ref3[0];
            prescriptions = _ref3[1];


            res.json({
              timestamp: Date.now(),
              patient: patient,
              prescriptions: prescriptions
            });
            _context.next = 13;
            break;

          case 10:
            _context.prev = 10;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0
            });

          case 13:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 10]]);
  }));

  return function findByPatientIdAndGetCaseHistory(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var _patientCaseHistory = require('./patient-case-history.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=patient-case-history.controller.js.map
