'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PrescriptionCaseHistory = exports.AppointmentCaseHistory = exports.PatientCaseHistory = exports.DoctorCaseHistory = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Static functions
 */

var findByPatientIdAndGetCaseHistory = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(patientId) {
    var patient;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(PatientCaseHistory.findById(patientId).exec());

          case 2:
            patient = _context.sent;
            _context.next = 5;
            return (0, _bluebird.resolve)(PrescriptionCaseHistory.find({
              is_pdfready: true,
              patients_id: patient._id
            }).populate('appointment_id').populate({
              path: 'doctors_id',
              select: 'fullname'
            }).sort({
              updated_at: 1
            }).exec());

          case 5:
            return _context.abrupt('return', _context.sent);

          case 6:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findByPatientIdAndGetCaseHistory(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Exports
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Schemas
 */

var DoctorCaseHistorySchema = new _mongoose.Schema({
  profile_pic: String,
  fullname: String,
  identity: String,
  specialized: String,
  email: String
});

var PatientCaseHistorySchema = new _mongoose.Schema({
  fullname: String,
  serialnumber: String,
  profilepiclink: String,
  phone: String,
  gender: String,
  dob: Date
});

var AppointmentCaseHistorySchema = new _mongoose.Schema({
  patient_weight: Number,
  patient_temp: Number,
  patient_pulse: Number,
  patient_systole: Number,
  patient_diastole: Number,
  patient_glucose: Number,

  symptoms: [String],
  patients_images: [String]
});

var PrescriptionCaseHistorySchema = new _mongoose.Schema({
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AppointmentCaseHistory'
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'PatientCaseHistory'
  },
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'RmpCaseHistory'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorCaseHistory'
  },

  is_pdfready: Boolean,
  pdflink: String,

  symptoms: [String],
  encodedSymptoms: [],

  personalinfo: [],
  familyinfo: [],
  druginfo: [],
  chronicinfo: [],

  is_followup: Boolean,
  is_referred: Boolean,
  followup_date: Date,

  chief_complaint: [{
    complainText: String,
    complainValue: Number,
    complainDur: String,
    complainDetail: String
  }],

  diagnosis: [String],
  diagnoses: {
    type: Object,
    default: {
      provisional: {
        type: Array,
        default: []
      },
      differential: {
        type: Array,
        default: []
      },
      final: {
        type: Array,
        default: []
      }
    }
  },
  investigations: [],
  advices: [],

  instruction: [{
    // FIXME: Should just be a single object instead of always an array of one value.
    selected: [{
      generic_name: String,
      trade_name: String,
      formulation: String
    }],
    // FIXME: Should just be an array of strings or numbers.
    doses: Object,
    duration: String,
    duration_type: String,
    // FIXME: Should just be an array of strings.
    instructions: [{
      text: String
    }],
    // FIXME: Should just be an array of strings.
    additional_instructions: [{
      text: String
    }]
  }]
});

/**
 * Options
 */
DoctorCaseHistorySchema.set('toJSON', {
  transform: transformDoctorToJSON
});

PatientCaseHistorySchema.set('toJSON', {
  transform: transformPatientToJSON
});

AppointmentCaseHistorySchema.set('toJSON', {
  transform: transformAppointmentToJSON
});

PrescriptionCaseHistorySchema.set('toJSON', {
  transform: transformPrescriptionToJSON
});

/**
 * Statics
 */

PrescriptionCaseHistorySchema.static('findByPatientIdAndGetCaseHistory', findByPatientIdAndGetCaseHistory);

/**
 * Transform functions
 */
function transformDoctorToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,
    name: ret.fullname,
    identity: ret.identity,
    speciality: ret.specialized,
    email: ret.email
  };
}

function transformPatientToJSON(doc, ret) {
  return {
    Name: ret.fullname,
    Profile_pic: ret.profilepiclink,
    Sex: ret.gender,
    Age: (0, _momentTimezone2.default)().diff((0, _momentTimezone2.default)(ret.dob), 'years'),
    Phone: ret.phone
  };
}

function transformAppointmentToJSON(doc, ret) {
  return {
    weight: ret.patient_weight,
    temperature: ret.patient_temp,
    pulse: ret.patient_pulse,
    systole: ret.patient_systole,
    diastole: ret.patient_diastole,
    glucose: ret.patient_glucose,

    images: ret.patients_images
  };
}

function transformPrescriptionToJSON(doc, ret) {
  return {
    prescription_id: ret._id,
    prescriptionUpdate: ret.updated_at,
    prescriptionCreated: ret.created_at,

    pdfLink: ret.pdflink,

    rmp: ret.rmp_id,
    fee: ret.fee,
    doctor: ret.doctors_id,
    appointment: ret.appointment_id,

    is_followup: ret.is_followup,
    is_referred: ret.is_referred,
    followUpDate: ret.followup_date,

    symptoms: ret.symptoms,
    note: ret.note,

    diagnoses: arrayNullChecker(ret.diagnoses),

    history: {
      personal: ret.personalinfo,
      family: ret.familyinfo,
      drug: ret.druginfo,
      chronic: ret.chronicinfo
    },

    Chief_complaint: ret.chief_complaint.map(function (complaint) {
      return {
        description: complaint.complainText,
        duration: {
          value: complaint.complainValue,
          type: complaint.complainDur
        },
        additional_description: complaint.complainDetail
      };
    }),

    chiefComplaint: ret.encodedSymptoms,

    diagnosis: ret.diagnosis.map(function (diagnosis) {
      return diagnosis;
    }),

    investigations: ret.investigations,
    advices: ret.advices,

    medicine: ret.instruction
  };
}

function arrayNullChecker(data) {
  if (data === undefined) {
    return {
      provisional: [],
      differential: [],
      final: []
    };
  } else {
    return data;
  }
}var DoctorCaseHistory = exports.DoctorCaseHistory = _mongoose2.default.model('DoctorCaseHistory', DoctorCaseHistorySchema, 'users');
var PatientCaseHistory = exports.PatientCaseHistory = _mongoose2.default.model('PatientCaseHistory', PatientCaseHistorySchema, 'patients');
var AppointmentCaseHistory = exports.AppointmentCaseHistory = _mongoose2.default.model('AppointmentCaseHistory', AppointmentCaseHistorySchema, 'appointments');
var PrescriptionCaseHistory = exports.PrescriptionCaseHistory = _mongoose2.default.model('PrescriptionCaseHistory', PrescriptionCaseHistorySchema, 'prescriptions');
//# sourceMappingURL=patient-case-history.model.js.map
