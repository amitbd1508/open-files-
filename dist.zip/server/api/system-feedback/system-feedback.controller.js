'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getLogoutFeedback = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */
var getLogoutFeedback = exports.getLogoutFeedback = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var uid, user, feedback, startDate, endDate, appointmentIds, minMaxTimeTook, eventType;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            uid = req.user._id;
            _context.next = 4;
            return (0, _bluebird.resolve)(_user2.default.findById(uid));

          case 4:
            user = _context.sent;
            feedback = {};

            if (!(user.usertype === 'doctor')) {
              _context.next = 20;
              break;
            }

            startDate = (0, _momentTimezone2.default)().startOf('day').toDate();
            endDate = (0, _momentTimezone2.default)().toDate();
            _context.next = 11;
            return (0, _bluebird.resolve)(_doctor.Appointment.findPrescriptionIdsByDoctorIdAndDates(uid, startDate, endDate));

          case 11:
            appointmentIds = _context.sent;


            feedback.timeout = 5 * 60 * 1000;
            feedback.user = { _id: uid, name: user.name, usertype: user.usertype };
            feedback.patientsCount = appointmentIds.length;

            _context.next = 17;
            return (0, _bluebird.resolve)(_doctor.Appointment.findMinMaxTimeTookByIds(appointmentIds));

          case 17:
            minMaxTimeTook = _context.sent;


            feedback.longestConsultation = Math.floor(minMaxTimeTook.max / 60);
            feedback.shortestConsultation = Math.floor(minMaxTimeTook.min / 60);

          case 20:

            //save logout time with userAgent for  user
            eventType = 'logout';

            _userLogSingInOut.UserSignInOutLog.logUserEvent(uid, req, eventType);

            res.json({
              timestamp: Date.now(),
              feedback: feedback
            }).end();
            _context.next = 28;
            break;

          case 25:
            _context.prev = 25;
            _context.t0 = _context['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 28:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 25]]);
  }));

  return function getLogoutFeedback(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var _user = require('../user/user.model');

var _user2 = _interopRequireDefault(_user);

var _doctor = require('../doctor/doctor.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _userLogSingInOut = require('../user-log-sign-in-out/user-log-sing-in-out.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=system-feedback.controller.js.map
