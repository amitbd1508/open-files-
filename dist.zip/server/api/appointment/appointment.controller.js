'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findAppointments = exports.load = exports.findBookedTimes = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var findBookedTimes = exports.findBookedTimes = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, appointment;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            _context.next = 5;
            return (0, _bluebird.resolve)(_appointment.Appointment.findBookedTimes(startDate, endDate));

          case 5:
            appointment = _context.sent;


            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context.next = 12;
            break;

          case 9:
            _context.prev = 9;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 12:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 9]]);
  }));

  return function findBookedTimes(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var load = exports.load = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var appointmentId, appointment;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            appointmentId = req.params.id;

            if (!appointmentId) res.status(400).end();

            _context2.next = 5;
            return (0, _bluebird.resolve)(_appointment.Appointment.load(appointmentId));

          case 5:
            appointment = _context2.sent;


            res.json({
              timestamp: Date.now(),
              appointment: appointment
            });
            _context2.next = 12;
            break;

          case 9:
            _context2.prev = 9;
            _context2.t0 = _context2['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 12:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 9]]);
  }));

  return function load(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findAppointments = exports.findAppointments = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var limit, skip, isBooked, isPrescribed, query, appointments;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            limit = req.query.limit || 50;
            skip = req.query.skip || 0;
            isBooked = req.query.booked || true;
            isPrescribed = req.query.isPrescribed || false;
            query = {
              is_booked: isBooked,
              is_prescribed: isPrescribed
            };
            _context3.prev = 5;
            _context3.next = 8;
            return (0, _bluebird.resolve)(_appointment.Appointment.findAppointments(query, skip, limit));

          case 8:
            appointments = _context3.sent;


            res.json({
              timestamp: Date.now(),
              appointments: appointments
            });
            _context3.next = 15;
            break;

          case 12:
            _context3.prev = 12;
            _context3.t0 = _context3['catch'](5);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0
            });

          case 15:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[5, 12]]);
  }));

  return function findAppointments(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var _appointment = require('./appointment.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=appointment.controller.js.map
