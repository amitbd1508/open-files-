'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Prescription = exports.Appointment = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Find all appointments scheduled for, or updated at, today (in Dhaka time).
 *
 * @returns {Promise}
 */

var load = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(id) {
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.findById(id).populate('rmp_id doctors_id').populate({
              path: 'patients_id',
              populate: 'village'
            }).exec());

          case 2:
            return _context.abrupt('return', _context.sent);

          case 3:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function load(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * @param query
 * @param skip
 * @param limit
 * @returns {Promise.<*>}
 */


var findAppointments = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(query, skip, limit) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(this.find(query).skip(skip).limit(limit).populate({
              path: 'rmp_id doctors_id patients_id',
              select: 'fullname phone phone_tab email identity specialized gender serialnumber profilepiclink profile_url center'
            }).sort('timestamp.book_by_rmp').exec());

          case 2:
            return _context2.abrupt('return', _context2.sent);

          case 3:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findAppointments(_x2, _x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findByScheduledOrUpdatedToday = function () {
  var _ref3 = (0, _bluebird.method)(function () {
    var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('day').toDate();
    var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('day').toDate();

    return this.findByScheduledAtOrUpdatedAt(startDate, endDate);
  });

  return function findByScheduledOrUpdatedToday() {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Find all appointments schedule for, or updated at, between a date range.
 *
 * @param startDate
 * @param endDate
 * @returns {Promise}
 */


var findByScheduledAtOrUpdatedAt = function () {
  var _ref4 = (0, _bluebird.method)(function (startDate, endDate) {
    return this.find({
      is_booked: true,
      $or: [{
        start: {
          $gte: startDate,
          $lte: endDate
        }
      }, {
        updated_at: {
          $gte: startDate,
          $lte: endDate
        }
      }]
    }).populate('rmp_id doctors_id patients_id').sort('start doctors_id').exec();
  });

  return function findByScheduledAtOrUpdatedAt(_x5, _x6) {
    return _ref4.apply(this, arguments);
  };
}();

var findBookedTimes = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(startDate, endDate) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            startDate = startDate || new Date(0);
            endDate = endDate || new Date();

            _context3.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: {
                is_booked: true,
                timestamp: { $exists: true },
                created_at: { $gte: startDate, $lte: endDate }
              }
            }, {
              $project: {
                timestamp: '$timestamp.book_by_rmp'
              }
            }, {
              $group: {
                _id: {
                  hour: { $hour: "$timestamp" }
                },
                total: { $sum: 1 }
              }
            }, {
              $project: {
                _id: 0,
                hours: '$_id.hour',
                total: '$total'
              }
            }, {
              $sort: {
                hours: 1
              }
            }]));

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findBookedTimes(_x7, _x8) {
    return _ref5.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _environment = require('../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

var _appointment = require('../../schemas/appointment.schema');

var _appointment2 = _interopRequireDefault(_appointment);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */
var TIMEZONE = _environment2.default.scheduleTimeZone;

/**
 * Statics
 */

_appointment2.default.static('findByScheduledOrUpdatedToday', findByScheduledOrUpdatedToday).static('findByScheduledAtOrUpdatedAt', findByScheduledAtOrUpdatedAt).static('findAppointments', findAppointments).static('findBookedTimes', findBookedTimes).static('load', load);var Appointment = exports.Appointment = _mongoose2.default.model('Appointment', _appointment2.default);
var Prescription = exports.Prescription = _mongoose2.default.model('AppointmentPrescription ', _prescription2.default, 'prescriptions');

/**
 * Exports
 */
exports.default = Appointment;
//# sourceMappingURL=appointment.model.js.map
