'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _prescription = require('./prescription.events');

var _prescription2 = _interopRequireDefault(_prescription);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  publish(socket);
  update(socket);

  refreshPrescriptionNote(socket);
}

/**
 * Socket Messages
 */

/**
 * Refresh Appointments Message
 *
 * @param socket
 */
function publish(socket) {
  var listener = function listener() {
    socket.emit('prescription:publish', {
      timestamp: Date.now()
    });
  };

  _prescription2.default.on('prescription:publish', listener);

  socket.on('disconnect', function () {
    _prescription2.default.removeListener('prescription:publish', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('prescription:update', {
      timestamp: Date.now()
    });
  };

  _prescription2.default.on('prescription:update', listener);

  socket.on('disconnect', function () {
    _prescription2.default.removeListener('prescription:update', listener);
  });
}

function refreshPrescriptionNote(socket) {
  var listener = function listener() {
    socket.emit('prescription:note:refresh', {
      timestamp: Date.now()
    });
  };

  _prescription2.default.on('prescription:note:refresh', listener);

  socket.on('disconnect', function () {
    _prescription2.default.removeListener('prescription:note:refresh', listener);
  });
}
//# sourceMappingURL=prescription.socket.js.map
