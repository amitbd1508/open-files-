'use strict';

/**
 * Imports
 */

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./prescription.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', auth.hasUserType(['doctor', 'admin', 'cca']), controller.list);

router.get('/count', controller.countPrescriptions);

router.get('/findServed', controller.findServed);
router.get('/findReferred', controller.findReferred);
router.get('/findFollowup', controller.findFollowup);

router.get('/findPatientServedByCenterByYear', controller.findPatientServedByCenterByYear);
router.get('/findPatientServedByRmpByYear', controller.findPatientServedByRmpByYear);

router.get('/findPatientServedByHPO', controller.findPatientServedByHPO);
router.get('/findPatientServedByCenter', controller.findPatientServedByCenter);
router.get('/findPatientServedByTE', controller.findPatientServedByTE);
router.get('/findPatientServedByRmp', controller.findPatientServedByRmp);
router.get('/findPatientServedByDoctor', controller.findPatientServedByDoctor);

router.get('/transactions', auth.hasUserType(['admin', 'cca', 'te']), controller.transactions);

router.get('/findPatientServedByRmpByMonthByYear', controller.findPatientServedByRmpByMonthByYear);
router.get('/findPatientServedByCenterByMonthByYear', controller.findPatientServedByCenterByMonthByYear);
router.get('/findPatientServedByHpoByMonthByYear', controller.findPatientServedByHpoByMonthByYear);

router.get('/findPatientServedByFee', auth.isAuthenticated(), controller.findPatientServedByFee);

router.get('/findDelayedPrescriptions', controller.findDelayedPrescriptions);
router.get('/findServeAverageTime', controller.findServeAverageTime);

router.get('/history/family', auth.hasUserType(['doctor', 'admin']), controller.familyHistory);
router.get('/history/personal', auth.hasUserType(['doctor', 'admin']), controller.personalHistory);
router.get('/history/drug', auth.hasUserType(['doctor', 'admin']), controller.drugHistory);
router.get('/history/chronic', auth.hasUserType(['doctor', 'admin']), controller.chronicHistory);
router.get('/history/allergy', auth.hasUserType(['doctor', 'admin']), controller.allergyHistory);

// To update follow-up date
router.put('/followupDate/:prescriptionId', auth.isAuthenticated(), controller.updateFollowUpDate);

router.get('/unPayed', controller.unPayed);
router.get('/:prescriptionId/pdf', auth.isAuthenticated(), controller.findPdf);

router.get('/:prescriptionId', auth.isAuthenticated(), controller.load);
router.post('/', auth.hasUserType(['doctor', 'admin']), controller.save);
router.patch('/:prescriptionId/publish', auth.hasUserType(['doctor', 'admin']), controller.publish);

// create a prescription call center survey note
router.post('/:prescriptionId/note', auth.isAuthenticated(), controller.createOrUpdatePrescriptionNote);

// list of prescription call center survey notes
router.get('/:prescriptionId/note', auth.isAuthenticated(), controller.findPrescriptionNoteByPrescriptionId);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
