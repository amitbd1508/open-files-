'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var PrescriptionEvents = new _events.EventEmitter();

/**
 * Options
 */
PrescriptionEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = PrescriptionEvents;
//# sourceMappingURL=prescription.events.js.map
