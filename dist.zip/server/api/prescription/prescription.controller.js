'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.publish = exports.save = exports.load = exports.findPrescriptionNoteByPrescriptionId = exports.createOrUpdatePrescriptionNote = exports.allergyHistory = exports.chronicHistory = exports.drugHistory = exports.familyHistory = exports.personalHistory = exports.unPayed = exports.updateFollowUpDate = exports.countPrescriptions = exports.findServeAverageTime = exports.findDelayedPrescriptions = exports.findPatientServedByFee = exports.findPatientServedByHpoByMonthByYear = exports.findPatientServedByCenterByMonthByYear = exports.findPatientServedByRmpByMonthByYear = exports.findPatientServedByDoctor = exports.findPatientServedByRmp = exports.findPatientServedByTE = exports.findPatientServedByHPO = exports.findPatientServedByRmpByYear = exports.findPatientServedByCenterByYear = exports.findPatientServedByCenter = exports.findFollowup = exports.findReferred = exports.findServed = exports.findPdf = exports.transactions = exports.list = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

/**
 * @param req
 * @param res
 */
var list = exports.list = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, skip, limit, type, doctorIds, rmpIds, prescriptions;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            skip = req.query.skip;
            limit = req.query.limit;
            type = req.query.type;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            _context.next = 10;
            return (0, _bluebird.resolve)(_prescription.Prescription.all(startDate, endDate, skip, limit, type, rmpIds, doctorIds));

          case 10:
            prescriptions = _context.sent;


            res.json({
              timestamp: Date.now(),
              prescriptions: prescriptions
            });
            _context.next = 17;
            break;

          case 14:
            _context.prev = 14;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 17:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 14]]);
  }));

  return function list(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var transactions = exports.transactions = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var startDate, endDate, skip, limit, doctorIds, rmpIds, _transactions;

    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            skip = req.query.skip;
            limit = req.query.limit;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            _context2.next = 9;
            return (0, _bluebird.resolve)(_prescription.PrescriptionTransactions.findTransactions(startDate, endDate, doctorIds, rmpIds, skip, limit));

          case 9:
            _transactions = _context2.sent;


            res.json({
              timestamp: Date.now(),
              transactions: _transactions
            });
            _context2.next = 16;
            break;

          case 13:
            _context2.prev = 13;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0.toString()
            });

          case 16:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 13]]);
  }));

  return function transactions(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findPdf = exports.findPdf = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var prescription;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return (0, _bluebird.resolve)(_prescription.Prescription.findByIdForPdf(req.params.prescriptionId));

          case 3:
            prescription = _context3.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context3.next = 10;
            break;

          case 7:
            _context3.prev = 7;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0.toString()
            });

          case 10:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 7]]);
  }));

  return function findPdf(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findServed = exports.findServed = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context4.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findServed(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context4.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context4.next = 15;
            break;

          case 12:
            _context4.prev = 12;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 15:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 12]]);
  }));

  return function findServed(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var findReferred = exports.findReferred = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context5.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findReferred(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context5.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context5.next = 15;
            break;

          case 12:
            _context5.prev = 12;
            _context5.t0 = _context5['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context5.t0.toString()
            });

          case 15:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[0, 12]]);
  }));

  return function findReferred(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var findFollowup = exports.findFollowup = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context6.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findFollowup(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context6.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context6.next = 15;
            break;

          case 12:
            _context6.prev = 12;
            _context6.t0 = _context6['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0.toString()
            });

          case 15:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[0, 12]]);
  }));

  return function findFollowup(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var findPatientServedByCenter = exports.findPatientServedByCenter = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _context7.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context7.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByCenter(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context7.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context7.next = 15;
            break;

          case 12:
            _context7.prev = 12;
            _context7.t0 = _context7['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context7.t0.toString()
            });

          case 15:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[0, 12]]);
  }));

  return function findPatientServedByCenter(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var findPatientServedByCenterByYear = exports.findPatientServedByCenterByYear = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(req, res) {
    var year, doctorIds, rmpIds, type, startDate, endDate, prescription;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            _context8.prev = 0;
            year = parseInt(req.query.year, 10) || parseInt(2017, 10);
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            startDate = (0, _momentTimezone2.default)().set('year', year).startOf('year').toDate();
            endDate = (0, _momentTimezone2.default)().set('year', year).endOf('year').toDate();
            _context8.next = 9;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByCenterByYear(startDate, endDate, type, rmpIds, doctorIds));

          case 9:
            prescription = _context8.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context8.next = 16;
            break;

          case 13:
            _context8.prev = 13;
            _context8.t0 = _context8['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context8.t0.toString()
            });

          case 16:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this, [[0, 13]]);
  }));

  return function findPatientServedByCenterByYear(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

var findPatientServedByRmpByYear = exports.findPatientServedByRmpByYear = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(req, res) {
    var year, doctorIds, rmpIds, type, startDate, endDate, prescription;
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.prev = 0;
            year = parseInt(req.query.year, 10) || parseInt(2017, 10);
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            startDate = (0, _momentTimezone2.default)().set('year', year).startOf('year').toDate();
            endDate = (0, _momentTimezone2.default)().set('year', year).endOf('year').toDate();
            _context9.next = 9;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByRmpByYear(startDate, endDate, type, rmpIds, doctorIds));

          case 9:
            prescription = _context9.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context9.next = 16;
            break;

          case 13:
            _context9.prev = 13;
            _context9.t0 = _context9['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context9.t0.toString()
            });

          case 16:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this, [[0, 13]]);
  }));

  return function findPatientServedByRmpByYear(_x17, _x18) {
    return _ref9.apply(this, arguments);
  };
}();

var findPatientServedByHPO = exports.findPatientServedByHPO = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            _context10.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context10.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByHPO(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context10.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context10.next = 15;
            break;

          case 12:
            _context10.prev = 12;
            _context10.t0 = _context10['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context10.t0.toString()
            });

          case 15:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this, [[0, 12]]);
  }));

  return function findPatientServedByHPO(_x19, _x20) {
    return _ref10.apply(this, arguments);
  };
}();

var findPatientServedByTE = exports.findPatientServedByTE = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee11(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            _context11.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context11.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByTE(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context11.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context11.next = 15;
            break;

          case 12:
            _context11.prev = 12;
            _context11.t0 = _context11['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context11.t0.toString()
            });

          case 15:
          case 'end':
            return _context11.stop();
        }
      }
    }, _callee11, this, [[0, 12]]);
  }));

  return function findPatientServedByTE(_x21, _x22) {
    return _ref11.apply(this, arguments);
  };
}();

var findPatientServedByRmp = exports.findPatientServedByRmp = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee12(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee12$(_context12) {
      while (1) {
        switch (_context12.prev = _context12.next) {
          case 0:
            _context12.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context12.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByRmp(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context12.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context12.next = 15;
            break;

          case 12:
            _context12.prev = 12;
            _context12.t0 = _context12['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context12.t0.toString()
            });

          case 15:
          case 'end':
            return _context12.stop();
        }
      }
    }, _callee12, this, [[0, 12]]);
  }));

  return function findPatientServedByRmp(_x23, _x24) {
    return _ref12.apply(this, arguments);
  };
}();

var findPatientServedByDoctor = exports.findPatientServedByDoctor = function () {
  var _ref13 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee13(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee13$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            _context13.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context13.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByDoctor(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context13.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context13.next = 15;
            break;

          case 12:
            _context13.prev = 12;
            _context13.t0 = _context13['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context13.t0.toString()
            });

          case 15:
          case 'end':
            return _context13.stop();
        }
      }
    }, _callee13, this, [[0, 12]]);
  }));

  return function findPatientServedByDoctor(_x25, _x26) {
    return _ref13.apply(this, arguments);
  };
}();

var findPatientServedByRmpByMonthByYear = exports.findPatientServedByRmpByMonthByYear = function () {
  var _ref14 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee14(req, res) {
    var month, year, doctorIds, rmpIds, type, startDate, endDate, prescription;
    return _regenerator2.default.wrap(function _callee14$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            _context14.prev = 0;
            month = parseInt(req.query.month, 10) || 0;
            year = parseInt(req.query.year, 10) || 2016;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            startDate = (0, _momentTimezone2.default)().month(month).set('year', year).startOf('month').toDate();
            endDate = (0, _momentTimezone2.default)().month(month).set('year', year).endOf('month').toDate();
            _context14.next = 10;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByRmpByMonthByYear(startDate, endDate, type, rmpIds, doctorIds));

          case 10:
            prescription = _context14.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context14.next = 17;
            break;

          case 14:
            _context14.prev = 14;
            _context14.t0 = _context14['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context14.t0.toString()
            });

          case 17:
          case 'end':
            return _context14.stop();
        }
      }
    }, _callee14, this, [[0, 14]]);
  }));

  return function findPatientServedByRmpByMonthByYear(_x27, _x28) {
    return _ref14.apply(this, arguments);
  };
}();

var findPatientServedByCenterByMonthByYear = exports.findPatientServedByCenterByMonthByYear = function () {
  var _ref15 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee15(req, res) {
    var month, year, doctorIds, rmpIds, type, startDate, endDate, prescription;
    return _regenerator2.default.wrap(function _callee15$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            _context15.prev = 0;
            month = parseInt(req.query.month, 10) || 0;
            year = parseInt(req.query.year, 10) || 2016;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            startDate = (0, _momentTimezone2.default)().month(month).set('year', year).startOf('month').toDate();
            endDate = (0, _momentTimezone2.default)().month(month).set('year', year).endOf('month').toDate();
            _context15.next = 10;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByCenterByMonthByYear(startDate, endDate, type, rmpIds, doctorIds));

          case 10:
            prescription = _context15.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context15.next = 17;
            break;

          case 14:
            _context15.prev = 14;
            _context15.t0 = _context15['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context15.t0.toString()
            });

          case 17:
          case 'end':
            return _context15.stop();
        }
      }
    }, _callee15, this, [[0, 14]]);
  }));

  return function findPatientServedByCenterByMonthByYear(_x29, _x30) {
    return _ref15.apply(this, arguments);
  };
}();

var findPatientServedByHpoByMonthByYear = exports.findPatientServedByHpoByMonthByYear = function () {
  var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee16(req, res) {
    var month, year, doctorIds, rmpIds, type, startDate, endDate, prescription;
    return _regenerator2.default.wrap(function _callee16$(_context16) {
      while (1) {
        switch (_context16.prev = _context16.next) {
          case 0:
            _context16.prev = 0;
            month = parseInt(req.query.month, 10) || 0;
            year = parseInt(req.query.year, 10) || 2017;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            startDate = (0, _momentTimezone2.default)().month(month).set('year', year).startOf('month').toDate();
            endDate = (0, _momentTimezone2.default)().month(month).set('year', year).endOf('month').toDate();
            _context16.next = 10;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByHpoByMonthByYear(startDate, endDate, type, rmpIds, doctorIds));

          case 10:
            prescription = _context16.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context16.next = 17;
            break;

          case 14:
            _context16.prev = 14;
            _context16.t0 = _context16['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context16.t0.toString()
            });

          case 17:
          case 'end':
            return _context16.stop();
        }
      }
    }, _callee16, this, [[0, 14]]);
  }));

  return function findPatientServedByHpoByMonthByYear(_x31, _x32) {
    return _ref16.apply(this, arguments);
  };
}();

var findPatientServedByFee = exports.findPatientServedByFee = function () {
  var _ref17 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee17(req, res) {
    var startDate, endDate, doctorIds, rmpIds, type, prescription;
    return _regenerator2.default.wrap(function _callee17$(_context17) {
      while (1) {
        switch (_context17.prev = _context17.next) {
          case 0:
            _context17.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            type = req.query.type;
            _context17.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPatientServedByFee(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context17.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context17.next = 15;
            break;

          case 12:
            _context17.prev = 12;
            _context17.t0 = _context17['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context17.t0.toString()
            });

          case 15:
          case 'end':
            return _context17.stop();
        }
      }
    }, _callee17, this, [[0, 12]]);
  }));

  return function findPatientServedByFee(_x33, _x34) {
    return _ref17.apply(this, arguments);
  };
}();

var findDelayedPrescriptions = exports.findDelayedPrescriptions = function () {
  var _ref18 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee18(req, res) {
    var startDate, endDate, type, doctorIds, rmpIds, startPoint, prescription;
    return _regenerator2.default.wrap(function _callee18$(_context18) {
      while (1) {
        switch (_context18.prev = _context18.next) {
          case 0:
            _context18.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            type = req.query.type;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            startPoint = req.query.startPoint === 'Booked at' ? '$appointment.timestamp.book_by_rmp' : '$appointment.start';
            _context18.next = 9;
            return (0, _bluebird.resolve)(_prescription.Prescription.findDelayedPrescriptions(startDate, endDate, type, rmpIds, doctorIds, startPoint));

          case 9:
            prescription = _context18.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context18.next = 16;
            break;

          case 13:
            _context18.prev = 13;
            _context18.t0 = _context18['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context18.t0.toString()
            });

          case 16:
          case 'end':
            return _context18.stop();
        }
      }
    }, _callee18, this, [[0, 13]]);
  }));

  return function findDelayedPrescriptions(_x35, _x36) {
    return _ref18.apply(this, arguments);
  };
}();

var findServeAverageTime = exports.findServeAverageTime = function () {
  var _ref19 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee19(req, res) {
    var startDate, endDate, type, doctorIds, rmpIds, prescription;
    return _regenerator2.default.wrap(function _callee19$(_context19) {
      while (1) {
        switch (_context19.prev = _context19.next) {
          case 0:
            _context19.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            type = req.query.type;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            _context19.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.findServeAverageTime(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            prescription = _context19.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context19.next = 15;
            break;

          case 12:
            _context19.prev = 12;
            _context19.t0 = _context19['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context19.t0.toString()
            });

          case 15:
          case 'end':
            return _context19.stop();
        }
      }
    }, _callee19, this, [[0, 12]]);
  }));

  return function findServeAverageTime(_x37, _x38) {
    return _ref19.apply(this, arguments);
  };
}();

var countPrescriptions = exports.countPrescriptions = function () {
  var _ref20 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee20(req, res) {
    var startDate, endDate, type, doctorIds, rmpIds, _countPrescriptions;

    return _regenerator2.default.wrap(function _callee20$(_context20) {
      while (1) {
        switch (_context20.prev = _context20.next) {
          case 0:
            _context20.prev = 0;
            startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
            endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();
            type = req.query.type;
            doctorIds = req.query.doctorIds;
            rmpIds = req.query.rmpIds;
            _context20.next = 8;
            return (0, _bluebird.resolve)(_prescription.Prescription.countPrescriptions(startDate, endDate, type, rmpIds, doctorIds));

          case 8:
            _countPrescriptions = _context20.sent;


            res.json({
              timestamp: Date.now(),
              countPrescriptions: _countPrescriptions
            });
            _context20.next = 15;
            break;

          case 12:
            _context20.prev = 12;
            _context20.t0 = _context20['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context20.t0.toString()
            });

          case 15:
          case 'end':
            return _context20.stop();
        }
      }
    }, _callee20, this, [[0, 12]]);
  }));

  return function countPrescriptions(_x39, _x40) {
    return _ref20.apply(this, arguments);
  };
}();

var updateFollowUpDate = exports.updateFollowUpDate = function () {
  var _ref21 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee21(req, res) {
    var followup_date, prescriptionId, prescription;
    return _regenerator2.default.wrap(function _callee21$(_context21) {
      while (1) {
        switch (_context21.prev = _context21.next) {
          case 0:
            _context21.prev = 0;
            followup_date = (0, _momentTimezone2.default)(req.body.followup_date).toDate();
            prescriptionId = req.params.prescriptionId;
            _context21.next = 5;
            return (0, _bluebird.resolve)(_prescription.Prescription.updateFollowUpDate(prescriptionId, followup_date));

          case 5:
            prescription = _context21.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context21.next = 12;
            break;

          case 9:
            _context21.prev = 9;
            _context21.t0 = _context21['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context21.t0.toString()
            });

          case 12:
          case 'end':
            return _context21.stop();
        }
      }
    }, _callee21, this, [[0, 9]]);
  }));

  return function updateFollowUpDate(_x41, _x42) {
    return _ref21.apply(this, arguments);
  };
}();

var unPayed = exports.unPayed = function () {
  var _ref22 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee22(req, res) {
    var limit, skip, rmpId, prescriptions;
    return _regenerator2.default.wrap(function _callee22$(_context22) {
      while (1) {
        switch (_context22.prev = _context22.next) {
          case 0:
            _context22.prev = 0;
            limit = parseInt(req.query.limit, 10) || 20;
            skip = parseInt(req.query.skip, 10) || 0;
            rmpId = req.query.rmpId;
            _context22.next = 6;
            return (0, _bluebird.resolve)(_prescription.Prescription.unPayed({ skip: skip, limit: limit, rmpId: rmpId }));

          case 6:
            prescriptions = _context22.sent;


            res.json({
              timestamp: Date.now(),
              prescriptions: prescriptions
            });
            _context22.next = 13;
            break;

          case 10:
            _context22.prev = 10;
            _context22.t0 = _context22['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context22.t0.toString()
            });

          case 13:
          case 'end':
            return _context22.stop();
        }
      }
    }, _callee22, this, [[0, 10]]);
  }));

  return function unPayed(_x43, _x44) {
    return _ref22.apply(this, arguments);
  };
}();

var personalHistory = exports.personalHistory = function () {
  var _ref23 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee23(req, res) {
    var limit, searchQuery, personal;
    return _regenerator2.default.wrap(function _callee23$(_context23) {
      while (1) {
        switch (_context23.prev = _context23.next) {
          case 0:
            limit = parseInt(req.query.limit) || 20;
            searchQuery = req.query.searchQuery;


            if (!searchQuery) {
              res.status(400).end();
            }
            _context23.prev = 3;
            _context23.next = 6;
            return (0, _bluebird.resolve)(_prescription.Prescription.findPersonalHistory(limit, searchQuery));

          case 6:
            personal = _context23.sent;


            res.json({
              timestamp: Date.now(),
              personal: personal
            });
            _context23.next = 13;
            break;

          case 10:
            _context23.prev = 10;
            _context23.t0 = _context23['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context23.t0.toString()
            });

          case 13:
          case 'end':
            return _context23.stop();
        }
      }
    }, _callee23, this, [[3, 10]]);
  }));

  return function personalHistory(_x45, _x46) {
    return _ref23.apply(this, arguments);
  };
}();

var familyHistory = exports.familyHistory = function () {
  var _ref24 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee24(req, res) {
    var limit, searchQuery, family;
    return _regenerator2.default.wrap(function _callee24$(_context24) {
      while (1) {
        switch (_context24.prev = _context24.next) {
          case 0:
            limit = req.query.limit || 20;
            searchQuery = req.query.searchQuery;


            if (!searchQuery) {
              res.status(400).end();
            }

            _context24.prev = 3;
            _context24.next = 6;
            return (0, _bluebird.resolve)(_prescription.Prescription.findFamilyHistory(limit, searchQuery));

          case 6:
            family = _context24.sent;


            res.json({
              timestamp: Date.now(),
              family: family
            });
            _context24.next = 13;
            break;

          case 10:
            _context24.prev = 10;
            _context24.t0 = _context24['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context24.t0.toString()
            });

          case 13:
          case 'end':
            return _context24.stop();
        }
      }
    }, _callee24, this, [[3, 10]]);
  }));

  return function familyHistory(_x47, _x48) {
    return _ref24.apply(this, arguments);
  };
}();

var drugHistory = exports.drugHistory = function () {
  var _ref25 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee25(req, res) {
    var limit, searchQuery, drug;
    return _regenerator2.default.wrap(function _callee25$(_context25) {
      while (1) {
        switch (_context25.prev = _context25.next) {
          case 0:
            limit = req.query.limit || 20;
            searchQuery = req.query.searchQuery;


            if (!searchQuery) {
              res.status(400).end();
            }
            _context25.prev = 3;
            _context25.next = 6;
            return (0, _bluebird.resolve)(_prescription.Prescription.findDrugHistory(limit, searchQuery));

          case 6:
            drug = _context25.sent;


            res.json({
              timestamp: Date.now(),
              drug: drug
            });
            _context25.next = 13;
            break;

          case 10:
            _context25.prev = 10;
            _context25.t0 = _context25['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context25.t0.toString()
            });

          case 13:
          case 'end':
            return _context25.stop();
        }
      }
    }, _callee25, this, [[3, 10]]);
  }));

  return function drugHistory(_x49, _x50) {
    return _ref25.apply(this, arguments);
  };
}();

var chronicHistory = exports.chronicHistory = function () {
  var _ref26 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee26(req, res) {
    var limit, searchQuery, chronic;
    return _regenerator2.default.wrap(function _callee26$(_context26) {
      while (1) {
        switch (_context26.prev = _context26.next) {
          case 0:
            limit = req.query.limit || 20;
            searchQuery = req.query.searchQuery;


            if (!searchQuery) {
              res.status(400).end();
            }
            _context26.prev = 3;
            _context26.next = 6;
            return (0, _bluebird.resolve)(_prescription.Prescription.findChronicHistory(limit, searchQuery));

          case 6:
            chronic = _context26.sent;


            res.json({
              timestamp: Date.now(),
              chronic: chronic
            });
            _context26.next = 13;
            break;

          case 10:
            _context26.prev = 10;
            _context26.t0 = _context26['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context26.t0.toString()
            });

          case 13:
          case 'end':
            return _context26.stop();
        }
      }
    }, _callee26, this, [[3, 10]]);
  }));

  return function chronicHistory(_x51, _x52) {
    return _ref26.apply(this, arguments);
  };
}();

var allergyHistory = exports.allergyHistory = function () {
  var _ref27 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee27(req, res) {
    var limit, searchQuery, allergy;
    return _regenerator2.default.wrap(function _callee27$(_context27) {
      while (1) {
        switch (_context27.prev = _context27.next) {
          case 0:
            limit = req.query.limit || 20;
            searchQuery = req.query.searchQuery;


            if (!searchQuery) {
              res.status(400).end();
            }

            _context27.prev = 3;
            _context27.next = 6;
            return (0, _bluebird.resolve)(_prescription.Prescription.findAllergyHistory(limit, searchQuery));

          case 6:
            allergy = _context27.sent;


            res.json({
              timestamp: Date.now(),
              allergy: allergy
            });
            _context27.next = 13;
            break;

          case 10:
            _context27.prev = 10;
            _context27.t0 = _context27['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context27.t0.toString()
            });

          case 13:
          case 'end':
            return _context27.stop();
        }
      }
    }, _callee27, this, [[3, 10]]);
  }));

  return function allergyHistory(_x53, _x54) {
    return _ref27.apply(this, arguments);
  };
}();

var createOrUpdatePrescriptionNote = exports.createOrUpdatePrescriptionNote = function () {
  var _ref28 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee28(req, res) {
    var prescriptionId, text, isDone, userId, prescriptionNote;
    return _regenerator2.default.wrap(function _callee28$(_context28) {
      while (1) {
        switch (_context28.prev = _context28.next) {
          case 0:
            _context28.prev = 0;
            prescriptionId = req.params.prescriptionId;
            text = req.body.text;
            isDone = req.body.isDone;
            userId = req.user._id;
            _context28.next = 7;
            return (0, _bluebird.resolve)(_prescription.PrescriptionNote.createOrUpdatePrescriptionNote(prescriptionId, text, isDone, userId));

          case 7:
            prescriptionNote = _context28.sent;


            res.json({
              timestamp: Date.now(),
              prescriptionNote: prescriptionNote
            });
            _context28.next = 14;
            break;

          case 11:
            _context28.prev = 11;
            _context28.t0 = _context28['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context28.t0.toString()
            });

          case 14:
          case 'end':
            return _context28.stop();
        }
      }
    }, _callee28, this, [[0, 11]]);
  }));

  return function createOrUpdatePrescriptionNote(_x55, _x56) {
    return _ref28.apply(this, arguments);
  };
}();

var findPrescriptionNoteByPrescriptionId = exports.findPrescriptionNoteByPrescriptionId = function () {
  var _ref29 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee29(req, res) {
    var prescriptionId, prescriptionNote;
    return _regenerator2.default.wrap(function _callee29$(_context29) {
      while (1) {
        switch (_context29.prev = _context29.next) {
          case 0:
            _context29.prev = 0;
            prescriptionId = req.params.prescriptionId;
            _context29.next = 4;
            return (0, _bluebird.resolve)(_prescription.PrescriptionNote.findNoteByPrescriptionId(prescriptionId));

          case 4:
            prescriptionNote = _context29.sent;


            res.json({
              timestamp: Date.now(),
              prescriptionNote: prescriptionNote
            });
            _context29.next = 11;
            break;

          case 8:
            _context29.prev = 8;
            _context29.t0 = _context29['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context29.t0.toString()
            });

          case 11:
          case 'end':
            return _context29.stop();
        }
      }
    }, _callee29, this, [[0, 8]]);
  }));

  return function findPrescriptionNoteByPrescriptionId(_x57, _x58) {
    return _ref29.apply(this, arguments);
  };
}();

// FIXME: Move model code into model layer.


var load = exports.load = function () {
  var _ref30 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee30(req, res) {
    var prescriptionId, prescription;
    return _regenerator2.default.wrap(function _callee30$(_context30) {
      while (1) {
        switch (_context30.prev = _context30.next) {
          case 0:
            _context30.prev = 0;
            prescriptionId = req.params.prescriptionId;

            if (prescriptionId) {
              _context30.next = 4;
              break;
            }

            throw new Error('No prescriptionId provided');

          case 4:
            _context30.next = 6;
            return (0, _bluebird.resolve)(_prescription.Prescription.findById(prescriptionId).populate('appointment_id rmp_id doctors_id').populate({
              path: 'patients_id',
              populate: 'village'
            }).lean().exec());

          case 6:
            prescription = _context30.sent;

            if (prescription) {
              _context30.next = 9;
              break;
            }

            throw new Error('No prescription ' + prescriptionId + ' found');

          case 9:
            _context30.next = 11;
            return (0, _bluebird.resolve)(_prescription.Feedback.findOne({
              appointment: prescription.appointment_id._id
            }).sort({
              created_at: 1
            }).lean().exec());

          case 11:
            prescription.sbFeedback = _context30.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context30.next = 18;
            break;

          case 15:
            _context30.prev = 15;
            _context30.t0 = _context30['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context30.t0
            });

          case 18:
          case 'end':
            return _context30.stop();
        }
      }
    }, _callee30, this, [[0, 15]]);
  }));

  return function load(_x59, _x60) {
    return _ref30.apply(this, arguments);
  };
}();

// FIXME: Move model code into model layer.


var save = exports.save = function () {
  var _ref31 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee31(req, res) {
    var appointmentId, appointment, sbFeedback, feedback, prescriptionBody, prescription;
    return _regenerator2.default.wrap(function _callee31$(_context31) {
      while (1) {
        switch (_context31.prev = _context31.next) {
          case 0:
            _context31.prev = 0;
            appointmentId = req.body.appointment_id._id;

            if (appointmentId) {
              _context31.next = 4;
              break;
            }

            throw new Error('No appointmentId provided');

          case 4:
            _context31.next = 6;
            return (0, _bluebird.resolve)(_prescription.Appointment.findByIdAndUpdate(appointmentId, {
              $set: { is_prescribed: false }
            }, {
              new: true
            }).lean().exec());

          case 6:
            appointment = _context31.sent;

            if (appointment) {
              _context31.next = 9;
              break;
            }

            throw new Error('No appointment ' + appointmentId + ' found');

          case 9:
            sbFeedback = req.body.sbFeedback;

            if (sbFeedback) {
              _context31.next = 12;
              break;
            }

            throw new Error('No sbFeedback provided');

          case 12:
            _context31.next = 14;
            return (0, _bluebird.resolve)(_prescription.Feedback.findOneAndUpdate({
              appointment: appointmentId
            }, {
              appointment: appointmentId,
              questions: sbFeedback.questions,
              rmp_rating: sbFeedback.rmp_rating
            }, {
              new: true
            }).sort({
              created_at: 1
            }).lean().exec());

          case 14:
            feedback = _context31.sent;

            if (feedback) {
              _context31.next = 19;
              break;
            }

            _context31.next = 18;
            return (0, _bluebird.resolve)(new _prescription.Feedback({
              appointment: appointmentId,
              questions: sbFeedback.questions,
              rmp_rating: sbFeedback.rmp_rating
            }).save());

          case 18:
            feedback = _context31.sent;

          case 19:
            prescriptionBody = req.body;


            prescriptionBody.pdflink = null;
            prescriptionBody.is_pdfready = false;
            prescriptionBody.rmp_seen = false;
            delete prescriptionBody.updated_at;

            _context31.next = 26;
            return (0, _bluebird.resolve)(_prescription.Prescription.findOneAndUpdate({
              appointment_id: prescriptionBody.appointment_id
            }, prescriptionBody, {
              new: true
            }).lean().exec());

          case 26:
            prescription = _context31.sent;

            if (prescription) {
              _context31.next = 31;
              break;
            }

            _context31.next = 30;
            return (0, _bluebird.resolve)(new _prescription.Prescription(prescriptionBody).save());

          case 30:
            prescription = _context31.sent;

          case 31:

            _prescription3.default.emit('prescription:update');

            _context31.next = 34;
            return (0, _bluebird.resolve)(_prescription.Prescription.findById(prescription._id).populate('appointment_id rmp_id doctors_id').populate({
              path: 'patients_id',
              populate: 'village'
            }).lean().exec());

          case 34:
            prescription = _context31.sent;
            _context31.next = 37;
            return (0, _bluebird.resolve)(_prescription.Feedback.findOne({
              appointment: prescription.appointment_id._id
            }).sort({
              created_at: 1
            }).lean().exec());

          case 37:
            prescription.sbFeedback = _context31.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context31.next = 44;
            break;

          case 41:
            _context31.prev = 41;
            _context31.t0 = _context31['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context31.t0
            });

          case 44:
          case 'end':
            return _context31.stop();
        }
      }
    }, _callee31, this, [[0, 41]]);
  }));

  return function save(_x61, _x62) {
    return _ref31.apply(this, arguments);
  };
}();

// FIXME: Move model code into model layer.


var publish = exports.publish = function () {
  var _ref32 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee32(req, res) {
    var prescriptionId, prescriptionTimeTook, prescription, appointmentId;
    return _regenerator2.default.wrap(function _callee32$(_context32) {
      while (1) {
        switch (_context32.prev = _context32.next) {
          case 0:
            _context32.prev = 0;
            prescriptionId = req.params.prescriptionId;
            prescriptionTimeTook = req.body.time_took;
            _context32.next = 5;
            return (0, _bluebird.resolve)(_prescription.Prescription.findByIdAndUpdate(prescriptionId, {
              $set: {
                is_pdfready: true,
                time_took: prescriptionTimeTook,
                publishAt: Date.now()
              }
            }, {
              new: true
            }).lean().exec());

          case 5:
            prescription = _context32.sent;
            appointmentId = prescription.appointment_id;
            _context32.next = 9;
            return (0, _bluebird.resolve)(_prescription.Appointment.findByIdAndUpdate(appointmentId, {
              $set: { is_prescribed: true }
            }, {
              new: true
            }).lean().exec());

          case 9:

            _prescription3.default.emit('prescription:publish');

            _context32.next = 12;
            return (0, _bluebird.resolve)(_prescription.Prescription.findById(prescription._id).populate('appointment_id rmp_id doctors_id').populate({
              path: 'patients_id',
              populate: 'village'
            }).lean().exec());

          case 12:
            prescription = _context32.sent;
            _context32.next = 15;
            return (0, _bluebird.resolve)(_prescription.Feedback.findOne({
              appointment: prescription.appointment_id._id
            }).sort({
              created_at: 1
            }).lean().exec());

          case 15:
            prescription.sbFeedback = _context32.sent;
            _context32.next = 18;
            return (0, _bluebird.resolve)(_prescription.Appointment.count({
              doctors_id: prescription.doctors_id,
              is_booked: true,
              is_prescribed: true
            }).lean().exec());

          case 18:
            prescription.milestone = _context32.sent;


            res.json({
              timestamp: Date.now(),
              prescription: prescription
            });
            _context32.next = 25;
            break;

          case 22:
            _context32.prev = 22;
            _context32.t0 = _context32['catch'](0);

            res.status(500).json({
              timestamp: Date.now(),
              error: _context32.t0
            });

          case 25:
          case 'end':
            return _context32.stop();
        }
      }
    }, _callee32, this, [[0, 22]]);
  }));

  return function publish(_x63, _x64) {
    return _ref32.apply(this, arguments);
  };
}();

var _prescription = require('./prescription.model');

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _prescription2 = require('./prescription.events');

var _prescription3 = _interopRequireDefault(_prescription2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=prescription.controller.js.map
