'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PrescriptionNote = exports.PrescriptionTransactions = exports.Feedback = exports.Appointment = exports.User = exports.Prescription = undefined;

var _bluebird = require('bluebird');

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 *
 * @param startDate
 * @param endDate
 * @param skip
 * @param limit
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise}
 */
var list = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(startDate, endDate, skip, limit, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            limit = parseInt(limit) || 10;
            skip = parseInt(skip) || 0;
            _context.next = 4;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 4:
            query = _context.sent;
            _context.next = 7;
            return (0, _bluebird.resolve)(findPrescriptions(query, skip, limit));

          case 7:
            return _context.abrupt('return', _context.sent);

          case 8:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function list(_x, _x2, _x3, _x4, _x5, _x6, _x7) {
    return _ref.apply(this, arguments);
  };
}();

/**
 *
 * @param {*} id
 */


var findByIdForPdf = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(id) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(Prescription.findById(id).populate({
              path: 'rmp_id doctors_id patients_id appointment_id'
            }).lean().exec());

          case 2:
            return _context2.abrupt('return', _context2.sent);

          case 3:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findByIdForPdf(_x8) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findServed = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context3.sent;
            _context3.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $group: {
                _id: {
                  month: { $month: '$created_at' },
                  year: { $year: '$created_at' },
                  day: { $dayOfMonth: '$created_at' }
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                year: '$_id.year',
                month: '$_id.month',
                day: '$_id.day',
                count: '$count'
              }
            }, {
              $sort: {
                year: 1,
                month: 1,
                day: 1
              }
            }]));

          case 5:
            return _context3.abrupt('return', _context3.sent);

          case 6:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findServed(_x9, _x10, _x11, _x12, _x13) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findReferred = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context4.sent;
            _context4.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $group: {
                _id: {
                  is_referred: '$is_referred'
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                referred: '$_id.is_referred',
                label: {
                  $cond: { if: '$_id.is_referred', then: 'Referred', else: 'Not Referred' }
                },
                count: '$count'
              }
            }]));

          case 5:
            return _context4.abrupt('return', _context4.sent);

          case 6:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findReferred(_x14, _x15, _x16, _x17, _x18) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findFollowup = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context5.sent;
            _context5.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $group: {
                _id: {
                  is_followup: '$is_followup'
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                followup: '$_id.is_followup',
                label: {
                  $cond: { if: '$_id.is_followup', then: 'Follow-up', else: 'New' }
                },
                count: '$count',
                average: '$average'
              }
            }]));

          case 5:
            return _context5.abrupt('return', _context5.sent);

          case 6:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findFollowup(_x19, _x20, _x21, _x22, _x23) {
    return _ref5.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findPatientServedByCenter = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context6.sent;
            _context6.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $group: {
                _id: {
                  center: '$rmp.center'
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                center: '$_id.center',
                total: '$count'
              }
            }, {
              $sort: {
                center: 1
              }
            }]));

          case 5:
            return _context6.abrupt('return', _context6.sent);

          case 6:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function findPatientServedByCenter(_x24, _x25, _x26, _x27, _x28) {
    return _ref6.apply(this, arguments);
  };
}();

var updateFollowUpDate = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(id, followUpDate) {
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            _prescription4.default.emit('prescription:update');

            _context7.next = 3;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(id, {
              followup_date: followUpDate
            }).exec());

          case 3:
            return _context7.abrupt('return', _context7.sent);

          case 4:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function updateFollowUpDate(_x29, _x30) {
    return _ref7.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @param startPoint
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findDelayedPrescriptions = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(startDate, endDate, type, rmpIds, doctorIds, startPoint) {
    var query;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            startPoint = startPoint || '$appointment.timestamp.book_by_rmp';

            _context8.next = 3;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 3:
            query = _context8.sent;
            _context8.next = 6;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'appointments',
                localField: 'appointment_id',
                foreignField: '_id',
                as: 'appointment'
              }
            }, {
              $unwind: {
                path: '$appointment'
              }
            }, {
              $project: {
                timeDifference: { $ifNull: [{ $subtract: ['$publishAt', startPoint] }, 0] }
              }
            }]));

          case 6:
            return _context8.abrupt('return', _context8.sent);

          case 7:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this);
  }));

  return function findDelayedPrescriptions(_x31, _x32, _x33, _x34, _x35, _x36) {
    return _ref8.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findPatientServedByCenterByYear = function () {
  var _ref9 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee9(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            _context9.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context9.sent;
            _context9.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $group: {
                _id: {
                  center: '$rmp.center',
                  month: { $month: '$created_at' },
                  year: { $year: '$created_at' }
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                center: '$_id.center',
                month: '$_id.month',
                year: '$_id.year',
                total: '$count'
              }
            }, {
              $sort: {
                center: 1,
                year: 1,
                month: 1
              }
            }]));

          case 5:
            return _context9.abrupt('return', _context9.sent);

          case 6:
          case 'end':
            return _context9.stop();
        }
      }
    }, _callee9, this);
  }));

  return function findPatientServedByCenterByYear(_x37, _x38, _x39, _x40, _x41) {
    return _ref9.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<*|Object|Aggregate|Promise>}
 */


var findPatientServedByRmpByYear = function () {
  var _ref10 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee10(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            _context10.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context10.sent;
            _context10.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $group: {
                _id: {
                  id: '$rmp._id',
                  fullname: '$rmp.fullname',
                  month: { $month: '$created_at' },
                  year: { $year: '$created_at' }
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                center: '$_id.fullname',
                month: '$_id.month',
                year: '$_id.year',
                total: '$count'
              }
            }, {
              $sort: {
                center: 1,
                year: 1,
                month: 1
              }
            }]));

          case 5:
            return _context10.abrupt('return', _context10.sent);

          case 6:
          case 'end':
            return _context10.stop();
        }
      }
    }, _callee10, this);
  }));

  return function findPatientServedByRmpByYear(_x42, _x43, _x44, _x45, _x46) {
    return _ref10.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<*|Object|Aggregate|Promise>}
 */


var findPatientServedByHPO = function () {
  var _ref11 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee11(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            _context11.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context11.sent;
            _context11.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp.mpo_id',
                foreignField: '_id',
                as: 'hpo'
              }
            }, {
              $unwind: {
                path: '$hpo'
              }
            }, {
              $group: {
                _id: {
                  hpo: '$hpo._id',
                  fullname: '$hpo.fullname'
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                hpo: '$_id.hpo',
                fullname: '$_id.fullname',
                total: '$count'
              }
            }, {
              $sort: {
                fullname: 1
              }
            }]));

          case 5:
            return _context11.abrupt('return', _context11.sent);

          case 6:
          case 'end':
            return _context11.stop();
        }
      }
    }, _callee11, this);
  }));

  return function findPatientServedByHPO(_x47, _x48, _x49, _x50, _x51) {
    return _ref11.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<*|Object|Aggregate|Promise>}
 */


var findPatientServedByTE = function () {
  var _ref12 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee12(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee12$(_context12) {
      while (1) {
        switch (_context12.prev = _context12.next) {
          case 0:
            _context12.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context12.sent;
            _context12.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp.te_id',
                foreignField: '_id',
                as: 'te'
              }
            }, {
              $unwind: {
                path: '$te'
              }
            }, {
              $group: {
                _id: {
                  te: '$te._id',
                  fullname: '$te.fullname'
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                te: '$_id.te',
                fullname: '$_id.fullname',
                total: '$count'
              }
            }, {
              $sort: {
                fullname: 1
              }
            }]));

          case 5:
            return _context12.abrupt('return', _context12.sent);

          case 6:
          case 'end':
            return _context12.stop();
        }
      }
    }, _callee12, this);
  }));

  return function findPatientServedByTE(_x52, _x53, _x54, _x55, _x56) {
    return _ref12.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findPatientServedByRmp = function () {
  var _ref13 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee13(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee13$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            _context13.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context13.sent;
            _context13.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $group: {
                _id: {
                  rmp: '$rmp._id',
                  fullname: '$rmp.fullname'
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                rmp: '$_id.rmp',
                fullname: '$_id.fullname',
                total: '$count'
              }
            }, {
              $sort: {
                fullname: 1
              }
            }]));

          case 5:
            return _context13.abrupt('return', _context13.sent);

          case 6:
          case 'end':
            return _context13.stop();
        }
      }
    }, _callee13, this);
  }));

  return function findPatientServedByRmp(_x57, _x58, _x59, _x60, _x61) {
    return _ref13.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findPatientServedByDoctor = function () {
  var _ref14 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee14(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee14$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            _context14.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context14.sent;
            _context14.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'doctors_id',
                foreignField: '_id',
                as: 'doctor'
              }
            }, {
              $unwind: {
                path: '$doctor'
              }
            }, {
              $group: {
                _id: {
                  doctor: '$doctor._id',
                  fullname: '$doctor.fullname'
                },
                count: {
                  $sum: 1
                }
              }
            }, {
              $project: {
                _id: 0,
                doctor: '$_id.doctor',
                fullname: '$_id.fullname',
                total: '$count'
              }
            }, {
              $sort: {
                fullname: 1
              }
            }]));

          case 5:
            return _context14.abrupt('return', _context14.sent);

          case 6:
          case 'end':
            return _context14.stop();
        }
      }
    }, _callee14, this);
  }));

  return function findPatientServedByDoctor(_x62, _x63, _x64, _x65, _x66) {
    return _ref14.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<*|Object|Aggregate|Promise>}
 */


var findPatientServedByRmpByMonthByYear = function () {
  var _ref15 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee15(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee15$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            _context15.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context15.sent;
            _context15.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $group: {
                _id: {
                  _id: '$rmp._id',
                  fullname: '$rmp.fullname',
                  year: { $year: '$created_at' },
                  day: { $dayOfMonth: '$created_at' }
                },
                count: {
                  $sum: 1
                },
                followup: {
                  $sum: { $cond: ['$is_followup', 1, 0] }
                },
                notFollowup: {
                  $sum: { $cond: ['$is_followup', 0, 1] }
                }
              }
            }, {
              $project: {
                _id: 0,
                fullname: '$_id.fullname',
                year: '$_id.year',
                day: '$_id.day',
                total: '$count',
                followup: '$followup',
                notfollowup: '$notFollowup'
              }
            }, {
              $sort: {
                fullname: 1,
                year: 1,
                day: 1
              }
            }]));

          case 5:
            return _context15.abrupt('return', _context15.sent);

          case 6:
          case 'end':
            return _context15.stop();
        }
      }
    }, _callee15, this);
  }));

  return function findPatientServedByRmpByMonthByYear(_x67, _x68, _x69, _x70, _x71) {
    return _ref15.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findPatientServedByCenterByMonthByYear = function () {
  var _ref16 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee16(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee16$(_context16) {
      while (1) {
        switch (_context16.prev = _context16.next) {
          case 0:
            _context16.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context16.sent;
            _context16.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $group: {
                _id: {
                  center: '$rmp.center',
                  year: { $year: '$created_at' },
                  day: { $dayOfMonth: '$created_at' }
                },
                count: {
                  $sum: 1
                },
                followup: {
                  $sum: { $cond: ['$is_followup', 1, 0] }
                },
                notFollowup: {
                  $sum: { $cond: ['$is_followup', 0, 1] }
                }
              }
            }, {
              $project: {
                _id: 0,
                center: '$_id.center',
                year: '$_id.year',
                day: '$_id.day',
                total: '$count',
                followup: '$followup',
                notfollowup: '$notFollowup'
              }
            }, {
              $sort: {
                center: 1,
                year: 1,
                day: 1
              }
            }]));

          case 5:
            return _context16.abrupt('return', _context16.sent);

          case 6:
          case 'end':
            return _context16.stop();
        }
      }
    }, _callee16, this);
  }));

  return function findPatientServedByCenterByMonthByYear(_x72, _x73, _x74, _x75, _x76) {
    return _ref16.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findPatientServedByHpoByMonthByYear = function () {
  var _ref17 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee17(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee17$(_context17) {
      while (1) {
        switch (_context17.prev = _context17.next) {
          case 0:
            _context17.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context17.sent;
            _context17.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp_id',
                foreignField: '_id',
                as: 'rmp'
              }
            }, {
              $unwind: {
                path: '$rmp'
              }
            }, {
              $lookup: {
                from: 'users',
                localField: 'rmp.mpo_id',
                foreignField: '_id',
                as: 'hpo'
              }
            }, {
              $unwind: {
                path: '$hpo'
              }
            }, {
              $group: {
                _id: {
                  _id: '$hpo._id',
                  fullname: '$hpo.fullname',
                  year: { $year: '$created_at' },
                  day: { $dayOfMonth: '$created_at' }
                },
                count: {
                  $sum: 1
                },
                followup: {
                  $sum: { $cond: ['$is_followup', 1, 0] }
                },
                notFollowup: {
                  $sum: { $cond: ['$is_followup', 0, 1] }
                }
              }
            }, {
              $project: {
                _id: 0,
                fullname: '$_id.fullname',
                year: '$_id.year',
                day: '$_id.day',
                total: '$count',
                followup: '$followup',
                notfollowup: '$notFollowup'
              }
            }, {
              $sort: {
                fullname: 1,
                year: 1,
                day: 1
              }
            }]));

          case 5:
            return _context17.abrupt('return', _context17.sent);

          case 6:
          case 'end':
            return _context17.stop();
        }
      }
    }, _callee17, this);
  }));

  return function findPatientServedByHpoByMonthByYear(_x77, _x78, _x79, _x80, _x81) {
    return _ref17.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findPatientServedByFee = function () {
  var _ref18 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee18(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee18$(_context18) {
      while (1) {
        switch (_context18.prev = _context18.next) {
          case 0:
            _context18.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context18.sent;
            _context18.next = 5;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $group: {
                _id: {
                  fee: '$fee'
                },
                total: { $sum: 1 }
              }
            }, {
              $project: {
                _id: 0,
                fee: '$_id.fee',
                total: '$total',
                label: '$_id.fee'
              }
            }]));

          case 5:
            return _context18.abrupt('return', _context18.sent);

          case 6:
          case 'end':
            return _context18.stop();
        }
      }
    }, _callee18, this);
  }));

  return function findPatientServedByFee(_x82, _x83, _x84, _x85, _x86) {
    return _ref18.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<Aggregate|Promise|*|Object>}
 */


var findServeAverageTime = function () {
  var _ref19 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee19(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee19$(_context19) {
      while (1) {
        switch (_context19.prev = _context19.next) {
          case 0:
            _context19.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context19.sent;

            query.opened = { $exists: true };

            _context19.next = 6;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: query
            }, {
              $project: {
                timeDifference: { $ifNull: [{ $subtract: ['$publishAt', '$opened'] }, 0] }
              }
            }]));

          case 6:
            return _context19.abrupt('return', _context19.sent);

          case 7:
          case 'end':
            return _context19.stop();
        }
      }
    }, _callee19, this);
  }));

  return function findServeAverageTime(_x87, _x88, _x89, _x90, _x91) {
    return _ref19.apply(this, arguments);
  };
}();

/**
 *
 * @param skip
 * @param limit
 * @param rmpId
 * @returns {Promise}
 */


var unPayed = function () {
  var _ref20 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee20(_ref21) {
    var skip = _ref21.skip,
        limit = _ref21.limit,
        rmpId = _ref21.rmpId;
    var query;
    return _regenerator2.default.wrap(function _callee20$(_context20) {
      while (1) {
        switch (_context20.prev = _context20.next) {
          case 0:
            limit = parseInt(limit, 10) || 10;
            skip = parseInt(skip, 10) || 0;

            query = {
              is_pdfready: true,
              isPayed: false,
              v2_id: { $exists: false }
            };


            rmpId ? query.rmp_id = rmpId : '';

            _context20.next = 6;
            return (0, _bluebird.resolve)(Prescription.find(query).skip(skip).limit(limit).select('rmp_id doctors_id patients_id created_at timestamp updated_at fee').populate({
              path: 'rmp_id doctors_id patients_id',
              select: 'fullname'
            }).sort({
              updated_at: -1
            }).lean().exec());

          case 6:
            return _context20.abrupt('return', _context20.sent);

          case 7:
          case 'end':
            return _context20.stop();
        }
      }
    }, _callee20, this);
  }));

  return function unPayed(_x92) {
    return _ref20.apply(this, arguments);
  };
}();

/**
 *
 * @param {*} limit
 * @param {*} searchQuery
 */


var findPersonalHistory = function () {
  var _ref22 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee21(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee21$(_context21) {
      while (1) {
        switch (_context21.prev = _context21.next) {
          case 0:
            limit = parseInt(limit);
            query = {
              personalinfo: { '$regex': searchQuery, '$options': 'i' }
            };
            _context21.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $project: { personalinfo: 1 }
            }, {
              $unwind: {
                path: '$personalinfo',
                includeArrayIndex: 'arrayIndex',
                preserveNullAndEmptyArrays: false
              }
            }, {
              $match: query
            }, {
              $group: {
                _id: '$personalinfo'
              }
            }, {
              $limit: limit
            }, {
              $sort: {
                '_id': 1
              }
            }]));

          case 4:
            return _context21.abrupt('return', _context21.sent);

          case 5:
          case 'end':
            return _context21.stop();
        }
      }
    }, _callee21, this);
  }));

  return function findPersonalHistory(_x93, _x94) {
    return _ref22.apply(this, arguments);
  };
}();

/**
 *
 * @param {*} limit
 * @param {*} searchQuery
 */


var findFamilyHistory = function () {
  var _ref23 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee22(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee22$(_context22) {
      while (1) {
        switch (_context22.prev = _context22.next) {
          case 0:
            limit = parseInt(limit);
            query = {
              familyinfo: { '$regex': searchQuery, '$options': 'i' }
            };
            _context22.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $project: { familyinfo: 1 }
            }, {
              $unwind: {
                path: '$familyinfo',
                includeArrayIndex: 'arrayIndex',
                preserveNullAndEmptyArrays: false
              }
            }, {
              $match: query
            }, {
              $group: {
                _id: '$familyinfo'
              }
            }, {
              $limit: limit
            }, {
              $sort: {
                '_id': 1
              }
            }]));

          case 4:
            return _context22.abrupt('return', _context22.sent);

          case 5:
          case 'end':
            return _context22.stop();
        }
      }
    }, _callee22, this);
  }));

  return function findFamilyHistory(_x95, _x96) {
    return _ref23.apply(this, arguments);
  };
}();

/**
 *
 * @param {*} limit
 * @param {*} searchQuery
 */


var findDrugHistory = function () {
  var _ref24 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee23(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee23$(_context23) {
      while (1) {
        switch (_context23.prev = _context23.next) {
          case 0:
            limit = parseInt(limit);
            query = {
              druginfo: { '$regex': searchQuery, '$options': 'i' }
            };
            _context23.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $project: { druginfo: 1 }
            }, {
              $unwind: {
                path: '$druginfo',
                includeArrayIndex: 'arrayIndex',
                preserveNullAndEmptyArrays: false
              }
            }, {
              $match: query
            }, {
              $group: {
                _id: '$druginfo'
              }
            }, {
              $limit: limit
            }, {
              $sort: {
                '_id': 1
              }
            }]));

          case 4:
            return _context23.abrupt('return', _context23.sent);

          case 5:
          case 'end':
            return _context23.stop();
        }
      }
    }, _callee23, this);
  }));

  return function findDrugHistory(_x97, _x98) {
    return _ref24.apply(this, arguments);
  };
}();

/**
 *
 * @param {*} limit
 * @param {*} searchQuery
 */


var findChronicHistory = function () {
  var _ref25 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee24(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee24$(_context24) {
      while (1) {
        switch (_context24.prev = _context24.next) {
          case 0:
            limit = parseInt(limit);
            query = {
              chronicinfo: { '$regex': searchQuery, '$options': 'i' }
            };
            _context24.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $project: { chronicinfo: 1 }
            }, {
              $unwind: {
                path: '$chronicinfo',
                includeArrayIndex: 'arrayIndex',
                preserveNullAndEmptyArrays: false
              }
            }, {
              $match: query
            }, {
              $group: {
                _id: '$chronicinfo'
              }
            }, {
              $limit: limit
            }, {
              $sort: {
                '_id': 1
              }
            }]));

          case 4:
            return _context24.abrupt('return', _context24.sent);

          case 5:
          case 'end':
            return _context24.stop();
        }
      }
    }, _callee24, this);
  }));

  return function findChronicHistory(_x99, _x100) {
    return _ref25.apply(this, arguments);
  };
}();

/**
 *
 * @param {*} limit
 * @param {*} searchQuery
 */


var findAllergyHistory = function () {
  var _ref26 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee25(limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee25$(_context25) {
      while (1) {
        switch (_context25.prev = _context25.next) {
          case 0:
            limit = parseInt(limit);
            query = {
              allergy: { '$regex': searchQuery, '$options': 'i' }
            };
            _context25.next = 4;
            return (0, _bluebird.resolve)(this.aggregate([{
              $project: { allergy: 1 }
            }, {
              $unwind: {
                path: '$allergy',
                includeArrayIndex: 'arrayIndex',
                preserveNullAndEmptyArrays: false
              }
            }, {
              $match: query
            }, {
              $group: {
                _id: '$allergy'
              }
            }, {
              $limit: limit
            }, {
              $sort: {
                '_id': 1
              }
            }]));

          case 4:
            return _context25.abrupt('return', _context25.sent);

          case 5:
          case 'end':
            return _context25.stop();
        }
      }
    }, _callee25, this);
  }));

  return function findAllergyHistory(_x101, _x102) {
    return _ref26.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param surveyType
 * @param doctorIds
 * @param rmpIds
 * @returns {Promise}
 */


var findSurveyList = function () {
  var _ref27 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee26(startDate, endDate, surveyType, doctorIds, rmpIds) {
    var prescriptionQuery, appointments, query;
    return _regenerator2.default.wrap(function _callee26$(_context26) {
      while (1) {
        switch (_context26.prev = _context26.next) {
          case 0:
            prescriptionQuery = {
              is_prescribed: true,
              start: {
                $gte: startDate,
                $lte: endDate
              }
            };


            if (doctorIds) {
              doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
              doctorIds = doctorIds.map(function (id) {
                return objectId(id);
              });
              doctorIds ? prescriptionQuery.doctors_id = { $in: doctorIds } : '';
            }

            if (rmpIds) {
              rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
              rmpIds = rmpIds.map(function (id) {
                return objectId(id);
              });
              rmpIds ? prescriptionQuery.rmp_id = { $in: rmpIds } : '';
            }

            _context26.next = 5;
            return (0, _bluebird.resolve)(Appointment.find(prescriptionQuery).exec());

          case 5:
            appointments = _context26.sent;
            query = {
              is_pdfready: true,
              appointment_id: {
                $in: appointments.map(function (a) {
                  return a._id;
                })
              }
            };
            _context26.t0 = surveyType;
            _context26.next = _context26.t0 === 'pss' ? 10 : _context26.t0 === 'pos' ? 10 : _context26.t0 === 'fps' ? 13 : _context26.t0 === 'rps' ? 15 : 16;
            break;

          case 10:
            query.is_followup = false;
            query.is_referred = false;
            return _context26.abrupt('break', 16);

          case 13:
            query.is_followup = true;
            return _context26.abrupt('break', 16);

          case 15:
            query.is_referred = true;

          case 16:
            return _context26.abrupt('return', Prescription.find(query).populate({
              path: 'appointment_id'
            }).populate({
              path: 'rmp_id doctors_id patients_id',
              select: 'fullname specialized gender serialnumber phone profile_url profilepiclink dob center'
            }).sort('-appointment_id.start').lean().exec());

          case 17:
          case 'end':
            return _context26.stop();
        }
      }
    }, _callee26, this);
  }));

  return function findSurveyList(_x103, _x104, _x105, _x106, _x107) {
    return _ref27.apply(this, arguments);
  };
}();

var findSurveyListForPPRO = function () {
  var _ref28 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee27(startDate, endDate, surveyType, doctorIds, rmpIds) {
    var appointmentCriteria, appointments, prescriptionCriteria;
    return _regenerator2.default.wrap(function _callee27$(_context27) {
      while (1) {
        switch (_context27.prev = _context27.next) {
          case 0:
            appointmentCriteria = {
              is_prescribed: true,
              start: {
                $gte: startDate,
                $lte: endDate
              }
            };


            if (doctorIds) {
              doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
              doctorIds = doctorIds.map(function (id) {
                return objectId(id);
              });
              doctorIds ? appointmentCriteria.doctors_id = { $in: doctorIds } : '';
            }

            if (rmpIds) {
              rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
              rmpIds = rmpIds.map(function (id) {
                return objectId(id);
              });
              rmpIds ? appointmentCriteria.rmp_id = { $in: rmpIds } : '';
            }

            _context27.next = 5;
            return (0, _bluebird.resolve)(Appointment.find(appointmentCriteria).exec());

          case 5:
            appointments = _context27.sent;
            prescriptionCriteria = {
              is_pdfready: true,
              appointment_id: {
                $in: appointments.map(function (a) {
                  return a._id;
                })
              }
            };
            return _context27.abrupt('return', Prescription.find(prescriptionCriteria).populate({
              path: 'appointment_id'
            }).populate({
              path: 'rmp_id doctors_id patients_id',
              select: 'fullname specialized gender serialnumber phone profile_url profilepiclink dob center'
            }).sort('-appointment_id.start').lean().exec());

          case 8:
          case 'end':
            return _context27.stop();
        }
      }
    }, _callee27, this);
  }));

  return function findSurveyListForPPRO(_x108, _x109, _x110, _x111, _x112) {
    return _ref28.apply(this, arguments);
  };
}();

var findSurveyListForPPROByAppointments = function () {
  var _ref29 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee28(startDate, endDate, surveyType, doctorIds, rmpIds) {
    var appointmentCriteria, appointments, prescriptionCriteria;
    return _regenerator2.default.wrap(function _callee28$(_context28) {
      while (1) {
        switch (_context28.prev = _context28.next) {
          case 0:
            appointmentCriteria = {
              is_prescribed: true,
              start: {
                $gte: startDate,
                $lte: endDate
              }
            };


            if (doctorIds) {
              doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
              doctorIds = doctorIds.map(function (id) {
                return objectId(id);
              });
              doctorIds ? appointmentCriteria.doctors_id = { $in: doctorIds } : '';
            }

            if (rmpIds) {
              rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
              rmpIds = rmpIds.map(function (id) {
                return objectId(id);
              });
              rmpIds ? appointmentCriteria.rmp_id = { $in: rmpIds } : '';
            }

            _context28.next = 5;
            return (0, _bluebird.resolve)(Appointment.find(appointmentCriteria).exec());

          case 5:
            appointments = _context28.sent;
            prescriptionCriteria = {
              is_pdfready: true,
              appointment_id: {
                $in: appointments.map(function (a) {
                  return a._id;
                })
              }
            };
            return _context28.abrupt('return', Prescription.find(prescriptionCriteria).populate({
              path: 'appointment_id'
            }).sort('-appointment_id.start').lean().exec());

          case 8:
          case 'end':
            return _context28.stop();
        }
      }
    }, _callee28, this);
  }));

  return function findSurveyListForPPROByAppointments(_x113, _x114, _x115, _x116, _x117) {
    return _ref29.apply(this, arguments);
  };
}();

/**
 *
 * @param query
 * @param skip
 * @param limit
 * @param sort
 * @returns {Promise}
 */


var findPrescriptions = function () {
  var _ref30 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee29(query, skip, limit) {
    return _regenerator2.default.wrap(function _callee29$(_context29) {
      while (1) {
        switch (_context29.prev = _context29.next) {
          case 0:
            _context29.next = 2;
            return (0, _bluebird.resolve)(Prescription.find(query).skip(skip).limit(limit).select('rmp_id doctors_id appointment_id patients_id created_at timestamp updated_at fee is_followup isPayed is_referred followup_date is_pdfready publishAt rmp_seen opened time_took').populate({
              path: 'appointment_id'
            }).populate({
              path: 'rmp_id doctors_id patients_id',
              select: 'fullname specialized gender serialnumber phone profile_url profilepiclink dob center'
            }).sort('-publishAt').lean().exec());

          case 2:
            return _context29.abrupt('return', _context29.sent);

          case 3:
          case 'end':
            return _context29.stop();
        }
      }
    }, _callee29, this);
  }));

  return function findPrescriptions(_x118, _x119, _x120) {
    return _ref30.apply(this, arguments);
  };
}();

var findTransactions = function () {
  var _ref31 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee30(startDate, endDate, doctorIds, rmpIds) {
    var skip = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0;
    var limit = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 10;
    var query;
    return _regenerator2.default.wrap(function _callee30$(_context30) {
      while (1) {
        switch (_context30.prev = _context30.next) {
          case 0:
            query = {
              created_at: { $gte: startDate, $lte: endDate }
            };


            if (doctorIds) {
              doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
              doctorIds = doctorIds.map(function (id) {
                return objectId(id);
              });
              doctorIds ? query.doctors_id = { $in: doctorIds } : '';
            }

            if (rmpIds) {
              rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
              rmpIds = rmpIds.map(function (id) {
                return objectId(id);
              });
              rmpIds ? query.rmp_id = { $in: rmpIds } : '';
            }

            _context30.next = 5;
            return (0, _bluebird.resolve)(PrescriptionTransactions.find(query).skip(parseInt(skip)).limit(parseInt(limit)).populate({
              path: 'rmp_id doctors_id patients_id prescription_id appointment_id',
              select: '-password -dashboard'
            }).sort('-created_at').lean().exec());

          case 5:
            return _context30.abrupt('return', _context30.sent);

          case 6:
          case 'end':
            return _context30.stop();
        }
      }
    }, _callee30, this);
  }));

  return function findTransactions(_x121, _x122, _x123, _x124, _x125, _x126) {
    return _ref31.apply(this, arguments);
  };
}();

var createOrUpdatePrescriptionNote = function () {
  var _ref32 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee31(prescriptionId, text, isDone, userId) {
    var prescriptionNote;
    return _regenerator2.default.wrap(function _callee31$(_context31) {
      while (1) {
        switch (_context31.prev = _context31.next) {
          case 0:
            _context31.next = 2;
            return (0, _bluebird.resolve)(PrescriptionNote.findOne({
              prescriptionId: prescriptionId
            }).exec());

          case 2:
            prescriptionNote = _context31.sent;


            if (!prescriptionNote) prescriptionNote = new PrescriptionNote();

            prescriptionNote.prescriptionId = prescriptionId;
            prescriptionNote.createdBy = userId;
            prescriptionNote.text = text;
            prescriptionNote.isDone = isDone;

            _prescription4.default.emit('prescription:note:refresh');

            _context31.next = 11;
            return (0, _bluebird.resolve)(prescriptionNote.save());

          case 11:
            return _context31.abrupt('return', _context31.sent);

          case 12:
          case 'end':
            return _context31.stop();
        }
      }
    }, _callee31, this);
  }));

  return function createOrUpdatePrescriptionNote(_x129, _x130, _x131, _x132) {
    return _ref32.apply(this, arguments);
  };
}();

var findNoteByPrescriptionId = function () {
  var _ref33 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee32(prescriptionId) {
    var query;
    return _regenerator2.default.wrap(function _callee32$(_context32) {
      while (1) {
        switch (_context32.prev = _context32.next) {
          case 0:
            query = {
              prescriptionId: prescriptionId
            };
            _context32.next = 3;
            return (0, _bluebird.resolve)(PrescriptionNote.findOne(query).populate({
              path: 'createdBy',
              select: 'fullname'
            }).exec());

          case 3:
            return _context32.abrupt('return', _context32.sent);

          case 4:
          case 'end':
            return _context32.stop();
        }
      }
    }, _callee32, this);
  }));

  return function findNoteByPrescriptionId(_x133) {
    return _ref33.apply(this, arguments);
  };
}();

/**
 *
 * @returns {Promise<*>}
 */


var countPublished = function () {
  var _ref34 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee33() {
    return _regenerator2.default.wrap(function _callee33$(_context33) {
      while (1) {
        switch (_context33.prev = _context33.next) {
          case 0:
            _context33.next = 2;
            return (0, _bluebird.resolve)(this.count({
              is_pdfready: true
            }));

          case 2:
            return _context33.abrupt('return', _context33.sent);

          case 3:
          case 'end':
            return _context33.stop();
        }
      }
    }, _callee33, this);
  }));

  return function countPublished() {
    return _ref34.apply(this, arguments);
  };
}();

var countPrescriptions = function () {
  var _ref35 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee34(startDate, endDate, type, rmpIds, doctorIds) {
    var query;
    return _regenerator2.default.wrap(function _callee34$(_context34) {
      while (1) {
        switch (_context34.prev = _context34.next) {
          case 0:
            _context34.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, type, rmpIds, doctorIds));

          case 2:
            query = _context34.sent;
            _context34.next = 5;
            return (0, _bluebird.resolve)(this.count(query));

          case 5:
            return _context34.abrupt('return', _context34.sent);

          case 6:
          case 'end':
            return _context34.stop();
        }
      }
    }, _callee34, this);
  }));

  return function countPrescriptions(_x134, _x135, _x136, _x137, _x138) {
    return _ref35.apply(this, arguments);
  };
}();

/**
 *
 */


var countPayed = function () {
  var _ref36 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee35() {
    return _regenerator2.default.wrap(function _callee35$(_context35) {
      while (1) {
        switch (_context35.prev = _context35.next) {
          case 0:
            _context35.next = 2;
            return (0, _bluebird.resolve)(this.count({
              isPayed: true
            }));

          case 2:
            return _context35.abrupt('return', _context35.sent);

          case 3:
          case 'end':
            return _context35.stop();
        }
      }
    }, _callee35, this);
  }));

  return function countPayed() {
    return _ref36.apply(this, arguments);
  };
}();

/**
 *
 * @param startDate
 * @param endDate
 * @param type
 * @param rmpIds
 * @param doctorIds
 * @returns {Promise.<{created_at: {$gt: *, $lt: *}}>}
 */


var filters = function () {
  var _ref37 = (0, _bluebird.method)(function (startDate, endDate, type, rmpIds, doctorIds) {
    var query = {
      created_at: { $gte: startDate, $lte: endDate }
    };

    if (doctorIds) {
      doctorIds = _lodash2.default.isArray(doctorIds) ? doctorIds : [doctorIds];
      doctorIds = doctorIds.map(function (id) {
        return objectId(id);
      });
      doctorIds ? query.doctors_id = { $in: doctorIds } : '';
    }

    if (rmpIds) {
      rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
      rmpIds = rmpIds.map(function (id) {
        return objectId(id);
      });
      rmpIds ? query.rmp_id = { $in: rmpIds } : '';
    }

    !type ? query.is_pdfready = true : '';
    type === 'Published' ? query.is_pdfready = true : '';
    type === 'New' ? query.is_followup = false : '';
    type === 'Follow-Up' ? query.is_followup = true : '';
    type === 'Referred' ? query.is_referred = true : '';
    type === 'Free' ? query.is_free = true : '';
    type === 'Un Published' ? query.is_pdfready = false : true;

    return query;
  });

  return function filters(_x139, _x140, _x141, _x142, _x143) {
    return _ref37.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _questionnaire = require('../../schemas/questionnaire.schema');

var _questionnaire2 = _interopRequireDefault(_questionnaire);

var _appointment = require('../../schemas/appointment.schema');

var _appointment2 = _interopRequireDefault(_appointment);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

var _prescription = require('../../schemas/prescription.schema');

var _prescription2 = _interopRequireDefault(_prescription);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _transaction = require('../../schemas/transaction.schema');

var _transaction2 = _interopRequireDefault(_transaction);

var _prescriptionNote = require('../../schemas/prescription-note.schema');

var _prescriptionNote2 = _interopRequireDefault(_prescriptionNote);

var _prescription3 = require('./prescription.events');

var _prescription4 = _interopRequireDefault(_prescription3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Statics
 */

_prescription2.default.static('all', list).static('findByIdForPdf', findByIdForPdf).static('findServed', findServed).static('findFollowup', findFollowup).static('findReferred', findReferred).static('findPatientServedByCenter', findPatientServedByCenter).static('findPatientServedByCenterByYear', findPatientServedByCenterByYear).static('findPatientServedByRmpByYear', findPatientServedByRmpByYear).static('findPatientServedByHPO', findPatientServedByHPO).static('findPatientServedByTE', findPatientServedByTE).static('findPatientServedByRmp', findPatientServedByRmp).static('findPatientServedByDoctor', findPatientServedByDoctor).static('findPatientServedByRmpByMonthByYear', findPatientServedByRmpByMonthByYear).static('findPatientServedByCenterByMonthByYear', findPatientServedByCenterByMonthByYear).static('findPatientServedByHpoByMonthByYear', findPatientServedByHpoByMonthByYear).static('findPatientServedByFee', findPatientServedByFee).static('findServeAverageTime', findServeAverageTime).static('findDelayedPrescriptions', findDelayedPrescriptions).static('updateFollowUpDate', updateFollowUpDate).static('unPayed', unPayed).static('countPublished', countPublished).static('countPayed', countPayed).static('findFamilyHistory', findFamilyHistory).static('findPersonalHistory', findPersonalHistory).static('findDrugHistory', findDrugHistory).static('findChronicHistory', findChronicHistory).static('findAllergyHistory', findAllergyHistory).static('findSurveyList', findSurveyList).static('findSurveyListForPPRO', findSurveyListForPPRO).static('findSurveyListForPPROByAppointments', findSurveyListForPPROByAppointments).static('countPrescriptions', countPrescriptions);

_transaction2.default.static('findTransactions', findTransactions);

_prescriptionNote2.default.static("createOrUpdatePrescriptionNote", createOrUpdatePrescriptionNote).static("findNoteByPrescriptionId", findNoteByPrescriptionId);var Prescription = exports.Prescription = _mongoose2.default.model('Prescription', _prescription2.default);
var User = exports.User = _mongoose2.default.model('PrescriptionUser', _user2.default, 'users');
var Appointment = exports.Appointment = _mongoose2.default.model('PrescriptionAppointment', _appointment2.default, 'appointments');
var Feedback = exports.Feedback = _mongoose2.default.model('PrescriptionQuestionnaires', _questionnaire2.default, 'questionnaires');
var PrescriptionTransactions = exports.PrescriptionTransactions = _mongoose2.default.model('PrescriptionTransactions', _transaction2.default, 'transactions');
var PrescriptionNote = exports.PrescriptionNote = _mongoose2.default.model('PrescriptionNote', _prescriptionNote2.default, 'prescription-note');
/**
 * Exports
 */
exports.default = Prescription;
//# sourceMappingURL=prescription.model.js.map
