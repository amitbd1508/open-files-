'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findSpecializations = exports.findByPatientIdAndGetHistory = exports.findByName = undefined;

var _bluebird = require('bluebird');

var _slicedToArray2 = require('babel-runtime/helpers/slicedToArray');

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

/**
 * Actions
 */

/**
 * List Patient for Audit
 *
 * @param req
 * @param res
 */
var findByName = exports.findByName = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var limit, skip, searchQuery, patients;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            limit = parseInt(req.query.limit) || 10;
            skip = parseInt(req.query.skip) || 0;
            searchQuery = req.query.patientName;
            _context.prev = 3;
            _context.next = 6;
            return (0, _bluebird.resolve)(_patientHistory.PatientHistory.findByName(searchQuery, limit, skip));

          case 6:
            patients = _context.sent;


            res.json({
              timestamp: Date.now(),
              patients: patients
            });
            _context.next = 13;
            break;

          case 10:
            _context.prev = 10;
            _context.t0 = _context['catch'](3);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0
            });

          case 13:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[3, 10]]);
  }));

  return function findByName(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var findByPatientIdAndGetHistory = exports.findByPatientIdAndGetHistory = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var _ref3, _ref4, patient, prescriptions;

    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return (0, _bluebird.resolve)((0, _bluebird.all)([_patientHistory.PatientHistory.findById(req.params.patientId), _patientHistory.PrescriptionHistory.findByPatientIdAndGetHistory(req.params.patientId)]));

          case 3:
            _ref3 = _context2.sent;
            _ref4 = (0, _slicedToArray3.default)(_ref3, 2);
            patient = _ref4[0];
            prescriptions = _ref4[1];


            res.json({
              timestamp: Date.now(),
              patient: patient,
              prescriptions: prescriptions
            });
            _context2.next = 13;
            break;

          case 10:
            _context2.prev = 10;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0
            });

          case 13:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 10]]);
  }));

  return function findByPatientIdAndGetHistory(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findSpecializations = exports.findSpecializations = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var _ref6, _ref7, patient, prescriptions;

    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            _context3.next = 3;
            return (0, _bluebird.resolve)((0, _bluebird.all)([_patientHistory.PatientHistory.findById(req.params.patientId), _patientHistory.PrescriptionHistory.findByPatientIdAndGetHistory(req.params.patientId)]));

          case 3:
            _ref6 = _context3.sent;
            _ref7 = (0, _slicedToArray3.default)(_ref6, 2);
            patient = _ref7[0];
            prescriptions = _ref7[1];


            res.json({
              timestamp: Date.now(),
              patient: patient,
              prescriptions: prescriptions
            });
            _context3.next = 13;
            break;

          case 10:
            _context3.prev = 10;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0
            });

          case 13:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 10]]);
  }));

  return function findSpecializations(_x5, _x6) {
    return _ref5.apply(this, arguments);
  };
}();

var _patientHistory = require('./patient-history.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=patient-history.controller.js.map
