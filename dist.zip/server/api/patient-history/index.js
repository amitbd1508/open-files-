'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./patient-history.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/findByName', controller.findByName);
router.get('/findByPatientIdAndGetHistory/:patientId', controller.findByPatientIdAndGetHistory);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
