'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PrescriptionHistory = exports.AppointmentHistory = exports.PatientHistory = exports.DoctorHistory = exports.RmpHistory = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var _values = require('babel-runtime/core-js/object/values');

var _values2 = _interopRequireDefault(_values);

/**
 * Static functions
 */
var findByName = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(searchQuery, limit, skip) {
    var query;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            query = {
              '$or': [{ fullname: { '$regex': searchQuery, '$options': 'i' } }, { serialnumber: { '$regex': searchQuery, '$options': 'i' } }, { phone: { '$regex': searchQuery, '$options': 'i' } }]
            };
            _context.next = 3;
            return (0, _bluebird.resolve)(PatientHistory.find(query).limit(limit).skip(skip).sort('fullname').exec());

          case 3:
            return _context.abrupt('return', _context.sent);

          case 4:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findByName(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

var findByPatientIdAndGetHistory = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(patientId) {
    var patient;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(PatientHistory.findById(patientId).exec());

          case 2:
            patient = _context2.sent;
            _context2.next = 5;
            return (0, _bluebird.resolve)(PrescriptionHistory.find({
              is_pdfready: true,
              patients_id: patient._id
            }).populate('appointment_id').populate('doctors_id').populate('rmp_id').sort('updated_at _id').exec());

          case 5:
            return _context2.abrupt('return', _context2.sent);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findByPatientIdAndGetHistory(_x4) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Exports
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Schemas
 */
var RmpHistorySchema = new _mongoose.Schema({
  profile_pic: String,
  fullname: String,
  center: String,
  phone: String,
  email: String
});

var DoctorHistorySchema = new _mongoose.Schema({
  profile_pic: String,
  fullname: String,
  identity: String,
  specialized: String,
  email: String
});

var PatientHistorySchema = new _mongoose.Schema({
  fullname: String,
  serialnumber: String,
  profilepiclink: String,
  phone: String,
  gender: String,
  dob: Date
});

var AppointmentHistorySchema = new _mongoose.Schema({
  patient_weight: Number,
  patient_temp: Number,
  patient_pulse: Number,
  patient_systole: Number,
  patient_diastole: Number,
  patient_glucose: Number,

  symptoms: [String],
  patients_images: [String]
});

var PrescriptionHistorySchema = new _mongoose.Schema({
  appointment_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'AppointmentHistory'
  },
  patients_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'PatientHistory'
  },
  rmp_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'RmpHistory'
  },
  doctors_id: {
    type: _mongoose.Schema.Types.ObjectId,
    ref: 'DoctorHistory'
  },

  is_pdfready: Boolean,

  symptoms: [String],

  personalinfo: [String],
  familyinfo: [String],
  druginfo: [String],
  chronicinfo: [String],

  is_followup: Boolean,
  is_referred: Boolean,

  chief_complaint: [{
    complainText: String,
    complainValue: Number,
    complainDur: String,
    complainDetail: String
  }],

  diagnosis: [String],
  investigations: [String],
  advices: [String],

  instruction: [{
    // FIXME: Should just be a single object instead of always an array of one value.
    selected: [{
      generic_name: String,
      trade_name: String,
      formulation: String
    }],
    // FIXME: Should just be an array of strings or numbers.
    doses: Object,
    duration: String,
    duration_type: String,
    // FIXME: Should just be an array of strings.
    instructions: [{
      text: String
    }],
    // FIXME: Should just be an array of strings.
    additional_instructions: [{
      text: String
    }]
  }]
});

/**
 * Options
 */
RmpHistorySchema.set('toJSON', {
  transform: transformRmpToJSON
});

DoctorHistorySchema.set('toJSON', {
  transform: transformDoctorToJSON
});

PatientHistorySchema.set('toJSON', {
  transform: transformPatientToJSON
});

AppointmentHistorySchema.set('toJSON', {
  transform: transformAppointmentToJSON
});

PrescriptionHistorySchema.set('toJSON', {
  transform: transformPrescriptionToJSON
});

/**
 * Statics
 */
PatientHistorySchema.static('findByName', findByName);

PrescriptionHistorySchema.static('findByPatientIdAndGetHistory', findByPatientIdAndGetHistory);

/**
 * Transform functions
 */
function transformRmpToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,
    name: ret.fullname,
    center: ret.center,
    phone: ret.phone,
    email: ret.email
  };
}

function transformDoctorToJSON(doc, ret) {
  return {
    id: ret._id,
    profile_pic: ret.profile_url,
    name: ret.fullname,
    identity: ret.identity,
    speciality: ret.specialized,
    email: ret.email
  };
}

function transformPatientToJSON(doc, ret) {
  return {
    id: ret._id,
    serial: ret.serialnumber,
    name: ret.fullname,
    profile_pic: ret.profilepiclink,
    sex: ret.gender,
    age: (0, _momentTimezone2.default)().diff((0, _momentTimezone2.default)(ret.dob), 'years'),
    phone: ret.phone
  };
}

function transformAppointmentToJSON(doc, ret) {
  return {
    id: ret._id,

    weight: ret.patient_weight,
    temperature: ret.patient_temp,
    pulse: ret.patient_pulse,

    blood_pressure: {
      systole: ret.patient_systole,
      diastole: ret.patient_diastole
    },
    glucose: ret.patient_glucose,

    symptoms: ret.symptoms,
    images: ret.patients_images
  };
}

function transformPrescriptionToJSON(doc, ret) {
  return {
    prescription_id: ret._id,
    prescription_date: ret.updated_at,

    rmp: ret.rmp_id,
    doctor: ret.doctors_id,
    appointment: ret.appointment_id,

    is_followup: ret.is_followup,
    is_referred: ret.is_referred,

    symptoms: ret.symptoms,

    history: {
      personal: ret.personalinfo,
      family: ret.familyinfo,
      drug: ret.druginfo,
      chronic: ret.chronicinfo
    },

    chief_complaint: ret.chief_complaint.map(function (complaint) {
      return {
        description: complaint.complainText,
        duration: {
          value: complaint.complainValue,
          type: complaint.complainDur
        },
        additional_description: complaint.complainDetail
      };
    }),

    diagnosis: ret.diagnosis,
    investigations: ret.investigations,
    advice: ret.advices,

    prescription: ret.instruction.map(function (instruct) {
      return {
        medicine: {
          generic_name: instruct.selected[0].generic_name,
          trade_name: instruct.selected[0].trade_name,
          formulation: instruct.selected[0].formulation
        },
        dose: instruct.doses ? (0, _values2.default)(instruct.doses).join('-') : '',
        duration: {
          value: instruct.duration,
          type: instruct.duration_type
        },
        instructions: instruct.instructions.map(function (innerInstruct) {
          return innerInstruct.text;
        }),
        additional_instructions: instruct.additional_instructions.map(function (innerInstruct) {
          return innerInstruct.text;
        })
      };
    })
  };
}var RmpHistory = exports.RmpHistory = _mongoose2.default.model('RmpHistory', RmpHistorySchema, 'users');
var DoctorHistory = exports.DoctorHistory = _mongoose2.default.model('DoctorHistory', DoctorHistorySchema, 'users');
var PatientHistory = exports.PatientHistory = _mongoose2.default.model('PatientHistory', PatientHistorySchema, 'patients');
var AppointmentHistory = exports.AppointmentHistory = _mongoose2.default.model('AppointmentHistory', AppointmentHistorySchema, 'appointments');
var PrescriptionHistory = exports.PrescriptionHistory = _mongoose2.default.model('PrescriptionHistory', PrescriptionHistorySchema, 'prescriptions');
//# sourceMappingURL=patient-history.model.js.map
