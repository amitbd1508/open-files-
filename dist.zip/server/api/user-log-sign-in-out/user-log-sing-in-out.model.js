'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UserSignInOutLog = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(startDate, endDate, eventType, userIds) {
    var limit = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 50;
    var skip = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0;
    var dateStartOfWeek, dateEndOfWeek, query, logs, count;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            dateStartOfWeek = (0, _momentTimezone2.default)().startOf('week').toDate();
            dateEndOfWeek = (0, _momentTimezone2.default)().endOf('week').toDate();


            startDate = startDate ? (0, _momentTimezone2.default)(startDate).toDate() : dateStartOfWeek;
            endDate = endDate ? (0, _momentTimezone2.default)(endDate).toDate() : dateEndOfWeek;

            query = {
              createdAt: { $gte: startDate, $lte: endDate }
            };


            eventType ? query.eventType = eventType : '';
            eventType === 'All' ? delete query.eventType : '';

            if (userIds) {
              userIds = _lodash2.default.isArray(userIds) ? userIds : [userIds];
              userIds = userIds.map(function (id) {
                return objectId(id);
              });
              userIds ? query.createdBy = { $in: userIds } : '';
            }

            _context.next = 10;
            return (0, _bluebird.resolve)(UserSignInOutLog.find(query).limit(parseInt(limit)).skip(parseInt(skip)).populate({
              path: 'createdBy',
              select: 'fullname profile_url usertype'
            }).sort('-createdAt').exec());

          case 10:
            logs = _context.sent;
            _context.next = 13;
            return (0, _bluebird.resolve)(UserSignInOutLog.count(query).exec());

          case 13:
            count = _context.sent;
            return _context.abrupt('return', {
              logs: logs,
              count: count
            });

          case 15:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function index(_x, _x2, _x3, _x4, _x5, _x6) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _userSingInOutLog = require('../../schemas/user-sing-in-out-log.schema');

var _userSingInOutLog2 = _interopRequireDefault(_userSingInOutLog);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _userLogSignInOut = require('./user-log-sign-in-out.events');

var _userLogSignInOut2 = _interopRequireDefault(_userLogSignInOut);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

var expressUserAgent = require('express-useragent');
/**
 * Statics
 */

_userSingInOutLog2.default.static('index', index).static('logUserEvent', logUserEvent);

/**
 * Save user login/out time with event('login/logout') & userAgent info
 *
 * @param userId
 * @param req
 * @param eventType
 * @return {Promise.<*>}
 */

function logUserEvent(userId, req, eventType) {
  var userAgent = exportUserDetail(req);

  var userSignInOutLog = new UserSignInOutLog();
  userSignInOutLog.createdBy = userId;
  userSignInOutLog.eventType = eventType;
  userSignInOutLog.time = new Date();
  userSignInOutLog.userAgent = userAgent;

  _userLogSignInOut2.default.emit('user:log:create');

  return userSignInOutLog.save();
}

function exportUserDetail(req) {
  var source = req.headers['user-agent'],
      ua = expressUserAgent.parse(source);

  return ua;
}

var UserSignInOutLog = exports.UserSignInOutLog = _mongoose2.default.model('UserSignInOutLog', _userSingInOutLog2.default, 'userSignInOutLog');
//# sourceMappingURL=user-log-sing-in-out.model.js.map
