'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.index = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */
var index = exports.index = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var startDate, endDate, limit, skip, eventType, userIds, logs;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;
            startDate = req.query.startDate;
            endDate = req.query.endDate;
            limit = req.query.limit;
            skip = req.query.skip;
            eventType = req.query.eventType;
            userIds = req.query.userIds;
            _context.next = 9;
            return (0, _bluebird.resolve)(_userLogSingInOut.UserSignInOutLog.index(startDate, endDate, eventType, userIds, limit, skip));

          case 9:
            logs = _context.sent;


            res.json({
              timestamp: Date.now(),
              logs: logs
            });
            _context.next = 16;
            break;

          case 13:
            _context.prev = 13;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0.toString()
            });

          case 16:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 13]]);
  }));

  return function index(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var _userLogSingInOut = require('./user-log-sing-in-out.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=user-log-sing-in-out.controller.js.map
