'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _userLogSignInOut = require('./user-log-sign-in-out.events');

var _userLogSignInOut2 = _interopRequireDefault(_userLogSignInOut);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
}

/**
 * Socket Messages
 */

/**
 * Publish Widget Message
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('user:log:create', {
      timestamp: Date.now()
    });
  };

  _userLogSignInOut2.default.on('user:log:create', listener);

  socket.on('disconnect', function () {
    _userLogSignInOut2.default.removeListener('user:log:create', listener);
  });
}
//# sourceMappingURL=user-log-sign-in-out.socket.js.map
