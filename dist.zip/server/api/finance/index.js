'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./finance.controller');

var router = express.Router();

/**
 * Routes
 */

router.get('/report', controller.allReports);
router.get('/report/:rmpId', controller.report);
router.get('/payments', controller.payments);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
