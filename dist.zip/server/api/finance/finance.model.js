'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.payments = undefined;

var _bluebird = require('bluebird');

var Promise = _interopRequireWildcard(_bluebird);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var payments = exports.payments = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(startDate, endDate, rmpIds, skip, limit) {
    var query;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(filters(startDate, endDate, rmpIds));

          case 2:
            query = _context.sent;
            return _context.abrupt('return', Payment.find(query).limit(parseInt(limit)).skip(parseInt(skip)).populate('rmp_id').sort('-created_at').lean().exec());

          case 4:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function payments(_x, _x2, _x3, _x4, _x5) {
    return _ref.apply(this, arguments);
  };
}();

var filters = function () {
  var _ref2 = (0, _bluebird.method)(function (startDate, endDate, rmpIds) {
    var query = {
      created_at: { $gte: startDate, $lte: endDate }
    };

    if (rmpIds) {
      rmpIds = _lodash2.default.isArray(rmpIds) ? rmpIds : [rmpIds];
      rmpIds = rmpIds.map(function (id) {
        return objectId(id);
      });
      rmpIds ? query.rmp_id = { $in: rmpIds } : '';
    }

    return query;
  });

  return function filters(_x6, _x7, _x8) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Models
 */


exports.generateAllReports = generateAllReports;
exports.generateReport = generateReport;

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

var _payment = require('../../schemas/payment.schema');

var _payment2 = _interopRequireDefault(_payment);

var _transaction = require('../../schemas/transaction.schema');

var _transaction2 = _interopRequireDefault(_transaction);

var _adjustment = require('../../schemas/adjustment.schema');

var _adjustment2 = _interopRequireDefault(_adjustment);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Functions for Finance
 */

function generateAllReports(startMoment, endMoment) {
  // Promise for list of rmps
  var pRmps = User.find({
    usertype: 'rmp'
  }).sort('fullname').exec();

  // Map to promise for list of reports
  return Promise.map(pRmps, function (rmp) {
    return generateReport(rmp.id, startMoment, endMoment);
  });
}

function generateReport(rmpId, startMoment, endMoment) {
  // List of moments
  var allMoments = [];
  var aMoment = startMoment.clone();
  while (aMoment <= endMoment) {
    allMoments.push(aMoment);
    aMoment = aMoment.clone().add(1, 'day');
  }

  // Promise for Rmp
  var pRmp = User.findById(rmpId).exec();

  // Map to promise for list of rows
  return pRmp.then(function (rmp) {
    return Promise.map(allMoments, function (aMoment) {
      return generateReportRow(rmp, aMoment);
    });
  });
}

function generateReportRow(rmp, aMoment) {
  // Promise for a row
  return Promise.all([calculateRevenue(rmp, aMoment), calculateAdjustment(rmp, aMoment), calculateNetRevenue(rmp, aMoment), calculateNetAdjustment(rmp, aMoment), calculateAdvance(rmp, aMoment), calculateNetAdvance(rmp, aMoment)]).spread(function (revenue, adjustment, netRevenue, netAdjustment, advance, netAdvance) {
    return {
      name: rmp.fullname,
      date: aMoment,
      revenue: revenue,
      adjustment: adjustment,
      advance: advance,
      netRevenue: netRevenue,
      netAdjustment: netAdjustment,
      netAdvance: netAdvance,
      netPayable: netAdvance + netAdjustment - netRevenue
    };
  });
}

function calculateRevenue(rmp, aMoment) {
  return Transaction.aggregate({
    $match: {
      rmp_id: rmp._id,
      created_at: {
        $gte: aMoment.toDate(),
        $lt: aMoment.clone().add(1, 'day').toDate()
      }
    }
  }, {
    $group: {
      _id: null,
      totalRevenue: { $sum: '$total' },
      rmpRevenue: { $sum: '$rmp_share' }
    }
  }, {
    $project: {
      revenue: { $subtract: ['$totalRevenue', '$rmpRevenue'] }
    }
  }).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].revenue;
    return 0;
  });
}

function calculateAdjustment(rmp, aMoment) {
  return Adjustment.aggregate({
    $match: {
      rmp_id: rmp._id,
      created_at: {
        $gte: aMoment.toDate(),
        $lt: aMoment.clone().add(1, 'day').toDate()
      }
    }
  }, {
    $group: {
      _id: null,
      transaction: { $sum: '$amount' }
    }
  }).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].transaction;
    return 0;
  });
}

function calculateNetRevenue(rmp, aMoment) {
  return Transaction.aggregate({
    $match: {
      rmp_id: rmp._id,
      created_at: {
        $lt: aMoment.clone().add(1, 'day').toDate()
      }
    }
  }, {
    $group: {
      _id: null,
      totalRevenue: { $sum: '$total' },
      rmpRevenue: { $sum: '$rmp_share' }
    }
  }, {
    $project: {
      revenue: { $subtract: ['$totalRevenue', '$rmpRevenue'] }
    }
  }).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].revenue;
    return 0;
  });
}

function calculateAdvance(rmp, aMoment) {
  return Payment.aggregate({
    $match: {
      rmp_id: rmp._id,
      created_at: {
        $gte: aMoment.toDate(),
        $lt: aMoment.clone().add(1, 'day').toDate()
      }
    }
  }, {
    $group: {
      _id: null,
      advance: { $sum: '$amount' }
    }
  }).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].advance;
    return 0;
  });
}

function calculateNetAdvance(rmp, aMoment) {
  return Payment.aggregate({
    $match: {
      rmp_id: rmp._id,
      created_at: {
        $lt: aMoment.clone().add(1, 'day').toDate()
      }
    }
  }, {
    $group: {
      _id: null,
      advance: { $sum: '$amount' }
    }
  }).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].advance;
    return 0;
  });
}

function calculateNetAdjustment(rmp, aMoment) {
  return Adjustment.aggregate({
    $match: {
      rmp_id: rmp._id,
      created_at: {
        $lt: aMoment.clone().add(1, 'day').toDate()
      }
    }
  }, {
    $group: {
      _id: null,
      transaction: { $sum: '$amount' }
    }
  }).exec().then(function (rows) {
    if (rows.length > 0) return rows[0].transaction;
    return 0;
  });
}

var User = _mongoose2.default.model('FinanceUser', _user2.default, 'users');
var Transaction = _mongoose2.default.model('FinanceTransaction', _transaction2.default, 'transactions');
var Adjustment = _mongoose2.default.model('FinanceAdjustmentTransaction', _adjustment2.default, 'adjustments');
var Payment = _mongoose2.default.model('FinancePayment', _payment2.default, 'payments');
//# sourceMappingURL=finance.model.js.map
