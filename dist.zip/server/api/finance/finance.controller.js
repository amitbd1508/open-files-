'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.payments = undefined;

var _bluebird = require('bluebird');

var payments = exports.payments = function () {
  var _ref = (0, _bluebird.method)(function (req, res) {
    var limit = parseInt(req.query.limit, 10) || 20;
    var skip = parseInt(req.query.skip, 10) || 0;
    var rmpIds = req.query.rmpIds;
    var startDate = (0, _momentTimezone2.default)(req.query.startDate).toDate();
    var endDate = (0, _momentTimezone2.default)(req.query.endDate).toDate();

    try {
      Finance.payments(startDate, endDate, rmpIds, skip, limit).then(function (payments) {
        res.json({
          timestamp: Date.now(),
          payments: payments
        });
      });
    } catch (error) {
      res.status(400).end(error);
    }
  });

  return function payments(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

exports.allReports = allReports;
exports.report = report;

var _finance = require('./finance.model');

var Finance = _interopRequireWildcard(_finance);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

/**
 * Actions
 */

/**
 * Reports for all RMPs
 *
 * @param req
 * @param res
 */
function allReports(req, res) {
  var startMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate) : (0, _momentTimezone2.default)().startOf('month');
  var endMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');

  Finance.generateAllReports(startMoment, endMoment).then(function (reports) {
    res.json({
      timestamp: Date.now(),
      startDate: startMoment,
      endDate: endMoment,
      reports: reports
    });
  });
}

/**
 * Report for an RMP
 *
 * @param req
 * @param res
 */
function report(req, res) {
  var rmpId = req.params.rmpId;
  var startMoment = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate) : (0, _momentTimezone2.default)().startOf('month');
  var endMoment = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate) : (0, _momentTimezone2.default)().endOf('month');

  Finance.generateReport(rmpId, startMoment, endMoment).then(function (report) {
    res.json({
      timestamp: Date.now(),
      startDate: startMoment,
      endDate: endMoment,
      reports: [report]
    });
  });
}
//# sourceMappingURL=finance.controller.js.map
