'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _investigation = require('./investigation.events');

var _investigation2 = _interopRequireDefault(_investigation);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
}

/**
 * Socket Messages
 */

/**
 * Publish Widget Message
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener() {
    socket.emit('investigation:create', {
      timestamp: Date.now()
    });
  };

  _investigation2.default.on('investigation:create', listener);

  socket.on('disconnect', function () {
    _investigation2.default.removeListener('investigation:create', listener);
  });
}
//# sourceMappingURL=investigation.socket.js.map
