'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.exportInvestigationData = exports.findByIdAndUpdateWithApprove = exports.findPendingApproval = exports.search = exports.removeDuplicateEntries = exports.create = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var create = exports.create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var investigation;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            req.body.userId = req.user._id;
            _context.next = 3;
            return (0, _bluebird.resolve)(_investigation.Investigation.create(req.body));

          case 3:
            investigation = _context.sent;

            res.json({
              timestamp: Date.now(),
              investigation: investigation
            });

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var removeDuplicateEntries = exports.removeDuplicateEntries = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var investigation;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(_investigation.Investigation.removeDuplicateEntries());

          case 2:
            investigation = _context2.sent;

            res.json({
              timestamp: Date.now(),
              investigation: investigation
            });

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function removeDuplicateEntries(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var search = exports.search = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var limit, skip, searchQuery, reports;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            limit = parseInt(req.query.limit, 10) || 20;
            skip = parseInt(req.query.skip, 10) || 0;
            searchQuery = req.query.q;


            if (!searchQuery) {
              searchQuery = 'hello';
            }

            _context3.next = 6;
            return (0, _bluebird.resolve)(_investigation.Investigation.findInvestigation(skip, limit, searchQuery));

          case 6:
            reports = _context3.sent;


            res.json({
              timestamp: Date.now(),
              reports: reports
            });

          case 8:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function search(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findPendingApproval = exports.findPendingApproval = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var limit, skip, reports;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            limit = parseInt(req.query.limit, 10) || 10;
            skip = parseInt(req.query.skip, 10) || 0;
            _context4.next = 4;
            return (0, _bluebird.resolve)(_investigation.Investigation.findPendingApproval(skip, limit));

          case 4:
            reports = _context4.sent;

            res.json({
              timestamp: Date.now(),
              reports: reports
            });

          case 6:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findPendingApproval(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = exports.findByIdAndUpdateWithApprove = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var investigationId, formBody, reports;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            investigationId = req.params.investigationId;
            formBody = req.body;
            _context5.next = 4;
            return (0, _bluebird.resolve)(_investigation.Investigation.findByIdAndUpdateWithApprove(investigationId, formBody));

          case 4:
            reports = _context5.sent;

            res.json({
              timestamp: Date.now(),
              reports: reports
            });

          case 6:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findByIdAndUpdateWithApprove(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var exportInvestigationData = exports.exportInvestigationData = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var reports;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(_investigation.Investigation.exportInvestigationData());

          case 2:
            reports = _context6.sent;

            res.json({
              timestamp: Date.now(),
              reports: reports
            });

          case 4:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function exportInvestigationData(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var _investigation = require('./investigation.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=investigation.controller.js.map
