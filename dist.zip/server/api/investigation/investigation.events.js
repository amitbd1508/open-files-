'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var InvestigationEvents = new _events.EventEmitter();

/**
 * Options
 */
InvestigationEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = InvestigationEvents;
//# sourceMappingURL=investigation.events.js.map
