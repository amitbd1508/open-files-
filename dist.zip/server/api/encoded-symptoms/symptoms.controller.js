'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findByIdAndUpdateWithApprove = exports.index = exports.search = exports.suggestions = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var suggestions = exports.suggestions = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var appointmentId, _suggestions;

    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            appointmentId = req.params.appointmentId;


            if (!appointmentId) res.status(400).send();

            _context.prev = 2;
            _context.next = 5;
            return (0, _bluebird.resolve)(_symptoms.Symptoms.suggestionsByAppointmentId(appointmentId));

          case 5:
            _suggestions = _context.sent;


            res.json({
              timestamp: Date.now(),
              suggestions: _suggestions
            });
            _context.next = 12;
            break;

          case 9:
            _context.prev = 9;
            _context.t0 = _context['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0
            });

          case 12:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[2, 9]]);
  }));

  return function suggestions(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var search = exports.search = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var limit, skip, searchQuery, symptoms;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            limit = parseInt(req.query.limit, 10) || 40;
            skip = parseInt(req.query.skip, 10) || 0;
            searchQuery = req.query.q;


            if (!searchQuery) res.status(400).end();

            _context2.next = 7;
            return (0, _bluebird.resolve)(_symptoms.Symptoms.search(skip, limit, searchQuery));

          case 7:
            symptoms = _context2.sent;


            res.json({
              timestamp: Date.now(),
              symptoms: symptoms
            });
            _context2.next = 14;
            break;

          case 11:
            _context2.prev = 11;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0
            });

          case 14:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 11]]);
  }));

  return function search(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var index = exports.index = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var limit, skip, count, countPending, symptoms;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            limit = parseInt(req.query.limit, 10) || 20;
            skip = parseInt(req.query.skip, 10) || 0;
            _context3.next = 5;
            return (0, _bluebird.resolve)(_symptoms.Symptoms.count());

          case 5:
            count = _context3.sent;
            _context3.next = 8;
            return (0, _bluebird.resolve)(_symptoms.Symptoms.countPending());

          case 8:
            countPending = _context3.sent;
            _context3.next = 11;
            return (0, _bluebird.resolve)(_symptoms.Symptoms.index(skip, limit));

          case 11:
            symptoms = _context3.sent;


            res.json({
              timestamp: Date.now(),
              symptoms: symptoms,
              count: count,
              countPending: countPending
            });
            _context3.next = 18;
            break;

          case 15:
            _context3.prev = 15;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0
            });

          case 18:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 15]]);
  }));

  return function index(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = exports.findByIdAndUpdateWithApprove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var userId, symptomsId, formBody, symptoms;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            userId = req.user._id;
            symptomsId = req.params.id;
            formBody = req.body;
            _context4.next = 6;
            return (0, _bluebird.resolve)(_symptoms.Symptoms.findByIdAndUpdateWithApprove(symptomsId, formBody, userId));

          case 6:
            symptoms = _context4.sent;


            res.json({
              timestamp: Date.now(),
              symptoms: symptoms
            });
            _context4.next = 13;
            break;

          case 10:
            _context4.prev = 10;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0
            });

          case 13:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 10]]);
  }));

  return function findByIdAndUpdateWithApprove(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var _symptoms = require('./symptoms.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=symptoms.controller.js.map
