'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Symptoms = exports.countPending = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var suggestionsByAppointmentId = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(appointmentId) {
    var appointment, prescriptions, encodedSymptoms;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(_prescription.Appointment.findById(appointmentId).select('patients_id start').lean().exec());

          case 2:
            appointment = _context.sent;
            _context.next = 5;
            return (0, _bluebird.resolve)(_prescription.Prescription.find({
              is_pdfready: true,
              publishAt: {
                $lt: appointment.start
              },
              patients_id: appointment.patients_id
            }).lean().exec());

          case 5:
            prescriptions = _context.sent;
            encodedSymptoms = [];

            prescriptions.map(function (prescription) {

              return prescription.encodedSymptoms.map(function (item) {
                encodedSymptoms.push(item);
                return item;
              });
            });

            return _context.abrupt('return', encodedSymptoms);

          case 9:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function suggestionsByAppointmentId(_x) {
    return _ref.apply(this, arguments);
  };
}();

var search = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(skip, limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            skip = parseInt(skip, 10) || 0;
            limit = parseInt(limit, 10) || 10;

            query = {
              primaryTerm: { $regex: searchQuery, $options: 'i' },
              isIgnored: false
            };
            _context2.next = 5;
            return (0, _bluebird.resolve)(Symptoms.find(query).limit(limit).skip(skip).sort({
              primaryTerm: -1
            }).select('primaryTerm SNOMEDConceptId').lean().exec());

          case 5:
            return _context2.abrupt('return', _context2.sent);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function search(_x2, _x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var index = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(skip, limit) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            skip = parseInt(skip, 10) || 0;
            limit = parseInt(limit, 10) || 40;

            _context3.next = 4;
            return (0, _bluebird.resolve)(Symptoms.find({
              isIgnored: false
            }).skip(skip).limit(limit).sort('isApproved primaryTerm').populate({
              path: 'userId',
              select: 'fullname'
            }).exec());

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function index(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(symptomsId, formData, userId) {
    var _this = this;

    var symptoms;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(Symptoms.findById(symptomsId).exec());

          case 2:
            symptoms = _context5.sent;


            symptoms.SNOMEDConceptId = formData.SNOMEDConceptId;
            symptoms.primaryTerm = formData.primaryTerm;
            symptoms.system = formData.system;
            symptoms.isApproved = true;
            symptoms.isPrimary = formData.isPrimary;
            symptoms.isIgnored = formData.isIgnored;
            symptoms.advice = formData.advice;

            if (formData.synonyms.length > 0) {
              formData.synonyms.forEach(function () {
                var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(value) {
                  var newSymptom;
                  return _regenerator2.default.wrap(function _callee4$(_context4) {
                    while (1) {
                      switch (_context4.prev = _context4.next) {
                        case 0:
                          newSymptom = new Symptoms();

                          newSymptom.SNOMEDConceptId = formData.SNOMEDConceptId;
                          newSymptom.primaryTerm = value;
                          newSymptom.isIgnored = formData.isIgnored;
                          newSymptom.isApproved = true;
                          newSymptom.isPrimary = false;
                          newSymptom.userId = userId;
                          _context4.next = 9;
                          return (0, _bluebird.resolve)(newSymptom.save());

                        case 9:
                        case 'end':
                          return _context4.stop();
                      }
                    }
                  }, _callee4, _this);
                }));

                return function (_x10) {
                  return _ref5.apply(this, arguments);
                };
              }());
            }

            _context5.next = 13;
            return (0, _bluebird.resolve)(symptoms.save());

          case 13:
            return _context5.abrupt('return', _context5.sent);

          case 14:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findByIdAndUpdateWithApprove(_x7, _x8, _x9) {
    return _ref4.apply(this, arguments);
  };
}();

var countPending = exports.countPending = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6() {
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(Symptoms.count({
              isApproved: false
            }));

          case 2:
            return _context6.abrupt('return', _context6.sent);

          case 3:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function countPending() {
    return _ref6.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _symptom = require('../../schemas/symptom.schema');

var _symptom2 = _interopRequireDefault(_symptom);

var _prescription = require('../prescription/prescription.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */

_symptom2.default.static('search', search).static('index', index).static('countPending', countPending).static('suggestionsByAppointmentId', suggestionsByAppointmentId).static('findByIdAndUpdateWithApprove', findByIdAndUpdateWithApprove);var Symptoms = exports.Symptoms = _mongoose2.default.model('Symptoms', _symptom2.default, 'symptoms');
//# sourceMappingURL=symptoms.model.js.map
