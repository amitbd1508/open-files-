'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.User = undefined;

var _toConsumableArray2 = require('babel-runtime/helpers/toConsumableArray');

var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Functions
 */
var saveWidgets = function () {
  var _ref = (0, _bluebird.method)(function (userId, widgets) {
    return this.findByIdAndUpdate(userId, {
      'dashboard.savedWidgets': widgets
    }).exec();
  });

  return function saveWidgets(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var findSavedWidgets = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(userId) {
    var user;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              _id: userId,
              'dashboard.savedWidgets': { $exists: true }
            }).select('dashboard.savedWidgets').exec());

          case 2:
            user = _context.sent;

            if (!user) {
              _context.next = 5;
              break;
            }

            return _context.abrupt('return', user.dashboard.savedWidgets);

          case 5:
            return _context.abrupt('return', []);

          case 6:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findSavedWidgets(_x3) {
    return _ref2.apply(this, arguments);
  };
}();

var publishWidget = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(userId, widget) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            widget.publishedAt = new Date();

            _context2.next = 3;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(userId, {
              $push: {
                'dashboard.publishedWidgets': widget
              }
            }).exec());

          case 3:

            _dashboard2.default.emit('dashboard:publish', widget);

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function publishWidget(_x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}();

var unpublishWidget = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(userId, widgetId) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(this.findByIdAndUpdate(userId, {
              $pull: {
                'dashboard.publishedWidgets': {
                  id: widgetId
                }
              }
            }).exec());

          case 2:

            _dashboard2.default.emit('dashboard:unpublish');

          case 3:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function unpublishWidget(_x6, _x7) {
    return _ref4.apply(this, arguments);
  };
}();

var findPublishedWidgets = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(userId) {
    var user;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.findOne({
              _id: userId,
              'dashboard.publishedWidgets': { $exists: true }
            }).select('dashboard.publishedWidgets').exec());

          case 2:
            user = _context4.sent;

            if (!user) {
              _context4.next = 5;
              break;
            }

            return _context4.abrupt('return', user.dashboard.publishedWidgets);

          case 5:
            return _context4.abrupt('return', []);

          case 6:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findPublishedWidgets(_x8) {
    return _ref5.apply(this, arguments);
  };
}();

var findAllPublishedWidgets = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5() {
    var _ref7;

    var users, publishedWidgetGroups;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(this.find({
              'dashboard.publishedWidgets': { $exists: true }
            }).select('fullname dashboard.publishedWidgets').exec());

          case 2:
            users = _context5.sent;
            publishedWidgetGroups = users.map(function (user) {
              return user.dashboard.publishedWidgets.map(function (widget) {
                widget.publishedBy = {
                  id: user._id,
                  name: user.fullname
                };
                return widget;
              });
            });
            return _context5.abrupt('return', (_ref7 = []).concat.apply(_ref7, (0, _toConsumableArray3.default)(publishedWidgetGroups)));

          case 5:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function findAllPublishedWidgets() {
    return _ref6.apply(this, arguments);
  };
}();

/**
 * Models
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _dashboard = require('./dashboard.events');

var _dashboard2 = _interopRequireDefault(_dashboard);

var _user = require('../../schemas/user.schema');

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_user2.default.static('saveWidgets', saveWidgets);
_user2.default.static('findSavedWidgets', findSavedWidgets);
_user2.default.static('publishWidget', publishWidget);
_user2.default.static('unpublishWidget', unpublishWidget);
_user2.default.static('findPublishedWidgets', findPublishedWidgets);
_user2.default.static('findAllPublishedWidgets', findAllPublishedWidgets);var User = exports.User = _mongoose2.default.model('DashboardUser', _user2.default, 'users');

/**
 * Exports
 */
exports.default = User;
//# sourceMappingURL=dashboard.model.js.map
