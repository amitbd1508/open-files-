'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _dashboard = require('./dashboard.events');

var _dashboard2 = _interopRequireDefault(_dashboard);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  publish(socket);
  unpublish(socket);
}

/**
 * Socket Messages
 */

/**
 * Publish Widget Message
 *
 * @param socket
 */
function publish(socket) {
  var listener = function listener(widget) {
    socket.emit('dashboard:publish', {
      timestamp: Date.now(),
      widget: widget
    });
  };

  _dashboard2.default.on('dashboard:publish', listener);

  socket.on('disconnect', function () {
    _dashboard2.default.removeListener('dashboard:publish', listener);
  });
}

/**
 * Unpublish Widget Message
 *
 * @param socket
 */
function unpublish(socket) {
  var listener = function listener() {
    socket.emit('dashboard:unpublish', {
      timestamp: Date.now()
    });
  };

  _dashboard2.default.on('dashboard:unpublish', listener);

  socket.on('disconnect', function () {
    _dashboard2.default.removeListener('dashboard:unpublish', listener);
  });
}
//# sourceMappingURL=dashboard.socket.js.map
