'use strict';

/**
 * Imports
 */

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var express = require('express');
var controller = require('./dashboard.controller');


var router = express.Router();

/**
 * Routes
 */

router.get('/:userId/widgets', auth.isAuthenticated(), controller.load);
router.get('/widgets', auth.isAuthenticated(), controller.injectParams, controller.load);

router.post('/:userId/widgets', auth.isAuthenticated(), controller.save);
router.post('/widgets', auth.isAuthenticated(), controller.injectParams, controller.save);

router.get('/:userId/publish', auth.isAuthenticated(), controller.list);
router.get('/publish', auth.isAuthenticated(), controller.injectParams, controller.list);

router.get('/publish/all', controller.listAll);

router.post('/:userId/publish', auth.isAuthenticated(), controller.publish);
router.post('/publish', auth.isAuthenticated(), controller.injectParams, controller.publish);

router.delete('/:userId/publish/:widgetId', auth.isAuthenticated(), controller.unpublish);
router.delete('/publish/:widgetId', auth.isAuthenticated(), controller.injectParams, controller.unpublish);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
