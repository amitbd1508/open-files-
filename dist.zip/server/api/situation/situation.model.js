'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Situation = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData) {
    var situation, newSituation, savedSituation;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Situation.findOne({
              primaryTerm: formData.primaryTerm
            }).exec());

          case 2:
            situation = _context.sent;

            if (!(situation === null)) {
              _context.next = 19;
              break;
            }

            newSituation = new Situation();

            newSituation.primaryTerm = formData.primaryTerm;
            newSituation.SNOMEDConceptId = formData.SNOMEDConceptId;
            newSituation.userId = formData.userId;
            newSituation.isApproved = false;
            newSituation.isPrimary = true;

            if (!(formData.userId && formData.primaryTerm)) {
              _context.next = 18;
              break;
            }

            _context.next = 13;
            return (0, _bluebird.resolve)(newSituation.save());

          case 13:
            savedSituation = _context.sent;

            _situation4.default.emit('prescription:situation:add', savedSituation);
            return _context.abrupt('return', savedSituation);

          case 18:
            return _context.abrupt('return', situation);

          case 19:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var findSituation = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(skip, limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            skip = parseInt(skip, 10) || 0;
            limit = parseInt(limit, 10) || 10;
            query = {
              primaryTerm: { $regex: searchQuery, $options: 'i' },
              isIgnored: false
            };
            _context2.next = 5;
            return (0, _bluebird.resolve)(Situation.find(query).limit(limit).skip(skip).sort({
              primaryTerm: -1
            }).select('primaryTerm SNOMEDConceptId').lean().exec());

          case 5:
            return _context2.abrupt('return', _context2.sent);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function findSituation(_x2, _x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findPendingApproval = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(skip, limit) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            skip = parseInt(skip, 10) || 0;
            limit = parseInt(limit, 10) || 20;

            _context3.next = 4;
            return (0, _bluebird.resolve)(Situation.aggregate([{
              $project: {
                primaryTerm: 1,
                isPrimary: 1,
                isApproved: 1,
                SNOMEDConceptId: 1,
                userId: 1,
                insensitive: {
                  $toLower: '$primaryTerm'
                }
              }
            }, {
              $sort: {
                insensitive: 1
              }
            }, {
              $skip: skip
            }, {
              $limit: limit
            }, {
              $lookup: {
                from: 'users',
                localField: 'userId',
                foreignField: '_id',
                as: 'theUser'
              }
            }, {
              $unwind: {
                path: '$theUser'
              }
            }]));

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findPendingApproval(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(symptomsId, formData) {
    var situation;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(Situation.findById(symptomsId).exec());

          case 2:
            situation = _context4.sent;


            situation.SNOMEDConceptId = formData.SNOMEDConceptId;
            situation.primaryTerm = formData.primaryTerm;
            situation.system = formData.system;
            situation.isApproved = true;
            situation.isPrimary = formData.isPrimary;
            situation.isIgnored = formData.isIgnored;

            _context4.next = 11;
            return (0, _bluebird.resolve)(situation.save(function (err, callback) {
              if (err) {
                return callback(err);
              }
              if (formData.synonyms) {
                formData.synonyms.forEach(function (value) {
                  var newSituation = new Situation();
                  if (formData.SNOMEDConceptId) {
                    newSituation.SNOMEDConceptId = formData.SNOMEDConceptId;
                  }
                  newSituation.primaryTerm = value;
                  newSituation.isApproved = true;
                  newSituation.isPrimary = false;
                  newSituation.isIgnored = formData.isIgnored;
                  newSituation.save();
                });
              }
            }));

          case 11:
            return _context4.abrupt('return', _context4.sent);

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function findByIdAndUpdateWithApprove(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _situation = require('../../schemas/situation.schema');

var _situation2 = _interopRequireDefault(_situation);

var _situation3 = require('./situation.events');

var _situation4 = _interopRequireDefault(_situation3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */

_situation2.default.static('findSituation', findSituation).static('findPendingApproval', findPendingApproval).static('create', create).static('findByIdAndUpdateWithApprove', findByIdAndUpdateWithApprove);var Situation = exports.Situation = _mongoose2.default.model('Situation', _situation2.default, 'situations');
//# sourceMappingURL=situation.model.js.map
