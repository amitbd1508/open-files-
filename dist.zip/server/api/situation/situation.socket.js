'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _situation = require('./situation.events');

var _situation2 = _interopRequireDefault(_situation);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  create(socket);
}

/**
 * Socket Messages
 */

/**
 * Publish Widget Message
 *
 * @param socket
 */
function create(socket) {
  var listener = function listener(situation) {
    socket.emit('prescription:situation:add', {
      timestamp: Date.now(),
      situation: situation
    });
  };

  _situation2.default.on('prescription:situation:add', listener);

  socket.on('disconnect', function () {
    _situation2.default.removeListener('prescription:situation:add', listener);
  });
}
//# sourceMappingURL=situation.socket.js.map
