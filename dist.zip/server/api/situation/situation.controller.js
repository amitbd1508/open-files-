'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.findByIdAndUpdateWithApprove = exports.findPendingApproval = exports.search = exports.create = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var create = exports.create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var situation;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;

            if (req.user) {
              req.body.userId = req.user._id;
            }
            _context.next = 4;
            return (0, _bluebird.resolve)(_situation.Situation.create(req.body));

          case 4:
            situation = _context.sent;

            res.json({
              timestamp: Date.now(),
              situation: situation
            });
            _context.next = 11;
            break;

          case 8:
            _context.prev = 8;
            _context.t0 = _context['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context.t0
            });

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[0, 8]]);
  }));

  return function create(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var search = exports.search = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var limit, skip, searchQuery, situations;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            limit = parseInt(req.query.limit, 10) || 20;
            skip = parseInt(req.query.skip, 10) || 0;
            searchQuery = req.query.q;


            if (!searchQuery) {
              res.status(400).end();
            }

            _context2.next = 7;
            return (0, _bluebird.resolve)(_situation.Situation.findSituation(skip, limit, searchQuery));

          case 7:
            situations = _context2.sent;


            res.json({
              timestamp: Date.now(),
              situations: situations
            });
            _context2.next = 14;
            break;

          case 11:
            _context2.prev = 11;
            _context2.t0 = _context2['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context2.t0
            });

          case 14:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this, [[0, 11]]);
  }));

  return function search(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var findPendingApproval = exports.findPendingApproval = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var limit, skip, situations;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.prev = 0;
            limit = parseInt(req.query.limit, 10) || 10;
            skip = parseInt(req.query.skip, 10) || 0;
            _context3.next = 5;
            return (0, _bluebird.resolve)(_situation.Situation.findPendingApproval(skip, limit));

          case 5:
            situations = _context3.sent;


            res.json({
              timestamp: Date.now(),
              situations: situations
            });
            _context3.next = 12;
            break;

          case 9:
            _context3.prev = 9;
            _context3.t0 = _context3['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context3.t0
            });

          case 12:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this, [[0, 9]]);
  }));

  return function findPendingApproval(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = exports.findByIdAndUpdateWithApprove = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var situationId, formBody, situations;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.prev = 0;
            situationId = req.params.situationId;
            formBody = req.body;
            _context4.next = 5;
            return (0, _bluebird.resolve)(_situation.Situation.findByIdAndUpdateWithApprove(situationId, formBody));

          case 5:
            situations = _context4.sent;

            res.json({
              timestamp: Date.now(),
              situations: situations
            });
            _context4.next = 12;
            break;

          case 9:
            _context4.prev = 9;
            _context4.t0 = _context4['catch'](0);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0
            });

          case 12:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[0, 9]]);
  }));

  return function findByIdAndUpdateWithApprove(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var _situation = require('./situation.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=situation.controller.js.map
