'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _events = require('events');

/**
 * Emitter
 */
var SituationEvents = new _events.EventEmitter();

/**
 * Options
 */
SituationEvents.setMaxListeners(0);

/**
 * Exports
 */
exports.default = SituationEvents;
//# sourceMappingURL=situation.events.js.map
