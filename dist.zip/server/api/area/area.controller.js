'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getVillageNames = exports.search = exports.create = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Actions
 */

var create = exports.create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var area;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            req.body.userId = req.user._id;
            _context.next = 3;
            return (0, _bluebird.resolve)(_area.Area.create(req.body));

          case 3:
            area = _context.sent;

            res.json({
              timestamp: Date.now(),
              area: area
            });

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

var search = exports.search = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    var limit, skip, searchQuery, reports;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            limit = parseInt(req.query.limit, 10) || 20;
            skip = parseInt(req.query.skip, 10) || 0;
            searchQuery = req.query.village;


            if (!searchQuery) {
              searchQuery = 'a';
            }

            _context2.next = 6;
            return (0, _bluebird.resolve)(_area.Area.getVillage(skip, limit, searchQuery));

          case 6:
            reports = _context2.sent;


            res.json({
              timestamp: Date.now(),
              reports: reports
            });

          case 8:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function search(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var getVillageNames = exports.getVillageNames = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var villages;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            villages = [];

            if (!req.body.villages) {
              _context3.next = 5;
              break;
            }

            _context3.next = 4;
            return (0, _bluebird.resolve)(_area.Area.getVillageNames(req.body.villages));

          case 4:
            villages = _context3.sent;

          case 5:

            res.json({
              timestamp: Date.now(),
              villages: villages
              //,
              // village
            });

          case 6:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getVillageNames(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

var _area = require('./area.model');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=area.controller.js.map
