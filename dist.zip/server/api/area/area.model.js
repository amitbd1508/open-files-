'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Area = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var create = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(formData) {
    var area;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Area.findOne({
              village: formData.village
            }).exec());

          case 2:
            area = _context.sent;

            if (!(area === null)) {
              _context.next = 14;
              break;
            }

            area = new Area();
            area.longitude = formData.longitude;
            area.latitude = formData.latitude;
            area.village = formData.village;
            area.userId = formData.userId;
            _context.next = 11;
            return (0, _bluebird.resolve)(area.save());

          case 11:
            return _context.abrupt('return', _context.sent);

          case 14:
            return _context.abrupt('return', area);

          case 15:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function create(_x) {
    return _ref.apply(this, arguments);
  };
}();

var getVillage = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(skip, limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            skip = parseInt(skip, 10) || 0;
            limit = parseInt(limit, 10) || 10;
            query = {
              village: { $regex: searchQuery, $options: 'i' }
            };
            _context2.next = 5;
            return (0, _bluebird.resolve)(Area.find(query).limit(limit).skip(skip).sort({
              village: -1
            }).select('village _id').lean().exec());

          case 5:
            return _context2.abrupt('return', _context2.sent);

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function getVillage(_x2, _x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

var getVillageNames = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(villages) {
    var villageObjects;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            villageObjects = [];

            villages.forEach(function (village) {
              villageObjects.push(objectId(village));
            });
            _context3.next = 4;
            return (0, _bluebird.resolve)(Area.find({ "_id": { $in: villageObjects } }).select('village _id').lean().exec());

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function getVillageNames(_x5) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _area = require('../../schemas/area.schema');

var _area2 = _interopRequireDefault(_area);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;

/**
 * Statics
 */

_area2.default.static('create', create).static('getVillage', getVillage).static('getVillageNames', getVillageNames);

var Area = exports.Area = _mongoose2.default.model('Area', _area2.default, 'areas');
//# sourceMappingURL=area.model.js.map
