'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.destroy = exports.update = exports.show = exports.create = exports.index = exports.latest = exports.removeAllFake = exports.createFake = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

/**
 * Actions
 */

/**
 * Create Fake Patient Action
 *
 * Create an active, fake patient and customize him with a form object that
 * contains his name and profile picture. Then return him.
 *
 * @param req
 * @param res
 */
var createFake = exports.createFake = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(req, res) {
    var patientForm, patient;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            patientForm = req.body;
            _context.prev = 1;
            _context.next = 4;
            return (0, _bluebird.resolve)(_patient2.default.createFake(patientForm));

          case 4:
            patient = _context.sent;


            res.json({
              timestamp: Date.now(),
              patient: patient
            });
            _context.next = 11;
            break;

          case 8:
            _context.prev = 8;
            _context.t0 = _context['catch'](1);

            res.status(400).json({
              timestamp: new Date(),
              error: _context.t0.toString()
            });

          case 11:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this, [[1, 8]]);
  }));

  return function createFake(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Remove All Fake Patients Action
 *
 * @param req
 * @param res
 */


var removeAllFake = exports.removeAllFake = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(req, res) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return (0, _bluebird.resolve)(_patient2.default.removeAllFake());

          case 2:

            res.json({
              timestamp: Date.now()
            });

          case 3:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function removeAllFake(_x3, _x4) {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Latest Patients Action
 *
 * Find the latest active patients, limited by the start and limit parameters.
 */


var latest = exports.latest = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(req, res) {
    var start, limit;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            start = parseInt(req.query.start, 10) || 0;
            limit = parseInt(req.query.limit, 10) || 5;
            _context3.t0 = res;
            _context3.t1 = Date.now();
            _context3.next = 6;
            return (0, _bluebird.resolve)(_patient2.default.countActive());

          case 6:
            _context3.t2 = _context3.sent;
            _context3.t3 = start;
            _context3.t4 = limit;
            _context3.next = 11;
            return (0, _bluebird.resolve)(_patient2.default.findLatestActive(start, limit));

          case 11:
            _context3.t5 = _context3.sent;
            _context3.t6 = {
              timestamp: _context3.t1,
              total: _context3.t2,
              start: _context3.t3,
              limit: _context3.t4,
              patients: _context3.t5
            };

            _context3.t0.json.call(_context3.t0, _context3.t6);

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function latest(_x5, _x6) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Patient Counts Action
 */


var index = exports.index = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(req, res) {
    var limit, skip, search, startDate, endDate, query, count, patients;
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            limit = parseInt(req.query.limit) || 20;
            skip = parseInt(req.query.skip) || 0;
            search = req.query.search;
            startDate = req.query.startDate ? (0, _momentTimezone2.default)(req.query.startDate).toDate() : '';
            endDate = req.query.endDate ? (0, _momentTimezone2.default)(req.query.endDate).toDate() : '';
            query = {};


            if (startDate && endDate) {
              query.registered_at = {
                $gte: startDate,
                $lte: endDate
              };
            }

            if (search) {
              query = {
                '$or': [{ fullname: { '$regex': search, '$options': 'i' } }, { serialnumber: { '$regex': search, '$options': 'i' } }, { phone: { '$regex': search, '$options': 'i' } }]
              };
            }

            _context4.prev = 8;
            _context4.next = 11;
            return (0, _bluebird.resolve)(_patient2.default.countActiveAll());

          case 11:
            count = _context4.sent;
            _context4.next = 14;
            return (0, _bluebird.resolve)(_patient2.default.index(query, limit, skip));

          case 14:
            patients = _context4.sent;


            res.json({
              timestamp: Date.now(),
              patients: patients,
              count: count
            });
            _context4.next = 21;
            break;

          case 18:
            _context4.prev = 18;
            _context4.t0 = _context4['catch'](8);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context4.t0.toString()
            });

          case 21:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this, [[8, 18]]);
  }));

  return function index(_x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();

var create = exports.create = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(req, res) {
    var formBody, patient;
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            formBody = req.body;
            _context5.prev = 1;
            patient = new _patient2.default(formBody);
            _context5.next = 5;
            return (0, _bluebird.resolve)(patient.save());

          case 5:
            patient = _context5.sent;


            _patient4.default.emit('patient:create', patient);

            res.json({
              timestamp: new Date(),
              patient: patient
            });
            _context5.next = 13;
            break;

          case 10:
            _context5.prev = 10;
            _context5.t0 = _context5['catch'](1);

            res.status(400).json({
              timestamp: new Date(),
              error: _context5.t0
            });

          case 13:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this, [[1, 10]]);
  }));

  return function create(_x9, _x10) {
    return _ref5.apply(this, arguments);
  };
}();

var show = exports.show = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(req, res) {
    var patientId, patient;
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            patientId = req.params.id;

            if (!patientId) res.status(400).end();

            _context6.prev = 2;
            _context6.next = 5;
            return (0, _bluebird.resolve)(_patient2.default.show(patientId));

          case 5:
            patient = _context6.sent;


            res.json({
              timestamp: Date.now(),
              patient: patient
            });
            _context6.next = 12;
            break;

          case 9:
            _context6.prev = 9;
            _context6.t0 = _context6['catch'](2);

            res.status(400).json({
              timestamp: Date.now(),
              error: _context6.t0
            });

          case 12:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this, [[2, 9]]);
  }));

  return function show(_x11, _x12) {
    return _ref6.apply(this, arguments);
  };
}();

var update = exports.update = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7(req, res) {
    var patientId, formBody, patient;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            patientId = req.params.id;
            formBody = req.body;


            if (!patientId) res.status(400).end();

            _context7.prev = 3;
            _context7.next = 6;
            return (0, _bluebird.resolve)(_patient2.default.findByIdAndUpdate(patientId, formBody));

          case 6:
            patient = _context7.sent;


            _patient4.default.emit('patient:createFake', patient);

            res.json({
              timestamp: new Date(),
              patient: patient
            });
            _context7.next = 14;
            break;

          case 11:
            _context7.prev = 11;
            _context7.t0 = _context7['catch'](3);

            res.status(400).json({
              timestamp: new Date(),
              error: _context7.t0.toString()
            });

          case 14:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this, [[3, 11]]);
  }));

  return function update(_x13, _x14) {
    return _ref7.apply(this, arguments);
  };
}();

var destroy = exports.destroy = function () {
  var _ref8 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee8(req, res) {
    var patientId, formBody, patient;
    return _regenerator2.default.wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            patientId = req.params.id;
            formBody = {
              active: false
            };

            if (!patientId) res.status(400).end();

            _context8.prev = 3;
            _context8.next = 6;
            return (0, _bluebird.resolve)(_patient2.default.findByIdAndUpdate(patientId, formBody));

          case 6:
            patient = _context8.sent;


            res.json({
              timestamp: new Date(),
              patient: patient
            });
            _context8.next = 13;
            break;

          case 10:
            _context8.prev = 10;
            _context8.t0 = _context8['catch'](3);

            res.status(400).json({
              timestamp: new Date(),
              error: _context8.t0
            });

          case 13:
          case 'end':
            return _context8.stop();
        }
      }
    }, _callee8, this, [[3, 10]]);
  }));

  return function destroy(_x15, _x16) {
    return _ref8.apply(this, arguments);
  };
}();

exports.counts = counts;
exports.getVillageName = getVillageName;

var _patient = require('./patient.model');

var _patient2 = _interopRequireDefault(_patient);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _patient3 = require('./patient.events');

var _patient4 = _interopRequireDefault(_patient3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function counts(req, res) {
  _bluebird2.default.all([_patient2.default.countActiveToday(), _patient2.default.countActiveThisWeek(), _patient2.default.countActiveThisMonth(), _patient2.default.countActive()]).spread(function (countToday, countThisWeek, countThisMonth, countTotal) {
    res.json({
      timestamp: Date.now(),
      counts: {
        day: countToday,
        week: countThisWeek,
        month: countThisMonth,
        total: countTotal
      }
    });
  });
}
/**
 * Get the village of patient
 */
function getVillageName(req, res) {
  _patient2.default.getVillageName(req.query.patientId).then(function (reports) {
    var villageName = '';
    if (reports[0] !== undefined) {
      villageName = reports[0].theVillage.village;
    }
    res.json({
      timestamp: Date.now(),
      reports: villageName
    });
  });
}
//# sourceMappingURL=patient.controller.js.map
