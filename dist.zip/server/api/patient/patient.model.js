'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

/**
 * Create Fake Patient
 *
 * Create a fresh active (fake) patient and then customize him with a form object
 * that contains his name and profile picture.
 *
 * @param patientForm
 */
var createFake = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(patientForm) {
    var patient;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _bluebird.resolve)(Patient.create({
              fullname: patientForm.fullname,
              profilepiclink: patientForm.profilepiclink,
              serialnumber: patientForm.serialnumber,
              registered_at: new Date(),
              active: true,
              isFake: true
            }));

          case 2:
            patient = _context.sent;


            _patient2.default.emit('patient:createFake', patient);
            return _context.abrupt('return', patient);

          case 5:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function createFake(_x) {
    return _ref.apply(this, arguments);
  };
}();

/**
 * Remove All Fake Patients
 */


var removeAllFake = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _patient2.default.emit('patient:removeFake');

            _context2.next = 3;
            return (0, _bluebird.resolve)(Patient.remove({
              isFake: true
            }));

          case 3:
            return _context2.abrupt('return', _context2.sent);

          case 4:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function removeAllFake() {
    return _ref2.apply(this, arguments);
  };
}();

/**
 * Count Active Patients
 *
 * Count the number of active patients in the given date range.
 *
 * @param startDate
 * @param endDate
 */


/**
 * Latest Active Patients
 *
 * Returns the latest active patients, with pagination.
 *
 * @param start
 * @param limit
 * @returns {Promise}
 */
var findLatestActive = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(start, limit) {
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            start = start || 0;
            limit = limit || 5;

            _context3.next = 4;
            return (0, _bluebird.resolve)(this.find({
              active: true
            }).skip(start).limit(limit).sort('-registered_at -_id').exec());

          case 4:
            return _context3.abrupt('return', _context3.sent);

          case 5:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findLatestActive(_x2, _x3) {
    return _ref3.apply(this, arguments);
  };
}();

/**
 * Get the patient village
 *
 * @param patientId
 * @returns {Promise}
 */


var getVillageName = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(patientId) {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.aggregate([{
              $match: {
                _id: objectId(patientId)
              }
            }, {
              $lookup: {
                "from": "areas",
                "localField": "village",
                "foreignField": "_id",
                "as": "theVillage"
              }
            }, {
              $unwind: {
                path: "$theVillage"
              }
            }]));

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function getVillageName(_x4) {
    return _ref4.apply(this, arguments);
  };
}();

var index = function () {
  var _ref5 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee5(query, limit, skip) {
    return _regenerator2.default.wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            _context5.next = 2;
            return (0, _bluebird.resolve)(Patient.find(query).limit(limit).skip(skip).sort('-updated_at').exec());

          case 2:
            return _context5.abrupt('return', _context5.sent);

          case 3:
          case 'end':
            return _context5.stop();
        }
      }
    }, _callee5, this);
  }));

  return function index(_x5, _x6, _x7) {
    return _ref5.apply(this, arguments);
  };
}();

var show = function () {
  var _ref6 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee6(id) {
    return _regenerator2.default.wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            _context6.next = 2;
            return (0, _bluebird.resolve)(Patient.findById(id).populate({
              path: 'registeredBy village'
            }).exec());

          case 2:
            return _context6.abrupt('return', _context6.sent);

          case 3:
          case 'end':
            return _context6.stop();
        }
      }
    }, _callee6, this);
  }));

  return function show(_x8) {
    return _ref6.apply(this, arguments);
  };
}();

var countActiveAll = function () {
  var _ref7 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee7() {
    var startDate, endDate;
    return _regenerator2.default.wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            startDate = (0, _momentTimezone2.default)().set('year', 1999).toDate();
            endDate = (0, _momentTimezone2.default)().endOf('day').toDate();
            _context7.next = 4;
            return (0, _bluebird.resolve)(this.countActive(startDate, endDate));

          case 4:
            return _context7.abrupt('return', _context7.sent);

          case 5:
          case 'end':
            return _context7.stop();
        }
      }
    }, _callee7, this);
  }));

  return function countActiveAll() {
    return _ref7.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

var _environment = require('../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

var _patient = require('./patient.events');

var _patient2 = _interopRequireDefault(_patient);

var _patient3 = require('../../schemas/patient.schema');

var _patient4 = _interopRequireDefault(_patient3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var objectId = require('mongoose').Types.ObjectId;


/**
 * Constants
 */
var TIMEZONE = _environment2.default.scheduleTimeZone;

/**
 * Statics
 */
_patient4.default.static('index', index).static('show', show).static('createFake', createFake).static('removeAllFake', removeAllFake).static('countActive', countActive).static('countActiveToday', countActiveToday).static('countActiveThisWeek', countActiveThisWeek).static('countActiveThisMonth', countActiveThisMonth).static('findLatestActive', findLatestActive).static('countActiveAll', countActiveAll).static('getVillageName', getVillageName);function countActive(startDate, endDate) {
  var query = this.count({
    active: true
  });

  if (startDate instanceof Date) query.where('registered_at').gte(startDate);
  if (endDate instanceof Date) query.where('registered_at').lte(endDate);

  return query.exec();
}

/**
 * Count Active Patients today, this week, and this month.
 *
 * Uses Bangladesh timezone.
 */
function countActiveToday() {
  var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('day').toDate();
  var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('day').toDate();

  return this.countActive(startDate, endDate);
}
function countActiveThisWeek() {
  var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('week').toDate();
  var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('week').toDate();

  return this.countActive(startDate, endDate);
}
function countActiveThisMonth() {
  var startDate = _momentTimezone2.default.tz(TIMEZONE).startOf('month').toDate();
  var endDate = _momentTimezone2.default.tz(TIMEZONE).endOf('month').toDate();

  return this.countActive(startDate, endDate);
}var Patient = _mongoose2.default.model('Patient', _patient4.default);

/**
 * Exports
 */
exports.default = Patient;
//# sourceMappingURL=patient.model.js.map
