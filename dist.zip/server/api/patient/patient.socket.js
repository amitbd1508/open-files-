'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _patient = require('./patient.model');

var _patient2 = _interopRequireDefault(_patient);

var _patient3 = require('./patient.events');

var _patient4 = _interopRequireDefault(_patient3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  register(socket);
  create(socket);
  refresh(socket);
  update(socket);
  counts(socket);
}

/**
 * Socket Messages
 */

/**
 * Register Patient Message
 *
 * @param socket
 */
function register(socket) {
  var listener = function listener(patient) {
    _patient2.default.countActive().then(function (totalActive) {
      socket.emit('patient:register', {
        timestamp: Date.now(),
        total: totalActive,
        patient: patient
      });
    });
  };

  _patient4.default.on('patient:createFake', listener);
  _patient4.default.on('patient:register', listener);

  socket.on('disconnect', function () {
    _patient4.default.removeListener('patient:createFake', listener);
    _patient4.default.removeListener('patient:register', listener);
  });
}

function update(socket) {
  var listener = function listener() {
    socket.emit('patient:update', {
      timestamp: Date.now()
    });
  };

  _patient4.default.on('patient:update', listener);

  socket.on('disconnect', function () {
    _patient4.default.removeListener('patient:update', listener);
  });
}

function create(socket) {
  var listener = function listener() {
    socket.emit('patient:create', {
      timestamp: Date.now()
    });
  };

  _patient4.default.on('patient:create', listener);

  socket.on('disconnect', function () {
    _patient4.default.removeListener('patient:create', listener);
  });
}

/**
 * Refresh Patient Message
 *
 * @param socket
 */
function refresh(socket) {
  var listener = function listener() {
    _patient2.default.countActive().then(function (totalActive) {
      socket.emit('patient:refresh', {
        timestamp: Date.now(),
        total: totalActive
      });
    });
  };

  _patient4.default.on('patient:removeFake', listener);
  _patient4.default.on('patient:refresh', listener);

  socket.on('disconnect', function () {
    _patient4.default.removeListener('patient:removeFake', listener);
    _patient4.default.removeListener('patient:refresh', listener);
  });
}

/**
 * Active Patient Counts Message
 *
 * @param socket
 */
function counts(socket) {
  var listener = function listener() {
    _bluebird2.default.all([_patient2.default.countActiveToday(), _patient2.default.countActiveThisWeek(), _patient2.default.countActiveThisMonth(), _patient2.default.countActive()]).spread(function (countToday, countThisWeek, countThisMonth, countTotal) {
      socket.emit('patient:counts', {
        timestamp: Date.now(),
        counts: {
          day: countToday,
          week: countThisWeek,
          month: countThisMonth,
          total: countTotal
        }
      });
    });
  };

  _patient4.default.on('patient:createFake', listener);
  _patient4.default.on('patient:removeFake', listener);
  _patient4.default.on('patient:register', listener);
  _patient4.default.on('patient:refresh', listener);

  socket.on('disconnect', function () {
    _patient4.default.removeListener('patient:createFake', listener);
    _patient4.default.removeListener('patient:removeFake', listener);
    _patient4.default.removeListener('patient:register', listener);
    _patient4.default.removeListener('patient:refresh', listener);
  });
}
//# sourceMappingURL=patient.socket.js.map
