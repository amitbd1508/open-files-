'use strict';

var _express = require('express');

var _user = require('./user.controller');

var controller = _interopRequireWildcard(_user);

var _auth = require('../../auth/auth.service');

var auth = _interopRequireWildcard(_auth);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var router = new _express.Router();

router.get('/', auth.isUserType('admin'), controller.index);
router.delete('/:id', auth.isUserType('admin'), controller.destroy);
router.get('/me', auth.isAuthenticated(), controller.me);
router.put('/:id/password', auth.isAuthenticated(), controller.changePassword);
router.get('/:id', auth.isAuthenticated(), controller.show);
router.post('/', controller.create);
router.put('/:id', auth.isAuthenticated(), controller.update);
router.get('/centers/all', auth.isAuthenticated(), controller.getCenters);
router.get('/mpo/all', auth.isAuthenticated(), controller.getMPOs);
router.get('/te/all', auth.isAuthenticated(), controller.getTEs);
router.get('/availability/email', auth.isAuthenticated(), controller.isEmailAvailable);
router.get('/availability/username', auth.isAuthenticated(), controller.isUsernameAvailable);
router.get('/list/all', auth.isAuthenticated(), controller.getUserList);
router.get('/search/all', auth.isAuthenticated(), controller.searchUser);
module.exports = router;
//# sourceMappingURL=index.js.map
