'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _set = require('babel-runtime/core-js/set');

var _set2 = _interopRequireDefault2(_set);

exports.index = index;
exports.searchUser = searchUser;
exports.getUserList = getUserList;
exports.isUsernameAvailable = isUsernameAvailable;
exports.isEmailAvailable = isEmailAvailable;
exports.create = create;
exports.show = show;
exports.getCenters = getCenters;
exports.getMPOs = getMPOs;
exports.getTEs = getTEs;
exports.destroy = destroy;
exports.changePassword = changePassword;
exports.update = update;
exports.me = me;
exports.authCallback = authCallback;

var _user = require('./user.model');

var _user2 = _interopRequireDefault2(_user);

var _environment3 = require('../../config/environment');

var _environment4 = _interopRequireDefault2(_environment3);

var _jsonwebtoken = require('jsonwebtoken');

var _jsonwebtoken2 = _interopRequireDefault2(_jsonwebtoken);

function _interopRequireDefault2(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function validationError(res, statusCode) {
  statusCode = statusCode || 422;
  return function (err) {
    return res.status(statusCode).json(err);
  };
}

function handleError(res, statusCode) {
  statusCode = statusCode || 500;
  return function (err) {
    return res.status(statusCode).send(err);
  };
}

/**
 * Get list of users
 * restriction: 'admin'
 */

function index(req, res) {
  return _user2.default.find({}, '-salt -password').exec().then(function (users) {
    res.status(200).json(users);
  }).catch(handleError(res));
}

// search user by name
function searchUser(req, res) {
  var searchQuery = req.query.searchTerm;
  return _user2.default.find({ $or: [{ fullname: { $regex: searchQuery, $options: 'i' } }, { usertype: { $regex: searchQuery, $options: 'i' } }, { username: { $regex: searchQuery, $options: 'i' } }, { email: { $regex: searchQuery, $options: 'i' } }, { phone: { $regex: searchQuery, $options: 'i' } }] }, '-salt -password').sort({
    usertype: 1
  }).lean().exec().then(function (users) {
    return res.status(200).json(users);
  }).catch(handleError(res));
}

// get limited userlist
function getUserList(req, res) {
  var skip = parseInt(req.query.skip, 10);
  var limit = parseInt(req.query.limit, 10);
  return _user2.default.find({}, '-salt -password').limit(limit).skip(skip).sort({
    usertype: 1
  }).lean().exec().then(function (users) {
    return res.status(200).json(users);
  }).catch(handleError(res));
}

// Check whether the user is avalable
function isUsernameAvailable(req, res) {
  var username = req.query.username;
  var isUserAvailable = false;
  _user2.default.findOne({ username: username }).exec().then(function (usr) {
    if (usr !== null) {
      isUserAvailable = true;
    }
    res.json({
      user: {
        available: isUserAvailable
      }
    });
  });
}

// Check whether the email is avalable
function isEmailAvailable(req, res) {
  var email = req.query.email;
  var isUserAvailable = false;
  _user2.default.findOne({ email: email }).exec().then(function (usr) {
    if (usr !== null) {
      isUserAvailable = true;
    }
    res.json({
      user: {
        available: isUserAvailable
      }
    });
  });
}

/**
 * Creates a new user
 */
function create(req, res) {
  var newUser = new _user2.default(req.body);
  newUser.provider = 'local';
  newUser.role = 'user';
  if (req.body.profileUrl64 !== undefined) {
    var profilePic = new Buffer(req.body.profileUrl64.replace(/^data:image\/\w+;base64,/, ""), 'base64');

    newUser.save().then(function (user) {
      var token = _jsonwebtoken2.default.sign({ _id: user._id }, _environment4.default.secrets.session, {
        expiresIn: 60 * 60 * 5
      });
      var result = new _awsSdk2.default.S3({
        accessKeyId: _environment2.default.aws.access_key_id,
        secretAccessKey: _environment2.default.aws.secret_access_key,
        region: _environment2.default.aws.s3_region
      }).upload({
        Bucket: _environment2.default.aws.s3_bucket,
        Key: 'awsupload/profilePic/' + user._id + '.' + req.body.profilePicType,
        ACL: 'public-read',
        Body: profilePic
      }).promise();

      result.then(function (proPic) {
        return _user2.default.findById(user._id).exec().then(function (newUserWithProfilePic) {
          newUserWithProfilePic.profile_url = proPic.Location;
          newUserWithProfilePic.save().then(function (updatedUser) {
            res.json({
              token: token,
              user: updatedUser
            });
          }).catch(validationError(res));
        }).catch(validationError(res));
      });
    }).catch(validationError(res));
  } else {
    req.body.profile_url = 'https://projotno-server.s3.ap-south-1.amazonaws.com/profilePic/file-1476949170198.jpeg';
    newUser.save().then(function (user) {
      var token = _jsonwebtoken2.default.sign({ _id: user._id }, _environment4.default.secrets.session, {
        expiresIn: 60 * 60 * 5
      });
      res.json({
        token: token,
        user: user
      });
    }).catch(validationError(res));
  }
}

/**
 * Get a single user
 */
function show(req, res, next) {
  var userId = req.params.id;

  return _user2.default.findById(userId).exec().then(function (user) {
    if (!user) {
      return res.status(404).end();
    }
    res.json(user.profile);
  }).catch(function (err) {
    return next(err);
  });
}

/**
 * Get the centers
 */

function getCenters(req, res) {
  return _user2.default.where({ usertype: 'rmp' }).distinct('center').lean().exec().then(function (centers) {
    return res.json(centers);
  }).catch(function (e) {
    res.json(e);
  });
}

/**
 * Get the MPOs
 */

function getMPOs(req, res) {
  return _user2.default.where({ usertype: 'mpo' }).select('_id fullname').lean().exec().then(function (mpos) {
    return res.json(mpos);
  }).catch(function (e) {
    res.json(e);
  });
}

/**
 * Get the TEs
 */

function getTEs(req, res) {
  return _user2.default.where({ usertype: 'te' }).select('_id fullname').lean().exec().then(function (tes) {
    return res.json(tes);
  }).catch(function (e) {
    res.json(e);
  });
}

/**
 * Deletes a user
 * restriction: 'admin'
 */
function destroy(req, res) {
  return _user2.default.findByIdAndRemove(req.params.id).exec().then(function () {
    res.status(204).end();
  }).catch(handleError(res));
}

/**
 * Change a users password
 */
function changePassword(req, res) {
  var userId = req.user._id;
  var oldPass = String(req.body.oldPassword);
  var newPass = String(req.body.newPassword);

  return _user2.default.findById(userId).exec().then(function (user) {
    if (user.authenticate(oldPass)) {
      user.password = newPass;
      return user.save().then(function () {
        res.status(204).end();
      }).catch(validationError(res));
    } else {
      return res.status(403).end();
    }
  });
}

/**
 * Update a user
 */
function update(req, res) {
  var userId = req.body._id;
  var fullname = req.body.fullname;
  var username = req.body.username;
  var email = req.body.email;
  var phone = req.body.phone;
  var pricing1 = req.body.pricing1;
  var pricing2 = req.body.pricing2;
  var specialized = req.body.specialized;
  var password = req.body.password ? req.body.password : null;
  var identity = req.body.identity;
  var signature_url = req.body.signature_url;
  var profile_url = req.body.profile_url;
  var villageIdSet = new _set2.default();
  var village_id = [];
  var center = req.body.center;
  var is_active = req.body.is_active;

  // make a set for village Ids
  if (req.body.village_id !== undefined && req.body.village_id !== null) {
    req.body.village_id.forEach(function (villageId) {
      villageIdSet.add(villageId);
    });
    villageIdSet.forEach(function (vId) {
      village_id.push(vId);
    });
  }

  if (req.body.profileUrl64 !== undefined && req.body.profileUrl64 !== null) {
    var profilePic = new Buffer(req.body.profileUrl64.replace(/^data:image\/\w+;base64,/, ""), 'base64');
    var result = new _awsSdk2.default.S3({
      accessKeyId: _environment2.default.aws.access_key_id,
      secretAccessKey: _environment2.default.aws.secret_access_key,
      region: _environment2.default.aws.s3_region
    }).upload({
      Bucket: _environment2.default.aws.s3_bucket,
      Key: 'awsupload/profilePic/' + userId + '.' + req.body.profilePicType,
      ACL: 'public-read',
      Body: profilePic
    }).promise();
    result.then(function (profilePic) {
      profile_url = profilePic.Location;
    }).then(function () {
      return _user2.default.findById(userId).exec().then(function (user) {
        user.fullname = fullname;
        user.username = username;
        user.email = email;
        user.phone = phone;
        user.pricing1 = pricing1;
        user.pricing2 = pricing2;
        user.specialized = specialized;
        if (password !== null) {
          user.password = password;
        }
        user.identity = identity;
        user.signature_url = signature_url;
        user.profile_url = profile_url;
        user.village_id = village_id;
        user.center = center;
        user.is_active = is_active;
        user.save().then(function (updatedUser) {
          return res.json(updatedUser);
        }).catch(validationError(res));
      });
    });
  } else {
    return _user2.default.findById(userId).exec().then(function (user) {
      user.fullname = fullname;
      user.username = username;
      user.email = email;
      user.phone = phone;
      user.pricing1 = pricing1;
      user.pricing2 = pricing2;
      user.specialized = specialized;
      if (password !== null) {
        user.password = password;
      }
      user.identity = identity;
      user.signature_url = signature_url;
      user.profile_url = profile_url;
      user.village_id = village_id;
      user.center = center;
      user.is_active = is_active;
      user.save().then(function (updatedUser) {
        return res.json(updatedUser);
      }).catch(validationError(res));
    });
  }
}

/**
 * Get my info
 */
function me(req, res, next) {
  var userId = req.user._id;

  return _user2.default.findOne({ _id: userId }, '-salt -password').exec().then(function (user) {
    // don't ever give out the password or salt
    if (!user) {
      return res.status(401).end();
    }
    res.json(user);
    // Prevent runaway promise warning
    return null;
  }).catch(function (err) {
    return next(err);
  });
}

/**
 * Authentication callback
 */
function authCallback(req, res) {
  res.redirect('/');
}

var _environment = require('../../config/environment');

var _environment2 = _interopRequireDefault(_environment);

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
//# sourceMappingURL=prescription.controller.js.map
//# sourceMappingURL=user.controller.js.map
