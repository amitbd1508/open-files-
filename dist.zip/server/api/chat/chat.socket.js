'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = initialize;

var _chat = require('./chat.model');

var _chat2 = _interopRequireDefault(_chat);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Socket Initialization
 *
 * @param socket
 */
function initialize(socket) {
  message(socket);
}

/**
 * Socket Messages
 */

/**
 * Chat Message Message
 *
 * @param socket
 */
function message(socket) {
  socket.on('chat:message', function (msg) {
    _chat2.default.create(msg.chat);

    socket.emit('chat:message', msg);
    socket.broadcast.emit('chat:message', msg);
  });

  socket.on('disconnect', function () {
    socket.removeAllListeners('chat:message');
  });
}
//# sourceMappingURL=chat.socket.js.map
