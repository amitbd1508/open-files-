'use strict';

/**
 * Imports
 */

var express = require('express');
var controller = require('./chat.controller');

var router = express.Router();

/**
 * Routes
 */
router.get('/', controller.log);

/**
 * Exports
 */
module.exports = router;
//# sourceMappingURL=index.js.map
