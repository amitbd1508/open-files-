'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Chat = undefined;

var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = require('babel-runtime/helpers/createClass');

var _createClass3 = _interopRequireDefault(_createClass2);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Constants
 */
var LIMIT = 50;

/**
 * Model
 */

var Chat = exports.Chat = function () {
  function Chat() {
    (0, _classCallCheck3.default)(this, Chat);
    this.chatMessages = [];
  }

  (0, _createClass3.default)(Chat, [{
    key: 'create',


    /**
     * Create Chat Message
     *
     * @param chatForm
     */
    value: function create(chatForm) {
      this.chatMessages.push(chatForm);
      if (this.chatMessages.length > LIMIT) this.chatMessages.shift();

      return _bluebird2.default.resolve(this.chatMessages);
    }

    /**
     * Get recent Chat Messages
     */

  }, {
    key: 'findRecent',
    value: function findRecent() {
      return _bluebird2.default.resolve(this.chatMessages);
    }
  }]);
  return Chat;
}();

/**
 * Exports
 */


exports.default = new Chat();
//# sourceMappingURL=chat.model.js.map
