'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.log = log;

var _chat = require('./chat.model');

var _chat2 = _interopRequireDefault(_chat);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Actions
 */

/**
 * Get Chat Log
 *
 * @param req
 * @param res
 */
function log(req, res) {
  _chat2.default.findRecent().then(function (chats) {
    res.json({
      timestamp: Date.now(),
      chats: chats
    });
  });
}
//# sourceMappingURL=chat.controller.js.map
