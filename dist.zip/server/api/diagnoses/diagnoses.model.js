'use strict';

/**
 * Imports
 */

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.Diagnoses = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _bluebird = require('bluebird');

var findDiagnoses = function () {
  var _ref = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee(skip, limit, searchQuery) {
    var query;
    return _regenerator2.default.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            skip = parseInt(skip) || 0;
            limit = parseInt(limit);
            query = {
              primaryTerm: { '$regex': searchQuery, '$options': 'i' },
              isIgnore: false
            };
            _context.next = 5;
            return (0, _bluebird.resolve)(Diagnoses.find(query).limit(limit).skip(skip).sort({
              SNOMEDConceptId: 1
            }).select('primaryTerm SNOMEDConceptId').lean().exec());

          case 5:
            return _context.abrupt('return', _context.sent);

          case 6:
          case 'end':
            return _context.stop();
        }
      }
    }, _callee, this);
  }));

  return function findDiagnoses(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();

var index = function () {
  var _ref2 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(skip, limit) {
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            skip = parseInt(skip) || 0;
            limit = parseInt(limit) || 20;

            _context2.next = 4;
            return (0, _bluebird.resolve)(Diagnoses.find({
              isIgnore: false
            }).populate({
              path: 'userId',
              select: 'fullname'
            }).limit(limit).skip(skip).sort('isApproved -created_at').exec());

          case 4:
            return _context2.abrupt('return', _context2.sent);

          case 5:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, this);
  }));

  return function index(_x4, _x5) {
    return _ref2.apply(this, arguments);
  };
}();

var findByIdAndUpdateWithApprove = function () {
  var _ref3 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(diagnosisId, formData) {
    var diagnosis;
    return _regenerator2.default.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return (0, _bluebird.resolve)(Diagnoses.findById(diagnosisId).exec());

          case 2:
            diagnosis = _context3.sent;


            diagnosis.SNOMEDConceptId = formData.SNOMEDConceptId;
            diagnosis.primaryTerm = formData.primaryTerm;
            diagnosis.system = formData.system;
            diagnosis.note = formData.note;
            diagnosis.isApproved = true;
            diagnosis.isPrimary = formData.isPrimary;
            diagnosis.isIgnore = formData.isIgnore;
            diagnosis.advice = formData.advice;

            _context3.next = 13;
            return (0, _bluebird.resolve)(diagnosis.save(function (err, callback) {
              if (err) {
                return err;
              } else {
                if (formData.synonyms) {
                  formData.synonyms.forEach(function (value) {
                    var diagnosis = new Diagnoses();
                    diagnosis.primaryTerm = value;
                    diagnosis.isApproved = true;
                    diagnosis.isPrimary = false;
                    diagnosis.isIgnore = formData.isIgnore;
                    diagnosis.save();
                  });
                } else {
                  return callback;
                }
              }
            }));

          case 13:
            return _context3.abrupt('return', _context3.sent);

          case 14:
          case 'end':
            return _context3.stop();
        }
      }
    }, _callee3, this);
  }));

  return function findByIdAndUpdateWithApprove(_x6, _x7) {
    return _ref3.apply(this, arguments);
  };
}();

var countPendingApproval = function () {
  var _ref4 = (0, _bluebird.coroutine)( /*#__PURE__*/_regenerator2.default.mark(function _callee4() {
    return _regenerator2.default.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            _context4.next = 2;
            return (0, _bluebird.resolve)(this.count({
              isApproved: false
            }).exec());

          case 2:
            return _context4.abrupt('return', _context4.sent);

          case 3:
          case 'end':
            return _context4.stop();
        }
      }
    }, _callee4, this);
  }));

  return function countPendingApproval() {
    return _ref4.apply(this, arguments);
  };
}();

/**
 * Model
 */


var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _diagnosis = require('../../schemas/diagnosis.schema');

var _diagnosis2 = _interopRequireDefault(_diagnosis);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Statics
 */
_diagnosis2.default.static('index', index).static('findDiagnoses', findDiagnoses).static('countPendingApproval', countPendingApproval).static('findByIdAndUpdateWithApprove', findByIdAndUpdateWithApprove);

var Diagnoses = exports.Diagnoses = _mongoose2.default.model('Diagnoses', _diagnosis2.default, 'diagnoses');
//# sourceMappingURL=diagnoses.model.js.map
