'use strict';

var _momentTimezone = require('moment-timezone');

var _momentTimezone2 = _interopRequireDefault(_momentTimezone);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports = module.exports = {
  unauthorizedAccess: {
    timestamp: (0, _momentTimezone2.default)(),
    success: false,
    message: 'No Token Found, Unauthorized Access'
  },
  sessionTimeOut: {
    timestamp: (0, _momentTimezone2.default)(),
    success: false,
    message: 'Session Expired, Please login again'
  }
};
//# sourceMappingURL=auth.responses.js.map
