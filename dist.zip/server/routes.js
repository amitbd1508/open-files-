/**
 * Main application routes
 */

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (app) {
  // Insert routes below
  app.use('/api/things', require('./api/thing'));
  app.use('/api/users', require('./api/user'));
  app.use('/api/user-management', require('./api/user-management'));

  app.use('/api/elearning/content/systems', require('./api/elearning/content/system'));
  app.use('/api/elearning/content/diseases', require('./api/elearning/content/disease'));
  app.use('/api/elearning/content/cases', require('./api/elearning/content/case'));
  app.use('/api/elearning/content/levels', require('./api/elearning/content/level'));
  app.use('/api/elearning/content/rugies', require('./api/elearning/content/rugi'));
  app.use('/api/elearning/content/quizzes', require('./api/elearning/content/quiz'));
  app.use('/api/elearning/content/health-tips', require('./api/elearning/content/healthTips'));

  app.use('/api/elearning/users', require('./api/elearning/user'));
  app.use('/api/elearning/points', require('./api/elearning/point'));
  app.use('/api/elearning/firebase', require('./api/elearning/firebase'));
  app.use('/api/elearning/firebase-admin', require('./api/elearning/firebase-admin'));
  app.use('/api/elearning/typeform', require('./api/elearning/typeform'));
  app.use('/api/elearning/home-sliders', require('./api/elearning/home-slider'));
  app.use('/api/elearning/security-question', require('./api/elearning/security-question'));
  app.use('/api/elearning/prescription-collect', require('./api/elearning/prescription-collect'));
  app.use('/api/elearning/patient-referral', require('./api/elearning/patient-referral'));
  app.use('/api/elearning/prices', require('./api/elearning/price'));
  app.use('/api/elearning/wallet', require('./api/elearning/wallet'));
  app.use('/api/elearning/products', require('./api/elearning/products'));
  app.use('/api/elearning/courses/chapters', require('./api/elearning/courses/chapter'));
  app.use('/api/elearning/courses/lessons', require('./api/elearning/courses/lesson'));
  app.use('/api/elearning/companies', require('./api/elearning/company'));
  app.use('/api/elearning/user-groups', require('./api/elearning/user-group'));
  app.use('/api/elearning/users-security-question', require('./api/elearning/users-security-question'));
  app.use('/api/elearning/loading-image', require('./api/elearning/loading-image'));

  app.use('/api/user-pickers', require('./api/user-picker'));
  app.use('/api/chat', require('./api/chat'));
  app.use('/api/doctors', require('./api/doctor'));
  app.use('/api/patients', require('./api/patient'));
  app.use('/api/patients-history', require('./api/patient-history'));
  app.use('/api/patients-case-history', require('./api/patient-case-history'));
  app.use('/api/prescriptions', require('./api/prescription'));
  app.use('/api/diagnoses', require('./api/diagnoses'));
  app.use('/api/doctor-schedule', require('./api/doctor-schedule'));
  app.use('/api/appointments', require('./api/appointment'));
  app.use('/api/appointments-transfer', require('./api/appointment-transfer'));
  app.use('/api/medicines', require('./api/medicine'));
  app.use('/api/survey', require('./api/survey'));
  app.use('/api/finance', require('./api/finance'));
  app.use('/api/care', require('./api/care'));
  app.use('/api/rmps', require('./api/rmp'));
  app.use('/api/meta', require('./api/meta'));
  app.use('/api/dashboard', require('./api/dashboard'));
  app.use('/api/symptoms', require('./api/encoded-symptoms'));
  app.use('/api/situation', require('./api/situation'));
  app.use('/api/investigation', require('./api/investigation'));
  app.use('/api/advice', require('./api/advice'));
  app.use('/api/fee', require('./api/fee'));
  app.use('/api/rmp-finding', require('./api/rmp-finding'));
  app.use('/api/system-feedback', require('./api/system-feedback'));
  app.use('/api/area', require('./api/area'));
  app.use('/api/service-duration', require('./api/service-duration'));
  app.use('/api/score', require('./api/score'));
  app.use('/api/transaction', require('./api/transaction'));
  app.use('/api/mobile', require('./api/mobile'));
  app.use('/api/feedback', require('./api/feedback'));
  app.use('/api/user-logs', require('./api/user-log-sign-in-out'));
  app.use('/api/events', require('./api/events'));

  app.use('/auth', require('./auth').default);

  // All undefined asset or api routes should return a 404
  app.route('/:url(api|auth|components|app|bower_components|assets)/*').get(_errors2.default[404]);

  // All other routes should redirect to the index.html
  app.route('/*').get(function (req, res) {
    res.sendFile(_path2.default.resolve(app.get('appPath') + '/index.html'));
  });
};

var _errors = require('./components/errors');

var _errors2 = _interopRequireDefault(_errors);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
//# sourceMappingURL=routes.js.map
