'use strict';
/*eslint no-process-env:0*/

// Test specific configuration
// ===========================

module.exports = {
  // MongoDB connection options
  mongo: {
    uri: process.env.MONGODB_URI || 'mongodb://localhost/projotno-dashboard-test'
  },
  sequelize: {
    uri: 'sqlite://',
    options: {
      logging: false,
      storage: 'test.sqlite',
      define: {
        timestamps: false
      }
    }
  },
  FIREBASE: {
    client_email: process.env.FIREBASE_CLIENT_EMAIL || 'firebase-adminsdk-3msg8@projotno-elearning-app.iam.gserviceaccount.com'
  }
};
//# sourceMappingURL=test.js.map
