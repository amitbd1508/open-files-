'use strict';

exports = module.exports = {
  // List of user roles
  userRoles: ['guest', 'doctor', 'rmp', 'fieldstaff', 'mpo', 'admin', 'cca', 'te'],
  // userRoles: ['guest', 'user', 'admin'],

  // Schedule Time Zone
  scheduleTimeZone: 'Asia/Dhaka',
  // List of Schedule Hours
  scheduleHours: [
  // (standard hours)
  '10 am', '11 am', '12 pm', '01 pm', '02 pm', '03 pm', '04 pm', '05 pm',
  // (extended hours, useful for development work at night)
  '06 pm', '07 pm', '08 pm', '09 pm', '10 pm', '11 pm'],
  // List of Schedule Days
  scheduleDays: [
  // (standard days)
  'sun', 'mon', 'tue', 'wed', 'thu',
  // (extended days, useful for development work in the weekends)
  'fri', 'sat'],
  // List of Schedule Durations (in minutes)
  scheduleDurations: [
  // (standard durations)
  10, 12, 15, 20, 30],

  expiresData: {
    'Days': [0, 1, 2, 3, 4, 5, 6, 7],
    'Weeks': [0, 1, 2, 3, 4],
    'Hours': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
    'Minutes': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 50]
  },

  NotificationPriorities: ['normal', 'high'],

  eLearningPages: {
    homePage: 'HomePage',
    profilePage: 'ProfilePage',
    leaderBoardPage: 'LeaderBoardPage',
    weeklyQuizPage: 'WeeklyQuizPage',
    weeklyQuizResultPage: 'WeeklyQuizResultPage',
    systemPage: 'SystemPage',
    systemPageDiseasesTab: 'diseases',
    systemPageCasesTab: 'cases',
    learnPage: 'LearnPage',
    diseasePage: 'DiseasePage',
    levelPage: 'LevelPage',
    practicalPage: 'PracticalPage',
    casePage: 'CasePage',
    rugiPage: 'RugiPage',
    newsPage: 'NewsPage',
    healthTipPage: 'HealthTipPage',
    productPage: 'ProductPage',
    courseCompanyPage: 'CoursePage',
    chapterPage: 'ChapterPage',
    lessonPage: 'LessonPage',
    referralPage: 'ReferralPage'
  },

  difficultyMood: {
    1: 'সহজ',
    2: 'কিছুটা কঠিন',
    3: 'কঠিন'
  },

  SERVICE_CATEGORY: {
    'prescription_collect': 'Prescription Collect',
    'patient_identification': 'Patient Identification',
    'referral_cataract_patient': 'Cataract Patient',
    'referral_srhr': 'Sexual and reproductive health and rights',
    'referral_fistula': 'Fistula',
    'partners_product': 'Partners Product',
    'wallet': 'Virtual Wallet',
    'course': 'Courses'
  },

  CASHOUT_TYPE: {
    'bKash': 'bKash',
    'flexi': 'Flexi',
    'bank_transfer': 'Bank Transfer',
    'cash': 'Hard Cash',
    'rocket': 'Rocket'
  }
};
//# sourceMappingURL=shared.js.map
