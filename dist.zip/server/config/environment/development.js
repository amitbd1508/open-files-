'use strict';
/*eslint no-process-env:0*/

// Development specific configuration
// ==================================

module.exports = {

  // MongoDB connection options
  mongo: {
    uri: process.env.MONGODB_URI || 'mongodb://localhost/projotno-telemedicine-dashboard',
    options: {
      server: {
        socketOptions: {
          keepAlive: 300000,
          connectTimeoutMS: 60000
        }
      }
    }
  },

  // Seed database on startup
  seedDB: false

};
//# sourceMappingURL=development.js.map
