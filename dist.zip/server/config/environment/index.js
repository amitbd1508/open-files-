'use strict';
/*eslint no-process-env:0*/

var path = require('path');
var _ = require('lodash');

/*function requiredProcessEnv(name) {
  if(!process.env[name]) {
    throw new Error('You must set the ' + name + ' environment variable');
  }
  return process.env[name];
}*/

// All configurations will extend these options
// ============================================
var all = {
  env: process.env.NODE_ENV,

  // Root path of server
  root: path.normalize(__dirname + '/../../..'),

  // Browser-sync port
  browserSyncPort: process.env.BROWSER_SYNC_PORT || 3000,

  // Server port
  port: process.env.PORT || 9000,

  // Server IP
  ip: process.env.IP || '0.0.0.0',

  // Should we populate the DB with sample data?
  seedDB: false,

  // Secret for session, you will want to change this and make it an environment variable
  secrets: {
    session: 'projotno-dashboard-secret'
  },

  // MongoDB connection options
  mongo: {
    options: {
      db: {
        safe: true
      }
    }
  },

  // AWS credentials
  aws: {
    access_key_id: process.env.AWS_ACCESS_KEY_ID || '',
    secret_access_key: process.env.AWS_SECRET_ACCESS_KEY || '',
    s3_region: process.env.AWS_S3_REGION || 'ap-south-1',
    s3_bucket: process.env.S3_BUCKET || 'projotno-server-dev',
    signatureVersion: 'v4'
  },

  // Firebase config
  firebase: {
    appDomain: process.env.FIREBASE_APP_DOMAIN || '',
    appId: process.env.FIREBASE_APP_ID || '',
    dynamicLink: {
      root: process.env.FIREBASE_DYNAMIC_LINK_ROOT || '',
      install: process.env.FIREBASE_DYNAMIC_LINK_INSTALL || '',
      desktop: process.env.FIREBASE_DYNAMIC_LINK_DESKTOP || ''
    }
  },

  GOOGLE_JWT_KEY: {
    'type': 'service_account',
    'project_id': 'noble-hangar-168404',
    'private_key_id': '2e2b97d7133258d1954a3bdd519e2972fca7e554',
    'private_key': '-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDXyTkLPjiLsBrC\nxtQgopkfN8WSSHl3w+R6jsWkwMSnlzvrSHvZ8FQXIF2vF+4U2uDQmlOy2HSWSVYw\nVWL4tCaApaGv098oi4GJR5Oif2r/NR4n1FPxGoyQojKvTvieGmO8RMw+1eQtjtGv\nzT7YtvY/LTtNd1Ic05nMPP1iPnL8yn2k0Akuot6RlcihunK5bWNKv8fewD2O1DaW\ntNvpFTQzuxCef+2g+SXofQDzkIcI/4amVHAtnI3kFR53R3aC+uuveixgqFDfAA4s\npWAF0nvTuMMzay56dFzNgQo6RErjgIkEXtKP1Wj2KctzJJ/yi0XzxCgZ9opZB4By\nayuAZp2VAgMBAAECgf9VRgUaQacW4gEGoowxrrp+xmDNQ4FnqCzM7J7Y/KoPkImd\nRoerGHjNVX0Fie9hTnMz/HNsZHMDm6JJIh/P02FjyrtFQJ/E5gcgDlPJY5EPnsN2\npJyHgHZhXGJV5QoFcL2j04w4nfi4suJ/wXGUiA5yk5gGhPYYw4YuWpZyEeZe/uw3\nVZ8CULcE1rQ8EfLqiba8sz6JMhaR9SObYUqH9BGZWuzwhPHw0azGIiBiY7Adhc5N\nUN51ojLbUPFNcJdPBg67/P+9vWrqNDqGdFNmM9F6eaLPLodOqmDkNsnznK2HxONX\ncTCpRZpOtdoE0+veKOwmQlDJFQMCMD087dNAbb8CgYEA+ceH+5EhXFoAuh4SXeOh\nzKrvMp1JePuc3mejlldncJCuZUJNbU98a56N8GbF9yWShhOvv6/lrQdrYJAk+UD+\nIVk4g9aahPN4MHsRouqnPuy++x93RznNeQYMjaZ54lXDgi0MgV0G+Ow1UzE7KNel\nTTx5m5D7x9AMrKghdUGtpMMCgYEA3Sj3fVov93XddGQs44aKT38i3uK5FvyJei6Y\n6QKCflZ78rumxgHzyhRvhwQa7sTy5S5hnuygjB2TDbv+ERVp8HwZAIZ/RCXYemzK\nhWJfZ+JwALc1QziRwQ07GDROFl/m/HBsYqZ2C+JcqQWR5K+RuzOrN6bCwk5FsWSk\npi7lrscCgYEAh/iSkeOjYX6tPqP4I5wzDBNROyBcSrvN3VRVvRW/fYuFJCI/u+21\nMXCSm/eWdL/DT7GPzq2WPeb4EQzm07kJnmXPWhWM8CsJlnqoUyOh/6MpI9MxP1i7\n/dHJK6MgXpGJaGfVkuZtUTxkmvEF32nk1nLBUGpQZalf/O1ZqVcji7kCgYEAwhsi\nnLJ7RwX7yBvkCg4bdopvYJA9Qx+Cyen76wZ44cmmH/Ty+vbbsZEeEbJYsRfK17tN\nkt68Sj3qwzMsWnIg+SDyELP7HyTYSxsQ5ODiO5tSEk66QLV1t6qVIzlFD/48DXPe\nrPbMxMF38iEhW0V88oD21XFXnpJ0OK3MlM60aCECgYBk6W9KJ45+Cxks7OPAD0bv\n+k1+ma0OdCGmXeBOErSD3dgziNbTdNEOH65DgoULGxhfirAdKe9N689YJI+cA+gv\n61tKruvIJCbZu6brkONg/Gd1Lr/MRfkxJEUOCFCHBZmu1vEQrle+zZ0utMvZ/RjI\nVXWex2lXWohzYTFrxS8wkA==\n-----END PRIVATE KEY-----\n',
    'client_email': 'callcenter@noble-hangar-168404.iam.gserviceaccount.com',
    'client_id': '115867060936951965111',
    'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
    'token_uri': 'https://accounts.google.com/o/oauth2/token',
    'auth_provider_x509_cert_url': 'https://www.googleapis.com/oauth2/v1/certs',
    'client_x509_cert_url': 'https://www.googleapis.com/robot/v1/metadata/x509/callcenter%40noble-hangar-168404.iam.gserviceaccount.com'
  },

  GOOGLE_SHEET_IDS: {
    pss: '1kWYaEtjhzrpqiEhaO3frovmqZeFiTsDCnckcFS0SOi8',
    pos: '1IlBAYhhbRz9vsbpft8rZDOLca4IMGJaCIr7Vjqkme6g',
    rps: '1A0czo26HmjJgX4zcmQpNmNtAJ9drDD8jZbwPBBuc7kg',
    fps: '1ArQ-Dj-gmmzYAWPo4aibdl6IzANb-1A0rkCKurPD7xY'
  },

  GOOGLE_API_SCOPES: ['https://www.googleapis.com/auth/spreadsheets.readonly'],

  FIREBASE: {
    'type': process.env.FIREBASE_ACCOUNT_TYPE || '',
    'project_id': process.env.FIREBASE_PROJECT_ID || '',
    'private_key_id': process.env.FIREBASE_PRIVATE_KEY_ID || '',
    'private_key': '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDWZM8p8AQ3jZ4n\ntQNmGs/X2rbslh/JDSQOt+aizj0L36InvXBlF/kuowR13H6BvkrB95+Wl7TrUIbJ\n53vLsBjOy9jLpTb7XdsRasGqqx++qbensgIxRjSRzM2RCJ+R/h9m4numLrFw7Gpp\nhPHw/XXwh77fOpgvLkhEbJbGbBXRACgQGXNmYxAvlfYQag7Xh3Zxnik9Ob5PokaO\nluziviNDQ91G0qIJm6+cBwuX7XLmOHET5KmNnk2WVIMtcO0/Dg7lzbJ01znpiFWd\nYYOKmZB4gZYoygMBeHoxqI1XXlVxvi8IEcXFqHSHdw7ljojndheM1BQ387uQLB+U\nuN29iPHpAgMBAAECggEAHP2YvdUE3PY7cqcZhI8Pl+KtZaSPO8KZI5xehZlZy+c7\nqCAHuMPbICFPExjzyluPBFeVrulov4EuGNNCfDKdyCjsce0vWCJC40IKWie1rTSJ\n7xU1ErCpnyWQjpIZ8cXpPSJXEguyVtDBOu+NP8cmUZYpi0oDFi4t+4KriL1I3e/l\n8uIxlE1Ioyr8CfddRxYgARs7UCwVvyYt0IBUBaA3D8XXwKPvxu/ACjlVo5VmC9N/\nKXBNkYp2SK04jf4yOUbfxsLVcf1UjEjOEhObqNIenjAViBEUV++MpR+GOTJcfiwG\n4MH1AIE4+wx7esVtQ0W3/Mj/om696SkbEOjSVndU4QKBgQD8OCvpWvnyYHWH7Oh2\n9dHqikMe8eTJ0ZKFf9D7PLXraYRdAOQFXLjdxN4JlkM7wNCoCSGMuqtVSODM9+A1\nqKBY5DEuQbwLzMyXWFiChp/mepYWXADx5EuHZmTLko82qNAzSeQQVXpW57/pltsJ\nLjI2H1P63iixq3ax0+R83sZSfQKBgQDZm33KGjvaBreIvtJxKNjfhqmo2G9rEYFA\n846jbEAf0Q5DBJkJF+YG4OJpOTbZkslH1KSFSQozUMJsVohy92aTAVzXt9ml4/Wf\nkNhOtc/3hEij56IOma7sxBiAosNJD4Pvs/xvDiE/LuWU1ZQ95eWORnlTxwjKOnmR\nSMbhf1Ns3QKBgQCT0Der4u1o5q76ohT64sXLNoxvrkPvIytDoczP8JyNAqHX/5Wi\nrtyI279kzvNIKZAfanqHBz8yFCvq87oquFCAx/sqqMuT/spISDZXCJ7dbCpZoEHN\ngYXiLFgWFiZoWjbqV/uYtv+jvt3x/78Oekxi+6kz9M7UkTBWt1/I7qY74QKBgEcD\nSjKJCx0kcgKLG0vYY6XWYUl7kCilpsOWd+b27Zo0c+4E8xgXl3aJLvndtPudvlfV\nmfbxFgYXBcurFY5HFE9G85BmK/3J/Z8b+qr9BCgnIDl03tra5k3X1JMuCoKuMIUp\n/GgVeV4QJNXEOUNV4erjLrbbThAIsyFpWZW/Im91AoGAdYCN3zp+q9QOiOybxGPy\nG2jUUZXysukI3rfOqtdxaOl1onzgYcHcNZCTCl+bCyxvSZFZp4pS+zNPxBCaSm0/\nV1V9vOr7U5u3WCvt+huWkQL6YxXi4OsYZGG2pLnwUaAx3cedpiWQYaMs3KYfcAw9\nnLUDVmame5YekrGYWlGNTiY=\n-----END PRIVATE KEY-----\n',
    'client_email': process.env.FIREBASE_CLIENT_EMAIL || '',
    'client_id': process.env.FIREBASE_CLIENT_ID || '',
    'auth_uri': process.env.FIREBASE_AUTH_URL || '',
    'token_uri': process.env.FIREBASE_TOKEN_URL || '',
    'auth_provider_x509_cert_url': process.env.FIREBASE_AUTH_PROVIDER_X509_CERT_URL || '',
    'client_x509_cert_url': process.env.FIREBASE_CLIENT_X509_CERT_URL || ''
  },
  FIREBASE_DATABASE_URL: process.env.FIREBASE_DATABASE_URL || '',

  FCM_GOOGLE_API: process.env.FCM_GOOGLE_API || '',
  FCM_GOOGLE_API_AUTHORIZATION_KEY: process.env.FCM_GOOGLE_API_AUTHORIZATION_KEY || '',

  userType: ['doctor', 'rmp', 'fieldstaff', 'mpo', 'admin', 'cca', 'te', 'ELearning']
};

// Export the config object based on the NODE_ENV
// ==============================================
module.exports = _.merge(all, require('./shared'), require('./' + process.env.NODE_ENV + '.js') || {});
//# sourceMappingURL=index.js.map
