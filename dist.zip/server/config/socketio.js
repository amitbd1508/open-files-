/**
 * Socket.io configuration
 */
'use strict';

// import config from './environment';

// When the user disconnects.. perform this

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

exports.default = function (socketio) {
  // socket.io (v1.x.x) is powered by debug.
  // In order to see all the debug output, set DEBUG (in server/config/local.env.js) to including the desired scope.
  //
  // ex: DEBUG: "http*,socket.io:socket"

  // We can authenticate socket.io users and access their token through socket.decoded_token
  //
  // 1. You will need to send the token in `client/components/socket/socket.service.js`
  //
  // 2. Require authentication here:
  // socketio.use(require('socketio-jwt').authorize({
  //   secret: config.secrets.session,
  //   handshake: true
  // }));

  socketio.on('connection', function (socket) {
    socket.address = socket.request.connection.remoteAddress + ':' + socket.request.connection.remotePort;

    socket.connectedAt = new Date();

    socket.log = function () {
      var _console;

      for (var _len = arguments.length, data = Array(_len), _key = 0; _key < _len; _key++) {
        data[_key] = arguments[_key];
      }

      (_console = console).log.apply(_console, ['SocketIO ' + socket.nsp.name + ' [' + socket.address + ']'].concat(data));
    };

    // Call onDisconnect.
    socket.on('disconnect', function () {
      onDisconnect(socket);
      socket.log('DISCONNECTED');
    });

    // Call onConnect.
    onConnect(socket);
    socket.log('CONNECTED');
  });
};

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function onDisconnect() /*socket*/{
  console.log('Socket Got disconnect!');
}

// When the user connects.. perform this
function onConnect(socket) {
  // When the client emits 'info', this listens and executes
  socket.on('info', function (data) {
    socket.log((0, _stringify2.default)(data, null, 2));
  });

  // Insert sockets below
  // require('../api/thing/thing.socket').register(socket);
  require('../api/appointment-transfer/appointment-transfer.socket').initialize(socket);
  require('../api/patient/patient.socket').initialize(socket);
  require('../api/chat/chat.socket').initialize(socket);
  require('../api/dashboard/dashboard.socket').initialize(socket);
  require('../api/doctor-schedule/doctor-schedule.socket').initialize(socket);
  require('../api/prescription/prescription.socket').initialize(socket);
  require('../api/investigation/investigation.socket').initialize(socket);
  require('../api/advice/advice.socket').initialize(socket);
  require('../api/survey/survey.socket').initialize(socket);
  require('../api/rmp-finding/rmp-finding.socket').initialize(socket);
  require('../api/situation/situation.socket').initialize(socket);
  require('../api/user-log-sign-in-out/user-log-sign-in-out.socket').initialize(socket);
  require('../api/events/event.socket').initialize(socket);
  require('../api/feedback/feedback.socket').initialize(socket);
  require('../api/mobile/mobile.socket').initialize(socket);

  require('../api/elearning/user/user.socket').initialize(socket);
  require('../api/elearning/content/system/system.socket').initialize(socket);
  require('../api/elearning/content/disease/disease.socket').initialize(socket);
  require('../api/elearning/content/case/case.socket').initialize(socket);
  require('../api/elearning/content/level/levelsocket').initialize(socket);
  require('../api/elearning/content/rugi/rugi.socket').initialize(socket);
  require('../api/elearning/content/quiz/quiz.socket').initialize(socket);
  require('../api/elearning/firebase-admin/firebase-admin.socket').initialize(socket);
  require('../api/elearning/typeform/typeform.socket').initialize(socket);
  require('../api/elearning/home-slider/home-slider.socket').initialize(socket);
  require('../api/elearning/content/healthTips/health-tips.socket').initialize(socket);
  require('../api/elearning/security-question/security-question.socket').initialize(socket);
  require('../api/elearning/price/price.socket').initialize(socket);
  require('../api/elearning/user-group/user-group.socket').initialize(socket);
  require('../api/elearning/prescription-collect/prescription-collect.socket').initialize(socket);
  require('../api/elearning/patient-referral/patient-referral.socket').initialize(socket);
  require('../api/elearning/wallet/wallet.socket').initialize(socket);
  require('../api/elearning/products/product.socket').initialize(socket);
  require('../api/elearning/courses/chapter/chapter.socket').initialize(socket);
  require('../api/elearning/courses/lesson/lesson.socket').initialize(socket);
  require('../api/elearning/company/company.socket').initialize(socket);
  require('../api/elearning/users-security-question/users-security-question.socket').initialize(socket);
  require('../api/elearning/loading-image/loading-image.socket').initialize(socket);
}
//# sourceMappingURL=socketio.js.map
